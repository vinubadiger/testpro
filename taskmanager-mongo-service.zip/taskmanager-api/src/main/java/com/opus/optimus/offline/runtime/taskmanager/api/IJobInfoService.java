package com.opus.optimus.offline.runtime.taskmanager.api;

import java.util.List;

import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;

public interface IJobInfoService {
	JobInfo save(JobInfo jobInfo);

	JobInfo findById(String jobId);

	JobInfo updateStatusAndGet(String jobId, JobStatus status) throws InvalidJobStatusException;

	JobInfo updateStatus(String jobId, JobStatus status);
	
	List<JobInfo> findByStatus(JobStatus status);

	void deleteById(String jobId);
}
