package com.opus.optimus.offline.runtime.taskmanager.exception;

public class InvalidJobIdException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String jobId;

    public InvalidJobIdException(String jobId) {
        this.jobId = jobId;
    }

    public String getJobId() {
        return jobId;
    }
}
