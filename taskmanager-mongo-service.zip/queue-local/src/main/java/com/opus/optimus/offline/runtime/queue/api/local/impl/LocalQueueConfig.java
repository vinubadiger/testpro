package com.opus.optimus.offline.runtime.queue.api.local.impl;

import com.opus.optimus.offline.runtime.workflow.api.IQueueConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LocalQueueConfig implements IQueueConfig {
    int maxQueueSize;
    long pollTimeoutInMs;
}
