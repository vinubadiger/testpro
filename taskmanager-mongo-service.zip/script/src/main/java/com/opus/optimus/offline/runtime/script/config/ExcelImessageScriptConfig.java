package com.opus.optimus.offline.runtime.script.config;

/**
 * The Class ExcelImessageScriptConfig.
 */
public class ExcelImessageScriptConfig extends ExcelScriptConfig {
}
