package com.opus.optimus.offline.runtime.script.excel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.script.code.IValueProvider;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.config.RecordType;
import com.opusconsulting.pegasus.formula.exception.FormulaExceptionCodes;
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException;

/**
 * The Class RawTextValueEvaluatorScript.
 */
@Component("excel.RawtextValueEvaluatorScript")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class RawTextValueEvaluatorScript extends ExcelFormulaEvaluatorScript<String, Object> {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(RawTextValueEvaluatorScript.class);

	/**
	 * Instantiates a new raw text value evaluator script.
	 *
	 * @param config the configuration 
	 */
	public RawTextValueEvaluatorScript(ExcelScriptConfig config) {
		super(config);
		config.setRecordType(RecordType.RAWTEXT);
	}

	@Override
	public Object execute(String data) {
		if (getFormulaCodeInstance() == null) {
			logger.error("Error while compiling formula. Formula Text: {}", getExcelScriptConfig().getFormulaText());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_COMPILATION_EXCEPTION,
					"Error while compiling formula. Formula Text:" + getExcelScriptConfig().getFormulaText(), null);
		}
		if (!IValueProvider.class.isAssignableFrom(getFormulaCodeInstance().getClass())) {
			return false;
		}
		return ((IValueProvider) getFormulaCodeInstance()).get(data);
	}

}
