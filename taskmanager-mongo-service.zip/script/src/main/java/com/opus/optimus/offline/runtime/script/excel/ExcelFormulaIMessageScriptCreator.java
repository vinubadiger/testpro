package com.opus.optimus.offline.runtime.script.excel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.api.IScriptCreator;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;

/**
 * The Class ExcelFormulaIMessageScriptCreator.
 */
@Component("excel.imessage-script")
public class ExcelFormulaIMessageScriptCreator implements IScriptCreator, BeanFactoryAware {
	private static final Logger logger = LoggerFactory.getLogger(ExcelFormulaIMessageScriptCreator.class);
	
	/** The Constant IMESSAGE_VALUE_EVALUATOR. */
	private static final String IMESSAGE_VALUE_EVALUATOR = "excel.IMessageValueEvaluatorScript";
	
	/** The Constant IMESSAGE_CONDITION_EVALUATOR. */
	private static final String IMESSAGE_CONDITION_EVALUATOR = "excel.IMessageConditionEvaluatorScript";
	
	/** The bean factory. */
	BeanFactory beanFactory;
	
	@Override
	public IScript create(IScriptConfig config) {
		ExcelScriptConfig excelScriptConfig = (ExcelScriptConfig)config;
		if(excelScriptConfig.isConditional()) {
			return createExcelFormulaEvaluatorScript(IMESSAGE_CONDITION_EVALUATOR, excelScriptConfig);
		} else {
			return createExcelFormulaEvaluatorScript(IMESSAGE_VALUE_EVALUATOR, excelScriptConfig);
		}
	}
	
	/**
	 * Creates the excel formula evaluator script.
	 *
	 * @param type - The type od script
	 * @param excelScriptConfig - The excel script configuration
	 * @return the i script
	 */
	private IScript createExcelFormulaEvaluatorScript(final String type, final ExcelScriptConfig excelScriptConfig) {
		boolean singleton = beanFactory.isSingleton(type);
        if (singleton) {
        	logger.error("ExcelFormulaEvaluatorScript component should be scoped as prototype ...{} is singleton..." ,type);
            throw new EngineException("ExcelFormulaEvaluatorScript component should be scoped as prototype ..." + type + " is singleton...");
        }

        return (ExcelFormulaEvaluatorScript) beanFactory.getBean(type, excelScriptConfig);
	}

	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}
}
