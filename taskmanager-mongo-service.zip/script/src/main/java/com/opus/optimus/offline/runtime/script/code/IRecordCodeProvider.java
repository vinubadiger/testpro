package com.opus.optimus.offline.runtime.script.code;

import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.SetterCode;

/**
 * The Class IRecordCodeProvider.
 */
@Component("IRecordTypeData")
public class IRecordCodeProvider implements ICodeProvider {
	
	/** The input data variable name. */
	static final String INPUT_DATA_VARIABLE_NAME = "request";
	
	@Override
	public GetterCode getGetterCode(String name) {
		GetterCode getterCode = new GetterCode();
		getterCode.setCode(INPUT_DATA_VARIABLE_NAME + ".getValue(" + INPUT_DATA_VARIABLE_NAME + ".getFieldId(\"" + name + "\"))");
        return getterCode;
	}

	@Override
	public SetterCode getSetterCode(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getDataClassName() {
		return IRecord.class.getName();
	}

}
