package com.opus.optimus.offline.runtime.script.config;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Instantiates a new excel script configuration.
 *
 * @param formulaText - The formula text
 * @param conditional - The conditional
 * @param recordType - The record type
 * @param type the type
 */
@AllArgsConstructor

/**
 * Instantiates a new excel script configuration.
 */
@NoArgsConstructor
@Builder
@Data
@ToString
public class ExcelScriptConfig implements IScriptConfig {
	
	/** The formula text. */
	private String formulaText;
	
	/** The conditional. */
	private boolean conditional;
	
	/** The record type. */
	private RecordType recordType;
	
	/** The type. */
	private String type;

}
