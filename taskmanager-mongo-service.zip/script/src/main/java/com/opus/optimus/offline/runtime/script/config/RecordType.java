package com.opus.optimus.offline.runtime.script.config;

/**
 * The Enum RecordType.
 */
public enum RecordType {
	
	/** The irecord. */
	IRECORD("IRecordTypeData","IRecord"),
	
	/** The imessage. */
	IMESSAGE("IMessageTypeData","IMessage"),
	
	/** The rawtext. */
	RAWTEXT("RawTextTypeData","String");
	
	/** The provider name. */
	private String providerName;
	
	/** The class name. */
	private String className;

	/**
	 * Instantiates a new record type.
	 *
	 * @param providerName the provider name
	 * @param className the class name
	 */
	private RecordType(String providerName, String className) {
		this.providerName = providerName;
		this.className = className;
	}

	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * Gets the provider name.
	 *
	 * @return the provider name
	 */
	public String getProviderName() {
		return providerName;
	}
}
