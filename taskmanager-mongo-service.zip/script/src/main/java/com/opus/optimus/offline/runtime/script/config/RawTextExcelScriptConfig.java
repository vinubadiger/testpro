package com.opus.optimus.offline.runtime.script.config;

/**
 * The Class RawTextExcelScriptConfig.
 */
public class RawTextExcelScriptConfig extends ExcelScriptConfig {

}
