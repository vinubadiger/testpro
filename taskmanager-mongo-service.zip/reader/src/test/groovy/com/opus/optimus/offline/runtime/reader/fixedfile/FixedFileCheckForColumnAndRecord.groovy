package com.opus.optimus.offline.runtime.reader.fixedfile

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.FixedFieldConfig
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig
import com.opus.optimus.offline.config.fieldextractor.impl.FixedFieldExtractorConfig
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.config.record.impl.FixedRecordExtractorConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.common.reader.TextFileReaderHelper;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class FixedFileCheckForColumnAndRecord extends Specification {

	@Autowired
	TextFileReaderHelper fileReader;

	@Autowired
	MapperFactory mapperFactory;

	def "FIXED reader record extractor check"() {
		setup:
		def noOfRows = 0;


		def fileReaderConfig = new TextFileReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/FixedLengthOneLine.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		/*List<String> props = new ArrayList<>();
		 props.add("./src/test/resources/testFileOneLine.txt");
		 */
		String inputFileLocation = "./src/test/resources/testFileOneLine.txt";

		fileReader.init(inputFileLocation, fileReaderConfig);

		def int[] arr = new int[4];
		arr[0] = 2;
		arr[1] = 2;
		arr[2] = 8;
		arr[3] = 3;
		def columnTypesMatch = true;

		when:
		fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						print("----------------FIXED reader record extractor check-----------------")
						println("data row");
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							if(record.getValue(i).toString().length() != arr[i]) {
								println(record.getValue(i).toString())
								columnTypesMatch = false;
							}
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		columnTypesMatch == true
	}

	// Test 2
	//TODO test case for file not found for new structure

	/*def "FIXED reader file not found"() {
	 setup:
	 def noOfRows = 0;
	 def fileReaderConfig = new TextFileReaderConfig();
	 def object ;
	 def mapper = mapperFactory.getMapper()
	 def jsonStream = getClass().getResourceAsStream("/json/FixedLengthOneLine.json")
	 object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
	 fileReaderConfig = object.stepConfig;
	 List<String> props = new ArrayList<>();
	 props.add("./src/test/resources/testFileOneLines.txt");
	 String inputFileLocation = "./src/test/resources/testFileOneLines.txt";
	 fileReader.init(inputFileLocation , fileReaderConfig);
	 when:
	 fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
	 public void onData(IRecord record,ISourceReference sourceReference) {}
	 });
	 then:
	 println(ReaderException)
	 thrown ReaderException
	 }*/





}
