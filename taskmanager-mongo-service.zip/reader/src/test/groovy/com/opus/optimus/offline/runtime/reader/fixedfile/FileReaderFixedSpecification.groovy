package com.opus.optimus.offline.runtime.reader.fixedfile

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.FixedFieldConfig
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig
import com.opus.optimus.offline.config.fieldextractor.impl.FixedFieldExtractorConfig
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.common.reader.TextFileReaderHelper;
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class FileReaderFixedSpecification extends Specification {

	@Autowired
	TextFileReaderHelper fileReader;

	@Autowired
	MapperFactory mapperFactory

	def "FIXED reader execution"() {
		setup:
		def noOfRows = 0;

		def fileReaderConfig = new TextFileReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/FixedLengthFileWithNewLine.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		/*List<String> props = new ArrayList<>();
		 props.add("./src/test/resources/testFile.txt");
		 */
		String inputFileLocation = "./src/test/resources/testFile.txt";

		fileReader.init(inputFileLocation , fileReaderConfig);

		when:
		fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data row");
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows == 2
	}
}
