package com.opus.optimus.offline.runtime.workflow.integration

import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ReaderStepLocalJobExecutor extends Specification {

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    MapperFactory mapperFactory

    def "Reader step execution"() {
        setup:
        /*String s1="\\reader\\src\\test\\resources\\testFile.csv";
         File currentDir = new File("");
         String path = currentDir.getAbsolutePath();
         path =path.replace("\\reader",s1 );
         System.out.println( path.replace("\\reader",s1 )+"<---" +"updated ");
         System.out.println(currentDir.getAbsolutePath());*/

        def fileReaderConfig = new TextFileReaderConfig();
        def object;

        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/json/DelimitedConfigJSON.json")
        object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
        fileReaderConfig = object.stepConfig;

        /*	List<String> props = new ArrayList<>();
            props.add(path);*/

        String inputFileLocation = "./src/test/resources/testFile.csv";

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [fileReaderConfig]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue("name").getEmitter()

        emitter.emit(messageFactory.createMessage(inputFileLocation))
        emitter.emit(messageFactory.createEndMessage())

        result.get()

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue("name").get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        println("Size----------->" + receivedData.size());
        receivedData.size() == 8
    }
}
