package com.opus.optimus.offline.runtime.reader.xlsx

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.ExcelReaderHelper
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelFileStructureCheckXLSX extends Specification {

	@Autowired
	ExcelReaderHelper excelReader;

	@Autowired
	MapperFactory mapperFactory

	def "Excel XLSX No of row iterated"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;
		/*
		 List<IFieldConfig> fieldConfigs = new ArrayList<IFieldConfig>();
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 1).name("Column1").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 2).name("Column2").type(FieldType.STRING)
		 .maxSize(12).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 3).name("Column3").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 4).name("Column4").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 5).name("Column5").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 6).name("Column6").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 7).name("Column7").type(FieldType.STRING)
		 .maxSize(24).build());
		 ExcelRecordExtractorConfig recordExtractorConfig = ExcelRecordExtractorConfig.builder()
		 .sectionName("Data").fieldConfigs(fieldConfigs).build();
		 Map<String, ExcelRecordExtractorConfig> recordExtractorMap = new HashMap<String, ExcelRecordExtractorConfig>();
		 recordExtractorMap.put("Data", recordExtractorConfig);
		 ExcelReaderConfig excelReaderConfig = new ExcelReaderConfig();
		 excelReaderConfig.setCharEncoding("USASCII"); // UTF8
		 excelReaderConfig.setTopRowsToSkip(3);
		 excelReaderConfig.setProcessAllSheets(true);
		 excelReaderConfig.setNoOfHeaderRecs(1);
		 excelReaderConfig.setRecordExtractorConfig(recordExtractorMap);
		 */
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		/*		Map<String, Object> props = new HashMap<String, Object>();
		 props.put(ExcelReaderHelper.READER_FILENAME, "./src/test/resources/testXLSX1.xlsx");
		 */
		String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig);

		when:
		println("--------TEST 1--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data row");
						int maxIndex = record.schema.fields.size();
						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows == 10
	}

	//	TEST 2
	def "Excel XLSX No of row skip check"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;
		def nullFlag = false;
		def nullCounter =0;
		/*
		 List<IFieldConfig> fieldConfigs = new ArrayList<IFieldConfig>();
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 1).name("Column1").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 2).name("Column2").type(FieldType.STRING)
		 .maxSize(12).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 3).name("Column3").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 4).name("Column4").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 5).name("Column5").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 6).name("Column6").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 7).name("Column7").type(FieldType.STRING)
		 .maxSize(24).build());
		 ExcelRecordExtractorConfig recordExtractorConfig = ExcelRecordExtractorConfig.builder()
		 .sectionName("Data").fieldConfigs(fieldConfigs).build();
		 Map<String, ExcelRecordExtractorConfig> recordExtractorMap = new HashMap<String, ExcelRecordExtractorConfig>();
		 recordExtractorMap.put("Data", recordExtractorConfig);
		 ExcelReaderConfig excelReaderConfig = new ExcelReaderConfig();
		 excelReaderConfig.setCharEncoding("USASCII"); // UTF8
		 excelReaderConfig.setTopRowsToSkip(4);
		 excelReaderConfig.setProcessAllSheets(true);
		 excelReaderConfig.setNoOfHeaderRecs(1);
		 excelReaderConfig.setRecordExtractorConfig(recordExtractorMap);
		 */
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/ExcelWithRowExcepion.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		/*Map<String, Object> props = new HashMap<String, Object>();
		props.put(ExcelReaderHelper.READER_FILENAME, "./src/test/resources/testXLSX2.xlsx");*/

		String inputFileLocation = "./src/test/resources/testXLSX2.xlsx";
		
		excelReader.init(inputFileLocation, excelReaderConfig);

		when:
		println("--------TEST 2--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data rows");
						int maxIndex = record.schema.fields.size();
						//						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							if((record.getValue(i)).toString().trim().length() <= 0) {
								nullCounter ++;
								print("row no#::"+noOfRows+"    field no#"+i);
							}
							if(nullCounter == maxIndex){
								nullFlag = true;
							}
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		nullFlag == false;
	}


	//	TEST 3
	def "Excel XLSX No of sheet iterate check"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 13;
		/*
		 List<IFieldConfig> fieldConfigs = new ArrayList<IFieldConfig>();
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 1).name("Column1").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 2).name("Column2").type(FieldType.STRING)
		 .maxSize(12).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 3).name("Column3").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 4).name("Column4").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 5).name("Column5").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 6).name("Column6").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 7).name("Column7").type(FieldType.STRING)
		 .maxSize(24).build());
		 ExcelRecordExtractorConfig recordExtractorConfig = ExcelRecordExtractorConfig.builder()
		 .sectionName("Data").fieldConfigs(fieldConfigs).build();
		 Map<String, ExcelRecordExtractorConfig> recordExtractorMap = new HashMap<String, ExcelRecordExtractorConfig>();
		 recordExtractorMap.put("Data", recordExtractorConfig);
		 ExcelReaderConfig excelReaderConfig = new ExcelReaderConfig();
		 excelReaderConfig.setCharEncoding("USASCII"); // UTF8
		 excelReaderConfig.setTopRowsToSkip(4);
		 excelReaderConfig.setProcessAllSheets(true);
		 excelReaderConfig.setNoOfHeaderRecs(1);
		 excelReaderConfig.setRecordExtractorConfig(recordExtractorMap);
		 */
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/ExcelWithRowExcepion.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		/*	Map<String, Object> props = new HashMap<String, Object>();
		 props.put(ExcelReaderHelper.READER_FILENAME, "./src/test/resources/testXLSX2.xlsx");*/
		
		String inputFileLocation = "./src/test/resources/testXLSX2.xlsx";

		excelReader.init(inputFileLocation, excelReaderConfig);

		when:
		println("--------TEST 3--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data rows");
						int maxIndex = record.schema.fields.size();
						//						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		recordsInSheet < noOfRows;
	}


	//	TEST 4
	def "Excel XLSX file invalid"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 13;
		/*
		 List<IFieldConfig> fieldConfigs = new ArrayList<IFieldConfig>();
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 1).name("Column1").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 2).name("Column2").type(FieldType.STRING)
		 .maxSize(12).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 3).name("Column3").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 4).name("Column4").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 5).name("Column5").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 6).name("Column6").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 7).name("Column7").type(FieldType.STRING)
		 .maxSize(24).build());
		 ExcelRecordExtractorConfig recordExtractorConfig = ExcelRecordExtractorConfig.builder()
		 .sectionName("Data").fieldConfigs(fieldConfigs).build();
		 Map<String, ExcelRecordExtractorConfig> recordExtractorMap = new HashMap<String, ExcelRecordExtractorConfig>();
		 recordExtractorMap.put("Data", recordExtractorConfig);
		 ExcelReaderConfig excelReaderConfig = new ExcelReaderConfig();
		 excelReaderConfig.setCharEncoding("USASCII"); // UTF8
		 excelReaderConfig.setTopRowsToSkip(4);
		 excelReaderConfig.setProcessAllSheets(true);
		 excelReaderConfig.setNoOfHeaderRecs(1);
		 excelReaderConfig.setRecordExtractorConfig(recordExtractorMap);
		 */
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;
		
		String inputFileLocation = "./src/test/resources/testXLSX2.xlsxx";

		excelReader.init(inputFileLocation, excelReaderConfig);

		when:
		println("--------TEST 4--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
					}
				});

		then:
		thrown ReaderException
	}


	//	TEST 5
	def "Excel XLSX file not support"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 13;
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;
		
		String inputFileLocation = "./src/test/resources/testXLSX2.xlsxx";

		excelReader.init(inputFileLocation, excelReaderConfig);

		when:
		println("--------TEST 5--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {}
				});

		then:
		thrown ReaderException
	}


	//	TEST 6
	def "Excel XLSX file not found"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 13;
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/nonExistFile.xlsxx";

		excelReader.init(inputFileLocation, excelReaderConfig);

		when:
		println("--------TEST 6--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {}
				});

		then:
		thrown ReaderException
	}

}
