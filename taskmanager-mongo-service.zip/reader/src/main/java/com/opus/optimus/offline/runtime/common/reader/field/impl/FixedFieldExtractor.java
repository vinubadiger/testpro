package com.opus.optimus.offline.runtime.common.reader.field.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.config.field.impl.FixedFieldConfig;
import com.opus.optimus.offline.config.fieldextractor.impl.FixedFieldExtractorConfig;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.FieldFormatException;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.field.IFieldExtractor;
import com.opus.optimus.offline.runtime.common.reader.field.formatter.FieldFormatterImpl;
import com.opus.optimus.offline.runtime.common.reader.util.SchemaBuilder;

import lombok.Getter;

/**
 * The Class FixedFieldExtractor for fields extractor from row data.
 * 
 * @author Yashkumar.Thakur
 *
 */
public class FixedFieldExtractor implements IFieldExtractor<String> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(FixedFieldExtractor.class);

	/** The configuration object. */
	private FixedFieldExtractorConfig config;

	@Getter
	private Schema schema;

	/** The record factory. */
	private IRecordFactory recordFactory;

	@Override
	public void setRecordFactory(IRecordFactory recordFactory) {
		this.recordFactory = recordFactory;
	}

	@Override
	public IRecord getRecord(String rawRecord) throws ReaderException {

		setPositions();
		int maxfieldCount = config.getFieldConfigs().size();
		IRecord record = recordFactory.createRecord(config.getSectionName());
		int fieldCount=1;
		try {
			for (FixedFieldConfig fieldConfig : config.getFieldConfigs()) {
				String fldValue = rawRecord.substring(fieldConfig.getStartPosition() - 1, fieldConfig.getEndPosition());
				int fldIndex = fieldConfig.getFieldIndex() - 1;
				record.setValue(fldIndex, FieldFormatterImpl.populateField(fieldConfig, fldValue));
				fieldCount++;
			}
		} catch (FieldFormatException exp) {
			logger.error("Error while formatting fields in reader: {}, {}", exp.getMessage() , exp);
			throw new ReaderException(ExceptionCodes.FIELD_FORMAT_EXCEPTION, exp.getMessage());
		} catch (StringIndexOutOfBoundsException exp) {
			logger.error("Expected {} , fields, But Error on filed {} size overflow. Error :{}", maxfieldCount, fieldCount,exp);
			throw new ReaderException(ExceptionCodes.MISSING_FIELDS,
					"Expected " + maxfieldCount + " fields,But Error on filed " + fieldCount + "size overflow.");
		}
		return record;
	}

	@Override
	public void init(IBaseConfig config) {
		this.config = (FixedFieldExtractorConfig) config;

		schema = SchemaBuilder.buildSchema(this.config.getSectionName(), this.config.getFieldConfigs());

		recordFactory.registerSchema(schema);
	}

	/**
	 * Sets the positions of fields i.e. start and end positions.
	 */
	public void setPositions() {
		short currentPosition = 0;
		for (FixedFieldConfig fieldConfig : config.getFieldConfigs()) {
			if (fieldConfig.getFieldIndex() == 1) {
				fieldConfig.setStartPosition((short) 1);
				fieldConfig.setEndPosition((short) fieldConfig.getMaxSize());
				currentPosition += (short) fieldConfig.getMaxSize();
			} else {
				fieldConfig.setStartPosition(currentPosition);
				currentPosition += (short) fieldConfig.getMaxSize() - 1;
				fieldConfig.setEndPosition(currentPosition);
			}
			currentPosition++;
		}
	}
}
