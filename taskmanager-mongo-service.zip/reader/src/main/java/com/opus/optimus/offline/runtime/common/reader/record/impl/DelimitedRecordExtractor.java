package com.opus.optimus.offline.runtime.common.reader.record.impl;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.record.IRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.stream.IStream;
import com.opus.optimus.offline.runtime.common.reader.stream.impl.FileStream;

/**
 * The Class DelimitedRecordExtractor.
 *
 * @author Ram
 */
public class DelimitedRecordExtractor implements IRecordExtractor<String> {

	/** The configuration object  */
	private DelimitedRecordExtractorConfig config;

	@Override
	public void init(IBaseConfig config) {
		this.config = (DelimitedRecordExtractorConfig) config;
	}

	@Override
	public String getRecord(Object context, IStream stream) throws ReaderException {
		return ((FileStream) stream).getRecord();
	}
}
