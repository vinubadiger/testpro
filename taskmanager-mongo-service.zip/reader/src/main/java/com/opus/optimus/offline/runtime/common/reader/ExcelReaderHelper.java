package com.opus.optimus.offline.runtime.common.reader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.reader.ExcelReaderConfig;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.record.impl.ExcelRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.stream.impl.ExcelStream;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Getter;

/**
 * The Class ExcelReaderHelper.
 *
 * @author Manjusha.Dhamdhere
 * @author Yashkumar.Thakur
 */

@Component("ExcelReaderHelper")
@Scope("prototype")
public class ExcelReaderHelper {
	private static final Logger logger = LoggerFactory.getLogger(ExcelReaderHelper.class);

	/** The record factory. */
	@Autowired
	RecordFactory recordFactory;

	/**
	 * Gets the reader configuration
	 *
	 * @return the reader configuration
	 */
	@Getter
	private ExcelReaderConfig readerConfig;

	/** The reader filename. */
	public static final String READER_FILENAME = "reader.fileName";
	
	/** The stream. */
	private ExcelStream stream;
	
	/** The record extractor. */
	private ExcelRecordExtractor recordExtractor;
	
	/** The input file location. */
	private String inputFileLocation;

	/**
	 * Inits the.
	 *
	 * @param properties - The input file location
	 * @param stepConfig - The step configuration
	 */
	/*
	 * this reader can hold different data Sections & mappings between dataSections
	 * & fieldExtractors
	 */
	public void init(String properties, IStepConfig stepConfig) {
		// Loading Excel file reader configuration
		this.readerConfig = (ExcelReaderConfig) stepConfig;
		this.inputFileLocation = properties;

		recordExtractor = new ExcelRecordExtractor();
		recordExtractor.setRecordFactory(recordFactory);
		recordExtractor.init(readerConfig);
	}

	/**
	 * 
	 * @param stepInstance - The step instance  
	 * @param readerEventHandler - The reader event handler
	 * @throws ReaderException
	 */
	public void processFile(ExcelReaderStep stepInstance,IReaderEventHandler readerEventHandler) throws ReaderException {
		try {
			
			// For force stop
			if (stepInstance != null && stepInstance.doStop()) {
				return;
			}
			// initialize fileStream
			stream = new ExcelStream();
			stream.init(inputFileLocation, readerConfig.getCharEncoding(), readerConfig);

			recordExtractor.process(null, stream.getWorkbook(), readerEventHandler);

		} catch (Exception e) {
			logger.error("Error in Excel reader:{} , {}",e.getMessage(), e);
			throw new ReaderException(e);
		} finally {
			try {
				stream.release();
			} catch (Exception e) {
				logger.error("Error while relesing file stream :{} , {}",e.getMessage(), e);
			}
		}
	}
}
