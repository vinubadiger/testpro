package com.opus.optimus.offline.runtime.common.reader.stream;

import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;

/**
 * The Interface ICharStream.
 */
public interface ICharStream extends IStream {
	  
	/**
	 * Read.
	 *
	 * @param paramInt the param int
	 * @return the char[]
	 * @throws ReaderException the reader exception
	 */
	public abstract char[] read(int paramInt)
			    throws ReaderException;
			  
	/**
	 * Gets the record.
	 *
	 * @param paramString the parameter string
	 * @return the record
	 * @throws ReaderException the reader exception
	 */
	public abstract String getRecord(String paramString)
			    throws ReaderException;
}
