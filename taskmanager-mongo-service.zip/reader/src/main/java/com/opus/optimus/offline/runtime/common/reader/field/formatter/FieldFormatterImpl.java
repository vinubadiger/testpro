package com.opus.optimus.offline.runtime.common.reader.field.formatter;

import java.text.SimpleDateFormat;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.icu.math.BigDecimal;
import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig;
import com.opus.optimus.offline.config.field.impl.FixedFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.reader.exception.FieldFormatException;

/**
 * For format data by specified data type .
 *
 * @author Yashkumar.Thakur
 */

public class FieldFormatterImpl {
	
	/** The Constant logger slf4j, to log info, warning, error and debug.  */
	private static final Logger logger = LoggerFactory.getLogger(FieldFormatterImpl.class);

	/**
	 * Instantiates a new field formatter private constructor.
	 */
	private FieldFormatterImpl() {
	}

	/**
	 * Populate field.
	 *
	 * @param fldConfig - The field configurations
	 * @param fieldValue - The field value
	 * @return the object type formated data
	 * @throws FieldFormatException the field format exception
	 */
	public static Object populateField(IFieldConfig fldConfig, String fieldValue) throws FieldFormatException {
		FieldType dataType = fldConfig.getType();
		String format = fldConfig.getFormat();
		
		try {
			if (dataType.equals(FieldType.STRING)) {
				return StringUtils.isEmpty(fieldValue) ? null : fieldValue;
			} else if (dataType.equals(FieldType.LONG)) {
				return StringUtils.isEmpty(fieldValue) ? new Long(0) : Long.valueOf(fieldValue);
			} else if (dataType.equals(FieldType.DOUBLE)) {

				if (DelimitedFieldConfig.class.isAssignableFrom(fldConfig.getClass())) {
					DelimitedFieldConfig delimitedFieldConfig = (DelimitedFieldConfig) fldConfig;
					return precisionConverter(fieldValue, delimitedFieldConfig.isImplicitDecimal(),
							delimitedFieldConfig.getNoOfDecimals()).doubleValue();
				} else if (FixedFieldConfig.class.isAssignableFrom(fldConfig.getClass())) {
					FixedFieldConfig fixedFieldConfig = (FixedFieldConfig) fldConfig;
					return precisionConverter(fieldValue, fixedFieldConfig.isImplicitDecimal(),
							fixedFieldConfig.getNoOfDecimals()).doubleValue();
				} else {
					return StringUtils.isEmpty(fieldValue) ? new Double(0) : Double.valueOf(fieldValue);
				}
			} else if (dataType.equals(FieldType.FLOAT)) {

				if (DelimitedFieldConfig.class.isAssignableFrom(fldConfig.getClass())) {
					DelimitedFieldConfig delimitedFieldConfig = (DelimitedFieldConfig) fldConfig;
					return precisionConverter(fieldValue, delimitedFieldConfig.isImplicitDecimal(),
							delimitedFieldConfig.getNoOfDecimals()).floatValue();
				} else if (FixedFieldConfig.class.isAssignableFrom(fldConfig.getClass())) {
					FixedFieldConfig fixedFieldConfig = (FixedFieldConfig) fldConfig;
					return precisionConverter(fieldValue, fixedFieldConfig.isImplicitDecimal(),
							fixedFieldConfig.getNoOfDecimals()).floatValue();
				} else {
					return StringUtils.isEmpty(fieldValue) ? new Float(0) : Float.valueOf(fieldValue);
				}
			} else if (dataType.equals(FieldType.BOOLEAN)) {
				return StringUtils.isEmpty(fieldValue) ? new Boolean(false) : Boolean.valueOf(fieldValue);
			} else if (dataType.equals(FieldType.INT)) {
				return StringUtils.isEmpty(fieldValue) ? new Integer(0) : Integer.valueOf(fieldValue);
			} else if (dataType.equals(FieldType.DATETIME) || dataType.equals(FieldType.DATE)) {
				SimpleDateFormat formatter = new SimpleDateFormat(format);
				return formatter.parse(fieldValue);
			} else {
				throw new FieldFormatException("Unsupported data type provided for the field");
			}
		} catch (Exception e) {
			logger.error("Field Format Error on:" + fldConfig.getName() + ", Error: " + e.getMessage());
			throw new FieldFormatException("Format Error on:" + fldConfig.getName() + ", Error: " + e.getMessage(), e);
		}
	}

	/**
	 * Precision converter for float and double data type
	 *
	 * @param fieldValue - The field value
	 * @param isImplicitDecimal - The is implicit decimal boolean check 
	 * @param noOfDecimals - The no of decimals to convert
	 * @return the big decimal converted field
	 */
	public static BigDecimal precisionConverter(final String fieldValue, boolean isImplicitDecimal, short noOfDecimals) {
		String operationValue = Optional.ofNullable(fieldValue).orElse("").trim();
		if (StringUtils.isEmpty(operationValue)) {
			operationValue = "00";
		}
		if (isImplicitDecimal) {
			BigDecimal sourceValue = new BigDecimal(operationValue);
			return sourceValue.movePointLeft(noOfDecimals);
		} else {
			BigDecimal sourceValue = new BigDecimal(operationValue);
			return sourceValue.setScale(noOfDecimals);
		}
	}

}
