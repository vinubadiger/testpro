package com.opus.optimus.offline.runtime.common.reader.field.formatter;

import java.text.SimpleDateFormat;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.reader.exception.FieldFormatException;

/**
 * The Class ExcelFieldFormatterImpl for extracting data from excel cells 
 *
 * @author Yashkumar.Thakur
 */

public class ExcelFieldFormatterImpl {
	
	/**
	 * Instantiates a new excel field formatter implementation
	 */
	private ExcelFieldFormatterImpl() {}

	/**
	 * Gets the cell value.
	 *
	 * @param cell - The single cell of excel file 
	 * @param fldConfig - The field configuration
	 * @return the cell value
	 * @throws FieldFormatException the field format exception
	 */
	public static Object getCellValue(Cell cell, IFieldConfig fldConfig) throws FieldFormatException {
		FieldType dataType = fldConfig.getType();
		DataFormatter dataFormatter = new DataFormatter();

		if (cell == null) {
			return null;
		}
		CellType cellTypeEnum = cell.getCellType();
		switch (cellTypeEnum) {
		case _NONE:
			return null;
		case BLANK:
			return "";
		case STRING:
			return cell.getStringCellValue();
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case NUMERIC: {
			if (dataType == null || dataType.equals(FieldType.STRING)) {
				return dataFormatter.formatCellValue(cell);
			}
			boolean cellDateFormatted = DateUtil.isCellDateFormatted(cell);
			if (cellDateFormatted) {
				SimpleDateFormat formatter = new SimpleDateFormat(fldConfig.getFormat());
				return formatter.format(cell.getDateCellValue());
			}
			return cell.getNumericCellValue();
		}
		case ERROR:
			return cell.getErrorCellValue();
		case FORMULA:
			return cell.getCellFormula();
		default:
			throw new FieldFormatException();
		}
	}

}
