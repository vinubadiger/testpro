package com.opus.optimus.offline.runtime.common.reader;

import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

/**
 * The Interface IReaderEventHandler.
 *
 * @author Ram
 * @param <T> the generic type
 */

public interface IReaderEventHandler<T> {

	/**
	 * On data.
	 *
	 * @param record - The record
	 * @param sourceReference - The source reference
	 */
	public void onData(T record, ISourceReference sourceReference);
	
	/**
	 * On data error.
	 *
	 * @param cause - The cause of exception
	 * @param sourceReference - The source reference
	 */
	void onDataError(Throwable cause, ISourceReference sourceReference);
}
