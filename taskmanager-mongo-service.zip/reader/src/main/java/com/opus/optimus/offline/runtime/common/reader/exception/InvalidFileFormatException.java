package com.opus.optimus.offline.runtime.common.reader.exception;

public class InvalidFileFormatException extends ReaderException {
	private static final long serialVersionUID = 1L;

	private final String errorCode ;

	public InvalidFileFormatException() {		
		this.errorCode = ExceptionCodes.INVALID_FILE_FORMAT_EXCEPTION;
	}

	public InvalidFileFormatException(Throwable cause) {
		super(cause);
		this.errorCode = ExceptionCodes.INVALID_FILE_FORMAT_EXCEPTION;
	}
	
	@Override
	public String getErrorCode() {
		return this.errorCode;
	}	
}
