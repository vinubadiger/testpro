package com.opus.optimus.offline.runtime.common.reader.exception;

public interface ExceptionCodes {
	// General Exception
	public static final String READER_GENERAL_EXCEPTION = "RDR-GEN-001";
	public static final String READER_FILE_NOT_FOUND_EXCEPTION = "RDR-GEN-005";
	public static final String READER_DUPLICATE_FILE_EXCEPTION = "RDR-GEN-006";
	public static final String READER_RELEASE_EXCEPTION = "RDR-GEN-007";

	// Data Exception
	public static final String READER_EOF_EXCEPTION = "RDR-DAT-001";
	public static final String FIELD_FORMAT_EXCEPTION = "RDR-DAT-002"; 
	public static final String INVALID_FILE_FORMAT_EXCEPTION = "RDR-DAT-003"; 
	public static final String MISSING_FIELDS = "RDR-DAT-004";
	
	// System Exception
	public static final String SYSTEM_GENERAL_EXCEPTION = "SYS-GEN-001";

}
