package com.opus.optimus.offline.runtime.common.reader;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;
import com.opus.optimus.offline.config.reader.TextFileReaderConfig;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.EOFException;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.field.IFieldExtractor;
import com.opus.optimus.offline.runtime.common.reader.record.IRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.stream.impl.FileStream;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Getter;

/**
 * The Class TextFileReader Helper for reading delimited and fixed files..
 * 
 * @author Yashkumar.Thakur
 *
 */

@Component("TextFileReaderHelper")
@Scope("prototype")
public class TextFileReaderHelper {

	/** The Constant for logger slf4j, to log info, warning, error and debug. */
	private static final Logger logger = LoggerFactory.getLogger(TextFileReaderHelper.class);

	/** The reader filename for accepting reader path. */
	public static final String READER_FILENAME = "reader.fileName";

	/** The record factory for creating record schema */
	@Autowired
	RecordFactory recordFactory;

	/** The script creator factory. */
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	/**
	 * Gets the reader configuration.
	 *
	 * @return the reader configuration
	 */
	@Getter
	private TextFileReaderConfig readerConfig;

	/**
	 * The script configuration map for generation script object with section name.
	 */
	private Map<String, IScript> scriptConfigs;

	/** The hash map of section name with field configuration */
	private Map<String, IFieldExtractor> sectionNameVsfieldExtractor;

	/** The record extractor for storing record extractor object */
	private IRecordExtractor<?> recordExtractor;

	/** It contain object of created file stream */
	private FileStream stream;

	/** It contains file name */
	private String fileName;

	/**
	 * Initialize the.
	 *
	 * @param inputFileLocation -
	 *            The input file location
	 * @param stepConfig -
	 *            The step configuration
	 */
	public void init(String inputFileLocation, IStepConfig stepConfig) {
		// load fileReaderConfig
		this.readerConfig = (TextFileReaderConfig) stepConfig;
		this.fileName = inputFileLocation;

		// initialize recordExtractor
		recordExtractor = RecordExtractorFactory.getExtractor(readerConfig.getRecordExtractorConfig());
		recordExtractor.init(readerConfig.getRecordExtractorConfig());

		/*
		 * Create script object from scripts with section data name for later section
		 * selection
		 */
		scriptConfigs = new HashMap<>();
		readerConfig.getSectionDetails().forEach((section, script) -> 
			scriptConfigs.put(section, scriptCreatorFactory.createScript(script))
		);

		// Map iteration for getting fields
		sectionNameVsfieldExtractor = new HashMap<>();
		Map<String, ITextFieldExtractorConfig> sectionNameVsfieldExtractorConfig = readerConfig
				.getFieldExtractorConfig();

		// initializing all fieldExtractors
		sectionNameVsfieldExtractorConfig.forEach((pSectionName, pFieldExtractorConfig) -> {
			IFieldExtractor<?> fieldExtractor = FieldExtractorFactory.getExtractor(pFieldExtractorConfig);
			fieldExtractor.setRecordFactory(recordFactory);
			fieldExtractor.init(pFieldExtractorConfig);
			sectionNameVsfieldExtractor.put(pSectionName, fieldExtractor);
		});
	}

	/**
	 * Process file.
	 *
	 * @param stepInstance -
	 *            The step instance
	 * @param readerEventHandler -
	 *            The reader event handler
	 * @throws ReaderException -
	 *             The reader exception related to all reading or formatting
	 *             exception
	 */
	public void processFile(TextFileReaderStep stepInstance, IReaderEventHandler readerEventHandler)
			throws ReaderException {
		try {
			boolean eof = false;
			int rawIndex = 0;

			stream = new FileStream();
			stream.init(this.fileName, readerConfig.getCharEncoding(), readerConfig);
			do {
				rawIndex++;

				if (stepInstance != null && stepInstance.doStop()) {
					return;
				}

				try {
					// get raw record from file
					Object rawRecord = recordExtractor.getRecord(null, stream);

					logger.info("Row data : {}", rawRecord);

					FileSourceReference fileSourceReference = FileSourceReference.builder().fileName(this.fileName)
							.rawRecordData((String) rawRecord).rowIndex(rawIndex).build();

					// get first sectionIdentification which returns true
					this.scriptConfigs.entrySet().stream()
							.filter((entry) -> (Boolean) entry.getValue().execute(rawRecord)).map((entry) -> {
								logger.info("Section identified as: " + entry.getKey());
								return sectionNameVsfieldExtractor.get(entry.getKey());
							}).forEach(fieldExtractor -> {
								if (fieldExtractor != null) {
									try {
										readerEventHandler.onData(fieldExtractor.getRecord(rawRecord),
												fileSourceReference);
									} catch (ReaderException readerException) {
										logger.error("Reader exception occured while processing the record: {}",
												readerException);
										readerEventHandler.onDataError(readerException, fileSourceReference);
									} catch (Exception e) {
										logger.error("Error in text file reader : {} ,{}",e.getMessage(), e);
										readerEventHandler.onDataError(e, fileSourceReference);
									}
								}
							});

				} catch (EOFException exp) {
					eof = true;
					logger.error(exp.getMessage(), exp);
				}
			} while (!eof);
		} catch (ReaderException readerException) {
			logger.error("Error While executing reader : {}", readerException);
			throw readerException;
		} catch (Exception e) {
			logger.error("Error While executing reader :{}", e);
			throw new ReaderException(e);
		} finally {
			stream.release();
		}
	}
}
