package com.opus.optimus.offline.runtime.script.api;

/**
 * The Interface IScriptCreator.
 */
@FunctionalInterface
public interface IScriptCreator {
    
    /**
     * Creates the.
     *
     * @param config the configuration
     * @return the i script
     */
    IScript create(IScriptConfig config);
}
