package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;

@Repository
public interface JobInfoRepository extends MongoRepository<JobInfo, String> {
    List<JobInfo> findByStatus(JobStatus status);
    
}
