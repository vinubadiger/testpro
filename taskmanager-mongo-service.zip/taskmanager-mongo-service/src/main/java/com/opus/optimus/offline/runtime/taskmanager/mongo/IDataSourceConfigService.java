package com.opus.optimus.offline.runtime.taskmanager.mongo;

import java.util.List;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;

public interface IDataSourceConfigService {
	List<MongoDataSourceMeta> findAllDataSourceConfigs(); //Later we can include the find by institution id.
}
