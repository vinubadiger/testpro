package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import java.io.File;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.ErrorReason;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatistics;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IReconSummary;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;

/**
 * This class is used for updating and getting the status of job based on jobId.
 * Also it is responsible for updating job info with error details and used for finding processing time of job.
 *
 */
@Service
public class JobInfoService implements IJobInfoService {
	private static final Logger logger = LoggerFactory.getLogger(JobInfoService.class);
	private String FILE_OUT_PROCESSLOCATION;
	private String FILE_ERROR_PROCESSLOCATION;
	
	@Value ("${file.process.out.directory}")
	public void setDirName(String filelocation) {
		FILE_OUT_PROCESSLOCATION = filelocation;
	}

	@Value ("${file.process.error.directory}")
	public void setErrorDirName(String filelocation) {
		FILE_ERROR_PROCESSLOCATION = filelocation;
	}


	@Autowired
	JobInfoRepository jobInfoRepository;

	@Autowired
	IJobErrorDetailsService jobErrorDetailsService;

	@Autowired
	IReconSummary reconSummary;

	@Autowired
	JobResultRepository jobResultRepository;

	@Override
	public JobInfo save(JobInfo jobInfo) {
		try{
			JobInfo info = jobInfoRepository.save(jobInfo);
			logger.debug("Saved JobInfo with id : {}", info.getId());
			return info;
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
			
		}
	}

	@Override
	public JobInfo findById(String jobId) {
		try{
			return jobInfoRepository.findById(jobId).get();
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	@Override
	public JobInfo updateStatusAndGet(String jobId, JobStatus status) throws InvalidJobStatusException {
		logger.info("Updating Job information of {} for status: {}", jobId, status);
		try{
			JobInfo jobInfo = jobInfoRepository.findById(jobId).get();
			switch (status) {
			case STARTED:
				jobInfo.setStartedTime(new Date());
				break;
			case CREATED:
				jobInfo.setCreatedTime(new Date());
				break;
			case COMPLETED_SUCCESS:
				updateSummary(jobId, jobInfo);
				jobInfo.setFinishedTime(new Date());
				jobInfo.setProcessingTime(getTimeDifference(jobInfo.getFinishedTime(), jobInfo.getStartedTime()));
				createDirectoryAndMoveFile(jobInfo, status);
				break;
			case COMPLETED_FAILED:
				updateFatalErrorInfo(jobInfo, status);
				jobInfo.setFinishedTime(new Date());
				jobInfo.setProcessingTime(getTimeDifference(jobInfo.getFinishedTime(), jobInfo.getStartedTime()));
				createDirectoryAndMoveFile(jobInfo, status);
				break;
			default:
				break;
			}
			jobInfo.setStatus(status);
			save(jobInfo);
			return jobInfo;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * This method is used to find difference between start time and finished time after job execution
	 * @author prashant.dongare
	 * @param finishedTime - The name which holds the job finish time
	 * @param startedTime - The name which holds job start time
	 * @return diffInSeconds - The name which holds the difference finish and start time
	 * @throws Exception
	 */
	private long getTimeDifference(Date finishedTime, Date startedTime) throws Exception {
		long processingTime = finishedTime.getTime() - startedTime.getTime();
		long diffInSeconds = TimeUnit.MILLISECONDS.toSeconds(processingTime);
		logger.info("Processing time is======= {}", Long.valueOf(diffInSeconds));
		return diffInSeconds;
	}

	@Override
	public JobInfo updateStatus(String jobId, JobStatus status) {
		try{
			return updateStatusAndGet(jobId, status);
		} catch (InvalidJobStatusException e){
			throw new EngineException(e);
		}
	}

	@Override
	public List<JobInfo> findByStatus(JobStatus status) {
		try{
			return jobInfoRepository.findByStatus(status);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	@Override
	public void deleteById(String jobId) {
		try{
			jobInfoRepository.deleteById(jobId);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * This method is used for updating JobInfo with Error Reason
	 * @author prashant.dongare
	 * @param jobInfo - The name which holds the job information
	 * @param status - The name which holds the job status
	 */
	private void updateFatalErrorInfo(JobInfo jobInfo, JobStatus status) {
		final JobErrorDetails jobErrorDetails = jobErrorDetailsService.getjobErrorDetails(jobInfo.getId());
		if (jobErrorDetails == null){
			logger.error("No job errror deatils found for the jobId {} ", jobInfo.getId());
			ErrorReason errorReason = new ErrorReason();
			errorReason.setErrorCode(ExceptionCodes.SYSTEM_GENERAL_EXCEPTION);
			errorReason.setExceptionType("FATAL");
			jobInfo.setErrorReason(errorReason);
			jobInfo.setStatus(status);
			return;
		}
		String errorType = jobErrorDetails.getErrorType();
		if (errorType.equals("FATAL")){
			ErrorReason errorReason = new ErrorReason();
			errorReason.setErrorCode(jobErrorDetails.getReasonCode());
			errorReason.setExceptionType(jobErrorDetails.getErrorType());
			jobInfo.setErrorReason(errorReason);
		}
	}

	/**
	 * @param jobInfo - The name which holds the job information
	 * @param status - The name which holds the job status
	 */
	private void createDirectoryAndMoveFile(JobInfo jobInfo, JobStatus status) {
		if (jobInfo.getWorkflowType() == null || !jobInfo.getWorkflowType().equals("ETL")){
			return;
		}
		jobInfo.getJobTasks().forEach(tasks -> {
			tasks.getExecutionInfo().getStepInputs().values().forEach(stepInputs -> {
				File sourceFile = new File(stepInputs.get(0));
				if (sourceFile.exists() && sourceFile.isFile()){
					moveFileToProcessedLocation(jobInfo, status, sourceFile);
				}
			});
		});

	}

	/**
	 * @param jobInfo - The name which holds the job status
	 * @param status - The name which holds the job status
	 * @param sourceFile - The name which holds the name of source file
	 */
	private void moveFileToProcessedLocation(JobInfo jobInfo, JobStatus status, File sourceFile) {
		switch (status) {
		case COMPLETED_SUCCESS:
			moveFileAsPerStatus(jobInfo, sourceFile, createAndGetTargetProjectFolder(FILE_OUT_PROCESSLOCATION, jobInfo));
			break;
		case COMPLETED_FAILED:
			moveFileAsPerStatus(jobInfo, sourceFile, createAndGetTargetProjectFolder(FILE_ERROR_PROCESSLOCATION, jobInfo));
			break;
		default:
			break;
		}
	}

	/**
	 * @param targetFolderParent
	 * @param jobInfo - The name which holds the job information
	 * @return String
	 */
	private String createAndGetTargetProjectFolder(String targetFolderParent, JobInfo jobInfo) {
		return new StringBuilder(targetFolderParent).append(jobInfo.getProjectName()).append("-").append(jobInfo.getWorkflowName()).toString();
	}

	/**
	 * @param jobInfo - The name which holds the job information
	 * @param sourceFile
	 * @param targetFolder
	 */
	private void moveFileAsPerStatus(JobInfo jobInfo, File sourceFile, String targetFolder) {
		File mkdirectory = new File(targetFolder, jobInfo.getProjectName());
		if (!mkdirectory.exists()){
			if (mkdirectory.mkdir()){
				logger.debug("Output directory created");
			} else{
				logger.error("Output directory cannot be created");
			}
		}
		boolean ifFileAlreadyPresent = new File(mkdirectory, sourceFile.getName()).exists();
		if (ifFileAlreadyPresent){
			String filename = changeFileName(sourceFile);
			moveFileToDirectory(sourceFile.getAbsolutePath(), new File(targetFolder, filename).getAbsolutePath());
		} else{
			moveFileToDirectory(sourceFile.getAbsolutePath(), new File(targetFolder, sourceFile.getName()).getAbsolutePath());
		}
	}

	/**
	 * @param file
	 * @return
	 */
	public static String changeFileName(File file) {
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMMdd-HH:mm:ssz");
		String extension = getFileExtension(file);
		return new StringBuilder(file.getName()).append("-duplicate-").append(dateFormat.format(date)).append(".").append(extension).toString();
	}

	/**
	 * @param file
	 * @return
	 */
	private static String getFileExtension(File file) {
		String fileName = file.getName();
		String extn = "";
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0){
			extn = fileName.substring(fileName.lastIndexOf(".") + 1);
		}
		return (extn.length() > 4) ? "" : extn;
	}

	/**
	 * move file from source location to destination location which is file-out-process
	 * 
	 * @param srcFilePath
	 * @param destFilePath
	 */
	public static void moveFileToDirectory(String srcFilePath, String destFilePath) {
		try{
			logger.debug("Moving file from {} to {}", srcFilePath, destFilePath);
			Files.move(Paths.get(srcFilePath), Paths.get(destFilePath), StandardCopyOption.ATOMIC_MOVE);
			logger.debug("File moved!!");
		} catch (NoSuchFileException e){
			logger.error("File not present at location: {}", e.getMessage());
		} catch (FileAlreadyExistsException e){
			logger.error("File alerady present: {} ", e.getMessage());
		} catch (Exception e){
			logger.error("In exception in moveFileOutProcessDirectory: {}", e.getMessage());
		}
	}

	/**
	 * @param jobId - The name which holds the id of job from jobinfo document
	 * @param jobInfo - The name which holds the job information
	 */
	private void updateSummary(String jobId, JobInfo jobInfo) {
		if (jobInfo == null || jobInfo.getWorkflowType() == null){
			return;
		}
		if (jobInfo.getWorkflowType().equals(StepTypeConstants.ReconWorkflowType)){
			logger.debug("Job's workflowType is RECON. Updating Summary for Recon");
			reconSummary.updateBatchSummary(jobId);
		} else if (jobInfo.getWorkflowType().equals(StepTypeConstants.ETLWorkflowType)){
			logger.debug("Job's workflowType is ETL, Updating summary for ETL readCount, processedCount & errorCount at the jobInfo");
			calculateRecordProcessingStats(jobId, jobInfo);
		}
	}

	/**
	 * @param jobId - The name which holds the id of job from jobinfo document
	 * @param jobInfo - The name which holds the job information
	 */
	private void calculateRecordProcessingStats(String jobId, JobInfo jobInfo) {
		List<JobTaskExecutorResult> jobResultList = jobResultRepository.findByJobId(jobId);

		List<JobStatistics> jobStatistics = new ArrayList<>();
		jobResultList.stream().forEach(jobResult -> {
			jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> {
				stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					JobStatistics statistic = JobStatistics.builder().stepName(stepExecutorResult.getStepName()).stepType(stepExecutorResult.getStepType()).build();
					jobStatistics.add(statistic);
					if (stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						if (stepInstanceStats.getOutbound().getErrorCount() != null){
							Long countData = stepInstanceStats.getOutbound().getErrorCount();
							statistic.setErrorCount(Optional.ofNullable(statistic.getErrorCount()).orElse(Long.valueOf(0)) + countData);
						}
						if (stepInstanceStats.getOutbound().getDataCount() != null){
							Long countData = stepInstanceStats.getOutbound().getDataCount();
							statistic.setProcessedCount(Optional.ofNullable(statistic.getProcessedCount()).orElse(Long.valueOf(0)) + countData);
						}
					}
				});
			});
		});
		jobStatistics.stream().filter(jobStats -> jobStats.getStepType().equals(StepTypeConstants.FILE_READER_STEPTYPE)).collect(Collectors.toList()).stream().forEach(jobStat -> {
			jobInfo.setReadCount(jobStat.getProcessedCount() + jobStat.getErrorCount());
		});
		jobStatistics.stream().forEach(jobStat -> {
			jobInfo.setErrorCount(jobInfo.getErrorCount() + jobStat.getErrorCount());
		});
	}
}
