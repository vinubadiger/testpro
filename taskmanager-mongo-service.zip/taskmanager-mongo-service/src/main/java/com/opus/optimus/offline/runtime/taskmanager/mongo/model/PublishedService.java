package com.opus.optimus.offline.runtime.taskmanager.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection="PublishedService")
public class PublishedService {
	@Id
	String id;
	String projectName;
	String workflowName;
	String workflowType;
	WorkflowConfig workflowConfig;
	WorkflowExecutionConfig workflowExecutionConfig;
}
