package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.runtime.taskmanager.mongo.IPublishedWorkflowConfigService;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepositoryFactory;

@Service
public class WorkflowConfigRepositoryFactory implements IWorkflowConfigRepositoryFactory {

    @Autowired
    IPublishedWorkflowConfigService publishedWorkflowRepository;
    
    @Override
    public IWorkflowConfigRepository create(String groupId) {
        return new WorkflowConfigRepository(groupId, publishedWorkflowRepository);
    }
}
