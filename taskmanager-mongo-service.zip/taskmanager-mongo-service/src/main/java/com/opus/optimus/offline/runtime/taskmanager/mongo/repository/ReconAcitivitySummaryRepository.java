package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import java.util.Date;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;

@Repository
public interface ReconAcitivitySummaryRepository extends MongoRepository<ReconAcitivitySummary, String> {

	@Query (value = "{ $and: [ { 'activityName' : ?0 }, { 'projectName' : ?1 },{'processingDate' : ?2}, {'status' : ?3}, {'subStatus' : ?4} ] }")
	ReconAcitivitySummary findAcitivitySummary(String activityName, String projectName, Date processingDate, ReconStatus status, ReconSubStatus subStatus);
}
