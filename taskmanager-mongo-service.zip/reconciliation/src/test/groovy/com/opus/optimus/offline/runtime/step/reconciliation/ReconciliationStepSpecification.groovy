package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.DelegatorConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class ReconciliationStepSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    def "Reconciliation single rule test"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def builder = ReconciliationRuleConfig.builder()
        def Rule1 = "Rule1"
        def reconciliationRuleStepConfig = builder
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key'], 'source2': ['key']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()
        workflowConfig.stepConfigs = [source1Config, reconciliationRuleStepConfig]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Rule1)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

        emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
        emitter.emit(messageFactory.createEndMessage())
        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(Rule1).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        def reconciliationResult = receivedData.get(0)

        reconciliationResult.getType() == MatchedResultType.MATCHED
        reconciliationResult.getRuleId() == 'Rule1'
        reconciliationResult.getRuleType() == RuleType.PERFECT

        def selectedRecords = reconciliationResult.getSelectedRecords()
        selectedRecords.get('source1').size() == 1
        selectedRecords.get('source2').size() == 1

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 2

        def rule1Result = stepExecutionResults.grep { it -> it.stepName == Rule1 }
        rule1Result != null
        rule1Result.size() == 1
        2 == rule1Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        receivedData.size() == rule1Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
        println jobTaskExecutorResult
    }

    def "Reconciliation multiple rule test"() {
        setup:
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def Source2 = "Source2"
        def source2Config = new CsvBasedMapRecordStepConfig(Source2)

        def Rule1 = "Rule1"
        def reconciliationRule1StepConfig = ReconciliationRuleConfig.builder()
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key1'], 'source2': ['key1']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()

        def Rule2 = "Rule2"
        def reconciliationRule2StepConfig = ReconciliationRuleConfig.builder()
                .stepName(Rule2)
                .ruleGroupName(Rule2)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key2'], 'source2': ['key2']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule2', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField2', 'matchField3']))])
                .build()

        def Reconciliation = 'Reconciliation'
        def reconciliationStepConfig = new TestReconciliationStepConfig(Reconciliation,
                [reconciliationRule1StepConfig, reconciliationRule2StepConfig])

        def Collector = 'Collector'
        def collectorStep = new DelegatorConfig(Collector)

        def input1 = '/reconciliation_input1.csv'
        def input2 = '/reconciliation_input2.csv'

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [source1Config, source2Config, reconciliationStepConfig, collectorStep]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Reconciliation),
                new StepLink(Source2, Reconciliation),
                new StepLink(Reconciliation, Collector)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
/*
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule2, new LocalStepExecutorConfig(1, 1, null))

        def repository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowExecutionConfig("JOB_TASK_1", Reconciliation + '.subworkflow', workflowExecutionConfig);
*/

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def source1Emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()
        def source2Emitter = localJobTaskExecutor.getInBoundQueue(Source2).getEmitter()

        source1Emitter.emit(messageFactory.createMessage(input1))
        source2Emitter.emit(messageFactory.createMessage(input2))

        source1Emitter.emit(messageFactory.createEndMessage())
        source2Emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(Collector).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 5

        println jobTaskExecutorResult
    }

}
