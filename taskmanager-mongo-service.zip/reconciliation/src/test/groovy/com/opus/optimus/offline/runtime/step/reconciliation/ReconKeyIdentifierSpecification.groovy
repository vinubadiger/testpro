package com.opus.optimus.offline.runtime.step.reconciliation


import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.step.reconciliation.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.step.reconciliation.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class ReconKeyIdentifierSpecification extends Specification {

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    Utility utility;
	
	@Autowired
	IMessageFactory messageFactory

    def "Recon Key Identifier test"() {
        setup:
        def sourceA_Name = "Amex"
        def sourceB_Name = "PaymentTech"

        //set up step config
        def keyIdenfierConfigJsonStream = getClass().getResourceAsStream("/reconKeyIdentifierConfig.json")
        def keyIdenfierConfig = mapperFactory.getMapper().readValue(keyIdenfierConfigJsonStream, ReconKeyIdentifierConfig.class)
        def keyIdentifier = new ReconKeyIdentifier(keyIdenfierConfig.getOrClause())
        //set up the record
        def amexRecord = buildSampleAmexRecord(sourceA_Name)
        def paymentTechRecord = buildSamplePaymentTechRecord(sourceB_Name)
        when:
        println(amexRecord)
        def amexKey = keyIdentifier.getKey(messageFactory.createMessage(amexRecord))
        def paymentTechKey = keyIdentifier.getKey(messageFactory.createMessage(paymentTechRecord))
        then:
        println("Amex Key: " + amexKey)
        println("PaymentTech Key: " + paymentTechKey)
        amexKey == "000000001-250"
        paymentTechKey == "000000001-250"
        amexKey == paymentTechKey
    }

    def "buildSampleAmexRecord"(def sourceName) {
        List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("recordReferenceID")
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("payAmount")
                .type(FieldType.FLOAT)
                .build());

        utility.buildRecordMetaData(recordFieldConfigs, sourceName);
        Map<String, Object> testRecordFieldValues = new HashMap<>();
        testRecordFieldValues.put("recordReferenceID", "000000001");
        testRecordFieldValues.put("payAmount", "250");
        return utility.buildRecord(recordFieldConfigs, testRecordFieldValues, sourceName);
    }

    def "buildSamplePaymentTechRecord"(def sourceName) {
        List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("refId")
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("amt")
                .type(FieldType.FLOAT)
                .build());

        utility.buildRecordMetaData(recordFieldConfigs, sourceName);
        Map<String, Object> testRecordFieldValues = new HashMap<>();
        testRecordFieldValues.put("refId", "000000001");
        testRecordFieldValues.put("amt", "250");
        return utility.buildRecord(recordFieldConfigs, testRecordFieldValues, sourceName);
    }

}
