package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.queue.api.IEmitter
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.MessageType
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("CsvBaseMapRecordStep")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class CsvBasedMapRecordPublisher extends AbstractStep<CsvBasedMapRecordStepConfig> {
    @Autowired
    IMessageFactory messageFactory

    CsvBasedMapRecordPublisher(CsvBasedMapRecordStepConfig config) {
        super(config)
    }

    @Override
    void process(IMessage message, IEmitter emitter) {
        String fileName = message.getData()
        List<Map<String, Object>> records = CsvUtil.instance.getAllRecords(fileName)
        records.each {
            emitter.emit(messageFactory.createMessage(MessageType.DATA, it))
        }
    }
}
