package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.DelegatorConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class ReconciliationStepWithDBReaderSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    def "Reconciliation single rule test with json"() {
        setup:
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def Source2 = "Source2"
        def source2Config = new CsvBasedMapRecordStepConfig(Source2)

        def Rule1 = "Rule1"
        def reconciliationRule1StepConfig = ReconciliationRuleConfig.builder()
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key1'], 'source2': ['key1']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                //.rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()

        def Reconciliation = 'Reconciliation'
        def reconciliationStepConfig = new TestReconciliationStepConfig(Reconciliation,
                [reconciliationRule1StepConfig])

        def Collector = 'Collector'
        def collectorStep = new DelegatorConfig(Collector)

        def input1 = '/reconciliation_input1.csv'
        def input2 = '/reconciliation_input2.csv'

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [source1Config, source2Config, reconciliationStepConfig, collectorStep]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Reconciliation),
                new StepLink(Source2, Reconciliation),
                new StepLink(Reconciliation, Collector)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
/*
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule2, new LocalStepExecutorConfig(1, 1, null))

        def repository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowExecutionConfig("JOB_TASK_1", Reconciliation + '.subworkflow', workflowExecutionConfig);
*/

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def source1Emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()
        def source2Emitter = localJobTaskExecutor.getInBoundQueue(Source2).getEmitter()

        source1Emitter.emit(messageFactory.createMessage(input1))
        source2Emitter.emit(messageFactory.createMessage(input2))

        source1Emitter.emit(messageFactory.createEndMessage())
        source2Emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(Collector).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		
		println receivedData
        receivedData.size() == 6

        println jobTaskExecutorResult
    }

}
