package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;

public class BeanHelper {
    static private ScriptCreatorFactory scriptCreatorFactory;

    public static ScriptCreatorFactory getScriptCreatorFactory() {
        return scriptCreatorFactory;
    }

    public static void setScriptCreatorFactory(ScriptCreatorFactory scriptCreatorFactory) {
        BeanHelper.scriptCreatorFactory = scriptCreatorFactory;
    }
}
