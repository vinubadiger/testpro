package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opus.optimus.offline.config.recon.SourceMappingType;
import com.opus.optimus.offline.config.recon.subtypes.AndClause;
import com.opus.optimus.offline.config.recon.subtypes.MatchingRule;
import com.opus.optimus.offline.runtime.workflow.api.IEmbeddedSubWorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import com.opus.optimus.offline.runtime.workflow.api.impl.EndStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.StartStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.StepLink;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReconciliationConfig implements IStepConfig, IEmbeddedSubWorkflowConfig {
    public static final String STEP_TYPE = "ReconciliationConfig";

    private static final long serialVersionUID = 1L;

    public enum UnitType {
        DAY, WEEK
    }

    private SourceMappingType sourceMapping; // reconType (OneToOne, OneToMany, ManyToOne, ManyToMany)
    private boolean unreconciledBacklog;
    private int timeLegInterval;
    private UnitType unit; // day/week
    private String stepName;
    private String stepType;
    private List<MatchingRule> matchingRules;
    private String activityName;
    
    @Override
    public String getStepType() {
        return STEP_TYPE;
    }

    @JsonIgnore
    @Override
	public WorkflowConfig getWorkflowConfig() {
		List<IStepConfig> iStepConfigs = new ArrayList<>();
		final List<ReconciliationRuleConfig> ruleStepConfigs = getRuleStepConfigs();
		iStepConfigs.addAll(ruleStepConfigs);

		final StartStepConfig startStepConfig = new StartStepConfig();
		iStepConfigs.add(startStepConfig);

		final EndStepConfig endStepConfig = new EndStepConfig();
		iStepConfigs.add(endStepConfig);

		final List<IStepLink> stepLinks = IntStream.range(0, ruleStepConfigs.size() - 1).mapToObj(ruleConfigIndex -> {
			final String from = ruleStepConfigs.get(ruleConfigIndex).getStepName();
			final String to = ruleStepConfigs.get(ruleConfigIndex + 1).getStepName();
			final String unwrapName = from + ".unWrap";
			iStepConfigs.add(new UnWrapReconciliationMatchedResultConfig(unwrapName));
			return Arrays.asList(
					new StepLink(from, unwrapName,
							new MatchedResultTypeScriptConfig(Arrays.asList(MatchedResultType.NO_DATA_IN_SOURCE))),
					new StepLink(unwrapName, to), new StepLink(from, endStepConfig.getStepName()));
		}).flatMap(stepLinkArrs -> stepLinkArrs.stream()).collect(Collectors.toList());

		stepLinks.add(new StepLink(startStepConfig.getStepName(), ruleStepConfigs.get(0).getStepName()));
		stepLinks.add(new StepLink(ruleStepConfigs.get(ruleStepConfigs.size() - 1).getStepName(),
				endStepConfig.getStepName()));
		return WorkflowConfig.builder().name(stepName + ".subworkflow").stepConfigs(iStepConfigs).stepLinks(stepLinks)
				.startStepName(startStepConfig.getStepName()).endStepName(endStepConfig.getStepName()).build();
	}

	/**
	 * This method is used to fetch rule step configuration
	 * @return List<ReconciliationRuleConfig>
	 */
	private List<ReconciliationRuleConfig> getRuleStepConfigs() {
		return matchingRules.stream().map(this::createReconciliationRuleStepConfig).collect(Collectors.toList());
	}

	/**
	 * This method is used to create reconciliation rule step configuration
	 * @param matchingRule
	 * @return ReconciliationRuleConfig
	 */
	private ReconciliationRuleConfig createReconciliationRuleStepConfig(MatchingRule matchingRule) {
        return ReconciliationRuleConfig.builder()
        		.ruleGroupName(matchingRule.getRuleId())
        		.ruleMatchType(getRuleType())
        		.sourceNames(identifySources()) //TODO In future UI will set the sources for this rule in the config.
                .stepName(stepName + "." + matchingRule.getRuleId())
                .keyIdentifier(new ReconKeyIdentifier(matchingRule.getMatchingClause()))
                // TODO
                .build();
    }

	/**
	 * This method is used to identify the sources
	 * @return List<String>
	 */
	private List<String> identifySources() {
		final List<String> sources = new ArrayList();
		List<AndClause> andClauses = this.matchingRules.get(0).getMatchingClause().getAndClauses();
		sources.add(andClauses.get(0).getLhsField().getSourceName());
		sources.add(andClauses.get(0).getRhsField().getSourceName());
		return sources;
	}

	/**
	 * This method is used to get the rule type
	 * @return RuleMatchType
	 */
	private RuleMatchType getRuleType() {
		switch(this.sourceMapping) {
			case OneToOne:
				return RuleMatchType.ONE_TO_ONE;
			case OneToMany:
				return RuleMatchType.ONE_TO_N;
			case ManyToOne:
				return RuleMatchType.N_TO_ONE;
			case ManyToMany:
				return RuleMatchType.N_TO_N;
			default:
				return null; //TODO throw exveption
		}
	}

}
