package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.collections.api.bag.Bag;
import org.eclipse.collections.api.list.MutableList;
import org.eclipse.collections.api.multimap.list.MutableListMultimap;
import org.eclipse.collections.impl.factory.Multimaps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;

public abstract class AbstractReconciliationRuleStep<T, C extends ReconciliationRuleConfig<T>> extends AbstractStep<C> {
	private static final Logger logger = LoggerFactory.getLogger(AbstractReconciliationRuleStep.class);
    MutableListMultimap<String, T> keyBasedRecords = Multimaps.mutable.list.empty();
    private static final int noOfSources = 2;

    public AbstractReconciliationRuleStep(C config) {
        super(config);
    }

    protected void collectRecords(T record) {
        String key = getKey(record);
        logger.debug("Key generated for Record received for recon collection : {}", key);
        keyBasedRecords.put(key, record);
    }

    protected void processAllRecords() {
        logger.info("No of records received for processing: {}", keyBasedRecords.size());
    	for (String key : keyBasedRecords.keySet()) {
            MutableList<T> singleKeyRecords = keyBasedRecords.get(key);
            emitResult(matchRecords(singleKeyRecords));

        }
    }

    protected ReconciliationMatchResult<T> matchRecords(MutableList<T> records) {
        MutableListMultimap<String, T> sourceBasedRecords = records.groupBy(this::getSource);
        RuleMatchType matchType = getRuleMatchType();
        switch (matchType) {
            case ONE_TO_ONE:
                return processOneToOneRule(sourceBasedRecords);
            case ONE_TO_N:
                return processOneToNRule(sourceBasedRecords);
            case N_TO_ONE:
                return processNToOneRule(sourceBasedRecords);
            case N_TO_N:
                return processNToNRule(sourceBasedRecords);
            default:
                throw new EngineException("Invalid rule match type " + matchType);
        }
    }

    private ReconciliationMatchResult<T> processOneToOneRule(MutableListMultimap<String, T> sourceBasedRecords) {
        logger.info("Processing for One-to-One matching type.");
    	Bag<String> sources = sourceBasedRecords.keyBag();
        if (sources.size() < noOfSources) {
            logger.debug("Received recon record is failed with status as NO_DATA_IN_SOURCE.");
        	// Return less data to compare
            return new ReconciliationMatchResult<T>(MatchedResultType.NO_DATA_IN_SOURCE, convertToMapOfList(sourceBasedRecords));
        }

        Bag<String> moreThanOneRecords = sources.selectByOccurrences((occurrence) -> occurrence > 1);
  

        if (moreThanOneRecords.size() > 0) {
        	logger.debug("Received recon record is failed with status as UNEXPECTED_MULTIPLE_RECORDS.");
            // Return MULTIPLE_RECORD

            return new ReconciliationMatchResult<>(MatchedResultType.UNEXPECTED_MULTIPLE_RECORDS, convertToMapOfList(sourceBasedRecords));
        }

        List<String> sourceNames = config.getSourceNames();
        String source1 = sourceNames.get(0);
        String source2 = sourceNames.get(1);
        if(config.getRules() == null || config.getRules().isEmpty()) {
        	logger.info("No tolerance rules configured to verify. Hence this record will be considered as exact match.");
			return new ReconciliationMatchResult<>(MatchedResultType.PERFECT, config.getRuleGroupName(), RuleType.PERFECT,
					convertToMapOfList(sourceBasedRecords), null);
        } else {
        	logger.info("Tolerance rules configured to verify. This record will be checked against the rules to match.");
        }
        
        for (ReconciliationRule<T> rule : config.getRules()) {
            T source1Data = sourceBasedRecords.get(source1).get(0);
            T source2Data = sourceBasedRecords.get(source2).get(0);
            RecordMatcherResult matcherResult = rule.getRecordMatcher().check(source1Data, source2Data);
            if (matcherResult.matches) {
            	logger.debug("Received recon record is succeed with status as MATCHED.");
            	return new ReconciliationMatchResult<>(MatchedResultType.MATCHED,
                        rule.getId(), matcherResult.getType(),
                        convertToMapOfList(sourceBasedRecords),
                        matcherResult.getSupportingData());
            }
        }
        logger.debug("Received recon record is failed with status as UNMATCHED.");
        return new ReconciliationMatchResult<>(MatchedResultType.UNMATCHED,
                config.getRuleGroupName(), null,
                convertToMapOfList(sourceBasedRecords), null);
    }

    private Map<String, List<T>> convertToMapOfList(MutableListMultimap<String, T> sourceBasedRecords) {
        Map<String, List<T>> convertedResult = new HashMap<>();
        for (String key : sourceBasedRecords.keySet()) {
            convertedResult.put(key, sourceBasedRecords.get(key));
        }

        return convertedResult;
    }

    private ReconciliationMatchResult<T> processOneToNRule(MutableListMultimap<String, T> sourceBasedRecords) {
        throw new EngineException("1 to N rule not supported");
    }

    private ReconciliationMatchResult<T> processNToOneRule(MutableListMultimap<String, T> sourceBasedRecords) {
        throw new EngineException("N to 1 rule not supported");
    }

    private ReconciliationMatchResult<T> processNToNRule(MutableListMultimap<String, T> sourceBasedRecords) {
        throw new EngineException("N to N rule not supported");
    }

    protected String getKey(T record) {
        return config.getKeyIdentifier().getKey(record);
    }

    protected RuleMatchType getRuleMatchType() {
        return config.getRuleMatchType();
    }

    protected abstract void emitResult(ReconciliationMatchResult<T> matchRecords);

    protected abstract String getSource(T record);

}

