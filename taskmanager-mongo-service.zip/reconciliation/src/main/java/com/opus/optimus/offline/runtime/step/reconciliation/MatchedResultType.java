package com.opus.optimus.offline.runtime.step.reconciliation;

public enum MatchedResultType {
    NO_DATA_IN_SOURCE, UNEXPECTED_MULTIPLE_RECORDS, PERFECT, MATCHED, UNMATCHED
}
