package com.opus.optimus.offline.runtime.step.reconciliation;

public interface IRecordMatcher<T> {
    RecordMatcherResult check(T lhs, T rhs);
}
