package com.opus.optimus.offline.runtime.step.reconciliation;

public enum RuleType {
    PERFECT, TOLERANCE
}
