package com.opus.optimus.offline.runtime.step.reconciliation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ReconciliationMatchResult<T> implements Serializable {
    MatchedResultType type;
    String ruleId;
    RuleType ruleType;
    Map<String, List<T>> selectedRecords;
    Map<String, Serializable> supportingData;

    public ReconciliationMatchResult(MatchedResultType type, Map<String, List<T>> selectedRecords) {
        this.type = type;
        this.selectedRecords = selectedRecords;
    }
}
