package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class ReconciliationRuleStepConfig<T> implements IStepConfig {
	private static final long serialVersionUID = 1L;

	public final static String STEP_TYPE = "ReconciliationRule";

    String stepName;

    @Builder.Default
    String stepType = STEP_TYPE;

    List<String> sourceNames;
    IKeyIdentifier keyIdentifier;
    RuleMatchType ruleMatchType;
    List<ReconciliationRule<T>> rules;
}
