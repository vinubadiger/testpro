package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UnWrapReconciliationMatchedResultConfig implements IStepConfig {
    public static final String STEP_TYPE = "UnWrapReconciliationMatchedResult";
    String stepName;
    String stepType = STEP_TYPE;

    public UnWrapReconciliationMatchedResultConfig(String stepName) {
        this.stepName = stepName;
    }
}
