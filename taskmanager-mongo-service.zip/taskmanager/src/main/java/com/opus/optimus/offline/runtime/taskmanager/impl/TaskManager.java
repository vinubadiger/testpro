package com.opus.optimus.offline.runtime.taskmanager.impl;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobResultService;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManager;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobIdException;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager;
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper;

/**
 * This class is used for managing the all the task which are related to job that is create, run ,cancel job and
 * fetching the job information and job result.
 *
 */
@Component
public class TaskManager implements ITaskManager, ITaskManagerAdmin, IRawTaskManagerListener {
	private static Logger logger = LoggerFactory.getLogger(TaskManager.class);

	@Autowired
	IRawTaskManager rawTaskManager;

	@Autowired
	IJobInfoService jobInfoService;

	@Autowired
	IJobResultService jobResultService;

	@Autowired (required = false)
	IJobEventManager jobEventManager;

	JobEventEmitterHelper jobEventEmitterHelper;

	@PostConstruct
	void init() {
		if (this.jobEventManager != null){
			this.jobEventEmitterHelper = new JobEventEmitterHelper(this.jobEventManager.getEmitter());
		}
	}

	@Override
	public void start() {
		this.rawTaskManager.addListener(this);
		this.rawTaskManager.start();
	}

	@Override
	public void stop() {
		this.rawTaskManager.stop();
		this.rawTaskManager.removeListener(this);
	}

	@Override
	public String createJob(String name, List<JobTask> jobTasks) {
		try{
			String jobId = this.rawTaskManager.generateJobId();
			JobInfo jobInfo = JobInfo.builder().id(jobId).name(name).jobTasks(jobTasks).status(JobStatus.CREATED).createdTime(new Date()).build();
			this.jobInfoService.save(jobInfo);
			return jobId;
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	@Override
	public CompletableFuture<JobResult> runJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException {
		logger.debug("Starting Run Job for JobID {}", jobId);
		JobInfo jobInfo = this.jobInfoService.updateStatusAndGet(jobId, JobStatus.WAITING_TO_START);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		try{
			logger.debug("Submitting Job with JobID {}", jobId);
			CompletableFuture<Void> result = this.rawTaskManager.submitJob(jobId, jobInfo.getJobTasks());
			return result.thenApply(v -> this.jobResultService.findById(jobId));
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	@Override
	public void cancelJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException {
		JobInfo jobInfo = this.jobInfoService.updateStatusAndGet(jobId, JobStatus.CANCEL_IN_PROGRESS);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		this.rawTaskManager.cancelJob(jobId);
	}

	@Override
	public JobInfo getJobInfo(String jobId) throws InvalidJobIdException {
		JobInfo jobInfo = this.jobInfoService.findById(jobId);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		return jobInfo;
	}

	@Override
	public List<JobInfo> getJobInfos(JobStatus jobStatus) {
		return this.jobInfoService.findByStatus(jobStatus);
	}

	@Override
	public JobResult getJobResult(String jobId) throws InvalidJobIdException {
		JobResult jobResult = this.jobResultService.findById(jobId);
		if (jobResult == null){
			throw new InvalidJobIdException(jobId);
		}

		return jobResult;
	}

	@Override
	public void onTaskStart(String jobId, String taskId) {
		logger.info("Task started with JobId {} & TaskId {}", jobId, taskId);
	}

	@Override
	public void onTaskComplete(String jobId, String taskId) {
		logger.info("Task completed with JobId {} & TaskId {}", jobId, taskId);
	}

	@Override
	public void onJobStart(String jobId) {
		this.jobInfoService.updateStatus(jobId, JobStatus.STARTED);

		if (this.jobEventEmitterHelper != null){
			this.jobEventEmitterHelper.startJob(jobId);
		}
	}

	@Override
	public void onJobComplete(String jobId) {
		try{
			final JobResult jobResult = getJobResult(jobId);

			boolean isJobAborted = jobResult.getTaskResults().stream().anyMatch(taskResult -> {
				return taskResult.getStepExecutorResults().stream().anyMatch(executorResult -> {
					return executorResult.getInstanceStats().anySatisfy(instanceStat -> OperationStatus.ABORTED.equals(instanceStat.getStatus()));
				});
			});

			if (isJobAborted){
				updateJobInfoStatus(jobId, JobStatus.COMPLETED_FAILED);
			} else{
				updateJobInfoStatus(jobId, JobStatus.COMPLETED_SUCCESS);
			}
		} catch (InvalidJobIdException e){
			logger.error(e.getMessage(), e);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
		}
	}

	private void updateJobInfoStatus(String jobId, JobStatus jobStatus) {
		jobInfoService.updateStatus(jobId, jobStatus);
		if (jobEventEmitterHelper != null){
			jobEventEmitterHelper.endJob(jobId, jobStatus.name());
		}
	}

	@Override
	public JobResult saveJobTaskResult(String jobId, String jobTaskId, JobTaskExecutorResult jobTaskExecutorResult) {
		return jobResultService.saveJobTaskResult(jobId, jobTaskId, jobTaskExecutorResult);
	}

	@Override
	public void deleteById(String jobId) {
		this.jobInfoService.deleteById(jobId);
	}

}
