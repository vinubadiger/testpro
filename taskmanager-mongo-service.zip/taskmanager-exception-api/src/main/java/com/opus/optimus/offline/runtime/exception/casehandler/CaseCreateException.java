package com.opus.optimus.offline.runtime.exception.casehandler;

public class CaseCreateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CaseCreateException(String message, Throwable exception) {
		super(message, exception);
	}

}
