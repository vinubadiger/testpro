package com.opus.optimus.offline.runtime.exception.config;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DefaultErrorHandlerStepConfig implements IStepConfig {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String stepName;
	String caseCreator;
	String stepType;

	@Override
	public String getStepType() {
		return StepTypeConstants.DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE;
	}

}
