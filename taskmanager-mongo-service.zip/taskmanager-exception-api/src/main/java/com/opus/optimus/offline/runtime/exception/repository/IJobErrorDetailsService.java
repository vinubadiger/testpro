package com.opus.optimus.offline.runtime.exception.repository;

import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;

public interface IJobErrorDetailsService {
	void logErrorDetails(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo);
	
	JobErrorDetails getjobErrorDetails(String jobId);
}
