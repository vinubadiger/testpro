package com.opus.optimus.offline.runtime.exception.config;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Data;

@Data
public class SalesForceCaseCreatorStepConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;
	String stepName;
	String stepType;
	
	@Override
	public String getStepType() {
		return StepTypeConstants.SALESFORCE_CASE_CREATOR;
	}

}
