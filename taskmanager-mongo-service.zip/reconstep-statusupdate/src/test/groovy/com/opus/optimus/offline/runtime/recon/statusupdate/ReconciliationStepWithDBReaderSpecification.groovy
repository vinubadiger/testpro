package com.opus.optimus.offline.runtime.recon.statusupdate

import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.TestStatusUpdateConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.db.MongoDBReaderHelper
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.DelegatorConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestStatusUpdateConfiguration.class)
class ReconciliationStepWithDBReaderSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	MongoDBReaderHelper mongoDBReaderHelper

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

    @Autowired
    IMessageFactory messageFactory
    
    @SpringBean
    IJobInfoService jobService = Mock();

    def "Reconciliation single rule test with json"() {
		setup:		
		def mapper = mapperFactory.getMapper()
		//register the data source
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

		//set up embedded mongo
		def dbHostIP = "localhost";
		def dbPort = 27017;

		MongodStarter starter = MongodStarter.getDefaultInstance();
		IMongodConfig mongodConfig = new MongodConfigBuilder()
				.version(Version.Main.DEVELOPMENT)
				.net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
				.build();

		def mongodExecutable = starter.prepare(mongodConfig);
		def mongod = mongodExecutable.start();
				
		//initialize data source factory
		mongoDataSource.init();
		dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);
		def mongoDataBase = mongoDataSource.getDatabase();

		def workflowConfigStream = getClass().getResourceAsStream("/MultiStepJson.json")
		def workflowConfig = mapper.readValue(workflowConfigStream, WorkflowConfig.class)

        def workflowExecutionConfig = new WorkflowExecutionConfig()
/*
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule2, new LocalStepExecutorConfig(1, 1, null))

        def repository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowExecutionConfig("JOB_TASK_1", Reconciliation + '.subworkflow', workflowExecutionConfig);
*/
		//insert Amex sample records to mongo db
		loadSampleData("amexcoll", "/sampleTransactionData_amexcoll.txt", mongoDataBase)
		loadSampleData("paymentcoll", "/sampleTransactionData_paymentcoll.txt", mongoDataBase)
		
		
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        
        jobService.findById(_ as String) >> { new JobInfo();}

        when:
        def result = localJobTaskExecutor.execute()
        def source1Emitter = localJobTaskExecutor.getInBoundQueue("Source-A").getEmitter()
        def source2Emitter = localJobTaskExecutor.getInBoundQueue("Source-B").getEmitter()

        source1Emitter.emit(messageFactory.createMessage(""))
        source2Emitter.emit(messageFactory.createMessage(""))

        source1Emitter.emit(messageFactory.createEndMessage())
        source2Emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue("ReconStatusUpdateStepName").get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		
		println receivedData
        receivedData.size() == 5
    }

	def loadSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			println("db object" + dbObject)
			collection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
	}
}
