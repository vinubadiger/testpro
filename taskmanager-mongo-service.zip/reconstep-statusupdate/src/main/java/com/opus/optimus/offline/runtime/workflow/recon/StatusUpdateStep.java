package com.opus.optimus.offline.runtime.workflow.recon;

import java.io.Serializable;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.text.StringSubstitutor;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.CaseCreation;
import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo;
import com.opus.optimus.offline.config.recon.subtypes.ReconControlInfo;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SummaryField;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.reader.MongoDBReaderStep;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.exception.utility.CaseCreationAuthImpl;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.step.reconciliation.MatchedResultType;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.ReconCaseTemplateSevice;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.ReconCaseTemplate;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceSummary;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

import lombok.Getter;

/**
 * This class is used to update the job reconciliation  status after the run of 
 * reconciliation complete.
 *
 */
@Component(StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE)
@Scope ("prototype")
public class StatusUpdateStep extends MapStep<ReconStatusUpdateConfig> implements IJobTaskInfoAware {

	private static final String CASE_ID = "caseID";
	private static final String SOURCE_A = "sourceA";
	private static final String SOURCE_B = "sourceB";

	private final int MAX_BATCH_COMMIT_SIZE = 512;

	private static final Logger logger = LoggerFactory.getLogger(StatusUpdateStep.class);
	private static final String RECONCTRLFIELDNAME = "reconControlFields";

	private static final String RECONCTRLFIELDNAME_PROCESSINGDATE = "processingDate";
	
/*	private static final String SOURCEA = "SourceA";
	private static final String SOURCEB = "SourceB";
	private static final String SOURCEAAmount = "SourceAAmt";
	private static final String SOURCEBAmount = "SourceBAmt";
	private static final String AMTDIFF = "AmtDiff";
*/
	@Getter
	private ReconStatusUpdateConfig config;

	@Autowired
	private DataSourceFactory dataSourceFactory;

	@Autowired
	RecordFactory recordFactory;
	
	@Autowired
	IJobInfoService jobInfoService;
	
	@Autowired
	ReconCaseTemplateSevice reconCaseTemplateService;
		
	@Autowired
	CaseCreationAuthImpl caseCreationAuthImpl;
	
	JobInfo jobInfo = null;
	
	Map<String, SourceConfig> sourceConfigMap = new HashMap<String, SourceConfig>();
	Map<String, Integer> summaryFieldInfo = new HashMap<String, Integer>();
	Map<String, String> sourceCounterPart = new HashMap<String, String>();
	Map<String, String> caseDescTemplates = null;
	
	IJobTaskInfo jobTaskInfo;
	
	public class SourceConfig {
		BulkOperations bulkOps;
		int currBulkCommandSize = 0;
		int summaryfieldID;
		
		/**
		 * This method is used for adding update command.
		 * @param query
		 * @param update
		 */
		void addUpdateCommand(Query query, Update update) {
			bulkOps.updateOne(query, update);
			currBulkCommandSize++;
		}
		
		/**
		 * This method is used for commit operation.
		 * @param force
		 */
		void commit(boolean force) {
			if ((force && currBulkCommandSize > 0) || (currBulkCommandSize >= MAX_BATCH_COMMIT_SIZE)) {
				bulkOps.execute();
				currBulkCommandSize = 0;
			}
		}
	}
	
	public StatusUpdateStep(ReconStatusUpdateConfig config) {
		super(config);
		this.config = config;
	}

	@PostConstruct
	public void init() throws Exception {
		try {
			sourceCounterPart.put(config.getSourceA().getSourceName(), config.getSourceB().getSourceName());
			sourceCounterPart.put(config.getSourceB().getSourceName(), config.getSourceA().getSourceName());
			
			buildSummaryInfo(config.getSourceA());
		} catch (Exception exception) {
			logger.error("Error while initialization of the Summary Info for Source : {}", config.getSourceA().getSourceName());
		}
		try {
			buildSummaryInfo(config.getSourceB());
		} catch (Exception exception) {
			logger.error("Error while initialization of the Summary Info for Source : {}", config.getSourceB().getSourceName());
		}
	}

	/**
	 * This method is used to build the summary information.
	 * @param summaryField
	 */
	private void buildSummaryInfo(SummaryField summaryField) {
		ISchema schema = recordFactory.getSchema(summaryField.getSourceName());
		if(schema == null) return;
		int index = 0;
		for(IFieldSchema fieldSchema : schema.getFields()) {
			if (fieldSchema.getName().equalsIgnoreCase(summaryField.getFieldName())) {
				summaryFieldInfo.put(summaryField.getSourceName(), index);
				break;
			}
			index++;
		}
	}
	
	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}

	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		try {
			if(summaryFieldInfo.get(config.getSourceA().getSourceName()) == null &&
					summaryFieldInfo.get(config.getSourceB().getSourceName()) == null) {
				logger.debug("Summary info is not initialized. Initializing summary info...");
				init();
			}
			if (jobInfo == null){
				jobInfo = jobInfoService.findById(jobTaskInfo.getJobId());
				
				// call service to get templates
				String projectName = jobInfo.getProjectName();
				String activityName = config.getActivityName();
				caseDescTemplates = reconCaseTemplateService.findByProjectNameandActivityName(projectName, activityName);				
			}
			
			if (data instanceof ReconciliationMatchResult) {
				ReconciliationMatchResult<IMessage> reconResult = (ReconciliationMatchResult<IMessage>)data;

				setupBulkOps(reconResult);
				logger.debug("Result received with Type: {}", reconResult.getType());
				switch (reconResult.getType()) {
					case PERFECT: 
					case MATCHED: {
						updateReconciledRecords(reconResult);
						break;
					}
					case NO_DATA_IN_SOURCE: {
						updateUnReconciledRecords(reconResult);
						break;
					}
					case UNMATCHED: {
						updateUnReconciledRecords(reconResult);
						break;
					}
					case UNEXPECTED_MULTIPLE_RECORDS: {
						createCase(reconResult);
						updateUnReconciledRecords(reconResult);
						break;
					}
					default :{
						logger.debug("In the default case...");
						break;
					}
				}
			} else {
				logger.error(
						"The data received in incorrect format. Received: {}, Expected: com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult",
						(data == null ? "No info available." : data.getClass().getName()));
			}
		} catch (RecordProcessingException e) {
			logger.error("Error while processing the record for Status update.", e);
			throw e;			
		} catch (Exception e) {
			logger.error("System error while processing the record for Status update.", e);
			ErrorDetails errorDetails = ErrorDetails.builder().userDetails("System Exception while update. Error message: " + e.getMessage())
					.errorDetail(e).severity(Severity.ERROR).build();
			throw new RecordProcessingException(errorDetails);
		}
		return (R)data;
	}
	
	@Override
	public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
		sourceConfigMap.forEach((sourceName, sourceConfig) -> {
			sourceConfig.commit(true);			
		});

		sourceConfigMap.clear();
		return super.onInstanceEnd(forceEnd, emitter);
	}
	
	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		super.onStepEnd(forceEnd, emitter);
	}
	
	/**
	 * This method is used to set up the bulk operations.
	 * @param reconResult
	 * @throws RecordProcessingException
	 */
	void setupBulkOps(ReconciliationMatchResult<IMessage> reconResult) throws RecordProcessingException {
		if (sourceConfigMap.size() >= 2) {
			return;
		}
		
		String dsName = "";
		try {
			for(Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet())  {
				String sourceName = entry.getKey();
				List<IMessage> selectedMessages = entry.getValue();
				if (sourceConfigMap.containsKey(sourceName) == false && selectedMessages != null && selectedMessages.size() > 0) {				
					ISourceReference srcRef = selectedMessages.get(0).getSourceReference();
					DBSourceReference dbSrcRef = (DBSourceReference)srcRef;
					dsName = dbSrcRef.getDataSourceName();
					IDataSource dataSource = dataSourceFactory.getDataSource(dsName);
					if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
						MongoTemplate mongoTemplate = new MongoTemplate(((MongoDataSource)dataSource).getMongoClient(), dbSrcRef.getSchemaName());
						BulkOperations bulkOps = mongoTemplate.bulkOps(BulkMode.ORDERED, HashMap.class, dbSrcRef.getCollectionName());
						SourceConfig config = new SourceConfig();
						config.bulkOps = bulkOps;
						config.summaryfieldID = summaryFieldInfo.get(sourceName);
						sourceConfigMap.put(sourceName, config);					
					}
				}
			}
		} catch (NoSuchDataSourceAvailableException dsNotAvailableException) {
			logger.error(dsNotAvailableException.getMessage(), dsNotAvailableException);
			ErrorDetails errorDetails = ErrorDetails.builder().userDetails("Invalid datasource - " + dsName)
					.errorDetail(dsNotAvailableException.getMessage()).severity(Severity.FATAL).build();
			throw new RecordProcessingException(errorDetails);
		}
	}	
	
	/**
	 * This method is used to update the records which are reconciled
	 * @param reconResult
	 */
	void updateReconciledRecords(ReconciliationMatchResult<IMessage> reconResult) {		
		for(Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet())  {
			String sourceName = entry.getKey();
			List<IMessage> selectedMessages = entry.getValue();
			SourceConfig sourceConfig = sourceConfigMap.get(sourceName);
			
			IMessage msg = selectedMessages.get(0); // for One to One recon only one record would be available
			IRecord record = (IRecord)msg.getData();
			String oID = record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
			double dblVal = record.getValue(sourceConfig.summaryfieldID);
			
			String counterPartSourceName = sourceCounterPart.get(sourceName);
			List<IMessage> counterPartSourceMessages = reconResult.getSelectedRecords().get(counterPartSourceName);			
			final List<String> relatedOIDList = counterPartSourceMessages.stream()
					.map(StatusUpdateStep::getOID).collect(Collectors.toList());
			
			Map<String, List<String>> relatedRecs = new HashMap<String, List<String>>();
			relatedRecs.put(sourceName, Arrays.asList(oID));
			relatedRecs.put(counterPartSourceName, relatedOIDList);
						
			Date currDate = java.util.Date.from(java.time.LocalDate.now().atStartOfDay()
				      .atZone(ZoneId.systemDefault())
				      .toInstant());
			Map<String, Object> reconControlField = record.getValue(record.getFieldId(RECONCTRLFIELDNAME));
			Date newDate = currDate;
			if (reconControlField == null) {
				reconControlField = new HashMap<String, Object>();
			} else {
				Object reconCntrlActivityDBValue = reconControlField.get(config.getActivityName());
				if(reconCntrlActivityDBValue != null && Document.class.isAssignableFrom(reconCntrlActivityDBValue.getClass())) {
					try {
						newDate = ((Document)reconCntrlActivityDBValue).getDate(RECONCTRLFIELDNAME_PROCESSINGDATE);
					} catch(ClassCastException classCastException) {
						logger.error(
								"Existing value of processing date in recon control field is not of type date. Actual Type: {}, Activity Name: {}, Sub Status: {}",
								(((Document) reconCntrlActivityDBValue)
										.get(RECONCTRLFIELDNAME_PROCESSINGDATE) == null
												? "Null Value"
												: ((Document) reconCntrlActivityDBValue)
														.get(RECONCTRLFIELDNAME_PROCESSINGDATE).getClass()),
								config.getActivityName(), getReconSubStatus(reconResult.getType()));
					}
				}
			}
			
			// TODO : to look into amtDiff in case of multiple tolerance fields of amount type
			double toleranceAmt = (reconResult.getType() == MatchedResultType.PERFECT ? 0.0 : 0.0);
			ReconControlInfo reconControlInfo = ReconControlInfo.builder()
					.activityName(config.getActivityName())
					.amount(dblVal)
					.tolerance(toleranceAmt) 
					.jobId(jobTaskInfo.getJobId())
					.processingDate(newDate)
					.ruleId(reconResult.getRuleId())					
					.status(ReconStatus.RECONCILED)
					.subStatus(getReconSubStatus(reconResult.getType()))
					.relatedRecords(relatedRecs)
					.build();
			
			reconControlField.put(config.getActivityName(), reconControlInfo);
			Query query = Query.query(new Criteria("_id").is(oID));			
			sourceConfig.addUpdateCommand(query, Update.update(RECONCTRLFIELDNAME, reconControlField));			
			sourceConfig.commit(false);
		}				
	}
	
	/**
	 * This method is used to get the reconciliation subStatus.
	 * @param type
	 * @return ReconSubStatus
	 */
	ReconSubStatus getReconSubStatus(MatchedResultType type) {
		switch (type) {
		case PERFECT:
			return ReconSubStatus.Exact;
		case MATCHED:
			return ReconSubStatus.MatchWithinTolerance;
		case NO_DATA_IN_SOURCE:
			return ReconSubStatus.Default;
		case UNEXPECTED_MULTIPLE_RECORDS:
			return ReconSubStatus.MultipleMatches;
		case UNMATCHED:
			return ReconSubStatus.MatchBeyondTolerance;
		default:
			return ReconSubStatus.Default;
		}
	}
	
	static String getOID (IMessage msg) {
		IRecord record = (IRecord)msg.getData();
		return (String)record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
	}

	/**
	 * This method is used to update the records which are not reconciled
	 * @param reconResult
	 * @throws RecordProcessingException
	 */
	void updateUnReconciledRecords(ReconciliationMatchResult<IMessage> reconResult) throws RecordProcessingException {		
		ReconSubStatus subStatus = getReconSubStatus(reconResult.getType());		
		// case 1: unreconciled (no corresponding records)
		// case 3: multiple records
		if (subStatus == ReconSubStatus.Default || subStatus == ReconSubStatus.MultipleMatches) {
			// stamp with processing date
			// each source could have different number of records
			// for multipleMatches
			reconResult.getSelectedRecords().entrySet().forEach(entry -> {							
				String sourceName = entry.getKey();
				String counterPartSourceName = sourceCounterPart.get(sourceName);

				List<IMessage> counterPartSourceMessages = reconResult.getSelectedRecords().get(counterPartSourceName);
				final Map<String, List<String>> relatedRecs = new HashMap<String, List<String>>();
				List<String> tempList = null;
				if (counterPartSourceMessages != null) {
					tempList = counterPartSourceMessages.stream()
						.map(StatusUpdateStep::getOID).collect(Collectors.toList());
				}											
				relatedRecs.put(counterPartSourceName, tempList);
				
				List<IMessage> selectedMessages = entry.getValue();
				tempList = null;
				if (subStatus == ReconSubStatus.MultipleMatches) {
					tempList = selectedMessages.stream().map(StatusUpdateStep::getOID)
							.collect(Collectors.toList());					
				}
				relatedRecs.put(sourceName, tempList);
				
				
				SourceConfig sourceConfig = sourceConfigMap.get(sourceName);
				if (selectedMessages != null) {
					final Date currDate = java.util.Date.from(java.time.LocalDate.now().atStartOfDay()
						      .atZone(ZoneId.systemDefault())
						      .toInstant());
					selectedMessages.forEach(msg -> {
						IRecord record = (IRecord)msg.getData();
						String oID = record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
						double dblVal = record.getValue(sourceConfig.summaryfieldID);
						
						Map<String, Object> reconControlField = record.getValue(record.getFieldId(RECONCTRLFIELDNAME));
						Date newDate = currDate;
						if (reconControlField == null) {
							reconControlField = new HashMap<String, Object>();
						} else {
							Object reconCntrlActivityDBValue = reconControlField.get(config.getActivityName());
							if(reconCntrlActivityDBValue != null && Document.class.isAssignableFrom(reconCntrlActivityDBValue.getClass())) {
								try {
									newDate = ((Document)reconCntrlActivityDBValue).getDate(RECONCTRLFIELDNAME_PROCESSINGDATE);
								} catch(ClassCastException classCastException) {
									logger.error(
											"Existing value of processing date in recon control field is not of type date. Actual Type: {}, Activity Name: {}, Sub Status: {}",
											(((Document) reconCntrlActivityDBValue)
													.get(RECONCTRLFIELDNAME_PROCESSINGDATE) == null
															? "Null Value"
															: ((Document) reconCntrlActivityDBValue)
																	.get(RECONCTRLFIELDNAME_PROCESSINGDATE).getClass()),
											config.getActivityName(), subStatus);
								}
							}
						}
						
						ReconControlInfo reconControlInfo = ReconControlInfo.builder()
								.activityName(config.getActivityName())
								.amount(dblVal)
								.tolerance(0)
								.jobId(jobTaskInfo.getJobId())
								.processingDate(newDate)
								.ruleId(reconResult.getRuleId())					
								.status(ReconStatus.UNRECONCILED)
								.subStatus(subStatus)
								.relatedRecords(relatedRecs)								
								.build();

						if (subStatus == ReconSubStatus.MultipleMatches) {
							final String caseID = (String)reconResult.getSupportingData().get(CASE_ID);
							final CaseInfo caseInfo = CaseInfo.builder().caseID(caseID).status(CaseStatus.OPEN).build();
							reconControlInfo.setCaseInfo(caseInfo);
						}
						
						reconControlField.put(config.getActivityName(), reconControlInfo);
						Query query = Query.query(new Criteria("_id").is(oID));			
						sourceConfig.addUpdateCommand(query, Update.update(RECONCTRLFIELDNAME, reconControlField));			
						sourceConfig.commit(false);
					});
				}
			});
		}		
		// case 2: matched beyond tolerance (Create a case)
		else if (subStatus == ReconSubStatus.MatchBeyondTolerance) {
			// stamp with processing date
			for(Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet())  {
				String sourceName = entry.getKey();
				List<IMessage> selectedMessages = entry.getValue();
				SourceConfig sourceConfig = sourceConfigMap.get(sourceName);
				final Date currDate = java.util.Date.from(java.time.LocalDate.now().atStartOfDay()
					      .atZone(ZoneId.systemDefault())
					      .toInstant());
				IMessage msg = selectedMessages.get(0); // for One to One recon only one record would be available
				IRecord record = (IRecord)msg.getData();
				String oID = record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
				double dblVal = record.getValue(sourceConfig.summaryfieldID);

				String counterPartSourceName = sourceCounterPart.get(sourceName);
				List<IMessage> counterPartSourceMessages = reconResult.getSelectedRecords().get(counterPartSourceName);			
				final List<String> relatedOIDList = counterPartSourceMessages.stream()
						.map(StatusUpdateStep::getOID).collect(Collectors.toList());
				
				Map<String, List<String>> relatedRecs = new HashMap<String, List<String>>();
				relatedRecs.put(sourceName, Arrays.asList(oID));
				relatedRecs.put(counterPartSourceName, relatedOIDList);
				
				Map<String, Object> reconControlField = record.getValue(record.getFieldId(RECONCTRLFIELDNAME));
				Date newDate = currDate;
				if (reconControlField == null) {
					reconControlField = new HashMap<String, Object>();
				} else {
					Object reconCntrlActivityDBValue = reconControlField.get(config.getActivityName());
					if(reconCntrlActivityDBValue != null && Document.class.isAssignableFrom(reconCntrlActivityDBValue.getClass())) {
						try {
							newDate = ((Document)reconCntrlActivityDBValue).getDate(RECONCTRLFIELDNAME_PROCESSINGDATE);
						} catch(ClassCastException classCastException) {
							logger.error(
									"Existing value of processing date in recon control field is not of type date. Actual Type: {}, Activity Name: {}, Sub Status: {}",
									(((Document) reconCntrlActivityDBValue)
											.get(RECONCTRLFIELDNAME_PROCESSINGDATE) == null
													? "Null Value"
													: ((Document) reconCntrlActivityDBValue)
															.get(RECONCTRLFIELDNAME_PROCESSINGDATE).getClass()),
									config.getActivityName(), subStatus);
						}
					}
				}
				
				ReconControlInfo reconControlInfo = ReconControlInfo.builder()
						.activityName(config.getActivityName())
						.amount(dblVal)
						.tolerance(0)
						.jobId(jobTaskInfo.getJobId())
						.processingDate(newDate)
						.ruleId(reconResult.getRuleId())					
						.status(ReconStatus.UNRECONCILED)
						.subStatus(subStatus)
						.relatedRecords(relatedRecs)
						.build();
				
				reconControlField.put(config.getActivityName(), reconControlInfo);
				Query query = Query.query(new Criteria("_id").is(oID));			
				sourceConfig.addUpdateCommand(query, Update.update(RECONCTRLFIELDNAME, reconControlField));			
				sourceConfig.commit(false);
			}
		}		
	}
	
	/**
	 * This method is used to commit the bulk operations if it is full.
	 * @param bulkOps
	 */
	void commitIfFull(BulkOperations bulkOps) {
		bulkOps.execute();
	}
	
	private void createCase(ReconciliationMatchResult<IMessage> reconResult) throws Exception {
		String caseID = null;
		ReconSubStatus subStatus = getReconSubStatus(reconResult.getType());		
		
		if (subStatus == ReconSubStatus.MultipleMatches) {
			final Map<String, IRecord> records = new HashMap<String, IRecord>();
			reconResult.getSelectedRecords().entrySet().forEach(entry -> {
				if(entry.getKey().equals(config.getSourceA().getSourceName())) {
					records.put(SOURCE_A, (IRecord)entry.getValue().get(0).getData());				
				} else {
					records.put(SOURCE_B, (IRecord)entry.getValue().get(0).getData());
				}
			});
			
			String desc = getCaseDescription(subStatus, records.get(SOURCE_A), records.get(SOURCE_B));
			String subject = "Multiple Matches found in " + config.getActivityName() + " run";
			
			// call utility to createCase & attach the caseID to the reconResult
			String ruleId = reconResult.getRuleId();
			try {
				caseID = createSalesForceCase(desc,subject, ruleId,subStatus);
			} catch(Exception e) {
				logger.error("Error while creating case for Multi match scenario of Activity: {}", config.getActivityName(), e);
			}
			if(reconResult.getSupportingData() == null) {
				logger.debug("Supporting data is null for result. Activity Name: {}", config.getActivityName());
				reconResult.setSupportingData(new HashMap<>());
			}
			reconResult.getSupportingData().put(CASE_ID, caseID);
		}
	}
	
	private String createSalesForceCase(String desc, String subject, String ruleId,ReconSubStatus subStatus) throws Exception {
		String projectName = jobInfo.getProjectName();
		String uniqueID = UUID.randomUUID().toString();
		CaseCreation caseCreation= CaseCreation.builder().referenceId(uniqueID).status("New").origin("Recon").priority(Priority.MEDIUM)
		.exceptionType(Severity.ERROR)
		.subject(subject)
		.description(desc)
		.batchTypeNameInstanceId(jobTaskInfo.getJobId()).reason(subStatus.toString())
		.activity(config.getActivityName())
		.project(projectName).build();
		
		return caseCreationAuthImpl.authentication(caseCreation);
	}
	
	private String getCaseDescription(ReconSubStatus subStatus, IRecord recordA, IRecord recordB) {
		String template= caseDescTemplates.get(subStatus.name());
       // String template = "DPS invoiceNo ${sourceA.invoiceNo} matched with PaymentTech record above the configured tolerance limit";
        if (subStatus == ReconSubStatus.MatchBeyondTolerance) {
            Map<String, String> valueMap = getTokens(template, recordA, recordB);            
			StringSubstitutor strSubstitutor = new StringSubstitutor(valueMap);
			return strSubstitutor.replace(template);
		} else if (subStatus == ReconSubStatus.MultipleMatches) {
            Map<String, String> valueMap = getTokens(template, recordA, recordB);            
			StringSubstitutor strSubstitutor = new StringSubstitutor(valueMap);
			return strSubstitutor.replace(template);			
		} else {
			logger.debug("No condition check available for received status: Received Status: {}", subStatus);
			return null;
		}
	}
	
	private Map<String, String> getTokens(String template, IRecord recordA, IRecord recordB) {
		Map<String, String> valueMap = new HashMap<>();
		try {
	        String[] tokens = template.split("[$][{]");
	        for(int index = 1; index < tokens.length; index++) {
	        	String token = tokens[index];
	        	String fieldNameWithSrc = token.substring(0, token.indexOf("}"));
	        	String[] fieldTokens = fieldNameWithSrc.split("[.]");
	        	String fieldName = fieldTokens[1];
	        	String srcName = fieldTokens[0];
	        	IRecord record = (srcName.equalsIgnoreCase(SOURCE_A) ? recordA : recordB);
				valueMap.put(fieldNameWithSrc, record.getValue(record.getFieldId(fieldName)));
	        }
		} catch (Exception e) {
			logger.error("Invalid template, unable to split tokens", e);
		}
        return valueMap;
	}
}
