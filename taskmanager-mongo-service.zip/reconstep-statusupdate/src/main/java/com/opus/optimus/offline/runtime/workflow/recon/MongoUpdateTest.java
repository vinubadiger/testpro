package com.opus.optimus.offline.runtime.workflow.recon;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.WriteModel;
import com.opus.optimus.offline.config.recon.subtypes.ReconControlInfo;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;

public class MongoUpdateTest {

	private static MongoDatabase database;

	private static MongoTemplate mongoTemplate;

	public static void main(String[] args) {

		MongoClient mongoClient;
		MongoClientOptions mongoClientOptions = MongoClientOptions.builder().applicationName("MongoDBWriter").build();

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

		mongoClient = new MongoClient("127.0.0.1", mongoClientOptions);
		mongoTemplate = new MongoTemplate(mongoClient, "test");

		MongoCollection<Document> coll = mongoTemplate.getCollection("test");
		List<WriteModel<Document>> writeModelBatch = new ArrayList<>();
		BulkOperations bulkOps = mongoTemplate.bulkOps(BulkMode.ORDERED, HashMap.class, "testcoll");
		String RECONCTRLFIELDNAME = "reconControlFields";
		Query query = new Query();
		mongoTemplate.executeQuery(query, "testcoll", (document) -> {
			System.out.println(document.get("key1"));
			System.out.println(document.get("_id"));
			Object val = document.get(RECONCTRLFIELDNAME);
			System.out.println((val != null ? val.getClass().getName() : "NULL"));
			ReconControlInfo reconControlStatus = ReconControlInfo.builder().jobId("aaa").activityName("PaymentTech").status(ReconStatus.RECONCILED).subStatus(ReconSubStatus.MatchWithinTolerance).tolerance(12.00).amount(1000).build();

			Map<String, Object> reconControlField = new HashMap<String, Object>();
			reconControlField.put("PaymentTech", reconControlStatus);
			reconControlStatus = ReconControlInfo.builder().jobId("123").activityName("Amex1").status(ReconStatus.UNRECONCILED).subStatus(ReconSubStatus.Default).tolerance(12.00).amount(1000).processingDate(new Date()).build();
			reconControlField.put("Amex1", reconControlStatus);

			Query lquery = Query.query(new Criteria("_id").is("5c5fa1d0233adf7e63a49bb6"));

			bulkOps.updateOne(lquery, Update.update(RECONCTRLFIELDNAME, reconControlField));
		});

		bulkOps.execute();
	}

}
