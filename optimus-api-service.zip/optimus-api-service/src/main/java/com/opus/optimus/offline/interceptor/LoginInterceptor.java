package com.opus.optimus.offline.interceptor;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.opus.optimus.offline.repository.user.ProfileRepository;
import com.opus.optimus.offline.repository.user.UserRolePermissionRepository;
import com.opus.optimus.ui.services.user.ApiConfig;
import com.opus.optimus.ui.services.user.Profile;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Component
public class LoginInterceptor implements HandlerInterceptor {
	private static final Log log = LogFactory.getLog(LoginInterceptor.class);

	@Autowired
	UserRolePermissionRepository userRolePermRepo;

	@Autowired
	ProfileRepository profileRepository;

	@Value ("${security.signing-key}")
	private String signingKey;

	@Value ("${server.servlet.context-path}")
	private String contextName;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		List role = null;
		try{
			log.debug("\n\n-----INTERCEPTOR START---------");

			String jwttoken = request.getHeader("Authorization");

			String requestUri = request.getRequestURI();
			String reqMethod = request.getMethod().toUpperCase();

			int endIndex = requestUri.indexOf("/", contextName.length() + 1);
			String actionName = "";

			if (endIndex > 0){
				actionName = requestUri.substring(contextName.length() + 1, endIndex);
			}

			role = parseJWT(jwttoken);// This method will be called while decoding the jwstoken

			// Fetch the role for the logged in user to get his permissions on the basis of fetched role
			if (requestUri.contains("/GetLoggedinUserRole/")){
				return true;
			}

			log.debug("Calling parseJWT1 :" + jwttoken);

			boolean isPermission = isPermitted(actionName, reqMethod, role.get(0).toString());
			if (isPermission){
				String username = parseJWTforUserName(jwttoken);// This method will be called while decoding the jwstoken for username
				// Set username in SecurityContext to access username in controller
				SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
				securityContext.setAuthentication(new UsernamePasswordAuthenticationToken(username, ""));
				SecurityContextHolder.setContext(securityContext);
				return true;
			} else{
				response.setHeader("UNAUTHORIZED", "You are unauthorized to access the resource");
				response.setStatus(403);
				return false;
			}
		} catch (Exception e){
			if (role == null){
				response.setHeader("INVALID_JWT_TOKEN", "Invalid JWT Token / You are unauthorized to access the resource");
			}
		}
		return false;
	}

	public boolean isPermitted(String actionName, String methodRequired, String roles) {
		Profile profile = profileRepository.getCurrentUserPermission(roles);

		int count = 0;
		for (ApiConfig apiConfig : profile.getRestApiConfig()){
			if (apiConfig.getActionName().equals(actionName)){
				count++;
				if (count == 1){
					break;
				}
			}
		}

		if (count == 0){
			return false;
		} else{
			return true;
		}
	}

	private List<String> parseJWT(String jwt) throws Exception {

		log.debug("inside parseJWT :" + jwt);

		final String SECRET1 = Base64.getEncoder().encodeToString(signingKey.getBytes());

		log.debug("parseJWT SECRET1 :" + SECRET1);
		Claims claimsx = Jwts.parser().setSigningKey(SECRET1).parseClaimsJws(jwt).getBody();

		log.debug("authorities: " + claimsx.get("authorities"));

		String name = (String) claimsx.get("user_name");
		log.debug("user_name==========> " + name);
		log.debug("user_name: " + claimsx.get("user_name"));

		return (List<String>) claimsx.get("authorities");

	}

	private String parseJWTforUserName(String jwt) throws Exception {

		log.debug("inside parseJWT :" + jwt);

		final String SECRET1 = Base64.getEncoder().encodeToString(signingKey.getBytes());

		log.debug("parseJWT SECRET1 :" + SECRET1);
		Claims claimsx = Jwts.parser().setSigningKey(SECRET1).parseClaimsJws(jwt).getBody();

		log.debug("user_name: " + claimsx.get("user_name"));

		return (String) claimsx.get("user_name");

	}
}
