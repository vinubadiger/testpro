package com.opus.optimus.offline;

import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IDataSourceConfigService;
import com.opus.optimus.offline.services.scheduler.BatchDefinitionService;


/**
 * The Class EntryPoint that used to bootstrap and launch a application from a Java main.
 */
@SpringBootApplication
@ComponentScan ({ "com.opus.optimus" })
@EntityScan ("com.opus.optimus")
@EnableMongoRepositories ("com.opus.optimus")
public class EntryPoint {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(EntryPoint.class);

	/** The customizers. */
	@Autowired (required = false)
	List<IMapperCustomizer<ObjectMapper>> customizers;

	/** The batch definition service. */
	@Autowired
	private BatchDefinitionService batchDefinitionService;

	/** The application context. */
	@Autowired
	private ApplicationContext applicationContext;

	/**
	 * On server restart Quartz scheduler read scheduling info from DB & reschedule configured jobs.
	 */
	@PostConstruct
	public void autoRestartSchedule() {
		logger.debug("Auto Restart Schedule Enable");
		try{
			this.batchDefinitionService.autoRestartSchedule();
		} catch (Exception e){
			logger.error(e.getMessage(), e);
		}

		logger.debug("Building and registering data source factories..");
		buildAndRegisterDataSourceFactory();

	}

	/**
	 * Builds the and register data source factory.
	 */
	private void buildAndRegisterDataSourceFactory() {
		try{
			final IDataSourceConfigService dataSourceConfigService = this.applicationContext.getBean(IDataSourceConfigService.class);
			List<MongoDataSourceMeta> dataSourceMetas = dataSourceConfigService.findAllDataSourceConfigs();

			final DataSourceFactory dataSourceFactory = this.applicationContext.getBean(DataSourceFactory.class);
			if (dataSourceMetas != null){
				dataSourceMetas.parallelStream().forEach(dataSourceMeta -> {
					final MongoDataSource dataSource = new MongoDataSource(dataSourceMeta);
					dataSource.init();
					dataSourceFactory.register(dataSourceMeta.getDataSourceName(), dataSource);
				});
			}
		} catch (Exception e){
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * Replace the default ObjectMapper to custom object mapper MapperFactory using @Primary.
	 *
	 * @param mapperFactory the mapper factory
	 * @return the object mapper
	 */

	@Bean
	@Primary
	public ObjectMapper optimusObjectMapper(MapperFactory mapperFactory) {
		return mapperFactory.getMapper();
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(EntryPoint.class, args);
	}
}
