package com.opus.optimus.ui.services.scheduler;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO: Auto-generated Javadoc
/**
 * Instantiates a new step input data.
 *
 * @param stepName the step name
 * @param stepType the step type
 * @param stepInputType the step input type
 * @param suggestionText the suggestion text
 * @param stepInputValue the step input value
 */
@AllArgsConstructor

/**
 * Instantiates a new step input data.
 */
@NoArgsConstructor
@Builder
@Data
public class StepInputData {

	/**
	 * The Enum StepInputType.
	 */
	public enum StepInputType {

	/** The file folder location. */
	FILE_FOLDER_LOCATION ("Enter Folder Location"),
	/** The file extension. */
	FILE_EXTENSION ("Enter File Extension");

		/** The label. */
		private String label;

		/**
		 * Instantiates a new step input type.
		 *
		 * @param value the value
		 */
		StepInputType(String value) {
			this.label = value;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public String getValue() {
			return label;
		}
	}

	/** The step name. */
	String stepName;
	
	/** The step type. */
	String stepType;
	
	/** The step input type. */
	StepInputType stepInputType;
	
	/** The suggestion text. */
	String suggestionText;
	
	/** The step input value. */
	String stepInputValue;
}