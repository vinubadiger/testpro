package com.opus.optimus.ui.services.util;
/**
 * The Enum ExecutionStatus.
 */
public enum ExecutionStatus {
	PENDING, INPROGRESS, COMPLETED, FAILED;
}
