package com.opus.optimus.ui.services.scheduler;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new wigdet result.
 *
 * @param status the status
 * @param count the count
 */
@AllArgsConstructor

/**
 * Instantiates a new wigdet result.
 */
@NoArgsConstructor
@Builder
@Data
public class WigdetResult {

	/** The status. */
	private String status;

	/** The count. */
	private Long count;
}
