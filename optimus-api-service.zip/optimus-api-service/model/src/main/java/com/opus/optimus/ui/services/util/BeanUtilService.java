package com.opus.optimus.ui.services.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;


/**
 * The Class BeanUtilService.
 */
@Component
public class BeanUtilService implements ApplicationContextAware {

	/** The application context. */
	private static ApplicationContext applicationContext;

	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext2) throws BeansException {
		BeanUtilService.applicationContext = applicationContext2;
	}

	/**
	 * Gets the bean object.
	 *
	 * @param <T> the generic type
	 * @param clazz the clazz
	 * @return the bean object
	 */
	public static <T> T getBeanObject(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}
}