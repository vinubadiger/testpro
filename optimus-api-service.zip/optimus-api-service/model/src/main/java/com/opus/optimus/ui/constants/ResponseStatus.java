package com.opus.optimus.ui.constants;

// TODO: Auto-generated Javadoc
/**
 * The Enum ResponseStatus.
 */
public enum ResponseStatus {
	
	FAILED, SUCCESS
}
