package com.opus.optimus.ui.services.user;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new user role permission.
 *
 * @param id the id
 * @param apiName the api name
 * @param apiUrl the api url
 * @param methodRequired the method required
 * @param roles the roles
 */
@AllArgsConstructor

/**
 * Instantiates a new user role permission.
 */
@NoArgsConstructor
@Builder
@Data
@Document(collection = "UserRolePermission")
public class UserRolePermission {

	/** The id. */
	private String id;

	/** The api name. */
	@Id
	private String apiName;
	
	/** The api url. */
	private String apiUrl;
	
	/** The method required. */
	private String methodRequired;
	
	/** The roles. */
	private List<Role> roles;
}
