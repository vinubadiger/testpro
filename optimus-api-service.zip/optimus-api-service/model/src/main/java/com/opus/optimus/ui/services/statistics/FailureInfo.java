package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
/**
 * Instantiates a new failure info.
 */
@NoArgsConstructor

/**
 * Instantiates a new failure info.
 *
 * @param failed the failed
 * @param total the total
 */
@AllArgsConstructor
@Builder
public class FailureInfo {

	/** The failed. */
	Long failed;

	/** The total. */
	Long total;

}
