package com.opus.optimus.ui.services.user;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new role.
 *
 * @param roleId the role id
 * @param roleName the role name
 * @param description the description
 * @param createdBy the created by
 * @param createdDate the created date
 * @param modifiedBy the modified by
 * @param modifiedDate the modified date
 */
@AllArgsConstructor

/**
 * Instantiates a new role.
 */
@NoArgsConstructor
@Builder
@Data
@Document(collection = "Role")
@JsonInclude(Include.NON_NULL)
public class Role {

	/**
	 * Instantiates a new role.
	 *
	 * @param roleId the role id
	 * @param roleName the role name
	 */
	public Role(String roleId, String roleName) {
		this.roleId = roleId;
		this.roleName = roleName;
	}

	/**
	 * Instantiates a new role.
	 *
	 * @param roleName the role name
	 */
	public Role(String roleName) {
		this.roleName = roleName;
	}

	/** The role id. */
	@Id
	private String roleId;

	/** The role name. */
	private String roleName; // unique name

	/** The description. */
	private String description;

	/** The created by. */
	private String createdBy;

	/** The created date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	/** The modified by. */
	private String modifiedBy;

	/** The modified date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
}