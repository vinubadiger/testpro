package com.opus.optimus.ui.services.scheduler;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new case response.
 *
 * @param access_token the access token
 * @param instance_url the instance url
 * @param id the id
 * @param token_type the token type
 * @param issued_at the issued at
 * @param signature the signature
 */
@AllArgsConstructor
@Builder
@Document

/**
 * Instantiates a new case response.
 */
@NoArgsConstructor
public class CaseResponse {
	
	/** The access token. */
	String access_token;

	/** The instance url. */
	String instance_url;

	/** The id. */
	String id;

	/** The token type. */
	String token_type;

	/** The issued at. */
	String issued_at;

	/** The signature. */
	String signature;
}
