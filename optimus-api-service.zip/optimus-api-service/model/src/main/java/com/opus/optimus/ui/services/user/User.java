package com.opus.optimus.ui.services.user;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new user.
 *
 * @param email the email
 * @param password the password
 * @param firstName the first name
 * @param lastName the last name
 * @param dateOfBirth the date of birth
 * @param mobileNumber the mobile number
 * @param lastLoginTime the last login time
 * @param active the active
 * @param accountLocked the account locked
 * @param createdBy the created by
 * @param createdDate the created date
 * @param modifiedBy the modified by
 * @param modifiedDate the modified date
 * @param roles the roles
 * @param institution the institution
 * @param group the group
 */
@AllArgsConstructor

/**
 * Instantiates a new user.
 */
@NoArgsConstructor

@Builder
@Data
@Document(collection = "User")
@JsonInclude(Include.NON_NULL)
public class User {

	/** The email. */
	@Id
	private String email;

	/** The password. */
	private String password;

	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;

	/** The date of birth. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date dateOfBirth;

	/** The mobile number. */
	private String mobileNumber;

	/** The last login time. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date lastLoginTime;

	/** The active. */
	private boolean active;

	/** The account locked. */
	private boolean accountLocked;

	/** The created by. */
	private String createdBy;

	/** The created date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	/** The modified by. */
	private String modifiedBy;

	/** The modified date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	/** The roles. */
	private List<Role> roles;

	/** The institution. */
	private Institution institution;

	/** The group. */
	private List<Group> group;
}
