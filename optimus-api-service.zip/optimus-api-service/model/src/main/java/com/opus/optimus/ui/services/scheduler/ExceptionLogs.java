package com.opus.optimus.ui.services.scheduler;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new exception logs.
 *
 * @param recordId the record id
 * @param exceptionMessage the exception message
 */
@AllArgsConstructor

/**
 * Instantiates a new exception logs.
 */
@NoArgsConstructor
@Builder
@Data
public class ExceptionLogs {

	/** The record id. */
	private String recordId;

	/** The exception message. */
	private String exceptionMessage;

}