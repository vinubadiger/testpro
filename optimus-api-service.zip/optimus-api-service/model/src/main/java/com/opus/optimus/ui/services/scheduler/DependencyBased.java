package com.opus.optimus.ui.services.scheduler;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonGetter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new dependency based.
 *
 * @param onCompletionOf the on completion of
 * @param policyType the policy type
 * @param startTime the start time
 */
@AllArgsConstructor

/**
 * Instantiates a new dependency based.
 */
@NoArgsConstructor
@Builder
@Data
public class DependencyBased implements SchedulerPolicy {

	/** The Constant RECORDTYPE. */
	public static final String RECORDTYPE = "DEPENDENCYBASED";

	/** The on completion of. */
	private String onCompletionOf;

	/** The policy type. */
	private String policyType;

	/** The start time. */
	private Date startTime;

	/* (non-Javadoc)
	 * @see com.opus.optimus.ui.services.scheduler.SchedulerPolicy#getPolicyType()
	 */
	@Override
	@JsonGetter ("policyType")
	public String getPolicyType() {
		return this.policyType = RECORDTYPE;
	}

}