package com.opus.optimus.ui.services.scheduler;

import org.springframework.data.mongodb.core.mapping.Document;

import com.opus.optimus.ui.services.scheduler.CaseCreation.CaseCreationBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new case creation.
 *
 */
@AllArgsConstructor
@Builder
@Document

/**
 * Instantiates a new case creation.
 */
@NoArgsConstructor
public class CaseCloseResponse {
boolean hasError;
}
