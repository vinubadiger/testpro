package com.opus.optimus.ui.services.scheduler.util;

import java.util.List;

/**
 * The Class CronGeneratorUtil.
 */
public class CronGeneratorUtil {
	
	/**
	 * Instantiates a new cron generator util.
	 */
	private CronGeneratorUtil() {}

	/**
	 * Cron expression format.
	 *
	 * @param hour the hour
	 * @param selectedDays the selected days
	 * @return the string
	 */
	public static String cronExpressionFormat(String hour, List<String> selectedDays) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("0 0 */" + hour + " ? * ");
		int size = selectedDays.size();
		for (int i = 0; i < size - 1; i++){
			stringBuilder.append(selectedDays.get(i) + ",");
		}
		stringBuilder.append(selectedDays.get(size - 1) + " *");
		return stringBuilder.toString();
	}
}