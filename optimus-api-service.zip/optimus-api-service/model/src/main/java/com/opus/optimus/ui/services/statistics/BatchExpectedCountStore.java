package com.opus.optimus.ui.services.statistics;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BatchExpectedCountStore {
	
	/** The project name. */
	String projectName;
	
	/** The workflow name. */
	String workflowName;
	
	/** The work flow type. */
	String workFlowType;
	
	/** The active from. */
	String activeFrom;


	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		BatchExpectedCountStore other = (BatchExpectedCountStore) obj;
		if (projectName == null){
			if (other.projectName != null) return false;
		} else if (!projectName.equals(other.projectName)) return false;
		if (workFlowType == null){
			if (other.workFlowType != null) return false;
		} else if (!workFlowType.equals(other.workFlowType)) return false;
		if (workflowName == null){
			if (other.workflowName != null) return false;
		} else if (!workflowName.equals(other.workflowName)) return false;
		return true;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + ((workFlowType == null) ? 0 : workFlowType.hashCode());
		result = prime * result + ((workflowName == null) ? 0 : workflowName.hashCode());
		return result;
	}

}
