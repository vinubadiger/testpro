package com.opus.optimus.ui.constants;

import lombok.Data;


/* 
 * ServiceResponse class to map reponse of all controller
 * 
 */
@Data
public class ServiceResponse {

	/** The status code. */
	int statusCode;

	/** The status. */
	ResponseStatus status;

	/** The msg. */
	String msg;

	/** The response obj. */
	Object responseObj;

	/**
	 * Instantiates a new service response.
	 *
	 * @param code the code
	 * @param status the status
	 * @param msg the msg
	 * @param responseObj the response obj
	 */
	public ServiceResponse(int code, ResponseStatus status, String msg, Object responseObj) {
		this.statusCode = code;
		this.status = status;
		this.msg = msg;
		this.responseObj = responseObj;
	}
}
