package com.opus.optimus.ui.services.scheduler;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonGetter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new time based.
 *
 * @param activeFrom the active from
 * @param intervalMin the interval min
 * @param intervalHour the interval hour
 * @param policyType the policy type
 * @param startTime the start time
 * @param intervalDay the interval day
 * @param selectedDays the selected days
 */
@AllArgsConstructor

/**
 * Instantiates a new time based.
 */
@NoArgsConstructor

@Builder
@Data
public class TimeBased implements SchedulerPolicy {
	
	/** The Constant RECORDTYPE. */
	public static final String RECORDTYPE = "TIMEBASED";

	/** The active from. */
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	private Date activeFrom;

	/** The interval min. */
	private String intervalMin;

	/** The interval hour. */
	private String intervalHour;

	/** The policy type. */
	private String policyType;

	/** The start time. */
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	private Date startTime;

	/** The interval day. */
	private String intervalDay;

	/** The selected days. */
	private List<String> selectedDays;

	/* (non-Javadoc)
	 * @see com.opus.optimus.ui.services.scheduler.SchedulerPolicy#getPolicyType()
	 */
	@Override
	@JsonGetter ("policyType")
	public String getPolicyType() {
		return this.policyType = RECORDTYPE;
	}

}