package com.opus.optimus.ui.services.statistics;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new file statistics.
 */
@NoArgsConstructor

/**
 * Instantiates a new file statistics.
 *
 * @param filesExpected the files expected
 * @param filesProcessed the files processed
 * @param totalFiles the total files
 * @param processedFiles the processed files
 * @param status the status
 */
@AllArgsConstructor
@Builder
public class FileStatistics {

	/** The files expected. */
	int filesExpected;
	
	/** The files processed. */
	int filesProcessed; // File count with Success status
	
	/** The total files. */
	int totalFiles; // count of all files
	
	/** The processed files. */
	List<FileProcessedTable> processedFiles;
	
	/** The status. */
	boolean status;

}
