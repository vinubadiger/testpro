package com.opus.optimus.ui.services.project;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.ui.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new project.
 *
 * @param id the id
 * @param institutionId the institution id
 * @param institutionName the institution name
 * @param projectId the project id
 * @param projectName the project name
 * @param projectDescription the project description
 * @param createdBy the created by
 * @param date the date
 */
@AllArgsConstructor

/**
 * Instantiates a new project.
 */
@NoArgsConstructor
@Builder
@Data
@Document (collection = "Project")
public class Project implements Comparable<Project> {

	/** The id. */
	@Id
	private String id;

	/** The institution id. */
	@Field (Constants.INSTITUTION_ID)
	private String institutionId;

	/** The institution name. */
	@Field (Constants.INSTITUTION_NAME)
	private String institutionName;

	/** The project id. */
	@Field (Constants.PROJECT_ID)
	private String projectId;

	/** The project name. */
	@Field (Constants.PROJECT_NAME)
	private String projectName;

	/** The project description. */
	@Field (Constants.PROJECT_DESCRIPTION)
	private String projectDescription;

	/** The created by. */
	@Field (Constants.CREATED_BY)
	private String createdBy;

	/** The date. */
	@Field (Constants.CREATED_DATE)
	private Date date = new Date();

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Project o) {
		return getDate().compareTo(o.getDate());
	}
}
