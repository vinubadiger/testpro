package com.opus.optimus.ui.services.user;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new profile.
 *
 * @param profileId the profile id
 * @param role the role
 * @param restApiConfig the rest api config
 */
@AllArgsConstructor

/**
 * Instantiates a new profile.
 */
@NoArgsConstructor
@Builder
@Data
@Document(collection = "Profile")
public class Profile {

	/** The profile id. */
	@Id
	private String profileId;

	/** The role. */
	private Role role; // unique

	/** The rest api config. */
	private List<ApiConfig> restApiConfig;
	
	private List<String> homeScreenIcons;
}