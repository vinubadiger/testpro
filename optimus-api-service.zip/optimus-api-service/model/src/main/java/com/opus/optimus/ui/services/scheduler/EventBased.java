package com.opus.optimus.ui.services.scheduler;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonGetter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new event based.
 *
 * @param policyType the policy type
 * @param eventType the event type
 * @param location the location
 * @param startTime the start time
 */
@AllArgsConstructor

/**
 * Instantiates a new event based.
 */
@NoArgsConstructor
@Builder
@Data
public class EventBased implements SchedulerPolicy {

	/** The policy type. */
	private String policyType;

	/** The Constant RECORDTYPE. */
	public static final String RECORDTYPE = "EVENTBASED";

	/** The event type. */
	private String eventType;

	/** The location. */
	private FilePollingEventDescriptor location;

	/** The start time. */
	private Date startTime;

	/**
	 * The Enum EventType.
	 */
	// Unused
	public enum EventType {
		
		/** The directory polling. */
		DIRECTORY_POLLING
	}

	/* (non-Javadoc)
	 * @see com.opus.optimus.ui.services.scheduler.SchedulerPolicy#getPolicyType()
	 */
	@Override
	@JsonGetter ("policyType")
	public String getPolicyType() {
		return this.policyType = RECORDTYPE;
	}

	/**
	 * The Class FilePollingEventDescriptor.
	 */
	public class FilePollingEventDescriptor {
		
		/** The directory location. */
		private String directoryLocation;

		/**
		 * Gets the directory location.
		 *
		 * @return the directory location
		 */
		public String getDirectoryLocation() {
			return directoryLocation;
		}

		/**
		 * Sets the directory location.
		 *
		 * @param directoryLocation the new directory location
		 */
		public void setDirectoryLocation(String directoryLocation) {
			this.directoryLocation = directoryLocation;
		}
	}
}