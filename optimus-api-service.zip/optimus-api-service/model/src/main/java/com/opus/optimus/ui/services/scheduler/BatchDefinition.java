package com.opus.optimus.ui.services.scheduler;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opus.optimus.ui.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new batch definition.
 *
 * @param id the id
 * @param workflowId the workflow id
 * @param projectName the project name
 * @param workflowName the workflow name
 * @param workflowType the workflow type
 * @param workflowConfigId the workflow config id
 * @param nextTriggerTime the next trigger time
 * @param previousTriggerTime the previous trigger time
 * @param schedulerPolicy the scheduler policy
 * @param groupId the group id
 * @param stepInputs the step inputs
 * @param stepInputData the step input data
 * @param createdDate the created date
 * @param modifiedDate the modified date
 * @param disabled the disabled
 * @param checkDuplicateHeader the check duplicate header
 * @param checkDuplicateFile the check duplicate file
 * @param numberOfExpectedFiles the number of expected files
 */
@AllArgsConstructor
/**
 * Instantiates a new batch definition.
 */
@NoArgsConstructor
@Builder
@Data
@Document (collection = "BatchDefinition")
public class BatchDefinition {
	
	/** The id. */
	@Id
	private String id;

	/** The workflow id. */
	@Field (Constants.WORKFLOW_ID)
	private String workflowId;

	/** The project name. */
	@Field (Constants.PROJECT_NAME)
	private String projectName;

	/** The workflow name. */
	@Field (Constants.WORKFLOW_NAME)
	private String workflowName;

	/** The workflow type. */
	@Field (Constants.WORKFLOW_TYPE)
	private String workflowType;

	/** The workflow config id. */
	@Field ("workflowConfigId")
	private String workflowConfigId;

	/** The next trigger time. */
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Field (Constants.NEXT_TRIGGER_TIME)
	private Date nextTriggerTime;

	/** The previous trigger time. */
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	@Field (Constants.PREVIOUS_TRIGGER_TIME)
	private Date previousTriggerTime;

	/** The scheduler policy. */
	@Field (Constants.SCHEDULAR_POLICY)
	private SchedulerPolicy schedulerPolicy;

	/** The group id. */
	@Field (Constants.GROUP_ID)
	private String groupId;

	/** The step inputs. */
	@Field (Constants.STEP_INPUT)
	private Map<String, List<String>> stepInputs;

	/** The step input data. */
	private List<StepInputData> stepInputData;

	/** The created date. */
	@Field (Constants.CREATED_DATE)
	private Date createdDate;

	/** The modified date. */
	@Field (Constants.MODIFIED_DATE)
	private Date modifiedDate;

	/** The disabled. */
	private boolean disabled;

	/** The check duplicate header. */
	private boolean checkDuplicateHeader;
	
	/** The check duplicate file. */
	private boolean checkDuplicateFile;
	
	/** The number of expected files. */
	private int numberOfExpectedFiles;
	
	/** The schedule description. */
	private String description;

}