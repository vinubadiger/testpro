package com.opus.optimus.ui.services.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonUtil.
 */
public class CommonUtil {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

	/** The mapper. */
	private static ObjectMapper mapper;

	/** The pattern. */
	private static String pattern;

	/** The Constant simpleDateFormat. */
	public static final SimpleDateFormat simpleDateFormat;

	static{
		pattern = "MMM-dd-yyyy";
		simpleDateFormat = new SimpleDateFormat(pattern);
		mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	/**
	 * Instantiates a new common util.
	 */
	private CommonUtil() {
	}

	/**
	 * Gets the json from string.
	 *
	 * @param jsonString the json string
	 * @return the json from string
	 */
	public static JsonNode getJsonFromString(String jsonString) {
		try{
			return mapper.readTree(jsonString);
		} catch (IOException e){
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	/**
	 * Gets the object from string.
	 *
	 * @param <T> the generic type
	 * @param jsonString the json string
	 * @param clazz the clazz
	 * @return the object from string
	 */
	public static <T> T getObjectFromString(String jsonString, Class<T> clazz) {
		try{
			return mapper.readValue(jsonString, clazz);
		} catch (IOException e){
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	/**
	 * Gets the json from object.
	 *
	 * @param object the object
	 * @return the json from object
	 */
	public static String getJsonFromObject(Object object) {
		try{
			return mapper.writer().writeValueAsString(object);
		} catch (JsonProcessingException e){
			LOGGER.error(e.getMessage());
			return null;
		}
	}

	/**
	 * Return next day.
	 *
	 * @param endDate the end date
	 * @return the date
	 */
	public static Date returnNextDay(Date endDate) {
		Date date = Optional.ofNullable(endDate).orElse(new Date());
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DAY_OF_YEAR, 1);
		c.set(Calendar.HOUR, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		return c.getTime();
	}

	/**
	 * This method formats a Date parameter as per the given pattern.
	 *
	 * @param date the date
	 * @param format the format
	 * @return the formatted date
	 * @throws ParseException the parse exception
	 */
	public static Date getFormattedDate(Date date, String format) throws ParseException {
		try{
			Date dateToFormat = Optional.ofNullable(date).orElse(new Date());
			SimpleDateFormat dateFormat = null == format || format.isEmpty() ? simpleDateFormat : new SimpleDateFormat(format);
			String tDate = dateFormat.format(dateToFormat);
			dateToFormat = dateFormat.parse(tDate);
			return dateToFormat;
		} catch (ParseException e){
			LOGGER.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the formatted date string.
	 *
	 * @param date the date
	 * @param format the format
	 * @return the formatted date string
	 */
	public static String getFormattedDateString(Date date, String format) {
		try{
			Date dateToFormat = Optional.ofNullable(date).orElse(new Date());
			SimpleDateFormat dateFormat = null == format || format.isEmpty() ? simpleDateFormat : new SimpleDateFormat(format);
			return dateFormat.format(dateToFormat);
		} catch (Exception e){
			LOGGER.error(e.getMessage());
			throw e;
		}
	}


	/**
	 * Creates the system note.
	 *
	 * @param sourceA the source A
	 * @param sourceB the source B
	 * @param transDetails the Transaction details
	 * @param userComments the user comments from force match screen
	 * @return the string
	 */
	public static String createSystemNote(ForceMatchRequest forceMatchRequest)
	{
		DateFormat date = new SimpleDateFormat("dd-mm-yyyy hh:mm:ss");
		String formatedDate = date.format(new Date()).toString();
		String comments = Stream.of("System Notes -", "Source A :",forceMatchRequest.getSourceA().getSourceName(),"Source B :",forceMatchRequest.getSourceB().getSourceName(),",","User Notes -",forceMatchRequest.getRemarks(),",","Update Date/time -", formatedDate).filter(s -> s != null && !s.isEmpty()).collect(Collectors.joining(" "));
		return comments;
	}
	
}
