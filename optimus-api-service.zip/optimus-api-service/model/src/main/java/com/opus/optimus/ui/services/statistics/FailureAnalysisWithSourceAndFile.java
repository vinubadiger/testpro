package com.opus.optimus.ui.services.statistics;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new failure analysis with source and file.
 */
@NoArgsConstructor

/**
 * Instantiates a new failure analysis with source and file.
 *
 * @param workflowName the workflow name
 * @param sourceFiles the source files
 */
@AllArgsConstructor
@Builder
public class FailureAnalysisWithSourceAndFile {

	/** The workflow name. */
	String workflowName;
	
	/** The source files. */
	List<String> sourceFiles;
}
