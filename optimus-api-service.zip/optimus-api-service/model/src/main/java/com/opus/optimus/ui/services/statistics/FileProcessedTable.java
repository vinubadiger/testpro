package com.opus.optimus.ui.services.statistics;

import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new file processed table.
 */
@NoArgsConstructor

/**
 * Instantiates a new file processed table.
 *
 * @param fileName the file name
 * @param jobStatus the job status
 * @param startedTime the started time
 */
@AllArgsConstructor
@Builder
public class FileProcessedTable {

	/** The file name. */
	String fileName;
	
	/** The job status. */
	JobStatus jobStatus;
	
	/** The started time. */
	String startedTime;

	
}
