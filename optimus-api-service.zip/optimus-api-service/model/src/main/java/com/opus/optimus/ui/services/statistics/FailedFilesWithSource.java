package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new failed files with source.
 */
@NoArgsConstructor

/**
 * Instantiates a new failed files with source.
 *
 * @param failedReason the failed reason
 * @param workflowName the workflow name
 * @param count the count
 */
@AllArgsConstructor
@Builder
public class FailedFilesWithSource {

	/** The failed reason. */
	String failedReason;
	
	/** The workflow name. */
	String workflowName;
	
	/** The count. */
	int count;
}
