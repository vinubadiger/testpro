package com.opus.optimus.ui.services.recon;

import java.util.List;

import com.opus.optimus.offline.config.recon.subtypes.EtlSource;

import lombok.Data;

/**
 * Instantiates a new recon source form helper.
 */
@Data
public class ReconSourceFormHelper {
	
	/** The sources. */
	private List<EtlSource> sources;
}