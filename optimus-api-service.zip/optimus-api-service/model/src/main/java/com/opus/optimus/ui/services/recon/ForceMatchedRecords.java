package com.opus.optimus.ui.services.recon;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new force match request.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ForceMatchedRecords {
	private String sourceName;
	private String stepName;
	private List<ForceMatchRecordInfo> selectedRec;

}
