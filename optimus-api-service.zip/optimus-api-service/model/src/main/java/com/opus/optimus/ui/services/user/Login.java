package com.opus.optimus.ui.services.user;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new login.
 *
 * @param userName the user name
 * @param password the password
 */
@AllArgsConstructor

/**
 * Instantiates a new login.
 */
@NoArgsConstructor
@Builder
@Data
@Document (collection = "Login")
public class Login {
	
	/** The user name. */
	@Id
	private String userName;

	/** The password. */
	private String password;

}
