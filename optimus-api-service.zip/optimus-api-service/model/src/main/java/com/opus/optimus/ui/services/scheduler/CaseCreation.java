package com.opus.optimus.ui.services.scheduler;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// TODO: Auto-generated Javadoc
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Data

/**
 * Instantiates a new case creation.
 *
 * @param referenceId the reference id
 * @param status the status
 * @param origin the origin
 * @param priority the priority
 * @param exceptionType the exception type
 * @param subject the subject
 * @param description the description
 * @param batchTypeNameInstanceId the batch type name instance id
 * @param runDataTime the run data time
 * @param fileUsedForUpload the file used for upload
 * @param contactName the contact name
 * @param contactSkypeName the contact skype name
 * @param reason the reason
 * @param activity the activity
 * @param project the project
 */
@AllArgsConstructor
@Builder
@Document

/**
 * Instantiates a new case creation.
 */
@NoArgsConstructor
public class CaseCreation {

	String caseId;
	
	/** The reference id. */
	String referenceId;

	/** The status. */
	String status;

	/** The origin. */
	String origin;

	/** The priority. */
	String priority;

	/** The exception type. */
	String exceptionType;

	/** The subject. */
	String subject;

	/** The description. */
	String description;

	/** The batch type name instance id. */
	String batchTypeNameInstanceId;

	/** The run data time. */
	String runDataTime;

	/** The file used for upload. */
	String fileUsedForUpload;

	/** The contact name. */
	String contactName;

	/** The contact skype name. */
	String contactSkypeName;

	/** The reason. */
	String reason;

	/** The activity. */
	String activity;

	/** The project. */
	String project;
	
	String comments;
	
	String reasonCode;
}
