package com.opus.optimus.ui.services.project;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.ui.constants.Constants;

import lombok.Data;

/**
 * Instantiates a new workflow.
 */
@Data
@Document (collection = "Workflow")
public class Workflow extends WorkflowConfig {

	/** The id. */
	@Id
	private String id;

	/** The project name. */
	@Field (Constants.PROJECT_NAME)
	private String projectName;

	/** The project id. */
	@Field (Constants.PROJECT_ID)
	private String projectId;

	/** The institution id. */
	@Field (Constants.INSTITUTION_ID)
	private String institutionId;

	/** The institution name. */
	@Field (Constants.INSTITUTION_NAME)
	private String institutionName;

	/** The workflow name. */
	@Field (Constants.WORKFLOW_NAME)
	private String workflowName;

	/** The workflow type. */
	@Field (Constants.WORKFLOW_TYPE)
	private String workflowType;

	/** The workflow description. */
	@Field (Constants.WORKFLOW_DESCRIPTION)
	private String workflowDescription;

	/** The created date. */
	@Field (Constants.CREATED_DATE)
	private Date createdDate;

	/** The modified date. */
	@Field (Constants.MODIFIED_DATE)
	private Date modifiedDate;

	/** The created by. */
	@Field (Constants.CREATED_BY)
	private String createdBy;

	/** The last updated by. */
	@Field (Constants.LAST_UPDATED_BY)
	private String lastUpdatedBy;

	/** The flow data. */
	@Field (Constants.FLOW_DATA)
	private Object flowData;

	/** The activity status. */
	@Field (Constants.ACTIVITY_STATUS)
	private String activityStatus;

}
