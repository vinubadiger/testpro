package com.opus.optimus.ui.services.statistics;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new failure summary with project.
 */
@NoArgsConstructor

/**
 * Instantiates a new failure summary with project.
 *
 * @param projectName the project name
 * @param outputMap the output map
 */
@AllArgsConstructor
@Builder
public class FailureSummaryWithProject {

	/** The project name. */
	String projectName;

	/** The output map. */
	Map<String, Long> outputMap;
}
