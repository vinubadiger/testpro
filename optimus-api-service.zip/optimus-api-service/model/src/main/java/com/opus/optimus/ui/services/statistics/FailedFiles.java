package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new failed files.
 */
@NoArgsConstructor

/**
 * Instantiates a new failed files.
 *
 * @param failedReason the failed reason
 * @param projectName the project name
 * @param count the count
 */
@AllArgsConstructor
@Builder
public class FailedFiles {

	/** The failed reason. */
	String failedReason;
	
	/** The project name. */
	String projectName;
	
	/** The count. */
	int count;
}
