package com.opus.optimus.ui.services.scheduler;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

/**
 * The Interface SchedulerPolicy.
 */
@JsonTypeInfo (use = Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "policyType", visible = true)
@JsonSubTypes ({ @JsonSubTypes.Type (value = EventBased.class, name = "EVENTBASED"), @JsonSubTypes.Type (value = TimeBased.class, name = "TIMEBASED"), @JsonSubTypes.Type (value = DependencyBased.class, name = "DEPENDENCYBASED"), })
public interface SchedulerPolicy {
	
	/**
	 * Gets the policy type.
	 *
	 * @return the policy type
	 */
	String getPolicyType();
}
