package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new failure info summary.
 */
@NoArgsConstructor

/**
 * Instantiates a new failure info summary.
 *
 * @param source the source
 * @param files the files
 * @param records the records
 */
@AllArgsConstructor
@Builder
public class FailureInfoSummary {

	/** The source. */
	FailureInfo source;

	/** The files. */
	FailureInfo files;

	/** The records. */
	FailureInfo records;

}
