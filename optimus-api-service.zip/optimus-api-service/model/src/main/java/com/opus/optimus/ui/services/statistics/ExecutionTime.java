package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new execution time.
 */
@NoArgsConstructor

/**
 * Instantiates a new execution time.
 *
 * @param avgProcessiongTimePerSource the avg processiong time per source
 * @param recordProcessedPerSec the record processed per sec
 */
@AllArgsConstructor
@Builder
public class ExecutionTime {

	/** The avg processiong time per source. */
	double avgProcessiongTimePerSource;

	/** The record processed per sec. */
	double recordProcessedPerSec;
}
