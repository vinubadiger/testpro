package com.opus.optimus.ui.services.util;

import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtility {
	private static final Logger logger = LoggerFactory.getLogger(FileUtility.class);
	
	private FileUtility() {}

	/**
	 * Return the extension of a file name
	 * 
	 * @param destfile
	 * @return
	 */
	public static String getFileExtension(String destfile) {
		logger.debug("File name with extension {}", destfile);
		String extn = (null != destfile) ? destfile.substring(destfile.lastIndexOf('.')+1) : "";
		logger.debug("Extension found {}", extn);
		return (extn.length() > 4) ? "" : extn;
	}

	/**
	 * Return the file name without its extension
	 * 
	 * @param destfile
	 * @return
	 */
	public static String getFileNameWithoutExtension(String destfile) {
		logger.debug("File name of which extension to be truncated : {}", destfile);
		String fileExtn = getFileExtension(destfile);
		logger.debug("Extension found {}", fileExtn);
		String fileWithoutExtn = (null != destfile && !fileExtn.isEmpty()) ? destfile.substring(0, destfile.lastIndexOf('.')) : destfile;
		logger.debug("FileName Without Extn {}", fileWithoutExtn);
		return fileWithoutExtn;
	}

	/**
	 * move file from source location to destination location which is file-in-process
	 * 
	 * @param srcFilePath
	 * @param destFilePath
	 */
	public static void moveFileInProcessDirectory(String srcFilePath, String destFilePath) {
		Path sourceFile = Paths.get(srcFilePath);
		Path targetFile = Paths.get(destFilePath);
		try{
			logger.debug("Moving file from {} to {}", srcFilePath, destFilePath);
			Files.move(sourceFile, targetFile, StandardCopyOption.ATOMIC_MOVE);
			logger.debug("File moved!");
		} catch (NoSuchFileException e){
			logger.error("File not present at location: {}", e.getMessage());
		} catch (FileAlreadyExistsException e){
			logger.error("File alerady present: {} ", e.getMessage());
		} catch (Exception e){
			logger.error("In exception in moveFileInProcessDirectory: {}", e.getMessage());
		}
	}
}
