package com.opus.optimus.ui.services.user;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.ui.constants.Constants;

import lombok.Data;


/**
 * Instantiates a new institution.
 */
@Data
@Document (collection = "Institution")
public class Institution {

	/** The id. */
	@Id
	private String id;

	/** The institution name. */
	@Field (Constants.INSTITUTION_NAME)
	private String institutionName;

	/** The display name. */
	@Field (Constants.DISPLAY_NAME)
	private String displayName;

	/** The admin email. */
	@Field (Constants.ADMIN_EMAIL)
	private String adminEmail;

	/** The mobile no. */
	@Field(Constants.MOBILE_NO)
	private String mobileNo;
	
	/** The address. */
	private String address;

}
