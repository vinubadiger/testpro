package com.opus.optimus.ui.services.user;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new group.
 *
 * @param grpId the grp id
 * @param grpName the grp name
 * @param grpDesc the grp desc
 * @param createdBy the created by
 * @param createdDate the created date
 * @param modifiedBy the modified by
 * @param modifiedDate the modified date
 */
@AllArgsConstructor

/**
 * Instantiates a new group.
 */
@NoArgsConstructor
@Builder
@Data
@Document(collection = "Group")
@JsonInclude(Include.NON_NULL)
public class Group {
	
	/** The grp id. */
	@Id
	private String grpId;

	/** The grp name. */
	private String grpName;

	/** The grp desc. */
	private String grpDesc;

	/** The created by. */
	private String createdBy;

	/** The created date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	/** The modified by. */
	private String modifiedBy;

	/** The modified date. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
}
