package com.opus.optimus.ui.services.recon;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new force match request.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ForceMatchRecordInfo {
	private String recId;
    private String caseID;

}
