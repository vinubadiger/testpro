package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new job info summary.
 */
@NoArgsConstructor

/**
 * Instantiates a new job info summary.
 *
 * @param workflowName the workflow name
 * @param workflowType the workflow type
 * @param count the count
 */
@AllArgsConstructor
@Builder
public class JobInfoSummary {

	/** The workflow name. */
	String workflowName;

	/** The workflow type. */
	String workflowType;

	/** The count. */
	int count;
}
