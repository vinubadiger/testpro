package com.opus.optimus.ui.services.scheduler.util;

/**
 * The Enum PolicyType.
 */
public enum PolicyType {

	/** The eventbased. */
	EVENTBASED,
	/** The timebased. */
	TIMEBASED,
	/** The dependencybased. */
	DEPENDENCYBASED
}
