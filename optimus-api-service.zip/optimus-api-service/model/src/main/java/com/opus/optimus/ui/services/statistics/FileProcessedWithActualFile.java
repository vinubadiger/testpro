package com.opus.optimus.ui.services.statistics;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new file processed with actual file.
 */
@NoArgsConstructor

/**
 * Instantiates a new file processed with actual file.
 *
 * @param projectName the project name
 * @param workflowName the workflow name
 * @param workflowType the workflow type
 * @param activeFrom the active from
 * @param statistics the statistics
 */
@AllArgsConstructor
@Builder
public class FileProcessedWithActualFile {

	/** The project name. */
	String projectName;
	
	/** The workflow name. */
	String workflowName;
	
	/** The workflow type. */
	String workflowType;
	
	/** The active from. */
	String activeFrom;

	/** The statistics. */
	Map<String, FileStatistics> statistics;


	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		FileProcessedWithActualFile other = (FileProcessedWithActualFile) obj;
		if (projectName == null){
			if (other.projectName != null) return false;
		} else if (!projectName.equals(other.projectName)) return false;
		if (workflowName == null){
			if (other.workflowName != null) return false;
		} else if (!workflowName.equals(other.workflowName)) return false;
		if (workflowType == null){
			if (other.workflowType != null) return false;
		} else if (!workflowType.equals(other.workflowType)) return false;
		return true;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + ((workflowName == null) ? 0 : workflowName.hashCode());
		result = prime * result + ((workflowType == null) ? 0 : workflowType.hashCode());
		return result;
	}

}
