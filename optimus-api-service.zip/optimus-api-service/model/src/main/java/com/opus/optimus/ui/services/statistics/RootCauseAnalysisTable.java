package com.opus.optimus.ui.services.statistics;

import java.util.Date;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new root cause analysis table.
 */
@NoArgsConstructor

/**
 * Instantiates a new root cause analysis table.
 *
 * @param fileName the file name
 * @param recordsImpacted the records impacted
 * @param errorType the error type
 * @param description the description
 * @param outputMap the output map
 * @param executionDate the execution date
 */
@AllArgsConstructor
@Builder
public class RootCauseAnalysisTable {

	/** The file name. */
	String fileName;
	
	/** The records impacted. */
	long recordsImpacted;
	
	/** The error type. */
	String errorType;
	
	/** The description. */
	String description;
	
	/** The output map. */
	Map<String, Long> outputMap;
	
	/** The execution date. */
	Date executionDate;
}
