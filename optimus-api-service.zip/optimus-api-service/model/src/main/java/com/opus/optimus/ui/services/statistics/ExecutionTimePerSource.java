package com.opus.optimus.ui.services.statistics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

/**
 * Instantiates a new execution time per source.
 */
@NoArgsConstructor

/**
 * Instantiates a new execution time per source.
 *
 * @param workflowName the workflow name
 * @param executionTime the execution time
 */
@AllArgsConstructor
@Builder
public class ExecutionTimePerSource {

	/** The workflow name. */
	String workflowName;
	
	/** The execution time. */
	double executionTime;
}
