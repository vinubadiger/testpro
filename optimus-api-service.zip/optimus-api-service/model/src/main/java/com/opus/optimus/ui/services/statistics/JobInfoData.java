package com.opus.optimus.ui.services.statistics;

import java.util.Date;

import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data

/**
 * Instantiates a new job info data.
 */
@NoArgsConstructor

/**
 * Instantiates a new job info data.
 *
 * @param projectName the project name
 * @param workflowName the workflow name
 * @param workflowType the workflow type
 * @param startedTime the started time
 * @param status the status
 * @param sourceFile the source file
 * @param count the count
 */
@AllArgsConstructor
@Builder
public class JobInfoData {

	/** The project name. */
	String projectName;
	
	/** The workflow name. */
	String workflowName;
	
	/** The workflow type. */
	String workflowType;
	
	/** The started time. */
	Date startedTime;
	
	/** The status. */
	JobStatus status;
	
	/** The source file. */
	String sourceFile;
	
	/** The count. */
	int count;

}
