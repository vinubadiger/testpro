package com.opus.optimus.ui.services.util;

import lombok.Data;

@Data
public class CustomErrorType {

	/** The error message. */
	private String errorMessage;

	/** The reference error msg. */
	private String referenceErrorMsg;

	/**
	 * Instantiates a new custom error type.
	 *
	 * @param errorMessage the error message
	 */
	public CustomErrorType(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Instantiates a new custom error type.
	 *
	 * @param logRef the log ref
	 * @param message the message
	 */
	public CustomErrorType(String logRef, String message) {
		this(message);
		this.referenceErrorMsg = logRef;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return this.errorMessage;
	}
}