package com.opus.optimus.ui.services.user;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new api config.
 *
 * @param configId the config id
 * @param actionName the action name
 * @param controllerName the controller name
 * @param method the method
 * @param url the url
 * @param shortDesc the short desc
 * @param created the created
 * @param modified the modified
 * @param longDescription the long description
 * @param selected the selected
 */
@AllArgsConstructor

/**
 * Instantiates a new api config.
 */
@NoArgsConstructor
@Builder
@Data
@Document(collection = "ApiConfig")
@JsonInclude(Include.NON_NULL)
public class ApiConfig {

	/** The config id. */
	@Id
	private String configId;
	
	/** The action name. */
	private String actionName;

	/** The controller name. */
	private String controllerName;

	/** The method. */
	private String method;

	/** The url. */
	private String url;

	/** The short desc. */
	private String shortDesc;

	/** The created. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date created;

	/** The modified. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modified;

	/** The long description. */
	private String longDescription;
	
	/** The selected. */
	private boolean selected; // This field is used to indicated if the checkbox is checked or not
}