package com.opus.optimus.ui.constants;

public final class Constants {
	
	private Constants() {}

	// Institution
	public static final String INSTITUTION_ID = "institution_id";

	public static final String INSTITUTION_NAME = "institution_name";

	public static final String DISPLAY_NAME = "display_name";

	public static final String ADMIN_EMAIL = "admin_email";

	public static final String MOBILE_NO = "admin_mobile";

	// Project
	public static final String PROJECT_COLLECTION_NAME = "Project";

	public static final String PROJECT_DESCRIPTION = "project_desc";

	public static final String PROJECT_NAME = "project_name";

	// Workflow
	public static final String WORKFLOW_COLLECTION_NAME = "Workflow";

	public static final String PROJECT_ID = "project_id";

	public static final String WORKFLOW_DESCRIPTION = "workflow_desc";

	public static final String CREATED_DATE = "created_date";

	public static final String MODIFIED_DATE = "modified_date";

	public static final String CREATED_BY = "created_by";

	public static final String LAST_UPDATED_BY = "last_updated_by";

	public static final String FLOW_DATA = "flow_data";

	public static final String WORKFLOW_ID = "workflowid";

	public static final String WORKFLOW_NAME = "workflowname";

	public static final String WORKFLOW_TYPE = "workflowtype";

	// BatchDefinition
	public static final String BATCH_DEFINATION_COLLECTION_NAME = "batch_definition";

	public static final String NEXT_TRIGGER_TIME = "next_trigger_time";

	public static final String PREVIOUS_TRIGGER_TIME = "previous_trigger_time";

	public static final String SCHEDULAR_POLICY = "scheduler_policy";

	// BatchMonitor
	public static final String BATCH_MONITOR_COLLECTION_NAME = "batch_monitor";

	public static final String BATCH_INSTANCE_ID = "batch_instance_id";

	public static final String CREATED_TIME = "created_time";

	public static final String START_TIME = "start_time";

	public static final String END_TIME = "end_time";

	public static final String TRIGGER_TYPE = "trigger_type";

	public static final String EXECUTION_STATUS = "execution_status";

	public static final String RECORDS_PROCESSED = "records_processed";

	public static final String RECORDS_PASSED = "records_passed";

	public static final String RECORDS_FAILED = "records_failed";

	public static final String SOURCE_INFORMATION = "source_information";

	public static final String EXCEPTION_LOGS = "exception_logs";

	public static final String STEP_INPUT = "step_input";

	public static final String GROUP_ID = "group_id";

	public static final String JOB_INFO = "jobInfo";

	public static final String STEP_NAMES = "step_names";
	
	public static final String DEFAULT_PASSOWRD = "Welcome";//Default password with which the user is created

	public static final String ACTIVITY_STATUS = "activity_status";
	
	/*
	 *Constant for list of aggregation steps to be performed by the MongoDB Aggregation 
	 */
	
	public static final String PROJECTNAME ="projectName";
	public static final String WORKFLOWNAME ="workflowName";
	public static final String WORKFLOWTYPE ="workflowType";
	public static final String STARTEDTIME ="startedTime";
	public static final String STATUS ="status";
	public static final String COUNT ="count";
	public static final String PROCESSINGTIME ="processingTime";
	public static final String FAILEDREASON ="failedReason";
	public static final String ERRORCODE = "errorReason.errorCode";
	public static final String SOURCEFILE = "sourceInfo.sourceFile";
	                                         
	/*
	 * Constants for user readable Step Type 
	*/
	public static final String EXTRACTION = "Extraction";
	public static final String LOADER = "Loader";
	public static final String TRANSFORMATION = "Transformation";
	public static final String VALIDATION = "Validation";
	public static final String GLOBLEERROR = "Global Error";
	public static final String SALESFORCECASECREATION = "Case Creation";
	public static final String RECONCILATION = "Reconciliation";
	public static final String RECONSOURCEREADER = "Recon Source Reader";
	public static final String RECONSTATUSUPDATOR = "Recon Status Updator";
	
	public static final String USERNAME = "userName";
}
