package com.opus.optimus.ui.services.recon;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.recon.SourceMappingType;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationConfig;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationConfig.UnitType;

import lombok.Data;

/**
 * Instantiates a new activity.
 */
@Data
@Document (collection = "Activity")
public class Activity {
	
	/** The id. */
	@Id
	private String id;
	
	/** The project name. */
	private String projectName;
	
	/** The name. */
	private String name;
	
	/** The workflow type. */
	private String workflowType; // value will be always "RECON"
	
	/** The description. */
	private String description;

	/** The source mapping. */
	private SourceMappingType sourceMapping;
	
	/** The unreconciled backlog. */
	private boolean unreconciledBacklog;
	
	/** The time leg interval. */
	private int timeLegInterval;
	
	/** The unit. */
	private UnitType unit; // day/week
	
	/** The db reader steps. */
	private List<MongoDBReaderConfig> dbReaderSteps; // List of SourceA and Source B
	
	/** The recon step config. */
	private ReconciliationConfig reconStepConfig; /// Matching rule
	
	/** The recon status update config. */
	private ReconStatusUpdateConfig reconStatusUpdateConfig; // SummaryFields
	
	/** The activity status. */
	private String activityStatus;

	/** The created date. */
	private Date createdDate;
	
	/** The modified date. */
	private Date modifiedDate;
	
	/** The institution id. */
	private String institutionId;
	
	/** The created by. */
	private String createdBy;
	
	/** The last updated by. */
	private String lastUpdatedBy;
}
