package com.opus.optimus.offline.services.taskmanager.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SkipOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.TextCriteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.repository.scheduler.BatchDefinitionRepository;
import com.opus.optimus.offline.repository.scheduler.taskmanager.JobInfoDataRepository;
import com.opus.optimus.offline.repository.scheduler.taskmanager.JobTaskExecutorResultRepository;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.offline.services.taskmanager.JobInfoDataService;
import com.opus.optimus.ui.constants.Constants;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.SchedulerPolicy;
import com.opus.optimus.ui.services.scheduler.TimeBased;
import com.opus.optimus.ui.services.scheduler.WigdetResult;
import com.opus.optimus.ui.services.statistics.BatchExpectedCountStore;
import com.opus.optimus.ui.services.statistics.ExecutionTime;
import com.opus.optimus.ui.services.statistics.ExecutionTimePerSource;
import com.opus.optimus.ui.services.statistics.FailedFiles;
import com.opus.optimus.ui.services.statistics.FailedFilesWithSource;
import com.opus.optimus.ui.services.statistics.FailureAnalysisWithSourceAndFile;
import com.opus.optimus.ui.services.statistics.FailureInfo;
import com.opus.optimus.ui.services.statistics.FailureInfoSummary;
import com.opus.optimus.ui.services.statistics.FailureSummaryWithProject;
import com.opus.optimus.ui.services.statistics.FileProcessedTable;
import com.opus.optimus.ui.services.statistics.FileProcessedWithActualFile;
import com.opus.optimus.ui.services.statistics.FileStatistics;
import com.opus.optimus.ui.services.statistics.JobInfoData;
import com.opus.optimus.ui.services.statistics.JobInfoSummary;
import com.opus.optimus.ui.services.statistics.RootCauseAnalysisTable;
import com.opus.optimus.ui.services.util.CommonUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class JobInfoDataServiceImpl.
 * 
 * @author manjusha.dhamdhere
 */
@Service
public class JobInfoDataServiceImpl implements JobInfoDataService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JobInfoDataServiceImpl.class);

	/** The job info data repository. */
	@Autowired
	private JobInfoDataRepository jobInfoDataRepository;

	/** The jobtaskexecutorresultrepository. */
	@Autowired
	private JobTaskExecutorResultRepository jobtaskexecutorresultrepository;

	/** The batch definition repository. */
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;

	/** The mongo template. */
	@Autowired
	private MongoTemplate mongoTemplate;

	/** The total records processed. */
	private Long totalRecordsProcessed = 0L;

	/**
	 * Save Job info.
	 *
	 * @param jobId the job id
	 * @param jobinfo the jobinfo
	 * @return the string
	 */
	@Override
	public String save(String jobId, JobInfo jobinfo) {
		try{
			logger.debug("jobid in service {}", jobId);
			logger.debug("jobid in service jobupdate {}", jobinfo.getSourceInfo());
			JobInfo recievedjobinfo = this.jobInfoDataRepository.findJobbyId(jobId);
			logger.debug("job info : {}", CommonUtil.getJsonFromObject(recievedjobinfo));
			recievedjobinfo.setWorkflowName(jobinfo.getWorkflowName());
			recievedjobinfo.setWorkflowType(jobinfo.getWorkflowType());
			recievedjobinfo.setProjectName(jobinfo.getProjectName());
			recievedjobinfo.setGroupId(jobinfo.getGroupId());
			recievedjobinfo.setSourceInfo(jobinfo.getSourceInfo());
			jobInfoDataRepository.save(recievedjobinfo);
			return "Updated Jobinfo";
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the job info.
	 *
	 * @param page the page
	 * @param size the size
	 * @return the job info
	 */
	@Override
	public Page<JobInfo> getJobInfo(int page, int size) {
		try{
			Pageable pageable = PageRequest.of(page, size);
			return this.jobInfoDataRepository.findAll(pageable);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the job info order by.
	 *
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the job info order by
	 */
	@Override
	public Page<JobInfo> getJobInfoOrderBy(int page, int size, String orderType, String field) {
		try{
			Sort sort;
			String order = "ASC";
			if (orderType.equals(order)){
				sort = new Sort(Sort.Direction.ASC, field);
			} else{
				sort = new Sort(Sort.Direction.DESC, field);
			}
			Pageable pageable = PageRequest.of(page, size, sort);
			return this.jobInfoDataRepository.findAll(pageable);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Find all Job info by.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	@Override
	public Page<JobInfo> findAllBy(String search, int page, int size) {
		TextCriteria tsearch = TextCriteria.forDefaultLanguage().matching(search).caseSensitive(false);
		Pageable pageable = PageRequest.of(page, size);
		return jobInfoDataRepository.findAllBy(tsearch, pageable);
	}

	/**
	 * Search by column name and text.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	@Override
	public Page<JobInfo> searchbycolumnnameandtext(String column, String text, int page, int size) {
		Pageable pageable = PageRequest.of(page, size);
		Criteria criteria = Criteria.where(column).regex(Pattern.compile(text, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));
		SkipOperation skipOperation = Aggregation.skip(Integer.valueOf(pageable.getPageNumber()).longValue() * Integer.valueOf(pageable.getPageSize()).longValue());
		LimitOperation limitOperation = Aggregation.limit(pageable.getPageSize());
		SortOperation sortOperation = sort(Sort.Direction.DESC, column);

		Aggregation agg = newAggregation(Aggregation.match(criteria), skipOperation, limitOperation, sortOperation);
		AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class, JobInfo.class);

		return new PageImpl<>(result.getMappedResults());
	}

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	@Override
	public Page<JobInfo> autocompleteByText(String column, String pattern) {
		Criteria regxCriteria = Criteria.where(column).regex(pattern);
		SortOperation sortOperation = sort(Sort.Direction.DESC, column);
		Aggregation agg = newAggregation(Aggregation.match(regxCriteria), sortOperation);
		AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class, JobInfo.class);
		return new PageImpl<>(result.getMappedResults());
	}

	// ****************** AGGREGATE FUNCTIONS STARTS FROM HERE *****************************//

	/**
	 * Builds the optional date range project criteria.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectname the projectname
	 * @param workflowType the workflow type
	 * @return the criteria
	 */
	private Criteria buildOptionalDateRangeProjectCriteria(Date startDate, Date endDate, String projectname, String workflowType) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowCheckCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			if (projectname != null){
				dateRangeCriteria.andOperator(Criteria.where(Constants.PROJECTNAME).is(projectname), workflowCheckCriteria);
			} else{
				dateRangeCriteria.andOperator(workflowCheckCriteria);
			}
			return dateRangeCriteria;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Aggregate.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<WigdetResult> aggregate(Date startDate, Date endDate, String projectName, String workflowType) {
		try{
			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOpeartion = group(Constants.STATUS).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.STATUS).previousOperation();
			SortOperation sortOperation = sort(Sort.Direction.DESC, Constants.COUNT);

			Aggregation agg = newAggregation(Aggregation.match(dateRangeProjectOptionalCriteria), groupOpeartion, projection, sortOperation);
			AggregationResults<WigdetResult> groupResults = mongoTemplate.aggregate(agg, JobInfo.class, WigdetResult.class);
			return groupResults.getMappedResults();

		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Workflow statistics.
	 *
	 * @param status the status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<JobInfoSummary> workflowStatistics(String status, Date startDate, Date endDate, String workflowType, String projectName) {

		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workFlowCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria statusCriteria = Criteria.where(Constants.STATUS).is(status);

			GroupOperation aggregationGroup = Aggregation.group(Constants.WORKFLOWNAME, Constants.WORKFLOWTYPE).count().as(Constants.COUNT);

			MatchOperation matchOperation;
			if (projectName != null){
				Criteria projectCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workFlowCriteria, projectCriteria, statusCriteria));
			} else{
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workFlowCriteria, statusCriteria));
			}
			TypedAggregation<JobInfo> aggregation = Aggregation.newAggregation(JobInfo.class, matchOperation, aggregationGroup);
			AggregationResults<JobInfoSummary> result = mongoTemplate.aggregate(aggregation, JobInfoSummary.class);
			List<JobInfoSummary> sortedCopy = new ArrayList<>(result.getMappedResults());
			Collections.sort(sortedCopy, Comparator.comparingInt(JobInfoSummary::getCount).reversed());
			return sortedCopy;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Failure statistics.
	 *
	 * @param startDate the start date
	 * @param endDate1 the end date 1
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the map
	 */
	@Override
	public Map<String, Long> failureStatistics(Date startDate, Date endDate1, String workflowType, String projectName, String workflowName, String sourceFile) {
		try{
			totalRecordsProcessed = 0L;
			List<String> jobInfoList = getJobInfoIdList(startDate, endDate1, workflowType, projectName, workflowName, sourceFile);

			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoList);

			Map<String, Long> outputMap = new HashMap<>();

			jobResultList.stream().forEach(jobResult -> jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> {
				String step = changeStepName(stepExecutorResult.getStepType());
				stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						long countData = stepInstanceStats.getOutbound().getErrorCount();
						outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
					}
				});
			}));

			jobResultList.stream().forEach(jbRslt -> jbRslt.getStepExecutorResults().stream().filter(stpExRslt -> Optional.ofNullable(stpExRslt.getStepType()).orElse("").equals(StepTypeConstants.FILE_READER_STEPTYPE) && Optional.ofNullable(stpExRslt.getStatus()).orElse(OperationStatus.ABORTED).equals(OperationStatus.COMPLETED)).collect(Collectors.toList()).stream().forEach(stpExRslt -> stpExRslt.getInstanceStats().forEach(stepInstStat -> {
				totalRecordsProcessed += stepInstStat.getOutbound().getDataCount();
				totalRecordsProcessed += stepInstStat.getOutbound().getErrorCount();
			})));
			return outputMap;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Gets the job info id list.
	 *
	 * @param startDate the start date
	 * @param endDate1 the end date 1
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the job info id list
	 */
	private List<String> getJobInfoIdList(Date startDate, Date endDate1, String workflowType, String projectName, String workflowName, String sourceFile) {
		try{
			List<String> response = new ArrayList<>();
			Date endDate = CommonUtil.returnNextDay(endDate1);
			List<String> result;
			if (projectName == null && workflowName == null){
				result = this.jobInfoDataRepository.findAllIdsByWorkflowType(workflowType, startDate, endDate);
			} else if (projectName != null && workflowName == null){
				result = this.jobInfoDataRepository.findAllIdsByWorkflowTypeProject(workflowType, startDate, endDate, projectName);
			} else if (projectName == null && sourceFile == null){
				result = this.jobInfoDataRepository.findAllIdsByWorkflowNameType(workflowType, startDate, endDate, workflowName);
			} else if (projectName != null && sourceFile == null){
				result = this.jobInfoDataRepository.findAllIdsByProjectWorkflowNameType(workflowType, startDate, endDate, projectName, workflowName);
			} else{
				result = this.jobInfoDataRepository.findAllIdsByProjectWorkflowNameTypeFile(workflowType, startDate, endDate, projectName, workflowName, sourceFile);
			}
			result.stream().forEach(jsonString -> response.add(CommonUtil.getJsonFromString(jsonString).get("_id").asText()));
			return response;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the job task executor resultby id
	 */
	@Override
	public List<JobTaskExecutorResult> getJobTaskExecutorResultbyId(String jobId) {
		logger.debug("Get jobtaskexecutorresult List by JobId {}", jobId);
		List<JobTaskExecutorResult> jobtaskexecutorresult = null;
		try{
			jobtaskexecutorresult = jobtaskexecutorresultrepository.findAllJobTaskExecutorResultbyId(jobId);
			return jobtaskexecutorresult;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Failure analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failure info summary
	 */
	@Override
	public FailureInfoSummary failureAnalysis(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			FailureInfoSummary failureSummary = new FailureInfoSummary();

			// for Failure Record Count
			Map<String, Long> outputMap = this.failureStatistics(startDate, endDate, workflowType, projectName, null, null);
			Long totalRecordValues = 0L;
			for (Long val : outputMap.values()){
				totalRecordValues += val;
			}
			// set Failed Records
			failureSummary.setRecords(new FailureInfo(totalRecordValues, totalRecordsProcessed));
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Long failedFiles;
			Long allProcessedFiles;

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria dateRangeCriteria1 = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria statusCriteria = Criteria.where(Constants.STATUS).is(JobStatus.COMPLETED_FAILED);
			GroupOperation groupByWorkflowName = Aggregation.group(Constants.WORKFLOWNAME).count().as("filesFailed");
			MatchOperation matchCriteriaTotalFiles;
			MatchOperation matchCriteriaFailedFiles;
			if (projectName == null){
				failedFiles = this.jobInfoDataRepository.countOfFailedFiles(workflowType, startDate, endDate1);
				allProcessedFiles = this.jobInfoDataRepository.countOfAllFiles(workflowType, startDate, endDate1);

				matchCriteriaFailedFiles = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, statusCriteria));
				matchCriteriaTotalFiles = Aggregation.match(dateRangeCriteria1.andOperator(workflowTypeCriteria));
			} else{

				Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				failedFiles = this.jobInfoDataRepository.countOfFailedFilesWithProjectName(workflowType, startDate, endDate1, projectName);
				allProcessedFiles = this.jobInfoDataRepository.countOfAllFilesWithProjectName(workflowType, startDate, endDate1, projectName);

				matchCriteriaFailedFiles = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, statusCriteria, projectNameCriteria));
				matchCriteriaTotalFiles = Aggregation.match(dateRangeCriteria1.andOperator(workflowTypeCriteria, projectNameCriteria));
			}

			failureSummary.setFiles(new FailureInfo(failedFiles, allProcessedFiles));

			TypedAggregation<JobInfo> aggregationFailed = Aggregation.newAggregation(JobInfo.class, matchCriteriaFailedFiles, groupByWorkflowName);
			TypedAggregation<JobInfo> aggregationTotal = Aggregation.newAggregation(JobInfo.class, matchCriteriaTotalFiles, groupByWorkflowName);

			AggregationResults<FailureInfoSummary> resultFailedFiles = mongoTemplate.aggregate(aggregationFailed, JobInfo.class, FailureInfoSummary.class);
			AggregationResults<FailureInfoSummary> resultTotalFiles = mongoTemplate.aggregate(aggregationTotal, JobInfo.class, FailureInfoSummary.class);

			failureSummary.setSource(new FailureInfo((long) resultFailedFiles.getMappedResults().size(), (long) resultTotalFiles.getMappedResults().size()));

			return failureSummary;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Failure analysis pie chart.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param workflowName the workflow name
	 * @param stepName the step name
	 * @return the map
	 */
	@Override
	public Map<String, Long> failurerAnalysisPieChart(Date startDate, Date endDate, String workflowType, String workflowName, String stepName) {
		try{
			List<String> jobInfoList = getJobInfoIdList(startDate, endDate, workflowType, workflowName, null, null);
			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoList);

			List<FailureSummaryWithProject> listSummary = new ArrayList<>();
			jobResultList.stream().forEach(jobResult -> {
				FailureSummaryWithProject failureSummaryObj = new FailureSummaryWithProject();
				if (jobResult.getWorkflowName() != null){
					failureSummaryObj.setProjectName(jobResult.getWorkflowName());
				}
				Map<String, Long> outputMap = new HashMap<>();
				jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					String step = changeStepName(stepExecutorResult.getStepType());
					if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						long countData = stepInstanceStats.getOutbound().getErrorCount();
						outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
					}
				}));

				failureSummaryObj.setOutputMap(outputMap);
				listSummary.add(failureSummaryObj);
			});
			return mapOfProjectNameAndFailedRecordsCount(listSummary, stepName);

		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * This return map of project name and count of failed records.
	 *
	 * @param listSummary the list summary
	 * @param stepName the step name
	 * @return the map
	 */
	private Map<String, Long> mapOfProjectNameAndFailedRecordsCount(List<FailureSummaryWithProject> listSummary, String stepName) {
		Map<String, Long> outputMapProject = new HashMap<>();
		listSummary.stream().forEach(summary -> {
			Long totalCount = 0L;
			if (stepName == null || stepName.isEmpty()){
				for (Long val : summary.getOutputMap().values()){
					totalCount += val;
				}
			} else{
				for (Map.Entry<String, Long> entry : summary.getOutputMap().entrySet()){
					switch (stepName) {
					case Constants.EXTRACTION:
						if (entry.getKey().equals(Constants.EXTRACTION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.VALIDATION:
						if (entry.getKey().equals(Constants.VALIDATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.TRANSFORMATION:
						if (entry.getKey().equals(Constants.TRANSFORMATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.LOADER:
						if (entry.getKey().equals(Constants.LOADER)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.GLOBLEERROR:
						if (entry.getKey().equals(Constants.GLOBLEERROR)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.SALESFORCECASECREATION:
						if (entry.getKey().equals(Constants.SALESFORCECASECREATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONCILATION:
						if (entry.getKey().equals(Constants.RECONCILATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONSOURCEREADER:
						if (entry.getKey().equals(Constants.RECONSOURCEREADER)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONSTATUSUPDATOR:
						if (entry.getKey().equals(Constants.RECONSTATUSUPDATOR)){
							totalCount += entry.getValue();
						}
						break;
					default:
						break;
					}
				}
			}
			outputMapProject.put(summary.getProjectName(), Optional.ofNullable(outputMapProject.get(summary.getProjectName())).orElse(Long.valueOf(0)) + Long.valueOf(totalCount));
		});

		return sortByValue(outputMapProject);
	}

	/**
	 * Sort by value.
	 *
	 * @param wordCounts the word counts
	 * @return the map
	 */
	private static Map<String, Long> sortByValue(final Map<String, Long> wordCounts) {
		return wordCounts.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
	}

	/**
	 * Processiong time calculation.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the execution time
	 */
	@Override
	public ExecutionTime processiongTimeCalculation(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			this.failureStatistics(startDate, endDate, workflowType, projectName, null, null);

			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOpeartion = Aggregation.group().avg(Constants.PROCESSINGTIME).as("avgProcessiongTimePerSource").sum(Constants.PROCESSINGTIME).as("recordProcessedPerSec");

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(dateRangeProjectOptionalCriteria), groupOpeartion);
			AggregationResults<ExecutionTime> result = mongoTemplate.aggregate(agg, ExecutionTime.class);

			ExecutionTime executionTime = result.getMappedResults().get(0);
			Double truncatedDouble = BigDecimal.valueOf(executionTime.getAvgProcessiongTimePerSource() / 1000).setScale(3, RoundingMode.HALF_UP).doubleValue();
			executionTime.setAvgProcessiongTimePerSource(truncatedDouble);
			executionTime.setRecordProcessedPerSec(Math.round(totalRecordsProcessed / (executionTime.getRecordProcessedPerSec() / 1000)));

			return executionTime;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;

		}

	}

	/**
	 * Failure analysis root cause analysis table.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@Override
	public List<RootCauseAnalysisTable> failureAnalysisRootCauseAnalysisTable(Date startDate, Date endDate, String workflowType, String projectName, String workflowName) {
		try{
			List<RootCauseAnalysisTable> rootCauseList = new ArrayList<>();
			List<RootCauseAnalysisTable> listSummary = new ArrayList<>();

			List<String> jobInfoIdList = getJobInfoIdList(startDate, endDate, workflowType, projectName, workflowName, null);
			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoIdList);

			Iterable<JobInfo> jobInfoList = jobInfoDataRepository.findAllById(jobInfoIdList);
			jobInfoList.forEach(jobInfo -> {
				jobInfo.getId();
				if (jobInfo.getErrorReason() != null && jobInfo.getErrorReason().getErrorCode() != null && jobInfo.getSourceInfo() != null && jobInfo.getSourceInfo().getSourceFile() != null && jobInfo.getStartedTime() != null){
					RootCauseAnalysisTable rootCauseAnalysis = rootCauseAnalysisData(jobInfo.getSourceInfo().getSourceFile(), jobInfo.getStartedTime(), 0L, "File Level", getErrorReason(jobInfo.getErrorReason().getErrorCode()));
					rootCauseList.add(rootCauseAnalysis);
				}

			});

			jobResultList.stream().forEach(jobResult -> {
				RootCauseAnalysisTable rootCauseObj = new RootCauseAnalysisTable();
				long tmp = jobResult.getStartTime();
				Date d = new Date(tmp);
				rootCauseObj.setExecutionDate(d);
				if (jobResult.getSourceFile() != null) rootCauseObj.setFileName(jobResult.getSourceFile());
				Map<String, Long> outputMap = stepTypeErrorCountMap(jobResult);
				rootCauseObj.setOutputMap(outputMap);
				listSummary.add(rootCauseObj);

			});

			listSummary.stream().forEach(summaryObject -> {
				if (summaryObject.getFileName() != null){
					summaryObject.getOutputMap().forEach((errorStepType, errorCount) -> {
						if (errorCount != 0){
							RootCauseAnalysisTable rootCauseAnalysis = rootCauseAnalysisData(summaryObject.getFileName(), summaryObject.getExecutionDate(), errorCount, "Record Level", errorStepType.concat(" error"));
							rootCauseList.add(rootCauseAnalysis);
						}
					});
				}
			});

			Collections.sort(rootCauseList, Comparator.comparing(RootCauseAnalysisTable::getExecutionDate).reversed());
			return rootCauseList;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Root cause analysis data.
	 *
	 * @param fileName the file name
	 * @param executionDate the execution date
	 * @param recordsImpacted the records impacted
	 * @param errorType the error type
	 * @param description the description
	 * @return the root cause analysis table
	 */
	public RootCauseAnalysisTable rootCauseAnalysisData(String fileName, Date executionDate, long recordsImpacted, String errorType, String description) {
		RootCauseAnalysisTable rootCauseAnalysis = new RootCauseAnalysisTable();
		rootCauseAnalysis.setFileName(fileName);
		rootCauseAnalysis.setExecutionDate(executionDate);
		rootCauseAnalysis.setRecordsImpacted(recordsImpacted);
		rootCauseAnalysis.setErrorType(errorType);
		rootCauseAnalysis.setDescription(description);
		return rootCauseAnalysis;
	}

	/**
	 * Step type error count map.
	 *
	 * @param jobResult the job result
	 * @return the map
	 */
	public Map<String, Long> stepTypeErrorCountMap(JobTaskExecutorResult jobResult) {
		Map<String, Long> outputMap = new HashMap<>();
		jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> {
			String step = changeStepName(stepExecutorResult.getStepType());
			stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
				if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
					long countData = stepInstanceStats.getOutbound().getErrorCount();
					outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
				}
			});
		});
		return outputMap;

	}

	/**
	 * Change step name for UI.
	 *
	 * @param stepName the step name
	 * @return the string
	 */
	public String changeStepName(String stepName) {
		switch (stepName) {
		case StepTypeConstants.FILE_READER_STEPTYPE:
		case StepTypeConstants.EXCEL_READER_STEPTYPE:
			return Constants.EXTRACTION;
		case StepTypeConstants.MONGODB_WRITER_STEPTYPE:
			return Constants.LOADER;
		case StepTypeConstants.TRANSFORMER_STEPTYPE:
			return Constants.TRANSFORMATION;
		case StepTypeConstants.VALIDATOR_STEPTYPE:
			return Constants.VALIDATION;
		case StepTypeConstants.DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE:
			return Constants.GLOBLEERROR;
		case StepTypeConstants.SALESFORCE_CASE_CREATOR:
			return Constants.SALESFORCECASECREATION;
		case StepTypeConstants.RECON_CONFIG_STEP:
			return Constants.RECONCILATION;
		case StepTypeConstants.MONGO_DBREADER_STEP_TYPE:
			return Constants.RECONSOURCEREADER;
		case StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE:
			return Constants.RECONSTATUSUPDATOR;
		default:
			return "";
		}
	}

	/**
	 * Gets the error reason (user readable) using error code.
	 *
	 * @param errorCode the error code
	 * @return the error reason
	 */
	public String getErrorReason(String errorCode) {
		switch (errorCode) {
		case "RDR-GEN-005":
			return "File Not Found";
		case "RDR-GEN-006":
			return "Duplicate File";
		case "RDR-GEN-001":
			return "Reader General Exception";
		case "SYS-GEN-001":
			return "System General Exception";
		default:
			return "";
		}
	}

	/**
	 * Source files group by workflow name.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<FailureAnalysisWithSourceAndFile> sourceFilesGroupByWorkflowName(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).push("sourceInfo.sourceFile").as("sourceFiles");
			ProjectionOperation projection = project("sourceFiles").and(Constants.WORKFLOWNAME).previousOperation();

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(dateRangeProjectOptionalCriteria), groupOperation, projection);
			AggregationResults<FailureAnalysisWithSourceAndFile> result = mongoTemplate.aggregate(agg, JobInfo.class, FailureAnalysisWithSourceAndFile.class);

			return result.getMappedResults();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Execution time with source.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<ExecutionTimePerSource> executionTimeWithSource(Date startDate, Date endDate, String workflowType, String projectName) {
		try{

			List<ExecutionTimePerSource> executionTimePerSourceList = new ArrayList<>();

			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).avg(Constants.PROCESSINGTIME).as("executionTime");
			ProjectionOperation projection = project("executionTime").and(Constants.WORKFLOWNAME).previousOperation();

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(dateRangeProjectOptionalCriteria), groupOperation, projection);
			AggregationResults<ExecutionTimePerSource> result = mongoTemplate.aggregate(agg, JobInfo.class, ExecutionTimePerSource.class);

			logger.debug("result--> {}", CommonUtil.getJsonFromObject(result.getMappedResults()));
			result.getMappedResults().forEach(executionObject -> {
				Double truncatedDouble = BigDecimal.valueOf(executionObject.getExecutionTime() / 1000).setScale(3, RoundingMode.HALF_UP).doubleValue();
				executionObject.setExecutionTime(truncatedDouble);
				executionTimePerSourceList.add(executionObject);
			});
			return executionTimePerSourceList;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Gets the jobinfodatabyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param page the page
	 * @param size the size
	 * @return the jobinfodatabyparam
	 */
	@Override
	public Page<JobInfo> getjobinfodatabyparam(String projectName, String workflowName, String workflowType, int page, int size) {
		Pageable pageable = PageRequest.of(page, size);
		return jobInfoDataRepository.getjobinfodatabyparam(projectName, workflowName, workflowType, pageable);
	}

	/**
	 * Failure analysis failed files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@Override
	public List<FailedFiles> failureAnalysisFailedFiles(Date startDate, Date endDate, String workflowType, String projectName, String workflowName) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria workflowNameCriteria = Criteria.where(Constants.WORKFLOWNAME).is(workflowName);
			GroupOperation groupOperation = Aggregation.group(Constants.ERRORCODE).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.FAILEDREASON).previousOperation();
			MatchOperation matchCriteria;

			if (projectName == null){
				matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria));
			} else if (workflowName == null){
				matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria));
			} else{
				matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, workflowNameCriteria));
			}
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, matchCriteria, groupOperation, projection);
			AggregationResults<FailedFiles> result = mongoTemplate.aggregate(agg, JobInfo.class, FailedFiles.class);

			result.getMappedResults().stream().forEach(resultData -> {
				if (resultData.getFailedReason() != null){
					resultData.setFailedReason(getErrorReason(resultData.getFailedReason()));
				}
			});
			return result.getMappedResults();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Failure analysis failed files and projects.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorCode the error code
	 * @return the list
	 */
	@Override
	public List<FailedFilesWithSource> failureAnalysisFailedFilesAndProjects(Date startDate, Date endDate, String workflowType, String projectName, String errorCode) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria errorCodeExist = Criteria.where(Constants.ERRORCODE).exists(true);
			Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria errorCodeCriteria = Criteria.where(Constants.ERRORCODE).is(errorCode);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.WORKFLOWNAME).previousOperation();

			MatchOperation matchOperation;
			if (errorCode == null && projectName == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, errorCodeExist));
			} else if (projectName != null && errorCode == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, errorCodeExist));
			} else if (projectName == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, errorCodeCriteria));
			} else{
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, errorCodeCriteria));
			}

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, matchOperation, groupOperation, projection);
			AggregationResults<FailedFilesWithSource> result = mongoTemplate.aggregate(agg, JobInfo.class, FailedFilesWithSource.class);

			List<FailedFilesWithSource> sortedCopy = new ArrayList<>(result.getMappedResults());
			Collections.sort(sortedCopy, Comparator.comparingInt(FailedFilesWithSource::getCount).reversed());
			return sortedCopy;

		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the job info processed data day wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the job info processed data day wise
	 */
	@Override
	public List<FileProcessedWithActualFile> getJobInfoProcessedDataDayWise(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			Date todaysDate = CommonUtil.getFormattedDate(new Date(), null);
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			List<BatchDefinition> batchDefinition = batchDefinitionRepository.getExpectedFilesCounts();
			logger.debug("Recieved Batch list : {}", CommonUtil.getJsonFromObject(batchDefinition));
			Map<BatchExpectedCountStore, Integer> batchInfo = new HashMap<>();
			batchDefinition.forEach(batch -> {
				logger.debug("Batch detail : {}", CommonUtil.getJsonFromObject(batch));
				batchInfo.put(getBatchKey(batch.getProjectName(), batch.getWorkflowName(), batch.getWorkflowType(), Optional.ofNullable(batch.getSchedulerPolicy()).orElse(null)), Integer.valueOf(batch.getNumberOfExpectedFiles() == 0 ? 1 : batch.getNumberOfExpectedFiles()));
			});
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria todaysDateCriteria = Criteria.where(Constants.STARTEDTIME).gte(todaysDate);
			Criteria dateCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria matchingCriteria;
			if (projectName != null){
				Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria).andOperator(projectNameCriteria);
			} else{
				matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria);
			}
			MatchOperation matchOperation = Aggregation.match(matchingCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.PROJECTNAME, Constants.WORKFLOWNAME, Constants.WORKFLOWTYPE, Constants.STARTEDTIME, Constants.STATUS, Constants.SOURCEFILE).count().as("count");

			TypedAggregation<JobInfo> aggregation = Aggregation.newAggregation(JobInfo.class, matchOperation, groupOperation);
			AggregationResults<JobInfoData> jobInfoAggregation = mongoTemplate.aggregate(aggregation, JobInfo.class, JobInfoData.class);
			List<JobInfoData> jobInfoList = jobInfoAggregation.getMappedResults();
			logger.debug("Recevied JobInfoList : {}", CommonUtil.getJsonFromObject(jobInfoList));
			return populateDashboardStatistics(jobInfoList, batchInfo);

		} catch (Exception e){
			logger.error(e.getMessage());
			throw new GenericException(e);
		}

	}

	/**
	 * Populate dashboard statistics.
	 *
	 * @param jobInfoList the job info list
	 * @param batchInfo the batch info
	 * @return the list
	 */
	private List<FileProcessedWithActualFile> populateDashboardStatistics(List<JobInfoData> jobInfoList, Map<BatchExpectedCountStore, Integer> batchInfo) {
		try{
			List<FileProcessedWithActualFile> result = new ArrayList<>();
			jobInfoList.stream().forEach(jobInfo -> {
				logger.debug("Fetching JobInfo : {}", CommonUtil.getJsonFromObject(jobInfo));
				BatchExpectedCountStore batchKey = getBatchKey(jobInfo.getProjectName(), jobInfo.getWorkflowName(), jobInfo.getWorkflowType(), null);
				if (batchKey == null){
					return;
				}
				Integer batchRecord = Optional.ofNullable(batchInfo.get(batchKey)).orElse(Integer.valueOf(0));
				logger.debug("Corresponding Batch record found is : {}", CommonUtil.getJsonFromObject(batchRecord));

				List<Object> batchInfoKeyAsList = Arrays.asList(batchInfo.keySet().toArray());
				BatchExpectedCountStore batchKeyData = batchInfoKeyAsList.contains(batchKey) ? (BatchExpectedCountStore) batchInfoKeyAsList.get(batchInfoKeyAsList.indexOf(batchKey)) : null;
				logger.debug("Batch Defination key : {}", CommonUtil.getJsonFromObject(batchKeyData));

				FileProcessedWithActualFile fileProcessedWithActualFile = FileProcessedWithActualFile.builder().projectName(jobInfo.getProjectName()).workflowName(jobInfo.getWorkflowName()).workflowType(jobInfo.getWorkflowType()).activeFrom((batchKeyData != null) ? batchKeyData.getActiveFrom() : "").build();
				if (result.contains(fileProcessedWithActualFile)){
					fileProcessedWithActualFile = result.get(result.indexOf(fileProcessedWithActualFile));
				} else{
					result.add(fileProcessedWithActualFile);
					fileProcessedWithActualFile.setStatistics(new HashMap<String, FileStatistics>());
				}
				String startedDate = CommonUtil.simpleDateFormat.format(jobInfo.getStartedTime());
				if (!fileProcessedWithActualFile.getStatistics().containsKey(startedDate)){
					FileStatistics newFileStat = new FileStatistics();
					newFileStat.setStatus(true);
					fileProcessedWithActualFile.getStatistics().put(startedDate, newFileStat);
				}
				FileStatistics fileStatistics = fileProcessedWithActualFile.getStatistics().get(startedDate);
				fileStatistics.setFilesExpected(batchRecord.intValue());
				fileStatistics.setTotalFiles(fileStatistics.getTotalFiles() + jobInfo.getCount());
				if (null == fileStatistics.getProcessedFiles() || fileStatistics.getProcessedFiles().isEmpty()){
					fileStatistics.setProcessedFiles(new ArrayList<FileProcessedTable>());
				}
				FileProcessedTable fileProcessedTable = new FileProcessedTable();
				fileProcessedTable.setFileName(jobInfo.getSourceFile());
				fileProcessedTable.setJobStatus(jobInfo.getStatus());
				fileProcessedTable.setStartedTime(CommonUtil.getFormattedDateString(jobInfo.getStartedTime(), "yyyy-MMM-dd HH:mm:ss.SSS"));

				if (jobInfo.getStatus().equals(JobStatus.COMPLETED_SUCCESS)){
					fileStatistics.setFilesProcessed(fileStatistics.getFilesProcessed() + 1);
					fileStatistics.setStatus(getFileStatus(fileStatistics, Boolean.TRUE));
				} else{
					fileStatistics.setStatus(getFileStatus(fileStatistics, Boolean.FALSE));
				}
				fileStatistics.getProcessedFiles().add(fileProcessedTable);
			});
			logger.debug("Dashboard results : {}", CommonUtil.getJsonFromObject(result));
			return result;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Gets the file status.
	 *
	 * @param fileStatistics the file statistics
	 * @param status the status
	 * @return the file status
	 */
	private boolean getFileStatus(FileStatistics fileStatistics, Boolean status) {
		return (fileStatistics.isStatus() && fileStatistics.getFilesProcessed() >= fileStatistics.getFilesExpected()) || status;
	}

	/**
	 * Gets the batch key.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param schedulerPolicy the scheduler policy
	 * @return the batch key
	 */
	private BatchExpectedCountStore getBatchKey(String projectName, String workflowName, String workflowType, SchedulerPolicy schedulerPolicy) {
		BatchExpectedCountStore countStore = BatchExpectedCountStore.builder().projectName(projectName).workflowName(workflowName).workFlowType(workflowType).build();
		if (null == schedulerPolicy || !(schedulerPolicy instanceof TimeBased)){
			return countStore;
		}
		TimeBased timeBasedPolicy = (TimeBased) schedulerPolicy;
		Date activeFrom = Optional.ofNullable(timeBasedPolicy.getActiveFrom()).orElse(new Date());
		String activeFromString = new SimpleDateFormat("HH:mm").format(activeFrom);
		countStore.setActiveFrom(activeFromString);
		return countStore;
	}

	/**
	 * Failed source.
	 *
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<JobInfo> failedSource(String workflowType, String projectName) {
		try{
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria failedSourceCriteria = Criteria.where(Constants.STATUS).is(JobStatus.COMPLETED_FAILED);
			Criteria projectCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria matchingCriteria = workflowTypeCriteria.andOperator(projectCriteria, failedSourceCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).count().as("Count");
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(matchingCriteria), groupOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class);
			return result.getMappedResults();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Project within date range.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<JobInfo> projectWithinDateRange(Date startDate, Date endDate, String workflowType) {
		try{
			Date todaysDate = CommonUtil.getFormattedDate(new Date(), null);
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria todaysDateCriteria = Criteria.where(Constants.STARTEDTIME).gte(todaysDate);
			Criteria dateCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.PROJECTNAME).count().as("Count");
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(matchingCriteria), groupOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class);
			return result.getMappedResults();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw new GenericException(e);
		}
	}
}
