package com.opus.optimus.offline.services.user;

import org.springframework.stereotype.Service;

import com.opus.optimus.ui.services.user.Login;

/**
 * The Interface ILoginService.
 */
@Service
public interface ILoginService {

	/**
	 * Validate user.
	 *
	 * @param login the login
	 * @return the string
	 */
	public String validateUser(Login login);
}
