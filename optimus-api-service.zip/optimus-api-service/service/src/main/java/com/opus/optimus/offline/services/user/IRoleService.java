package com.opus.optimus.offline.services.user;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.Role;

// TODO: Auto-generated Javadoc
/**
 * The Interface IRoleService.
 */
@Service
public interface IRoleService {

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	List<Role> getRoles();

	/**
	 * Gets the role.
	 *
	 * @param roleId the role id
	 * @return the role
	 */
	Role getRole(String roleId);

	/**
	 * Update role.
	 *
	 * @param roleId the role id
	 * @param role the role
	 * @return the service response
	 */
	ServiceResponse updateRole(String roleId, Role role);

	/**
	 * Delete role.
	 *
	 * @param roleId the role id
	 * @return the service response
	 */
	ServiceResponse deleteRole(String roleId);

	/**
	 * Save role.
	 *
	 * @param role the role
	 * @return the service response
	 */
	public ServiceResponse saveRole(Role role);

	/**
	 * Assign role to user.
	 *
	 * @param roleId the role id
	 * @param emails the emails
	 * @return the string
	 */
	public String assignRoleToUser(String roleId, @RequestBody List<String> emails);

	/**
	 * Revoke role from user.
	 *
	 * @param roleName the role name
	 * @param emails the emails
	 * @return the string
	 */
	String revokeRoleFromUser(String roleName, List<String> emails);

}
