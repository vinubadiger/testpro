package com.opus.optimus.offline.services.user.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.opus.optimus.offline.repository.user.LoginRepository;
import com.opus.optimus.offline.repository.user.UserRepository;
import com.opus.optimus.offline.services.user.IUserService;
import com.opus.optimus.ui.constants.Constants;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.Login;
import com.opus.optimus.ui.services.user.Role;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class UserServiceImpl.
 */
@Service
public class UserServiceImpl implements IUserService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	/** The Constant USER_EXISTS. */
	private static final String USER_EXISTS = "User with this Email ID Already Exists";

	/** The Constant USER_CREATED. */
	private static final String USER_CREATED = "User Registered";

	/** The Constant USER_UPDATED. */
	private static final String USER_UPDATED = "User Updated";

	/** The Constant USER_NOT_EXISTS. */
	private static final String USER_NOT_EXISTS = "User Does not Exists";

	/** The Constant USER_DELETED. */
	private static final String USER_DELETED = "User deleted";

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;

	/** The login repository. */
	@Autowired
	private LoginRepository loginRepository;

	/** The b crypt password encoder. */
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	/**
	 * Save user.
	 *
	 * @param user the user
	 * @return the service response
	 */
	@Override
	public ServiceResponse saveUser(User user) {
		try{
			User userDb = getUser(user.getEmail());

			if (userDb != null){
				return new ServiceResponse(500, ResponseStatus.FAILED, USER_EXISTS, userDb);
			} else{

				String encodedPassword = bCryptPasswordEncoder.encode(Constants.DEFAULT_PASSOWRD);

				Login login = new Login();
				login.setUserName(user.getEmail());
				login.setPassword(encodedPassword);

				user.setPassword(encodedPassword);
				user.setCreatedBy(user.getEmail());
				user.setCreatedDate(new Date());

				loginRepository.save(login);
				userRepository.save(user);

				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_CREATED, user);
			}
		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in UserServiceImpl saveUser ", e);
		}
	}

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	@Override
	public List<User> getUsers() {
		return this.userRepository.findAll();
	}

	/**
	 * Gets the user.
	 *
	 * @param emailId the email id
	 * @return the user
	 */
	@Override
	public User getUser(String emailId) {
		return this.userRepository.findUserByEmail(emailId);
	}

	/**
	 * Update user.
	 *
	 * @param userName the user name
	 * @param user the user
	 * @return the service response
	 */
	@Override
	public ServiceResponse updateUser(String email, User user) {

		User userDb = getUser(email);
		try{
			if (userDb != null){
				user.setPassword(userDb.getPassword());
				user.setModifiedBy(email);
				user.setModifiedDate(new Date());
				user.setEmail(userDb.getEmail());
				this.userRepository.save(user);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_UPDATED, user);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, USER_NOT_EXISTS, userDb);
			}

		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in UserServiceImpl updateUser ", e);
		}
	}

	/**
	 * Delete user.
	 *
	 * @param userName the user name
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteUser(String email) {
		User userDb = this.userRepository.findUserByEmail(email);
		try{
			if (userDb != null){
				this.userRepository.delete(userDb);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_DELETED, userDb);
			} else return new ServiceResponse(500, ResponseStatus.FAILED, USER_NOT_EXISTS, userDb);
		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in UserServiceImpl deleteUser ", e);
		}
	}

	/**
	 * Assign role.
	 *
	 * @param email the email
	 * @param role the role
	 * @return the string
	 */
	public String assignRole(String email, @RequestBody List<Role> role) {
		try{

			int i = 0;
			User userDb = getUser(email);
			if (userDb != null){
				for (Role roles : role){
					if ((userDb.getRoles()).contains(roles)){
						userDb.getRoles().get(i).setRoleName(role.get(i).getRoleName());
						userDb.getRoles().get(i).setRoleName(role.get(i).getRoleName());
					} else{
						userDb.getRoles().add(new Role(role.get(i).getRoleId(), role.get(i).getRoleName()));
					}

					i++;
				}
				saveUser(userDb);

			}
			return "Role updated";
		} 
		catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in UserServiceImpl assignRole ", e);
		}

	}

	/**
	 * Fetch users for selected role.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	@Override
	public List<User> fetchUsersForSelectedRole(String roleName) {
		List<User> users = (List<User>) this.userRepository.findAll();

		return users.stream().filter(user -> user.getRoles() != null && user.getRoles().size() > 0 && user.getRoles().get(0).getRoleName().equals(roleName)).collect(Collectors.toList());
	}

	/**
	 * Fetch available users.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	public List<User> fetchAvailableUsers(String roleName) {
		List<User> users = (List<User>) this.userRepository.findAll();

		return users.stream().filter(user -> !user.getRoles().get(0).getRoleName().equals(roleName)).collect(Collectors.toList());
	}
}
