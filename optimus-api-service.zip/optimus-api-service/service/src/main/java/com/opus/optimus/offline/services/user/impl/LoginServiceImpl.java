package com.opus.optimus.offline.services.user.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.repository.user.LoginRepository;
import com.opus.optimus.offline.services.user.ILoginService;
import com.opus.optimus.ui.services.user.Login;

/**
 * The Class LoginServiceImpl.
 */
@Service
public class LoginServiceImpl implements ILoginService {
	
	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(LoginServiceImpl.class);

	/** The login repository. */
	@Autowired
	private LoginRepository loginRepository;

	/**
	 * Validate user.
	 *
	 * @param login the login
	 * @return the string
	 */
	@Override
	public String validateUser(Login login) {
		try{
			Login userFromDb = loginRepository.findUserByUserName(login.getUserName());
			if (userFromDb != null){
				if (userFromDb.getPassword().equals(login.getPassword())){
					log.info("email & password exists");
					return "email & password exists";
				} else log.info("password invalid");
				return "password invalid";
			} else{
				log.info("email Not exists");
				return "email Not exists";
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}
}
