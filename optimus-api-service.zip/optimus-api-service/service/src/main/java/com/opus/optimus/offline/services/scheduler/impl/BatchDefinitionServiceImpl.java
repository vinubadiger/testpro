package com.opus.optimus.offline.services.scheduler.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.quartz.JobKey;
import org.quartz.ObjectAlreadyExistsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.TextCriteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.repository.scheduler.BatchDefinitionRepository;
import com.opus.optimus.offline.services.scheduler.BatchDefinitionService;
import com.opus.optimus.offline.services.scheduler.quartz.QuartzScheduler;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.DependencyBased;
import com.opus.optimus.ui.services.scheduler.EventBased;
import com.opus.optimus.ui.services.scheduler.TimeBased;
import com.opus.optimus.ui.services.scheduler.util.CronGeneratorUtil;


/**
 * The Class BatchDefinitionServiceImpl.
 */
@Service ("batchDefinitionService")
public class BatchDefinitionServiceImpl implements BatchDefinitionService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(BatchDefinitionServiceImpl.class);

	/** The Constant JOB_STOPPED. */
	private static final String JOB_STOPPED = "Job Stopped";

	/** The Constant JOB_NOT_STOPPED. */
	private static final String JOB_NOT_STOPPED = "Job Not Stopped";

	/** The batch definition repository. */
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;

	/** The mongo template. */
	@Autowired
	MongoTemplate mongoTemplate;

	
	@Override
	public BatchDefinition saveBatchDefinition(BatchDefinition batchDefinition) {
		if (batchDefinition.getId() == null){
			batchDefinition.setCreatedDate(new Date());
		}
		batchDefinition.setModifiedDate(new Date());
		return this.batchDefinitionRepository.save(batchDefinition);
	}

	/**
	 * Save batch definition job execution.
	 *
	 * @param batchDefinition the batch definition
	 */
	@Override
	public void saveBatchDefinitionJobExecution(BatchDefinition batchDefinition) {
		try{
			BatchDefinition currentBatchDefinition = this.batchDefinitionRepository.findWorkflowByGivenData(batchDefinition.getProjectName(), batchDefinition.getWorkflowName(), batchDefinition.getWorkflowType());
			if (currentBatchDefinition != null){
				batchDefinition.setId(currentBatchDefinition.getId());
				batchDefinition.setGroupId(currentBatchDefinition.getGroupId());
				batchDefinition.setModifiedDate(new Date());
				if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(TimeBased.RECORDTYPE)){
					StringBuilder jobKey = new StringBuilder();
					jobKey.append(batchDefinition.getProjectName());
					jobKey.append(batchDefinition.getWorkflowName());
					jobKey.append(batchDefinition.getWorkflowType());
					JobKey jkey = new JobKey(jobKey.toString(), batchDefinition.getWorkflowName());
					QuartzScheduler.removeQuartzSchedulerCronExpression(jkey);
				}
			} else{
				batchDefinition.setCreatedDate(new Date());
				batchDefinition.setModifiedDate(new Date());
			}
			this.batchDefinitionRepository.save(batchDefinition);
			if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(TimeBased.RECORDTYPE) && !batchDefinition.isDisabled()){
				timebasedProcess(batchDefinition);
			} else if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(EventBased.RECORDTYPE)){
				log.debug("EVENTBASED");
			} else if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(DependencyBased.RECORDTYPE)){
				log.debug("DEPENDENCYBASED");
			} else{
				log.debug("Policy Type Not Defined");
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw new GenericException(e);
		}

	}

	/**
	 * Gets the batch definitions.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @return the batch definitions
	 */
	@Override
	public Page<BatchDefinition> getBatchDefinitions(String scheduleFlag, int page, int size) {
		try{
			Sort sort = null;
			sort = new Sort(Sort.Direction.DESC, "modifiedDate");
			Pageable pageable = PageRequest.of(page, size, sort);

			if (scheduleFlag.equals("schedule")){
				Page<BatchDefinition> list = this.batchDefinitionRepository.findAllIsNotNull(pageable);

				for (BatchDefinition batchDefinition : list){
					log.debug("batchDefinition :{}" , batchDefinition.toString());
				}
				return this.batchDefinitionRepository.findAllIsNotNull(pageable);
			}
			if (scheduleFlag.equals("nonschedule")){
				return this.batchDefinitionRepository.findAllIsNull(pageable);
			} else{
				return this.batchDefinitionRepository.findAll(pageable);
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the batch definitions.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the batch definitions
	 */
	@Override
	public Page<BatchDefinition> getBatchDefinitions(String scheduleFlag, int page, int size, String orderType, String field) {
		try{
			Sort sort = null;
			if (orderType.equals("ASC")){
				sort = new Sort(Sort.Direction.ASC, field);
			} else{
				sort = new Sort(Sort.Direction.DESC, field);
			}
			Pageable pageable = PageRequest.of(page, size, sort);
			if (scheduleFlag.equals("schedule")){
				return this.batchDefinitionRepository.findAllIsNotNull(pageable);
			}
			if (scheduleFlag.equals("nonschedule")){
				return this.batchDefinitionRepository.findAllIsNull(pageable);
			} else{
				return this.batchDefinitionRepository.findAll(pageable);
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the batch definition.
	 *
	 * @param batchDefinition the batch definition
	 * @return the batch definition
	 */
	@Override
	public BatchDefinition getBatchDefinition(BatchDefinition batchDefinition) {
		try{
			return this.batchDefinitionRepository.findWorkflowByGivenData(batchDefinition.getProjectName(), batchDefinition.getWorkflowName(), batchDefinition.getWorkflowType());
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/* (non-Javadoc)
	 * @see com.opus.optimus.offline.services.scheduler.BatchDefinitionService#getBatchDefinition(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public BatchDefinition getBatchDefinition(String projectName, String workflowName, String workflowType) {
		try{
			return this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the batch definition.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the batch definition
	 */
	@Override
	public String removeScheduling(String projectName, String workflowName, String workflowtype) {
		log.debug("Request received for deleting job.");
		try{
			StringBuilder jobKey = new StringBuilder();
			jobKey.append(projectName);
			jobKey.append(workflowName);
			jobKey.append(workflowtype);

			JobKey jkey = new JobKey(jobKey.toString(), workflowName);
			log.debug("Parameters received for deleting job : jobKey :{}" , jobKey);
			QuartzScheduler.removeQuartzSchedulerCronExpression(jkey);
			return JOB_STOPPED;
		} catch (Exception e){
			log.error(e.getMessage());
			return JOB_NOT_STOPPED;
		}
	}

	/* 
	 *findAllBy
	 */
	@Override
	public Page<BatchDefinition> findAllBy(String search, int page, int size) {
		TextCriteria tsearch = TextCriteria.forDefaultLanguage().matching(search).caseSensitive(false);
		Pageable pageable = PageRequest.of(page, size);
		return batchDefinitionRepository.findAllBy(tsearch, pageable);
	}

	/**
	 * Searchbycolumnnameandtext.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	@Override
	public Page<BatchDefinition> searchbycolumnnameandtext(String column, String text, int page, int size) {
		Pageable pageable = PageRequest.of(page, size);
		Aggregation agg = newAggregation(Aggregation.match(Criteria.where(column).regex(Pattern.compile(text, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE))), sort(Sort.Direction.DESC, column), Aggregation.skip(pageable.getPageNumber() * pageable.getPageSize()), Aggregation.limit(pageable.getPageSize())

		);

		AggregationResults<BatchDefinition> result = mongoTemplate.aggregate(agg, BatchDefinition.class, BatchDefinition.class);

		return new PageImpl<>(result.getMappedResults());
	}

	/**
	 * Auto restart schedule.
	 */
	@Override
	public void autoRestartSchedule() {
		try{
			List<BatchDefinition> listBatchDefinition = this.batchDefinitionRepository.findAllIsNotNull();
			if (null == listBatchDefinition){
				log.debug("Nothing do schedule");
			} else{
				for (BatchDefinition batchDefinition : listBatchDefinition){
					if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(TimeBased.RECORDTYPE) && !batchDefinition.isDisabled()){
						timebasedProcess(batchDefinition);
					} else if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(EventBased.RECORDTYPE)){
						log.debug("EVENTBASED");
					} else if (batchDefinition.getSchedulerPolicy().getPolicyType().equals(DependencyBased.RECORDTYPE)){
						log.debug("DEPENDENCYBASED");
					} else{
						log.debug("Policy Type Not Defined");
					}
				}
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Timebased process.
	 *
	 * @param batchDefinition the batch definition
	 */
	private void timebasedProcess(BatchDefinition batchDefinition) {
		try{
			TimeBased timeBasedBatchDefinition = (TimeBased) batchDefinition.getSchedulerPolicy();
			if (timeBasedBatchDefinition.getIntervalDay() != null){
				String intervalDay = timeBasedBatchDefinition.getIntervalDay();
				String intervalHour = timeBasedBatchDefinition.getIntervalHour();
				String intervalMin = timeBasedBatchDefinition.getIntervalMin();
				intervalDay = (null == intervalDay || intervalDay.isEmpty()) ? "0" : intervalDay;
				intervalHour = (null == intervalHour || intervalHour.isEmpty()) ? "0" : intervalHour;
				intervalMin = (null == intervalMin || intervalMin.isEmpty()) ? "0" : intervalMin;
				int intervalM = 60 * 24 * (Integer.parseInt(intervalDay));
				intervalM = intervalM + (60 * (Integer.parseInt(intervalHour)));
				intervalM = intervalM + (Integer.parseInt(intervalMin));
				log.debug("StartDate - {}" , timeBasedBatchDefinition.getActiveFrom());
				log.debug("Total Minute in interval converted - {}" , intervalM);
				QuartzScheduler.quartzSchedulerTrigger(intervalM, batchDefinition, timeBasedBatchDefinition.getActiveFrom());
			} else{
				log.debug("StartDate -{} " , timeBasedBatchDefinition.getActiveFrom());
				TimeBased timeBasedBatchDefinition1 = (TimeBased) batchDefinition.getSchedulerPolicy();
				String cronExpression = CronGeneratorUtil.cronExpressionFormat(timeBasedBatchDefinition1.getIntervalHour(), timeBasedBatchDefinition1.getSelectedDays());
				log.debug("Cron Expression - {}" , cronExpression);
				QuartzScheduler.quartzSchedulerCronExpression(cronExpression, batchDefinition, timeBasedBatchDefinition.getActiveFrom());
			}
		} catch (ObjectAlreadyExistsException e){
			log.error(e.getMessage());
		} catch (Exception e){

			throw new GenericException(e);
		}
	}

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	@Override
	public Page<BatchDefinition> autocompleteByText(String column, String pattern) {

		Aggregation agg = newAggregation(Aggregation.match(Criteria.where(column).regex(pattern)), sort(Sort.Direction.DESC, column));

		AggregationResults<BatchDefinition> result = mongoTemplate.aggregate(agg, BatchDefinition.class, BatchDefinition.class);

		return new PageImpl<>(result.getMappedResults());
	}

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	/*@Override
	public ServiceResponse delete(String projectName, String workflowName, String workflowType) {
		BatchDefinition batchDb = this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		if (batchDb == null){
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
		} else{
			if(batchDb.getSchedulerPolicy()==null||batchDb.isDisabled()) {
				batchDefinitionRepository.delete(batchDb);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, "Workflow is scheduled, cannot be deleted", workflowName);
			}
		}

	}*/
	
	
	//Added Code
	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteCheck(String projectName, String workflowName, String workflowType) {
		BatchDefinition batchDb = this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		if (batchDb == null){
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
		} else{
			if (batchDb.getSchedulerPolicy() == null || batchDb.isDisabled()){
				log.debug("Workflow is not scheduled, can be deleted {}", workflowName);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, "Workflow is scheduled, cannot be deleted", workflowName);
			}
		}

	}
	
	@Override
	public ServiceResponse delete(String projectName, String workflowName, String workflowType) {
		BatchDefinition batchDb = this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		if (batchDb != null){
			log.debug("Scheduling information deleting...{}", batchDb);
			batchDefinitionRepository.delete(batchDb);
		}
		return new ServiceResponse(200, ResponseStatus.SUCCESS, "Scheduling information is deleted of Workflow", workflowName);
	}

}