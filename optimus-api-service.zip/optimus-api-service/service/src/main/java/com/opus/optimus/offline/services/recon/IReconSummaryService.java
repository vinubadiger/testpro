package com.opus.optimus.offline.services.recon;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;

/**
 * The Interface ReconSummaryService.
 */
public interface IReconSummaryService {

	/**
	 * Find recon acitivity summary.
	 *
	 * @param activityId the activity id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the list
	 */
	List<ReconAcitivitySummary> findReconActivitySummary(String activityId, Date startDate, Date endDate);

	/**
	 * Save recon acitivity summary.
	 *
	 * @param reconAcitivitySummary the recon acitivity summary
	 * @return the recon acitivity summary
	 */
	ReconAcitivitySummary saveReconActivitySummary(ReconAcitivitySummary reconAcitivitySummary);

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	List<ReconAcitivitySummary> findAll();

	/**
	 * Gets the summary.
	 *
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param pageNo the page no
	 * @param size the size
	 * @param subStatus
	 * @param status
	 * @param endDate
	 * @param startDate
	 * @return the summary
	 * @throws Exception
	 */
	Page<Object> getSummary(String projectName, String activityName, String sourceName, Map<String, Object> parameters, Map<String, Integer> paginationDetails) throws Exception;

	/**
	 * @param recordHolder
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param recordId
	 * @param caseId
	 */
	ServiceResponse forceMatch(ForceMatchRequest forceMatchRequest, String projectName, String activityName);
}
