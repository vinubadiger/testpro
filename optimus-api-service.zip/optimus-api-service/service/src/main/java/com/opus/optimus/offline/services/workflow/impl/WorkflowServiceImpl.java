package com.opus.optimus.offline.services.workflow.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.repository.workflow.PublishedWorkflowRepository;
import com.opus.optimus.offline.repository.workflow.WorkflowRepository;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.services.scheduler.BatchDefinitionService;
import com.opus.optimus.offline.services.workflow.IWorkflowService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.project.Workflow;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.StepInputData;
import com.opus.optimus.ui.services.scheduler.StepInputData.StepInputType;

/**
 * The Class WorkflowServiceImpl.
 */
@Service
public class WorkflowServiceImpl implements IWorkflowService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(WorkflowServiceImpl.class);

	/** The workflow repository. */
	@Autowired
	private WorkflowRepository workflowRepository;

	/** The published workflow repository. */
	@Autowired
	private PublishedWorkflowRepository publishedWorkflowRepository;

	/** The batch definition service. */
	@Autowired
	private BatchDefinitionService batchDefinitionService;

	/** The Constant WORKFLOW_DELETED. */
	private static final String WORKFLOW_DELETED = "Workflow deleted";

	/** The Constant WORKFLOW_DUPLICATED. */
	private static final String WORKFLOW_DUPLICATED = "Workflow duplicated";

	/** The Constant WORKFLOW_CREATED. */
	private static final String WORKFLOW_CREATED = "Workflow created";

	/** The Constant WORKFLOW_UPDATED. */
	private static final String WORKFLOW_UPDATED = "Workflow updated successfully";

	/** The Constant WORKFLOW_NOT_EXISTS. */
	private static final String WORKFLOW_NOT_EXISTS = "Workflow not exists";

	/** The Constant WORKFLOW_EXISTS. */
	private static final String WORKFLOW_EXISTS = "Workflow exists";

	/**
	 * Get Workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	@Override
	public Workflow get(String projectName, String workflowName, String workflowType) {
		try{
			return this.workflowRepository.findWorkFlowByProjectName(projectName, workflowName, workflowType);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Save Workflow.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@Override
	public ServiceResponse save(Workflow workflow) {
		try{
			log.debug("Saving Workflow");
			Workflow workflowDb = get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());
			if (workflowDb != null){
				log.debug("Found existing workflow. Updating Workflow");
				workflow.setId(workflowDb.getId());
			}

			this.workflowRepository.save(workflow);
			log.debug("Workflow Saved");

			log.debug("Publishing Workflow");
			PublishedService publishWorkflow = publishWorkflow(workflow);
			log.debug("Workflow published");

			log.debug("Updating Batch definition");
			updateBatchDefinition(workflow, publishWorkflow);
			log.debug("Batch definition updated");

			return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_CREATED, workflow);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Publish workflow.
	 *
	 * @param workflow the workflow
	 * @return the published service
	 */
	private PublishedService publishWorkflow(Workflow workflow) {
		try{
			PublishedService publishWokflow = publishedWorkflowRepository.get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());

			if (publishWokflow == null){
				publishWokflow = new PublishedService();
				publishWokflow.setProjectName(workflow.getProjectName());
				publishWokflow.setWorkflowName(workflow.getWorkflowName());
				publishWokflow.setWorkflowType(workflow.getWorkflowType());

			}
			publishWokflow.setWorkflowConfig(WorkflowConfig.builder().name(workflow.getWorkflowName()).startStepName(workflow.getStartStepName()).stepConfigs(workflow.getStepConfigs()).stepLinks(workflow.getStepLinks()).build());

			String publishWokflowId = publishedWorkflowRepository.save(publishWokflow).getId();
			if (null == publishWokflowId){
				publishWokflowId = publishedWorkflowRepository.get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType()).getId();
				publishWokflow.setId(publishWokflowId);
			}

			return publishWokflow;
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Update batch definition.
	 *
	 * @param workflow the workflow
	 * @param publishWorkflow the publish workflow
	 * @throws Exception the exception
	 */
	private void updateBatchDefinition(Workflow workflow, PublishedService publishWorkflow) throws Exception {
		try{
			BatchDefinition batchDefinition = batchDefinitionService.getBatchDefinition(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());
			if (batchDefinition == null){
				batchDefinition = new BatchDefinition();
				batchDefinition.setProjectName(workflow.getProjectName());
				batchDefinition.setWorkflowName(workflow.getWorkflowName());
				batchDefinition.setWorkflowType(workflow.getWorkflowType());
				batchDefinition.setDescription(workflow.getWorkflowDescription());
				batchDefinition.setStepInputs(new HashMap<String, List<String>>());
			}
			if (workflow.getStepConfigs() != null){
				List<StepInputData> stepInputData = Optional.ofNullable(batchDefinition.getStepInputData()).orElse(new ArrayList<>());
				for (IStepConfig stepConfig : workflow.getStepConfigs()){
					switch (stepConfig.getStepType()) {
					case StepTypeConstants.FILE_READER_STEPTYPE:
					case StepTypeConstants.EXCEL_READER_STEPTYPE:{
						log.debug("Stepname: " + stepConfig.getStepName());
						List<StepInputData> existingList = stepInputData.stream().filter(s -> s.getStepName().equals(stepConfig.getStepName()) && s.getStepInputType().equals(StepInputType.FILE_FOLDER_LOCATION)).collect(Collectors.toList());

						if (existingList == null || existingList.isEmpty()){
							StepInputData inputData = new StepInputData();
							inputData.setStepName(stepConfig.getStepName());
							inputData.setStepType(stepConfig.getStepType());
							inputData.setStepInputType(StepInputType.FILE_FOLDER_LOCATION);
							inputData.setSuggestionText(StepInputType.FILE_FOLDER_LOCATION.getValue());
							stepInputData.add(inputData);
						}

						break;
					}
					default:
						break;
					}
				}
				batchDefinition.setStepInputData(stepInputData);
			}
			batchDefinition.setGroupId(publishWorkflow.getId());
			batchDefinition.setWorkflowId(workflow.getId());
			batchDefinitionService.saveBatchDefinition(batchDefinition);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Update Workflow.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@Override
	public ServiceResponse update(Workflow workflow) {
		try{
			Workflow workflowDB = get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());
			if (workflowDB == null){
				log.debug(WORKFLOW_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_NOT_EXISTS, workflow);
			} else{
				save(workflow);
				log.debug(WORKFLOW_UPDATED);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_UPDATED, workflow);
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Get Workflow by.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<Workflow> get(String projectName, String workflowType) {
		try{
			return this.workflowRepository.findWorkFlowByProjectName(projectName, workflowType);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * delete workflow when project is deleted.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	@Override
	public ServiceResponse delete(String projectName) {
		try{
			List<Workflow> workflowList = this.workflowRepository.getWorkFlow(projectName);
			if (!workflowList.isEmpty()){
				log.debug("In Workflows deleted of this project");
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_EXISTS, projectName);
			} else{
				return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_NOT_EXISTS, projectName);
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Delete particular workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */

	@Override
	public ServiceResponse delete(String projectName, String workflowName, String workflowType) {
		Workflow workflow = this.workflowRepository.findWorkFlowByProjectName(projectName, workflowName, workflowType);
		try{
			if (workflow != null){
				ServiceResponse responseBatchdefinition = this.batchDefinitionService.delete(projectName, workflowName, workflowType);
				if (responseBatchdefinition.getStatus().equals(ResponseStatus.FAILED)){

					return new ServiceResponse(500, ResponseStatus.FAILED, responseBatchdefinition.getMsg(), workflowName);
				} else{
					this.workflowRepository.delete(workflow);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_DELETED, workflow);
				}
			} else return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_NOT_EXISTS, workflowName);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the all workflows.
	 *
	 * @param projectName the project name
	 * @return the all workflows
	 */
	@Override
	public List<Workflow> getAllWorkflows(String projectName) {
		try{
			return this.workflowRepository.getWorkFlow(projectName);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Duplicate workflow when project is duplicated.
	 *
	 * @param sourceProjectName the source project name
	 * @param destinationProjectName the destination project name
	 */
	@Override
	public void duplicate(String sourceProjectName, String destinationProjectName) {
		List<Workflow> workflowList = getAllWorkflows(sourceProjectName);
		List<Workflow> newWorkflowList = new ArrayList<>();

		try{
			if (!workflowList.isEmpty()){
				for (Workflow workflow : workflowList){
					workflow.setProjectName(destinationProjectName);
					workflow.setId(null);
					save(workflow);
					newWorkflowList.add(workflow);
				}
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Duplicate workflow with different user provided name.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param targetWorkflow the target workflow
	 * @return the service response
	 */
	@Override
	public ServiceResponse duplicateWorkflow(String projectName, String workflowName, String workflowType, String targetWorkflow,String description) {
		Workflow wf = get(projectName, workflowName, workflowType);
		try{
			if (wf != null){
				wf.setWorkflowName(targetWorkflow);
				wf.setWorkflowDescription(description);
				wf.setId(null);
				save(wf);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_DUPLICATED, wf);
			} else{
				log.debug(WORKFLOW_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_NOT_EXISTS, workflowName);
			}

		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Get list of workflowType.
	 *
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<Workflow> get(String workflowType) {
		try{
			List<Workflow> result = this.workflowRepository.findETLWorkFlows(workflowType);
			log.debug("Total ETL source found - {}", result.size());
			return result;
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}
	/**
	 * delete workflow when project is deleted.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteCheck(String projectName) {
		try{
			List<Workflow> workflowList = this.workflowRepository.getWorkFlow(projectName);
			List<ServiceResponse> responseList = new ArrayList<>();
			if (!workflowList.isEmpty()){
				log.debug("Checking workflows are scheduled in this project....");
				workflowList.forEach(wf -> responseList.add(batchDefinitionService.deleteCheck(wf.getProjectName(), wf.getWorkflowName(), wf.getWorkflowType())));
				for(ServiceResponse res : responseList) {
					if(res.getStatusCode()==500) {
						return new ServiceResponse(500, ResponseStatus.FAILED,res.getMsg(), res.getResponseObj());
					}
				}log.debug("Project can be deleted, no workflow under this project is scheduled");
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Project can be deleted", projectName);
			} else{
				log.debug("Project can be deleted, no workflow under this project exists");
				
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Project can be deleted", projectName);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Delete particular workflow without deleteCheck
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteWorkflow(String projectName, String workflowName, String workflowType) {
		Workflow workflow = this.workflowRepository.findWorkFlowByProjectName(projectName, workflowName, workflowType);
		try{
			if (workflow != null){
				log.debug("Workflow deleting...{}",workflow.getWorkflowName());
				this.workflowRepository.delete(workflow);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, WORKFLOW_DELETED, workflow);
			} else {
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_NOT_EXISTS, workflowName);
			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}
	
	

}
