package com.opus.optimus.offline.services.recon.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.subtypes.CaseStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class ReconMongoDbReader.
 */
@Service
public class ReconMongoDbReader {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconMongoDbReader.class);

	/** The data source factory. */
	@Autowired
	private DataSourceFactory dataSourceFactory;

	/**
	 * Gets the transaction.
	 *
	 * @param config the config
	 * @param activityName the activity name
	 * @param parameters the parameters
	 * @param pagination the pagination
	 * @return the transaction
	 */
	public Page<Object> getTransaction(final MongoDBReaderConfig config, String activityName, Map<String, Object> parameters, Map<String, Integer> pagination) {
		logger.debug("Getting transaction summary");
		List<Object> records = new ArrayList<>();
		try{
			String dataSourceName = config.getSourceDefinition().getDataSourceName();
			String collectionName = config.getSourceDefinition().getCollectionName();
			logger.info("DataSource Name - {}, Collection Name - {}", dataSourceName, collectionName);
			final IDataSource dataSource = dataSourceFactory.getDataSource(dataSourceName);

			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());
				Pageable pageable = PageRequest.of(pagination.get("page").intValue(), pagination.get("size").intValue());
				Query query = new Query().with(pageable);

				Criteria criteria = getCondition(activityName, parameters);
				query.addCriteria(criteria);

				mongoTemplate.executeQuery(query, collectionName, doc -> {
					doc.put("id", doc.get("_id").toString());
					logger.info("ReconControlInfo --->{}", doc);
					records.add(doc);
				});
				return PageableExecutionUtils.getPage(records, pageable, () -> mongoTemplate.count(query, collectionName));
			}
			throw new GenericException("Data source not available");
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Gets the condition.
	 *
	 * @param activityName the activity name
	 * @param parameters the parameters
	 * @return the condition
	 */
	private Criteria getCondition(String activityName, Map<String, Object> parameters) {
		String status = (String) parameters.get("status");
		String subStatus = (String) parameters.get("subStatus");
		Date startDate = (Date) parameters.get("startDate");
		Date endDate = (Date) parameters.get("endDate");
		StringBuilder field = new StringBuilder("reconControlFields").append(".").append(activityName);
		Criteria criteria = Criteria.where(field.toString()).exists(true);

		if (null != status && !status.isEmpty()){
			criteria.and(field + ".status").is(status);
		}
		if (null != subStatus && !subStatus.isEmpty()){
			criteria.and(field + ".subStatus").is(subStatus);
		}
		if (null != startDate){
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			criteria.and(field + ".processingDate").gte(startDate).lt(endDate1);
		}

		return criteria;
	}

	/**
	 * Change status in db.
	 *
	 * @param collection the collection
	 * @param activityName the activity name
	 * @param recordId the record id
	 * @param comment the comment
	 * @return the date
	 */
	public Date changeStatusInDb(MongoCollection<Document> collection, String activityName, String recordId, String comment) {
		try{

			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String userName = (String) auth.getPrincipal();
			logger.debug("Username in {}", userName);

			StringBuilder field = new StringBuilder("reconControlFields.").append(activityName);

			BasicDBObject updateFields = new BasicDBObject(field + ".status", ReconStatus.RECONCILED.toString());
			updateFields.append(field + ".subStatus", ReconSubStatus.ForceMatch.toString());
			updateFields.append(field + ".caseInfo.status", CaseStatus.CLOSE.toString());
			updateFields.append(field + ".caseInfo.comment", comment);
			updateFields.append(field + ".updatedBy", userName);

			BasicDBObject updateQuery = new BasicDBObject("$set", updateFields);
			BasicDBObject searchQuery = new BasicDBObject("_id", new ObjectId(recordId));

			Document doc = collection.findOneAndUpdate(searchQuery, updateQuery);
			logger.debug("Result document {}", doc.toJson());
			if ((doc != null && !doc.isEmpty()) && doc.containsKey("reconControlFields")){
				Document reconFields = ((Document) ((Document) doc.get("reconControlFields")).get(activityName));
				return reconFields.getDate("processingDate");
			}
			return null;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

}
