package com.opus.optimus.offline.services.webclient;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.ui.services.scheduler.CaseCloseResponse;
import com.opus.optimus.ui.services.scheduler.CaseCreation;
import com.opus.optimus.ui.services.scheduler.CaseResponse;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class RestClient client to perform HTTP requests for below tasks. 1.Create JobInfo when user schedule job or onjob creation 2.Close case using
 * caseID
 */
@Service
public class RestClient {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(RestClient.class);

	/** The host url. */
	@Value ("${client.hosturl}")
	private String hostUrl;

	/** The api base url. */
	@Value ("${client.baseurl}")
	private String apiBaseUrl;

	/** The salesforce auth url. */
	@Value ("${saleforce.authurl}")
	String salesforceAuthUrl;

	/** The salesforce case url. */
	@Value ("${saleforce.casecloseurl}")
	String salesforceCaseUrl;

	/** The salesforce token. */
	@Value ("${saleforce.token}")
	String salesforceToken;
	
	/** The salesforce token. */
	@Value ("${saleforce.exceptiontype}")
	String exceptionType;

	/** The rest template. */
	RestTemplate restTemplate;

	/** The rest template with requestfactory. */
	RestTemplate restTemplatewithrequestfactory;

	/**
	 * Init the two restTemplate object 1.Create a new instance of the {@link RestTemplate} using default settings. 2.Create a new instance of the
	 * {@link RestTemplate} based on the given {@link ClientHttpRequestFactory}.
	 */
	@PostConstruct
	public void init() {
		restTemplate = new RestTemplate();
		restTemplatewithrequestfactory = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
	}

	/**
	 * Builds the api url.
	 *
	 * @param apiUrl the api url
	 * @return the string
	 */
	private String buildApiUrl(String apiUrl) {
		StringBuilder urlBuilder = new StringBuilder();
		urlBuilder.append(hostUrl);
		urlBuilder.append(apiBaseUrl);
		urlBuilder.append(apiUrl);
		log.info("URL - {}",  urlBuilder.toString());
		return urlBuilder.toString();
	}

	/**
	 * Creates the job.
	 *
	 * @param job the job
	 * @return the string
	 */
	public String createJob(JobInfo job) {
		log.debug("In Rest client Save job");
		try{
			final String uri = buildApiUrl(job.getName());
			return restTemplate.postForObject(uri, job.getJobTasks(), String.class);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Run job.
	 *
	 * @param jobId the job id
	 */
	public void runJob(String jobId) {
		try{
			log.debug("In Rest client Run job");
			final String uri = buildApiUrl("run/{jobId}");
			Map<String, String> params = new HashMap<>();
			params.put("jobId", jobId);
			RestTemplate restTemp = new RestTemplate();
			restTemp.getForObject(uri, String.class, params);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Method call to close case
	 *
	 * @param cases the cases
	 * @param token the token
	 */
	public CaseCloseResponse patchMethodCall(CaseCreation cases, String token) {
		CaseCloseResponse caseCloseResponse = null;
		log.debug("In Rest client close case");
		try{
			String authtoken = "OAuth " + token;
			log.debug("token created {} ", authtoken);
			final String uri = salesforceCaseUrl;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authorization", authtoken);

			MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
			map.add("records", cases);
			HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
			String caseResponse = restTemplatewithrequestfactory.patchForObject(uri, httpEntity, String.class);
			if (caseResponse != null){
				caseCloseResponse = CommonUtil.getObjectFromString(caseResponse, CaseCloseResponse.class);
			}
		} catch (Exception e){
			log.debug(e.getMessage());
			throw e;
		}
		return caseCloseResponse;
	}

	/**
	 * Case Close request.
	 *
	 * @param cases the cases
	 * @param token the token
	 */
	public CaseCloseResponse closeCase(String caseId, String comment,String reason,String reasonCode) {
		log.debug("In Rest client{} Close Case");
		CaseCloseResponse caseCloseResponse = null;
		try{
			final String uri = salesforceAuthUrl;
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			HttpEntity<String> request = new HttpEntity<>(salesforceToken, headers);
			String recievedtoken = restTemplate.postForObject(uri, request, CaseResponse.class).getAccess_token();
			log.debug("token - {}", recievedtoken);
			CaseCreation create = new CaseCreation();
			create.setCaseId(caseId);
			create.setStatus("Closed");
			create.setExceptionType(exceptionType);
			create.setComments(comment);
			create.setReason(reason);
			create.setReasonCode(reasonCode);
			caseCloseResponse = patchMethodCall(create, recievedtoken);
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;
		}
		return caseCloseResponse;
	}

}
