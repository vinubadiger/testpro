package com.opus.optimus.offline.services.user.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.repository.user.ProfileRepository;
import com.opus.optimus.offline.services.user.IProfileService;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.Profile;

/**
 * The Class ProfileServiceImpl.
 */
@Service
public class ProfileServiceImpl implements IProfileService {
	
	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(ProfileServiceImpl.class);
	
	/** The Constant PROFILE_DELETED. */
	private static final String PROFILE_DELETED = "Profile deleted";

	/** The Constant PROFILE_NOT_DELETED. */
	private static final String PROFILE_NOT_DELETED = "Profile not deleted";

	/** The profile repository. */
	@Autowired
	private ProfileRepository profileRepository;

	/**
	 * Save profile.
	 *
	 * @param profile the profile
	 */
	@Override
	public void saveProfile(Profile profile) {
		try {
			profileRepository.save(profile);
		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in saveProfile with roleName", e);
		} 
	}

	/**
	 * Gets the profiles.
	 *
	 * @return the profiles
	 */
	@Override
	public List<Profile> getProfiles() {
		return this.profileRepository.findAll();
	}

	/**
	 * Gets the profile.
	 *
	 * @param profileId the profile id
	 * @return the profile
	 */
	@Override
	public Profile getProfile(String profileId) {
		return this.profileRepository.findByProfileId(profileId);
	}

	/**
	 * Update profile.
	 *
	 * @param profile the profile
	 * @return the string
	 */
	@Override
	public String updateProfile(Profile profile) {
		try {
			Profile profileDb = getProfileByRole(profile.getRole().getRoleName());

			if (profileDb != null) {
				profile.setProfileId(profileDb.getProfileId());
			}
				saveProfile(profile);
				return "Profile updated";
			
		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in  ProfileServiceImpl updateProfile  ", e);
		}
	}

	/**
	 * Delete profile.
	 *
	 * @param profileId the profile id
	 * @return the string
	 */
	@Override
	public String deleteProfile(String profileId) {
		Profile profileDb;
		try {
			profileDb = this.profileRepository.findByProfileId(profileId);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}

		try {
			if (profileDb != null) {
				this.profileRepository.delete(profileDb);
				return PROFILE_DELETED;
			} else {
				return PROFILE_NOT_DELETED;
			}
		}catch (GenericException e){
			throw e;
		}catch (Exception e){
			throw new GenericException("Error in  ProfileServiceImpl deleteProfile  ", e);
		} 
	}

	/**
	 * Gets the profile by role.
	 *
	 * @param roleName the role name
	 * @return the profile by role
	 */
	@Override
	public Profile getProfileByRole(String roleName) {
		return this.profileRepository.findProfileByRoleName(roleName);
		
	}

}
