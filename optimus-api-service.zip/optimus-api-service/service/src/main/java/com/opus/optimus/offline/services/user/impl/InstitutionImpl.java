package com.opus.optimus.offline.services.user.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.repository.user.InstitutionRepository;
import com.opus.optimus.offline.services.user.IInstitutionService;
import com.opus.optimus.ui.services.user.Institution;

/**
 * The Class InstitutionImpl.
 */
@Service
public class InstitutionImpl implements IInstitutionService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(InstitutionImpl.class);
	
	/** The Constant INSTITUTION_DELETED. */
	private static final String INSTITUTION_DELETED = "Institution deleted";

	/** The Constant INSTITUTION_NOT_DELETED. */
	private static final String INSTITUTION_NOT_DELETED = "Institution not deleted";

	/** The institution repository. */
	@Autowired
	private InstitutionRepository institutionRepository;

	/**
	 * Save institution.
	 *
	 * @param institution the institution
	 */
	@Override
	public void saveInstitution(Institution inst) {
		try {
			institutionRepository.save(inst);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the institutions.
	 *
	 * @return the institutions
	 */
	@Override
	public List<Institution> getInstitutions() {
		return this.institutionRepository.findAll();
	}

	/* (non-Javadoc)
	 * @see com.opus.optimus.offline.services.user.IInstitutionService#getInstitution(java.lang.String)
	 */
	@Override
	public Institution getInstitution(String instid) {
		return this.institutionRepository.findByInstitutionId(instid);
	}

	/**
	 * Update institution.
	 *
	 * @param institution the institution
	 * @param instId the inst id
	 * @return the string
	 */
	@Override
	public String updateInstitution(Institution institution, String instId) {
		try {
			Institution instDb = getInstitution(instId);

			if (instDb != null) {
				institution.setId(instDb.getId());

				saveInstitution(institution);
				return "Institution updated";
			} else {
				return "Institution not updated";
			}
		} catch (Exception e) {
			log.error("Exception in InstitutionImpl updateInstitution :" + e);
			return "Institution not updated";
		}

	}

	/**
	 * Delete institution.
	 *
	 * @param instId the inst id
	 * @return the string
	 */
	@Override
	public String deleteInstitution(String instid) {
		Institution inst;
		try {
			inst = this.institutionRepository.findByInstitutionId(instid);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}

		try {
			if (inst != null) {
				this.institutionRepository.delete(inst);
				return INSTITUTION_DELETED;
			} else {
				return INSTITUTION_NOT_DELETED;
			}
		} catch (Exception e) {
			log.error("Exception in InstitutionImpl deleteInstitution :" + e);
			return INSTITUTION_NOT_DELETED;
		}

	}

}
