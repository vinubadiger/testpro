package com.opus.optimus.offline.services.scheduler.quartz;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.repository.workflow.PublishedWorkflowRepository;
import com.opus.optimus.offline.runtime.taskmanager.exception.CustomException;
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.taskmanager.model.SourceInfo;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.services.scheduler.BatchDefinitionService;
import com.opus.optimus.offline.services.taskmanager.JobInfoDataService;
import com.opus.optimus.offline.services.webclient.RestClient;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.StepInputData;
import com.opus.optimus.ui.services.util.BeanUtilService;
import com.opus.optimus.ui.services.util.FileUtility;


/**
 * The Class JobExecution class is responsible for schedule the create job ,schedule job.
 */
@Component
public class JobExecution implements Job {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JobExecution.class);

	/** The file inprocess location. */
	public static String FILE_INPROCESS_LOCATION;

	/**
	 * Sets the file name.
	 *
	 * @param filelocation the new file name
	 */
	@Value ("${file.process.directory}")
	public void setFileName(String filelocation) {
		FILE_INPROCESS_LOCATION = filelocation;
	}

	/* 
	 * quartz implementation to execute job
	 */
	@Override
	public void execute(JobExecutionContext arg) throws JobExecutionException {
		logger.info("Executing Job at : {}", new Date());
		try{
			JobDataMap jobDataMap = arg.getMergedJobDataMap();

			String projectName = (String) jobDataMap.get(QuartzScheduler.PROJECT_NAME);
			String workflowName = (String) jobDataMap.get(QuartzScheduler.WORKFLOW_NAME);
			String workflowType = (String) jobDataMap.get(QuartzScheduler.WORKFLOW_TYPE);
			String groupId = (String) jobDataMap.get(QuartzScheduler.GROUP_ID);
			List<?> stepInputData = (List<?>) jobDataMap.get(QuartzScheduler.STEPINPUT_DATA);

			setInputDataAndTriggerJob(projectName, workflowName, groupId, workflowType, stepInputData);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Sets the input data and trigger job.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @param workflowType the workflow type
	 * @param stepInputData the step input data
	 * @return the string
	 */
	public static String setInputDataAndTriggerJob(String projectName, String workflowName, String groupId, String workflowType, List<?> stepInputData) {
		logger.debug("in job execution");

		try{
			if (workflowType.equals("ETL")){
				logger.debug("Trying to trigger an ETL job with Group Id: {}", groupId);
				if (null == stepInputData || stepInputData.isEmpty()){
					throw new GenericException("StepInputs not found");
				} else{
					return setETLStepInputDataAndTriggerJob(projectName, workflowName, groupId, workflowType, stepInputData);
				}
			} else{
				logger.debug("Trying to trigger an RECON job with Group Id: {}", groupId);
				return setReconStepInputAndTrigger(projectName, workflowName, workflowType, groupId);
			}
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Sets the ETL step input data and trigger job.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @param workflowType the workflow type
	 * @param stepInputData the step input data
	 * @return the string
	 */
	private static String setETLStepInputDataAndTriggerJob(String projectName, String workflowName, String groupId, String workflowType, List<?> stepInputData) {
		for (Object stepInput : stepInputData){
			StepInputData inputData = (StepInputData) stepInput;
			switch (inputData.getStepInputType()) {
			case FILE_FOLDER_LOCATION:{
				String directoryLocation = inputData.getStepInputValue();
				logger.debug("Directory location in application.properties: {}", directoryLocation);
				File dir = new File(directoryLocation);
				if (dir.exists() && dir.isDirectory() && dir.list().length > 0){
					for (File file : dir.listFiles()){
						if(file.isDirectory()) {
							continue;
						}
						logger.debug("Destination File Location  {}", JobExecution.FILE_INPROCESS_LOCATION);
						File mkdirectory = new File(JobExecution.FILE_INPROCESS_LOCATION, new StringBuilder(projectName).append("-").append(workflowName).toString());
						String destFilePath = mkdirectory.getAbsolutePath().concat(File.separator).concat(file.getName());
						logger.debug("Destination File Name  {}", destFilePath);
						if (!mkdirectory.exists()){
							logger.debug("Creating Directory {}, with permission : {}", mkdirectory, Boolean.valueOf(mkdirectory.canWrite()));
							if (mkdirectory.mkdir()){
								logger.debug("Directory is created!");
							} else{
								logger.error("Unable to create destination directory");
							}
						}

						logger.debug("Checking if file already exists");
						File destinationFile = new File(destFilePath);
						String destFileExtn = FileUtility.getFileExtension(destFilePath);
						JobInfo jobInfo;
						if (destinationFile.exists()){
							logger.debug("File exists. Renaming as duplicate");
							String newFilePath = new StringBuilder(FileUtility.getFileNameWithoutExtension(destFilePath)).append("-duplicate-").append(getCurrentDate()).append(destFileExtn).toString();
							FileUtility.moveFileInProcessDirectory(file.getAbsolutePath(), newFilePath);
							jobInfo = buildETLJobInfo(projectName, workflowName, workflowType, groupId, inputData.getStepName(), newFilePath, file.getName());
						} else{
							logger.debug("Moving file to In Process directory");
							FileUtility.moveFileInProcessDirectory(file.getAbsolutePath(), destFilePath);
							jobInfo = buildETLJobInfo(projectName, workflowName, workflowType, groupId, inputData.getStepName(), destFilePath, file.getName());
						}

						sendToServerToCreateAndRun(jobInfo);
					}
					return "success";
				} else{
					logger.debug("Case management directory is emty hence case created and to log error send to taskmanager");
					final JobInfo jobInfo = buildETLJobInfo(projectName, workflowName, workflowType, groupId, inputData.getStepName(), directoryLocation, "");
					sendToServerToCreateAndRun(jobInfo);
					return "Directory/File does not exist. Case has been logged.";
				}
			}
			default:
				break;
			}
		}
		return "Job not submitted. Please check your configuration";
	}

	/**
	 * Gets the current date.
	 *
	 * @return the current date
	 */
	private static String getCurrentDate() {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMMdd-HH:mm:ssz");
		return format.format(new Date());
	}

	/**
	 * Sets the recon step input and trigger.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @return the string
	 */
	private static String setReconStepInputAndTrigger(String projectName, String workflowName, String workflowType, String groupId) {
		JobInfo jobInfo = buildReconJobInfo(projectName, workflowName, workflowType, groupId);
		sendToServerToCreateAndRun(jobInfo);
		return "success";
	}

	/**
	 * Builds the recon job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @return the job info
	 */
	private static JobInfo buildReconJobInfo(String projectName, String workflowName, String workflowType, String groupId) {
		JobInfo jobinfo = buildGenericJobInfo(projectName, workflowName, workflowType, groupId);
		jobinfo.getJobTasks().forEach(jobTask -> {
			jobTask.getExecutionInfo().setStepInputs(getStepInputsForRecon(groupId));
		});
		return jobinfo;
	}

	/**
	 * Gets the step inputs for recon.
	 *
	 * @param groupId the group id
	 * @return the step inputs for recon
	 */
	private static Map<String, List<String>> getStepInputsForRecon(String groupId) {
		try{
			HashMap<String, List<String>> stepInputs = new HashMap<>();
			List<String> emptyArray = new ArrayList<>();
			emptyArray.add("");
			PublishedWorkflowRepository publishedRepoService = BeanUtilService.getBeanObject(PublishedWorkflowRepository.class);
			PublishedService publishedService = publishedRepoService.findById(groupId).isPresent() ? publishedRepoService.findById(groupId).get() : null;
			if (null == publishedService){
				throw new CustomException("Acitity Not Yet Published", 500);
			}
			publishedService.getWorkflowConfig().getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE)).collect(Collectors.toList()).forEach(stepConfig -> {
				stepInputs.put(stepConfig.getStepName(), emptyArray);
			});
			return stepInputs;
		} catch (GenericException ce){
			throw ce;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Send to server to create and run.
	 *
	 * @param jobInfo the job info
	 */
	public static void sendToServerToCreateAndRun(JobInfo jobInfo) {
		try{
			final RestClient client = BeanUtilService.getBeanObject(RestClient.class);
			String jobId = client.createJob(jobInfo);
			if (jobId != null){
				updateJobInfo(jobId, jobInfo);
				client.runJob(jobId);
			} else{
				logger.error("Failed to create the job. PLease check the server log");
			}
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Update job info.
	 *
	 * @param jobId the job id
	 * @param jobInfo the job info
	 */
	private static void updateJobInfo(String jobId, JobInfo jobInfo) {
		logger.debug("Id in service {}", jobId);
		try{
			JobInfoDataService jobInfoservice = BeanUtilService.getBeanObject(JobInfoDataService.class);
			logger.info("{}", jobInfoservice);
			jobInfoservice.save(jobId, jobInfo);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Builds the ETL job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param stepName the step name
	 * @param destfile the destfile
	 * @param filename the filename
	 * @return the job info
	 */
	public static JobInfo buildETLJobInfo(String projectName, String workflowName, String workflowType, String groupId, String stepName, String destfile, String filename) {
		try{
			JobInfo jobinfo = buildGenericJobInfo(projectName, workflowName, workflowType, groupId);
			SourceInfo sourcefile = new SourceInfo();
			sourcefile.setSourceFile(filename);
			jobinfo.setSourceInfo(sourcefile);

			jobinfo.getJobTasks().forEach(jobTask -> {
				jobTask.getExecutionInfo().setStepInputs(getStepInputsForEtl(stepName, destfile, filename));
			});

			logger.debug("Updating Batch definition");
			updateBatchDefinition(groupId, projectName, workflowName, workflowType);
			return jobinfo;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Update batch definition.
	 *
	 * @param groupId the group id
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 */
	private static void updateBatchDefinition(String groupId, String projectName, String workflowName, String workflowType) {
		if (null == groupId || groupId.isEmpty()){
			BatchDefinitionService batchDefinitionService = BeanUtilService.getBeanObject(BatchDefinitionService.class);
			BatchDefinition batchDefinition = batchDefinitionService.getBatchDefinition(projectName, workflowName, workflowType);
			groupId = batchDefinition.getGroupId();
			if (null == groupId || groupId.isEmpty()){
				groupId = BeanUtilService.getBeanObject(PublishedWorkflowRepository.class).get(projectName, workflowName, workflowType).getId();
				batchDefinition.setGroupId(groupId);
				batchDefinitionService.saveBatchDefinition(batchDefinition);
			}
		}
	}

	/**
	 * Builds the generic job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @return the job info
	 */
	private static JobInfo buildGenericJobInfo(String projectName, String workflowName, String workflowType, String groupId) {
		JobInfo jobinfo = new JobInfo();
		jobinfo.setName(projectName + workflowName);
		jobinfo.setStatus(JobStatus.CREATED);
		jobinfo.setGroupId(groupId);
		jobinfo.setProjectName(projectName);
		jobinfo.setWorkflowName(workflowName);
		jobinfo.setWorkflowType(workflowType);

		jobinfo.setJobTasks(getJobTasks(workflowName, groupId));

		return jobinfo;

	}

	/**
	 * Gets the job tasks.
	 *
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @return the job tasks
	 */
	private static List<JobTask> getJobTasks(String workflowName, String groupId) {
		JobTask jobtask = new JobTask();
		jobtask.setTaskId(UUID.randomUUID().toString().replace("-", ""));
		jobtask.setExecutionInfo(getExecutionInfo(workflowName, groupId));
		ArrayList<JobTask> jobtasks = new ArrayList<>();
		jobtasks.add(jobtask);
		return jobtasks;

	}

	/**
	 * Gets the execution info.
	 *
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @return the execution info
	 */
	private static ExecutionInfo getExecutionInfo(String workflowName, String groupId) {
		ExecutionInfo executionInfo = new ExecutionInfo();
		executionInfo.setGroupId(groupId);
		executionInfo.setId(workflowName);
		executionInfo.setType("Workflow");
		executionInfo.setErrorHandlingId(null);
		executionInfo.setErrorHandlingType(null);
		return executionInfo;
	}

	/**
	 * Gets the step inputs for etl.
	 *
	 * @param stepName the step name
	 * @param destfile the destfile
	 * @param filename the filename
	 * @return the step inputs for etl
	 */
	private static Map<String, List<String>> getStepInputsForEtl(String stepName, String destfile, String filename) {
		HashMap<String, List<String>> stepInputs = new HashMap<>();
		logger.info("File name  while creating jobInfo object {}", filename);
		List<String> readerStepParameter = new ArrayList<>();
		logger.info("File directory location in while creating jobInfo object {}", destfile);
		readerStepParameter.add(destfile);
		stepInputs.put(stepName, readerStepParameter);
		return stepInputs;
	}
}