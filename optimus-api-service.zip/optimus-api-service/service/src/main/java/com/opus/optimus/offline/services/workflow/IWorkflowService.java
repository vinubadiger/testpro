package com.opus.optimus.offline.services.workflow;

import java.util.List;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Interface IWorkflowService.
 */
public interface IWorkflowService {

	/**
	 * Save Workflow.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	ServiceResponse save(Workflow workflow);

	/**
	 * Update Workflow.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	ServiceResponse update(Workflow workflow);

	/**
	 * Get Workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	Workflow get(String projectName, String workflowName, String workflowType);

	/**
	 * Get Workflow by.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<Workflow> get(String projectName, String workflowType);

	/**
	 * Delete Workflow by.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	ServiceResponse delete(String projectName);

	/**
	 * Delete Workflow by.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	ServiceResponse delete(String projectName, String workflowName, String workflowType);

	/**
	 * Gets the all workflows.
	 *
	 * @param projectName the project name
	 * @return the all workflows
	 */
	List<Workflow> getAllWorkflows(String projectName);

	/**
	 * Duplicate.
	 *
	 * @param projectName the project name
	 * @param string the string
	 */
	void duplicate(String projectName, String string);

	/**
	 * Duplicate workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param targetWorkflow the target workflow
	 * @return the service response
	 */
	ServiceResponse duplicateWorkflow(String projectName, String workflowName, String workflowType, String targetWorkflow,String description);

	/**
	 * Get list of workflowType.
	 *
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<Workflow> get(String workflowType);
	
ServiceResponse deleteCheck(String projectName);
	
	ServiceResponse deleteWorkflow(String projectName, String workflowName, String workflowType);

}
