package com.opus.optimus.offline.services.recon.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.mongodb.Block;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.SourceMappingType;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.repository.recon.ReconSummaryRepository;
import com.opus.optimus.offline.repository.recon.ReconWorkflowRepository;
import com.opus.optimus.offline.repository.workflow.PublishedWorkflowRepository;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.services.recon.IReconSummaryService;
import com.opus.optimus.offline.services.webclient.RestClient;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.recon.Activity;
import com.opus.optimus.ui.services.recon.ForceMatchRecordInfo;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;
import com.opus.optimus.ui.services.recon.ForceMatchedRecords;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class ReconSummaryServiceImpl.
 */
@Service
public class ReconSummaryServiceImpl implements IReconSummaryService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconSummaryServiceImpl.class);

	/** The recon summary repository. */
	@Autowired
	private ReconSummaryRepository reconSummaryRepository;

	/** The published service repo. */
	@Autowired
	private PublishedWorkflowRepository publishedServiceRepo;

	@Autowired
	private ReconWorkflowRepository reconWfRepo;

	/** The mongo reader. */
	@Autowired
	private ReconMongoDbReader mongoReader;

	/** The data source factory. */
	@Autowired
	private DataSourceFactory dataSourceFactory;

	/** The rest client. */
	@Autowired
	RestClient restClient;

	/** The Constant ACTIVITY_NAME. */
	private static final String ACTIVITY_NAME = "activityName";

	/** The Constant RECON_CONTROL_FIELD. */
	private static final String RECON_CONTROL_FIELD = "$reconControlFields";

	/** The Constant PROCESSING_DATE. */
	private static final String PROCESSING_DATE = "processingDate";

	/** The Constant STATUS. */
	private static final String STATUS = "status";

	/** The Constant SUB_STATUS. */
	private static final String SUB_STATUS = "subStatus";

	/** The Constant PROCESS_FAILED. */
	private static final String PROCESS_FAILED = "Process failed";

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.services.recon.IReconSummaryService#findReconActivitySummary(java.lang.String, java.util.Date, java.util.Date)
	 */
	@Override
	public List<ReconAcitivitySummary> findReconActivitySummary(String projectName, Date startDate, Date endDate) {
		try{
			if (projectName == null || projectName.isEmpty()){
				return reconSummaryRepository.findByProcessingDateBetween(startDate, endDate);
			} else return reconSummaryRepository.findByProcessingDateBetween(startDate, endDate, projectName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * saving Recon Activity summary.
	 *
	 * @param reconAcitivitySummary the recon acitivity summary
	 * @return the recon acitivity summary
	 */
	@Override
	public ReconAcitivitySummary saveReconActivitySummary(ReconAcitivitySummary reconAcitivitySummary) {
		try{
			logger.debug("Saving Activity Summary");
			return reconSummaryRepository.save(reconAcitivitySummary);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.services.recon.IReconSummaryService#findAll()
	 */
	@Override
	public List<ReconAcitivitySummary> findAll() {
		try{
			return reconSummaryRepository.findAll();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the summary.
	 *
	 * @author Ranjana.Yadav
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param parameters the parameters
	 * @param paginationDetails the pagination details
	 * @return the summary
	 * @throws Exception the exception
	 */

	@Override
	public Page<Object> getSummary(String projectName, String activityName, String sourceName, Map<String, Object> parameters, Map<String, Integer> paginationDetails) throws Exception {
		try{
			logger.debug("Getting Activity Summary");
			PublishedService publishedService = publishedServiceRepo.get(projectName, activityName, "RECON");
			if (publishedService == null){
				throw new GenericException("Activity not found");
			}
			WorkflowConfig wkconfig = publishedService.getWorkflowConfig();
			if (wkconfig == null){
				throw new GenericException("Workflow configuration not found");
			}
			Optional<IStepConfig> step = wkconfig.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getSourceName().equals(sourceName)).findAny();
			if (step.isPresent()){
				return mongoReader.getTransaction((MongoDBReaderConfig) step.get(), activityName, parameters, paginationDetails);
			} else{
				throw new GenericException("Mongo db reader step not found");
			}

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update summary results.
	 *
	 * @param recordHolder the record holder
	 * @param collection the collection
	 * @param activityName the activity name
	 * @param forceMatchedRecord
	 * @param processingDate the processing date
	 */

	private void updateSummaryResults(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, MongoCollection<Document> collection, String activityName, ForceMatchedRecords forceMatchedRecord, Date processingDate) {
		try{
			logger.debug("Aggregation started against the forced matched records......");
			List<Document> andConditions = new ArrayList<>();
			andConditions.add(new Document(new StringBuilder("reconControlFields").append(".").append(activityName).toString(), new Document("$exists", Boolean.TRUE)));
			andConditions.add(new Document(new StringBuilder("reconControlFields").append(".").append(activityName).append(".").append(PROCESSING_DATE).toString(), processingDate));
			Document match = new Document("$match", new Document("$and", andConditions));

			Document idDocument = new Document(ACTIVITY_NAME, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(ACTIVITY_NAME).toString());
			idDocument.append(PROCESSING_DATE, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(PROCESSING_DATE).toString());
			idDocument.append(STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(STATUS).toString());
			idDocument.append(SUB_STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(SUB_STATUS).toString());
			Document totalAmount = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("amount").toString());
			Document totalVariance = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("tolerance").toString());
			Document count = new Document("$sum", Long.valueOf(1));
			Document group = new Document("$group", new Document("_id", idDocument).append("totalAmount", totalAmount).append("totalVariance", totalVariance).append("count", count));

			List<Bson> aggregationQuery = new ArrayList<>();
			aggregationQuery.add(match);
			aggregationQuery.add(group);
			logger.debug("Aggregate Query-- {}", aggregationQuery);
			AggregateIterable<Document> result = collection.aggregate(aggregationQuery);

			result.forEach((Block<? super Document>) (Document document) -> decorateSummaryRecordHolder(document, recordHolder, forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName()));

		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * Decorate summary record holder.
	 *
	 * @param document the document
	 * @param recordHolder the record holder
	 * @param sourceName the source name
	 * @param stepName the step name
	 */
	private void decorateSummaryRecordHolder(Document document, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String sourceName, String stepName) {
		if (null == document){
			logger.debug("Result rowset is null");
			return;
		}
		logger.debug("Processing result rowset : {}", document);
		try{
			Document key = (Document) document.get("_id");
			SummaryKey summaryKey = SummaryKey.builder().activityName(key.getString(ACTIVITY_NAME)).processingDate(key.getDate(PROCESSING_DATE)).status(ReconStatus.valueOf(key.getString(STATUS))).subStatus(ReconSubStatus.valueOf(key.getString(SUB_STATUS))).build();

			ReconSourceSummary reconSourceSummary = ReconSourceSummary.builder().sourceName(sourceName).stepName(stepName).totalAmount(document.getDouble("totalAmount")).totalVarianceAmnt(document.getDouble("totalVariance")).recordCount(document.getLong("count")).build();
			if (!recordHolder.containsKey(summaryKey)){
				recordHolder.put(summaryKey, new ArrayList<ReconSourceSummary>());
			}
			recordHolder.get(summaryKey).add(reconSourceSummary);
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * Save activity summary.
	 *
	 * @param recordHolder the record holder
	 * @param activityType the activity type
	 * @param projectName the project name
	 */
	public void saveActivitySummary(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, SourceMappingType sourceMappingType, String projectName) {
		try{
			List<ReconAcitivitySummary> entites = new ArrayList<>();
			logger.debug("Updating Activity Summaries");
			for (Entry<SummaryKey, List<ReconSourceSummary>> entry : recordHolder.entrySet()){
				SummaryKey summaryKey = entry.getKey();
				ReconAcitivitySummary acitivitySummary = ReconAcitivitySummary.builder().activityName(summaryKey.getActivityName()).processingDate(summaryKey.getProcessingDate()).status(summaryKey.getStatus()).subStatus(summaryKey.getSubStatus()).activityType(sourceMappingType).projectName(projectName).build();
				entry.getValue().forEach(rec -> {
					switch (rec.getStepName()) {
					case ("Source-A"):
						acitivitySummary.setSourceASummary(rec);
						break;
					case ("Source-B"):
						acitivitySummary.setSourceBSummary(rec);
						break;
					default:
						logger.error("Neither Source A nor Source B found in record");
						break;
					}
				});
				entites.add(populateActivitySummary(acitivitySummary));
			}
			logger.debug("Activity Summaries record count to be saved - {}", Integer.valueOf(entites.size()));
			reconSummaryRepository.saveAll(entites);
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * Populate activity summary.
	 *
	 * @param acitivitySummary the acitivity summary
	 * @return the recon acitivity summary
	 */
	private ReconAcitivitySummary populateActivitySummary(ReconAcitivitySummary acitivitySummary) {
		try{
			ReconAcitivitySummary dbAcitivitySummary = reconSummaryRepository.findAcitivitySummary(acitivitySummary.getActivityName(), acitivitySummary.getProjectName(), acitivitySummary.getProcessingDate(), acitivitySummary.getStatus(), acitivitySummary.getSubStatus());
			if (dbAcitivitySummary != null){
				acitivitySummary.setId(dbAcitivitySummary.getId());
			}
			return acitivitySummary;
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.services.recon.IReconSummaryService#forceMatch(com.opus.optimus.ui.services.recon.ForceMatchRequest,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public ServiceResponse forceMatch(ForceMatchRequest forceMatchRequest, String projectName, String activityName) {

		Set<String> cases = new HashSet<>();
		Activity activity = reconWfRepo.findReconSource(projectName, activityName, StepTypeConstants.ReconWorkflowType);
		SourceMappingType sourceMappingType = activity.getSourceMapping();

		ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder = new ConcurrentHashMap<>();

		ServiceResponse responseA = generateSourceWiseSummary(forceMatchRequest.getSourceA(), cases, recordHolder, projectName, activityName, forceMatchRequest.getRemarks());

		ServiceResponse responseB = generateSourceWiseSummary(forceMatchRequest.getSourceB(), cases, recordHolder, projectName, activityName, forceMatchRequest.getRemarks());

		logger.debug("Case set source A and source B {}", cases);

		try{

			cases.parallelStream().forEach(caseId -> {
				logger.debug("caseID in loop while sending to salesforce client {}", caseId);
				String systemNote=CommonUtil.createSystemNote(forceMatchRequest);
				restClient.closeCase(caseId,systemNote, "Reconciled", "Forcematch");
			});

		} catch (Exception e){
			logger.error("Error while closing case", e);
		}

		if (responseA != null && responseA.getStatusCode() == 200 && responseB != null && responseB.getStatusCode() == 200){
			saveActivitySummary(recordHolder, sourceMappingType, projectName);
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Reconciled with force match done", activityName);
		}

		return responseB;

	}

	/**
	 * Generate source wise summary.
	 *
	 * @param forceMatchedRecord the force matched record
	 * @param cases the cases
	 * @param recordHolder the record holder
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param remarks the remarks
	 * @return the service response
	 */
	private ServiceResponse generateSourceWiseSummary(ForceMatchedRecords forceMatchedRecord, Set<String> cases, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String projectName, String activityName, String remarks) {
		List<ForceMatchRecordInfo> sourceInfo = forceMatchedRecord.getSelectedRec();
		cases.addAll(sourceInfo.stream().map(recordInfo -> recordInfo.getCaseID()).collect(Collectors.toSet()));

		logger.info("SOURCE-A---> sourceName -{},stepName - {}, remarks - {}", forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName(), remarks);
		for (ForceMatchRecordInfo info : sourceInfo){
			if (info.getRecId() != null){
				return changeStatus(recordHolder, projectName, activityName, forceMatchedRecord, info.getRecId(), remarks);
			}
		}
		return null;
	}

	/**
	 * Change status.
	 *
	 * @param recordHolder the record holder
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param stepName the step name
	 * @param recordId the record id
	 * @param remarks the remarks
	 * @return the service response
	 */
	private ServiceResponse changeStatus(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String projectName, String activityName, ForceMatchedRecords forceMatchedRecord, String recordId, String remarks) {
		logger.debug("Changing status of record id {}", recordId);
		try{
			PublishedService publishedService = publishedServiceRepo.get(projectName, activityName, "RECON");
			if (publishedService == null){
				throw new GenericException("No Activity found for the given Activity Name");
			}
			WorkflowConfig wkconfig = publishedService.getWorkflowConfig();

			MongoCollection<Document> collection = null;

			Optional<
							IStepConfig> step = wkconfig.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getSourceName().equals(forceMatchedRecord.getSourceName())).findAny();
			if (step.isPresent()){
				MongoDBReaderConfig stepToUpdate = (MongoDBReaderConfig) step.get();
				String dataSourceName = stepToUpdate.getSourceDefinition().getDataSourceName();
				String collectionName = stepToUpdate.getSourceDefinition().getCollectionName();
				logger.debug("DataSource Name - {}, Collection Name - {}", dataSourceName, collectionName);
				IDataSource dataSource = dataSourceFactory.getDataSource(dataSourceName);
				if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
					MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
					MongoDatabase database = mongoDataSource.getDatabase();
					collection = database.getCollection(collectionName);

				}
				logger.debug("Changing record status with collection - {}, activity - {}, recordId - {}", collectionName, activityName, recordId);
				Date processingDate = mongoReader.changeStatusInDb(collection, activityName, recordId, remarks);

				updateSummaryResults(recordHolder, collection, activityName, forceMatchedRecord, processingDate);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Summary updated", recordId);
			}
			return new ServiceResponse(500, ResponseStatus.FAILED, PROCESS_FAILED, forceMatchedRecord.getSourceName());
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
