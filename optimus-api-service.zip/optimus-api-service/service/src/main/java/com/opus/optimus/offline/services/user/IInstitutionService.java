package com.opus.optimus.offline.services.user;

import java.util.List;

import com.opus.optimus.ui.services.user.Institution;

/**
 * The Interface IInstitutionService.
 */
public interface IInstitutionService {

	/**
	 * Save institution.
	 *
	 * @param institution the institution
	 */
	void saveInstitution(Institution institution);

	/**
	 * Gets the institutions.
	 *
	 * @return the institutions
	 */
	List<Institution> getInstitutions();

	/**
	 * Gets the institution.
	 *
	 * @param instId the inst id
	 * @return the institution
	 */
	Institution getInstitution(String instId);

	/**
	 * Update institution.
	 *
	 * @param institution the institution
	 * @param instId the inst id
	 * @return the string
	 */
	String updateInstitution(Institution institution, String instId);

	/**
	 * Delete institution.
	 *
	 * @param instId the inst id
	 * @return the string
	 */
	String deleteInstitution(String instId);

}
