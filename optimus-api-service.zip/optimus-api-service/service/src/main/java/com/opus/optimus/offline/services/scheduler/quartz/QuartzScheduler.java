package com.opus.optimus.offline.services.scheduler.quartz;

import java.util.Date;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Class QuartzScheduler entry point to schedule job.
 */
public class QuartzScheduler {
	
	private QuartzScheduler() {}
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(QuartzScheduler.class);
	
	/** The Constant PROJECT_NAME. */
	public static final String PROJECT_NAME = "projectName";
	
	/** The Constant WORKFLOW_NAME. */
	public static final String WORKFLOW_NAME = "workflowName";
	
	/** The Constant WORKFLOW_TYPE. */
	public static final String WORKFLOW_TYPE = "workflowType";
	
	/** The Constant GROUP_ID. */
	public static final String GROUP_ID = "groupId";
	
	/** The Constant STEPINPUT_DATA. */
	public static final String STEPINPUT_DATA = "stepInputData";
	
	/**
	 * Quartz scheduler trigger.
	 *
	 * @param intervalM the interval M
	 * @param batchDefinition the batch definition
	 * @param startTime the start time
	 * @throws Exception the exception
	 */
	public static void quartzSchedulerTrigger(int intervalM, BatchDefinition batchDefinition, Date startTime) throws Exception {
		try{
			JobDataMap jobDataMap = new JobDataMap();
			jobDataMap.put(PROJECT_NAME, batchDefinition.getProjectName());
			jobDataMap.put(WORKFLOW_NAME, batchDefinition.getWorkflowName());
			jobDataMap.put(WORKFLOW_TYPE, batchDefinition.getWorkflowType());
			jobDataMap.put(GROUP_ID, batchDefinition.getGroupId());
			jobDataMap.put(STEPINPUT_DATA, batchDefinition.getStepInputData());
			StringBuilder jobKey = new StringBuilder();
			jobKey.append(batchDefinition.getProjectName());
			jobKey.append(batchDefinition.getWorkflowName());
			jobKey.append(batchDefinition.getWorkflowType());

			logger.info("INNN JOB = " + jobKey.toString());
			JobDetail job = JobBuilder.newJob(JobExecution.class).withIdentity(jobKey.toString()).setJobData(jobDataMap).build();

			Trigger trigger = TriggerBuilder.newTrigger().withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes(intervalM).repeatForever()).startAt(startTime).build();

			SchedulerFactory scFactory = new StdSchedulerFactory();
			Scheduler sch = scFactory.getScheduler();
			sch.start();
			sch.scheduleJob(job, trigger);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Quartz scheduler cron expression.
	 *
	 * @param crondata the crondata
	 * @param batchDefinition the batch definition
	 * @param startTime the start time
	 * @throws Exception the exception
	 */
	public static void quartzSchedulerCronExpression(String crondata, BatchDefinition batchDefinition, Date startTime) throws Exception {
		try{
			JobDataMap jobDataMap = new JobDataMap();
			jobDataMap.put(PROJECT_NAME, batchDefinition.getProjectName());
			jobDataMap.put(WORKFLOW_NAME, batchDefinition.getWorkflowName());
			jobDataMap.put(WORKFLOW_TYPE, batchDefinition.getWorkflowType());
			jobDataMap.put(GROUP_ID, batchDefinition.getGroupId());
			jobDataMap.put(STEPINPUT_DATA, batchDefinition.getStepInputData());
			StringBuilder jobKey = new StringBuilder();
			jobKey.append(batchDefinition.getProjectName());
			jobKey.append(batchDefinition.getWorkflowName());
			jobKey.append(batchDefinition.getWorkflowType());
			JobDetail job = JobBuilder.newJob(JobExecution.class).withIdentity(jobKey.toString()).setJobData(jobDataMap).build();

			CronTrigger crontrigger = TriggerBuilder.newTrigger().withIdentity(jobKey.toString()).startAt(startTime).withSchedule(CronScheduleBuilder.cronSchedule(crondata)).build();

			SchedulerFactory scFactory = new StdSchedulerFactory();
			Scheduler sch = scFactory.getScheduler();
			sch.start();
			sch.scheduleJob(job, crontrigger);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Removes the quartz scheduler cron expression.
	 *
	 * @param jobKey the job key
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public static boolean removeQuartzSchedulerCronExpression(JobKey jobKey) throws Exception {
		SchedulerFactory scFactory = new StdSchedulerFactory();
		try{
			boolean status = scFactory.getScheduler().deleteJob(new JobKey(jobKey.getName()));
			logger.debug("Job with jobKey :" + jobKey + " deleted with status :" + status);
			return status;
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}
}