package com.opus.optimus.offline.services.workflow;

import java.util.List;
import java.util.Map;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.ui.constants.ServiceResponse;

/**
 * The Interface IDataSourceService.
 */
public interface IDataSourceService {
	
	/**
	 * Save the MongoDataSourceMeta.
	 *
	 * @param dataSource the data source
	 * @return the service response
	 */
	ServiceResponse save(MongoDataSourceMeta dataSource);

	/**
	 * Gets the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	MongoDataSourceMeta get(String dataSourceName, String databaseType);

	/**
	 * Delete the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the service response
	 */
	ServiceResponse delete(String dataSourceName, String databaseType);

	/**
	 * Update the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @param dataSource the data source
	 * @return the service response
	 */
	ServiceResponse update(String dataSourceName, String databaseType, MongoDataSourceMeta dataSource);

	/**
	 * Gets the data sources.
	 *
	 * @param databaseType the database type
	 * @return the data sources
	 */
	List<MongoDataSourceMeta> getDataSources(String databaseType);

	/**
	 * Gets the collections.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the collections
	 */
	List<MongoDataSourceMeta> getCollections(String dataSourceName, String databaseType);

	/**
	 * Gets the all data source details.
	 *
	 * @return the all data source details
	 */
	List<MongoDataSourceMeta> getAllDataSourceDetails();

	/**
	 * Gets the mongo conn test.
	 *
	 * @param dataSource the data source
	 * @return the mongo conn test
	 */
	Map<String, Boolean> getMongoConnTest(MongoDataSourceMeta dataSource);
}