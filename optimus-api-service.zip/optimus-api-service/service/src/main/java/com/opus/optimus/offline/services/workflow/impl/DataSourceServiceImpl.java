package com.opus.optimus.offline.services.workflow.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.config.datasource.ServerAddressMetadata;
import com.opus.optimus.offline.repository.workflow.DataSourceRepository;
import com.opus.optimus.offline.services.workflow.IDataSourceService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;

/**
 * The Class DataSourceServiceImpl.
 */
@Service
public class DataSourceServiceImpl implements IDataSourceService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(DataSourceServiceImpl.class);

	/** The data source repository. */
	@Autowired
	private DataSourceRepository dataSourceRepository;

	/** The Constant DATASOURCE_DELETED. */
	private static final String DATASOURCE_DELETED = "Datasource deleted";

	/** The Constant DATASOURCE_CREATED. */
	private static final String DATASOURCE_CREATED = "Datasource saved successfully";

	/** The Constant DATASOURCE_UPDATED. */
	private static final String DATASOURCE_UPDATED = "Datasource updated successfully";

	/** The Constant DATASOURCE_NOT_EXISTS. */
	private static final String DATASOURCE_NOT_EXISTS = "Datasource not exists";

	/**
	 * Save the MongoDataSourceMeta.
	 *
	 * @param dataSource the data source
	 * @return the service response
	 */
	@Override
	public ServiceResponse save(MongoDataSourceMeta dataSource) {
		try{
			MongoDataSourceMeta mongoDataSourceMetaDb = get(dataSource.getDataSourceName(), dataSource.getDatabaseType());
			if (mongoDataSourceMetaDb != null){
				dataSource.setId(mongoDataSourceMetaDb.getId());
				this.dataSourceRepository.save(dataSource);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_UPDATED, dataSource);
			} else{
				this.dataSourceRepository.save(dataSource);
				return new ServiceResponse(500, ResponseStatus.FAILED, DATASOURCE_CREATED, dataSource);
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	@Override
	public MongoDataSourceMeta get(String dataSourceName, String databaseType) {
		try{
			return this.dataSourceRepository.findByDataSource(dataSourceName, databaseType);
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Delete the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the service response
	 */
	@Override
	public ServiceResponse delete(String dataSourceName, String databaseType) {
		MongoDataSourceMeta mongoDataSourceMeta;
		try{
			mongoDataSourceMeta = this.dataSourceRepository.findByDataSource(dataSourceName, databaseType);
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}

		try{
			if (mongoDataSourceMeta != null){
				this.dataSourceRepository.delete(mongoDataSourceMeta);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_DELETED, dataSourceName);
			} else{
				log.debug(DATASOURCE_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, DATASOURCE_NOT_EXISTS, dataSourceName);
			}
		} catch (Exception e){
			log.error("Exception in DataSourceServiceImpl delete :" + e);
			throw e;
		}

	}

	/**
	 * Update the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @param dataSource the data source
	 * @return the service response
	 */
	@Override
	public ServiceResponse update(String dataSourceName, String databaseType, MongoDataSourceMeta mongoDataSourceMeta) {
		try{
			MongoDataSourceMeta mongoDataSrcDb = get(dataSourceName, databaseType);

			if (mongoDataSrcDb != null){
				mongoDataSourceMeta.setId(mongoDataSrcDb.getId());
				save(mongoDataSourceMeta);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_UPDATED, dataSourceName);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, DATASOURCE_NOT_EXISTS, dataSourceName);
			}
		} catch (Exception e){
			log.error("Exception in DataSourceServiceImpl delete :" + e);
			throw e;
		}
	}

	/**
	 * Gets the data sources.
	 *
	 * @param databaseType the database type
	 * @return the data sources
	 */
	@Override
	public List<MongoDataSourceMeta> getDataSources(String databaseType) {
		return this.dataSourceRepository.findBydatabaseTypeLike(databaseType);
	}

	/**
	 * Gets the collections.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the collections
	 */
	@Override
	public List<MongoDataSourceMeta> getCollections(String dataSourceName, String databaseType) {
		return this.dataSourceRepository.findBydatabaseTypeLike(databaseType, dataSourceName);
	}

	/**
	 * Gets the all data source details.
	 *
	 * @return the all data source details
	 */
	@Override
	public List<MongoDataSourceMeta> getAllDataSourceDetails() {
		return this.dataSourceRepository.findAll();
	}

	/**
	 * Gets the mongo conn test.
	 *
	 * @param dataSource the data source
	 * @return the mongo conn test
	 */
	@Override
	public Map<String, Boolean> getMongoConnTest(MongoDataSourceMeta dataSource) {
		Map<String, Boolean> results = new HashMap<>();
		List<ServerAddressMetadata> serverAddressMetadata = dataSource.getAddressMetadatas();
		for (ServerAddressMetadata object : serverAddressMetadata){
			try{
				MongoClient mongoClient = null;
				MongoCredential mongoCredential = null;
				mongoCredential = MongoCredential.createScramSha1Credential(dataSource.getDataSourceName(), dataSource.getAuthMetaData().getUserName(), dataSource.getAuthMetaData().getPassword().toCharArray());
				mongoClient = new MongoClient(new ServerAddress(object.getIpAddress(), object.getPort()), Arrays.asList(mongoCredential));
				DB db = mongoClient.getDB(dataSource.getDataSourceName());
				log.debug("{}",db.getStats());
				log.debug("{}",db.getStats().ok());
				log.debug("{}",db.getCollectionNames());
				mongoClient.close();
				results.put(object.getIpAddress(), true);
			} catch (Exception e){
				results.put(object.getIpAddress(), false);
			}
		}
		return results;
	}
}
