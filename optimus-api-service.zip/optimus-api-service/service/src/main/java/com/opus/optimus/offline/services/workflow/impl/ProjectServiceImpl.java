package com.opus.optimus.offline.services.workflow.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.repository.workflow.ProjectRepository;
import com.opus.optimus.offline.repository.workflow.PublishedWorkflowRepository;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.services.recon.IReconWorkflowService;
import com.opus.optimus.offline.services.scheduler.BatchDefinitionService;
import com.opus.optimus.offline.services.workflow.IProjectService;
import com.opus.optimus.offline.services.workflow.IWorkflowService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Project;
import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Class ProjectServiceImpl.
 */
@Service
public class ProjectServiceImpl implements IProjectService {
	
	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(ProjectServiceImpl.class);

	/** The Constant PROJECT_EXISTS. */
	private static final String PROJECT_EXISTS = "Project already exists";

	/** The Constant PROJECT_NOT_EXISTS. */
	private static final String PROJECT_NOT_EXISTS = "Project not exists";

	/** The Constant PROJECT_CREATED. */
	private static final String PROJECT_CREATED = "Project created succesfully";

	/** The Constant PROJECT_DELETED. */
	private static final String PROJECT_DELETED = "Project deleted succesfully";

	/** The Constant PROJECT_DUPLICATED. */
	private static final String PROJECT_DUPLICATED = "Project duplicated";

	/** The Constant PROJECT_UPDATED. */
	private static final String PROJECT_UPDATED = "Project updated succesfully";

	/** The project repository. */
	@Autowired
	private ProjectRepository projectRepository;

	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;
	
	@Autowired
	private BatchDefinitionService batchDefinitionService;
	
	@Autowired
	PublishedWorkflowRepository publishedWorkflowRepository;
	
	/**
	 * Gets the Project.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	@Override
	public Project get(String projectName) {
		return this.projectRepository.findProjectByProjectName(projectName);
	}

	/**
	 * Save Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@Override
	public ServiceResponse save(Project project) {
		try{
			Project projectdb = get(project.getProjectName());
			if (projectdb != null){
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_EXISTS, projectdb);
			} else{
				this.projectRepository.save(project);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_CREATED, project);
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the project names.
	 *
	 * @return the project names
	 */
	@Override
	public List<Project> getProjectNames() {
		try{
			List<Project> projects = this.projectRepository.findAll();
			Collections.sort(projects);
			Collections.reverse(projects);
			return projects;
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Update Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@Override
	public ServiceResponse update(Project project) {
		Project projectdb = get(project.getProjectName());
		try{
			if (projectdb != null){
				project.setId(projectdb.getId());
				this.projectRepository.save(project);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_UPDATED, project);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, projectdb);
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}

	}

	/**
	 * Delete project as well its workflow.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	/*TODO Will be deleted ,once delete functionality will be tested for each scenarios.
	 * @Override
	public ServiceResponse delete(String projectName) {

		Project project = this.projectRepository.findProjectByProjectName(projectName);
		try{
			if (project != null){
				ServiceResponse responseWf = this.workflowService.delete(projectName);
				if (responseWf.getStatus().equals(ResponseStatus.SUCCESS)){
					this.projectRepository.delete(project);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_DELETED, project);
				} else return new ServiceResponse(500, ResponseStatus.FAILED, responseWf.getMsg(), project);
			} else{
				log.debug(PROJECT_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, project);
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}

	}*/

	/**
	 * Duplicate Project.
	 *
	 * @param sourceProjectName the source project name
	 * @param destinationProjectName the destination project name
	 * @param projectDescription the project description
	 * @return the service response
	 */
	@Override
	public ServiceResponse duplicate(String sourceProjectName, String destinationProjectName, String projectDescription) {
		try{
			log.debug("Entered in duplicate project");
			Project project2;
			Project project1 = get(sourceProjectName);
			Project projectDb2 = get(destinationProjectName);
			if (projectDb2 == null){

				if (project1 != null){
					project2 = project1;
					project2.setId(null);
					project2.setProjectName(destinationProjectName);
					project2.setProjectDescription(projectDescription);
					this.projectRepository.save(project2);
					this.workflowService.duplicate(sourceProjectName, project2.getProjectName());
					return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_DUPLICATED, project2);
				} else{
					log.info("Source project does not exists");
					return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, sourceProjectName);
				}
			} else{
				log.info("Project with this name already exists");
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_EXISTS, destinationProjectName);

			}
		} catch (Exception e){
			log.error(e.getMessage());
			throw e;

		}

	}
	
	/**
	 * Delete project as well its workflow.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	@Override
	public ServiceResponse delete(String projectName) {
		Project project = this.projectRepository.findProjectByProjectName(projectName);
		try{
			if (project != null){
				ServiceResponse responseWf = this.workflowService.deleteCheck(projectName);
				if (responseWf.getStatus().equals(ResponseStatus.SUCCESS)){
					List<Workflow> workflowList = this.workflowService.getAllWorkflows(projectName);
					workflowList.forEach(wf -> this.batchDefinitionService.delete(projectName, wf.getWorkflowName(), wf.getWorkflowType()));
					workflowList.forEach(wf -> this.workflowService.deleteWorkflow(projectName, wf.getWorkflowName(), wf.getWorkflowType()));
					for (Workflow wf : workflowList) {
						PublishedService publishedService = this.publishedWorkflowRepository.get(wf.getProjectName(), wf.getWorkflowName(), wf.getWorkflowType());
						try{
							if (publishedService != null){
								log.debug("PublishedService deleting...{}", publishedService.getProjectName());
								this.publishedWorkflowRepository.delete(publishedService);
							}
						} catch (Exception e){
							log.error(e.getMessage());
							throw e;
						}
					}
					log.debug("Project deleting...{}",project.getProjectName());
					this.projectRepository.delete(project);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_DELETED, project);
				} else {
					return new ServiceResponse(500, ResponseStatus.FAILED, responseWf.getMsg(), project);
				}
			} else{
				log.debug(PROJECT_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, project);
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}

	}

}
