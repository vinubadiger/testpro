package com.opus.optimus.offline.services.taskmanager;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.ui.services.scheduler.WigdetResult;
import com.opus.optimus.ui.services.statistics.ExecutionTime;
import com.opus.optimus.ui.services.statistics.ExecutionTimePerSource;
import com.opus.optimus.ui.services.statistics.FailedFiles;
import com.opus.optimus.ui.services.statistics.FailedFilesWithSource;
import com.opus.optimus.ui.services.statistics.FailureAnalysisWithSourceAndFile;
import com.opus.optimus.ui.services.statistics.FailureInfoSummary;
import com.opus.optimus.ui.services.statistics.FileProcessedWithActualFile;
import com.opus.optimus.ui.services.statistics.JobInfoSummary;
import com.opus.optimus.ui.services.statistics.RootCauseAnalysisTable;

/**
 * The Interface JobInfoDataService.
 *
 * @author manjusha.dhamdhere
 */

@Service
public interface JobInfoDataService {

	/**
	 * Save.
	 *
	 * @param jobId the job id
	 * @param jobinfo the jobinfo
	 * @return the string
	 */
	String save(String jobId, JobInfo jobinfo);

	/**
	 * Gets the job info.
	 *
	 * @param page the page
	 * @param size the size
	 * @return the job info
	 */
	Page<JobInfo> getJobInfo(int page, int size);

	/**
	 * Gets the job info order by.
	 *
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the job info order by
	 */
	Page<JobInfo> getJobInfoOrderBy(int page, int size, String orderType, String field);

	/**
	 * Aggregate.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectname the projectname
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<WigdetResult> aggregate(Date startDate, Date endDate, String projectname, String workflowType);

	/**
	 * Workflow statistics.
	 *
	 * @param status the status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<JobInfoSummary> workflowStatistics(String status, Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failure statistics.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the map
	 */
	Map<String, Long> failureStatistics(Date startDate, Date endDate, String workflowType, String projectName, String workflowName, String sourceFile);

	/**
	 * Gets the job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the job task executor resultby id
	 */
	List<JobTaskExecutorResult> getJobTaskExecutorResultbyId(String jobId);

	/**
	 * Find all by.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<JobInfo> findAllBy(String search, int page, int size);

	/**
	 * Failure analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failure info summary
	 */
	FailureInfoSummary failureAnalysis(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failurer analysis pie chart.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param stepName the step name
	 * @return the map
	 */
	Map<String, Long> failurerAnalysisPieChart(Date startDate, Date endDate, String workflowType, String projectName, String stepName);

	/**
	 * Processiong time calculation.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the execution time
	 */
	ExecutionTime processiongTimeCalculation(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Searchbycolumnnameandtext.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<JobInfo> searchbycolumnnameandtext(String column, String text, int page, int size);

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	Page<JobInfo> autocompleteByText(String column, String pattern);

	/**
	 * Failure analysis root cause analysis table.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	List<RootCauseAnalysisTable> failureAnalysisRootCauseAnalysisTable(Date startDate, Date endDate, String workflowType, String projectName, String workflowName);

	/**
	 * Source files group by workflow name.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<FailureAnalysisWithSourceAndFile> sourceFilesGroupByWorkflowName(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Execution time with source.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<ExecutionTimePerSource> executionTimeWithSource(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Gets the jobinfodatabyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param page the page
	 * @param size the size
	 * @return the jobinfodatabyparam
	 */
	Page<JobInfo> getjobinfodatabyparam(String projectName, String workflowName, String workflowType, int page, int size);

	/**
	 * Failure analysis failed files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	List<FailedFiles> failureAnalysisFailedFiles(Date startDate, Date endDate, String workflowType, String projectName, String workflowName);

	/**
	 * Failure analysis failed files and projects.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorCode the error code
	 * @return the list
	 */
	List<FailedFilesWithSource> failureAnalysisFailedFilesAndProjects(Date startDate, Date endDate, String workflowType, String projectName, String errorCode);

	/**
	 * Gets the job info processed data day wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the job info processed data day wise
	 */
	List<FileProcessedWithActualFile> getJobInfoProcessedDataDayWise(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failed source.
	 *
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<JobInfo> failedSource(String workflowType, String projectName);

	/**
	 * Project within date range.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<JobInfo> projectWithinDateRange(Date startDate, Date endDate, String workflowType);
}