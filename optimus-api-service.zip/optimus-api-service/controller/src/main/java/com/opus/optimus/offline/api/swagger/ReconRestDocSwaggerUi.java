package com.opus.optimus.offline.api.swagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The Class ReconRestDocSwaggerUi is responsible to documenting all controllers end points.
 */
@Configuration
@EnableSwagger2
public class ReconRestDocSwaggerUi implements WebMvcConfigurer {
	
	/**
	 * Docket instance provides the primary api configration with method configration specific to controller
	 * User controller doc.
	 *
	 * @return the docket
	 */
	@Bean
	public Docket userDoc() {
		// @formatter:off
		return new Docket(DocumentationType.SWAGGER_2).groupName("User").select().apis(RequestHandlerSelectors.any()).apis(RequestHandlerSelectors.basePackage("com.opus.optimus.offline.api.user")).paths(PathSelectors.any()).build().apiInfo(apiEndPointsInfo());
		// @formatter:on
	}

	/**
	 * Schedular controller doc.
	 *
	 * @return the docket
	 */
	@Bean
	public Docket schedularDoc() {
		// @formatter:off
		return new Docket(DocumentationType.SWAGGER_2).groupName("Schedular").select().apis(RequestHandlerSelectors.any()).apis(RequestHandlerSelectors.basePackage("com.opus.optimus.offline.api.scheduler")).paths(PathSelectors.any()).build().apiInfo(apiEndPointsInfo());
		// @formatter:on
	}

	/**
	 * Dashboardstats controller doc.
	 *
	 * @return the docket
	 */
	@Bean
	public Docket dashboardstatsDoc() {
		// @formatter:off
		return new Docket(DocumentationType.SWAGGER_2).groupName("Dashboard statistics").select().apis(RequestHandlerSelectors.any()).apis(RequestHandlerSelectors.basePackage("com.opus.optimus.offline.api.taskmanager")).paths(PathSelectors.any()).build().apiInfo(apiEndPointsInfo());
		// @formatter:on
	}

	/**
	 * Workflow controller doc.
	 *
	 * @return the docket
	 */
	@Bean
	public Docket workflowDoc() {
		// @formatter:off
		return new Docket(DocumentationType.SWAGGER_2).groupName("Workflow").select().apis(RequestHandlerSelectors.any()).apis(RequestHandlerSelectors.basePackage("com.opus.optimus.offline.api.workflow")).paths(PathSelectors.any()).build().apiInfo(apiEndPointsInfo());
		// @formatter:on
	}

	/**
	 * Recon controller doc.
	 *
	 * @return the docket
	 */
	@Bean
	public Docket ReconDoc() {
		// @formatter:off
		return new Docket(DocumentationType.SWAGGER_2).groupName("Recon").select().apis(RequestHandlerSelectors.any()).apis(RequestHandlerSelectors.basePackage("com.opus.optimus.offline.api.recon")).paths(PathSelectors.any()).build().apiInfo(apiEndPointsInfo());
		// @formatter:on
	}
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#addResourceHandlers(org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry)
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	/**
	 * Api end points info.
	 *
	 * @return the api info
	 */
	private ApiInfo apiEndPointsInfo() {
		return new ApiInfoBuilder().title("Optimus Recon").description("ETL,Recon,Case management").license("Recon 1.0").licenseUrl("https://www.opusconsulting.com/#").version("1.0.0").build();
	}
}
