package com.opus.optimus.offline.api.workflow;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.workflow.IWorkflowService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class WorkflowController exposes api related to Workflow.
 */
@RestController
@Api (value = "/workflows", description = "REST Apis related to workflows!!!")
@RequestMapping ("{actionName}/workflows")
public class WorkflowController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(WorkflowController.class);

	/** The Constant WORKFLOW_EXISTS. */
	private static final String WORKFLOW_EXISTS = "Workflow exists";

	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowname,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@RequestMapping (value = "/{projectname}/{workflowname}/{workflowType}", method = RequestMethod.GET)
	public Workflow get(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType) {
		try{
			logger.debug("Entered in get all worklow of project");
			return this.workflowService.get(projectName, workflowName, workflowType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the all.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the all
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{projectname}/{workflowType}")
	public List<Workflow> getAll(@PathVariable ("projectname") String projectName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Entered in get all workflows");
		try{
			return this.workflowService.get(projectName, workflowType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Get All ETL Workflows.
	 *
	 * @return the etl workflow
	 */
	@ApiOperation (value = "Get Etl Workflow list", response = Workflow.class, tags = "Get ETL Workflow list")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/ETL")
	public List<Workflow> getEtlWorkflow() {
		logger.debug("Entered in get all workflows");
		try{
			return this.workflowService.get("ETL");
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Save.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow [Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping
	public ServiceResponse save(@RequestBody Workflow workflow) {
		logger.debug("Entered in save workflow");
		try{
			Workflow workflowinDB = this.workflowService.get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());

			if (workflowinDB != null){
				logger.debug("Existing Workflow found with workflow Id" + workflowinDB.getId());
				if (workflow.getId() == null){
					return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_EXISTS, workflow.getWorkflowName());
				}
			}

			return this.workflowService.save(workflow);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Update.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PutMapping
	public ServiceResponse update(@RequestBody Workflow workflow) {
		logger.debug("Entered in update workflow");
		try{
			return this.workflowService.update(workflow);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Deleted"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{projectname}/{workflowname}/{workflowType}")
	public ServiceResponse delete(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType) {
		try{
			logger.debug("Entered in delete workflow");
			return this.workflowService.delete(projectName, workflowName, workflowType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

	/**
	 * Gets the project workflows.
	 *
	 * @param projectName the project name
	 * @return the project workflows
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{projectname}")
	public List<Workflow> getProjectWorkflows(@PathVariable ("projectname") String projectName) {
		logger.debug("Entered in get project workflows");
		try{
			return this.workflowService.getAllWorkflows(projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Duplicate.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param targetWorkflow the target workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow[Duplicate]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping (value = "duplicate/{projectname}/{workflowname}/{workflowType}/{targetWorkflow}/{description}")
	public ServiceResponse duplicate(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType, @PathVariable ("targetWorkflow") String targetWorkflow,@PathVariable("description") String description) {
		try{
			logger.debug("Entered in duplicate workflow");

			Workflow workflowinDB = this.workflowService.get(projectName, targetWorkflow, workflowType);
			if (workflowinDB != null){
				logger.debug("Workflow already exists with this name");
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_EXISTS, targetWorkflow);
			}

			return this.workflowService.duplicateWorkflow(projectName, workflowName, workflowType, targetWorkflow,description);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}

	}

}
