package com.opus.optimus.offline.api.recon;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.services.recon.IReconSummaryService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class ReconSummaryController exposes api related to Reconciliation.
 */
@RestController
@Api (value = "/reconSummary", description = "REST Apis related to recon summaries!!!")
@RequestMapping ("{actionName}/reconSummary")
public class ReconSummaryController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(ReconSummaryController.class);

	/** The recon summary service. */
	@Autowired
	private IReconSummaryService iReconSummaryService;

	/**
	 * Access reconciliation summary.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the list
	 */
	@GetMapping (path = { "/accessReconcillationSummary/{startDate}/{endDate}", "/accessReconcillationSummary/{startDate}/{endDate}/{projectName}" })
	public List<ReconAcitivitySummary> accessReconcillationSummary(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable (required = false) String projectName) {
		try{
			return iReconSummaryService.findReconActivitySummary(projectName, startDate, endDate);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;

		}
	}

	/**
	 * Save reconciliation summary.
	 *
	 * @param reconAcitivitySummary the recon activity summary
	 * @return the recon activity summary
	 */
	@PostMapping (value = "/saveReconcillationSummary")
	public ReconAcitivitySummary saveReconcillationSummary(@RequestBody ReconAcitivitySummary reconAcitivitySummary) {
		try{
			return iReconSummaryService.saveReconActivitySummary(reconAcitivitySummary);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the reconciliation summaries.
	 *
	 * @return the reconciliation summaries
	 */
	@GetMapping (value = "/getReconcillationSummaries")
	public List<ReconAcitivitySummary> getReconcillationSummaries() {
		try{
			return iReconSummaryService.findAll();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the summary.
	 *
	 * @author Ranjana.Yadav
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param pageNo the page no
	 * @param pageSize the page size
	 * @return the summary
	 * @throws Exception
	 */

	@ApiOperation (value = "Get Summary ", response = ReconAcitivitySummary.class, tags = "Get Summary")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@RequestMapping (value = "/getSummary/{projectName}/{activityName}/{sourceName}/{pageNo}/{pageSize}", method = RequestMethod.GET)
	public Page<
					Object> getSummary(@PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("sourceName") String sourceName, @PathVariable ("pageNo") int pageNo, @PathVariable ("pageSize") int pageSize, @RequestParam (value = "status", required = false) String status, @RequestParam (value = "subStatus", required = false) String subStatus, @RequestParam (value = "startDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date startDate, @RequestParam (value = "endDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date endDate) throws Exception {
		Map<String, Integer> paginationDetails = new HashMap<>();
		paginationDetails.put("page", pageNo);
		paginationDetails.put("size", pageSize);

		Map<String, Object> parameters = new HashMap<>();
		parameters.put("status", status);
		parameters.put("subStatus", subStatus);
		parameters.put("startDate", startDate);
		parameters.put("endDate", endDate);

		return iReconSummaryService.getSummary(projectName, activityName, sourceName, parameters, paginationDetails);

	}

	/**
	 * To change the status and substatus on record level input as List
	 * 
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param caseId
	 * @param status
	 */
	@ApiOperation (value = "Change Status for List", response = ServiceResponse.class, tags = "Change Status")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Status changed"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/forceMatch/{projectName}/{activityName}")
	public ServiceResponse forceMatch(@RequestBody ForceMatchRequest forceMatchRequest, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName) {
		return this.iReconSummaryService.forceMatch(forceMatchRequest, projectName, activityName);

	}

}
