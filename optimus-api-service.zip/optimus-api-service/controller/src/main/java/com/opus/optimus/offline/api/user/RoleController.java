package com.opus.optimus.offline.api.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.IRoleService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.Role;

/**
 * The Class RoleController exposes api related to user roles.
 */
@RestController
@RequestMapping ("{actionName}/roles")
public class RoleController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(RoleController.class);

	/** The role service. */
	@Autowired
	private IRoleService roleService;

	/**
	 * Registers the role.
	 *
	 * @param role the role
	 * @return the service response	
	 */
	//@PostMapping
	@RequestMapping (method = RequestMethod.POST)
	public ServiceResponse registerRole(@RequestBody Role role) {
		try{
			log.debug("RoleController::registerRole");
			return roleService.saveRole(role);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in registerRole :", e);
		} 
	}

	/**
	 * Get the data for all the roles.
	 *
	 * @return the roles
	 */
	@GetMapping
	public List<Role> getRoles() {
		try{
			log.debug("Entered in getRoles");
			return this.roleService.getRoles();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getRoles :", e);
		} 
	}

	/**
	 * Get the data for a particular role.
	 *
	 * @param roleName the role name
	 * @return the role
	 */
	@GetMapping(value = "/{roleName}")
	public Role getRole(@PathVariable ("roleName") String roleName) {
		try{
			log.debug(roleName);
			return roleService.getRole(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getRole :", e);
		} 
	}

	/**
	 * Edit the data for particular role.
	 *
	 * @param roleName the role name
	 * @param role the role
	 * @return the service response
	 */
	@PutMapping(value = "/{roleName}")
	public ServiceResponse updateRole(@PathVariable ("roleName") String roleName, @RequestBody Role role) {
		try{
			log.debug(roleName);
			return roleService.updateRole(roleName, role);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in updateRole :", e);
		} 
	}

	/**
	 * Delete the data for particular role.
	 *
	 * @param roleName the role name
	 * @return the service response
	 */
	@DeleteMapping(value = "/{roleName}")
	public ServiceResponse deleteRole(@PathVariable ("roleName") String roleName) {
		try{
			log.debug(roleName);
			return roleService.deleteRole(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteRole :", e);
		} 
	}

	/**
	 * Assign one role to single or multiple users.
	 *
	 * @param roleName the role name
	 * @param emails the emails
	 * @return the string
	 */
	@PostMapping(value = "/{roleName}")
	public String assignRoleToUser(@PathVariable ("roleName") String roleName, @RequestBody List<String> emails) {
		try{
			log.debug(roleName);
			return roleService.assignRoleToUser(roleName, emails);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in assignRoleToUser :", e);
		} 
	}
	
	/**
	 * Revoke role from user.
	 *
	 * @param roleName the role name
	 * @param emails the emails
	 * @return the string
	 */
	@PostMapping(value = "revokerole/{roleName}")
	public String revokeRoleFromUser(@PathVariable ("roleName") String roleName, @RequestBody List<String> emails) {
		try{
			log.debug(roleName);
			return roleService.revokeRoleFromUser(roleName, emails);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in revokeRoleFromUser :", e);
		} 
	}
}
