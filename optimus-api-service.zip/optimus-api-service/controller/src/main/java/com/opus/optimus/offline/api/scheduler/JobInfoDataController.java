package com.opus.optimus.offline.api.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.services.taskmanager.JobInfoDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class JobInfoDataController expose all api related to Jobs.
 */
@RestController
@Api(value = "/scheduler/jobInfoData", tags = "REST Apis related to Schedule jobInfoData")
@RequestMapping("{actionName}/scheduler/jobInfoData")
public class JobInfoDataController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(JobInfoDataController.class);

	/** The job info service. */
	@Autowired
	private JobInfoDataService jobInfoService;

	/**
	 * Retrieve All jobInfoData with pagination.
	 *
	 * @param page the page
	 * @param size the size
	 * @return the job info
	 */
	@ApiOperation(value = "Get Job Info with pagination", response = JobInfo.class, tags = "jobInfoData [pagination]")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping("/{page}/{size}")
	public ResponseEntity<Page<JobInfo>> getJobInfo(@PathVariable("page") int page, @PathVariable("size") int size) {
		try {
			logger.debug("Fetching Job Info Details.");
			Page<JobInfo> jobInfo = this.jobInfoService.getJobInfo(page, size);
			if (jobInfo.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(jobInfo, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Retrieve All jobInfoData with pagination & sort.
	 *
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the job info data order by
	 */
	@ApiOperation(value = "Job Info with pagination,sorting", response = JobInfo.class, tags = "jobInfoData [pagination,sorting]")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping("/{page}/{size}/{orderType}/{field}")
	public ResponseEntity<Page<JobInfo>> getJobInfoDataOrderBy(@PathVariable("page") int page,
			@PathVariable("size") int size, @PathVariable("orderType") String orderType,
			@PathVariable("field") String field) {
		try {
			logger.debug("Fetching Job Info Details Field with Order ASC/DESC with field {} ", field);
			Page<JobInfo> jobInfo = this.jobInfoService.getJobInfoOrderBy(page, size, orderType, field);
			if (jobInfo.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(jobInfo, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the job task executor resultby id
	 */
	@ApiOperation(value = "Get JobTaskExecutorResult ", response = JobTaskExecutorResult.class, tags = "Get userName")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping(value = "/get/{jobId}")
	public List<JobTaskExecutorResult> getJobTaskExecutorResultbyId(@PathVariable("jobId") String jobId) {
		try {
			return jobInfoService.getJobTaskExecutorResultbyId(jobId);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Retrieve All jobInfo data using fulltext search in specific document.
	 *
	 * @param column the column
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return java.util.List
	 */
	@ApiOperation(value = "Search JobInfo columnwise[Advance search] ", response = JobInfo.class, tags = "Returns all occurrences matched with serach criteria columnwise")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping("/searchbycolumn/{column}/{search}/{page}/{size}")
	public ResponseEntity<Page<JobInfo>> fullTextsearchcolumnwise(@PathVariable String column,
			@PathVariable String search, @PathVariable("page") int page, @PathVariable("size") int size) {
		Page<JobInfo> jobinfo = jobInfoService.searchbycolumnnameandtext(column, search, page, size);
		return new ResponseEntity<>(jobinfo, HttpStatus.OK);
	}

	/**
	 * Retrieve All Batchmonitor data using fulltext search in specific document.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return java.util.List
	 */
	@ApiOperation(value = "Search JobInfo ", response = JobInfo.class, tags = "Returns all occurrences matched with serach criteria")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping("/search/{search}/{page}/{size}")
	public ResponseEntity<Page<JobInfo>> fullTextsearch(@PathVariable String search, @PathVariable("page") int page,
			@PathVariable("size") int size) {
		Page<JobInfo> jobinfosearchdata = jobInfoService.findAllBy(search, page, size);
		return new ResponseEntity<>(jobinfosearchdata, HttpStatus.OK);
	}

	/**
	 * Retrieve All JobInfo data using fulltext search in specific document.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return java.util.List
	 */
	@ApiOperation(value = "Autocomplete Search Batchdefination columnwise[Advance search] ", response = JobInfo.class, tags = "Returns all occurrences matched with serach criteria columnwise for autocomplete")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping("/autocomplete/{column}/{pattern}")
	public ResponseEntity<Page<JobInfo>> autocomplete(@PathVariable String column, @PathVariable String pattern) {

		Page<JobInfo> jobinfo = jobInfoService.autocompleteByText(column, pattern);
		return new ResponseEntity<>(jobinfo, HttpStatus.OK);
	}
	
	/**
	 * Gets the listof jobinfobyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workFlowType the work flow type
	 * @param page the page
	 * @param size the size
	 * @return the listof jobinfobyparam
	 */
	@GetMapping ("/getlistbyjobinfoparam/{projectName}/{workflowName}/{workFlowType}/{page}/{size}")
	public ResponseEntity<Page<JobInfo>> getListofJobinfobyparam(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workFlowType") String workFlowType,@PathVariable ("page") int page, @PathVariable ("size") int size) {
		
		Page<JobInfo> jobinfo = jobInfoService.getjobinfodatabyparam(projectName, workflowName, workFlowType,page,size);
		
		return new ResponseEntity<>(jobinfo, HttpStatus.OK);
	}
}
