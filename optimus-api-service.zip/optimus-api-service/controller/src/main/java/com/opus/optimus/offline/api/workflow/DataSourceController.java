package com.opus.optimus.offline.api.workflow;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.services.workflow.IDataSourceService;
import com.opus.optimus.ui.constants.ServiceResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * The Class DataSourceController exposes api related to .
 */
@RestController
@Api (value = "/settings/datasource", description = "REST Apis related to datasource!!!")
@RequestMapping ("{actionName}/settings/datasource")
public class DataSourceController {
	
	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(DataSourceController.class);

	/** The data source service. */
	@Autowired
	private IDataSourceService dataSourceService;

	/**
	 * Save.
	 *
	 * @param dataSource the data source
	 * @return the service response
	 */
	@ApiOperation (value = "datasource ", response = MongoDataSourceMeta.class, tags = "datasource [Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping
	public ServiceResponse save(@RequestBody MongoDataSourceMeta dataSource) {
		try{
			logger.debug("Entered in save ");
			return this.dataSourceService.save(dataSource);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}

	}

	/**
	 * Gets the.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	@ApiOperation (value = "Get datasource,databaseType ", response = MongoDataSourceMeta.class, tags = "datasourcedatabaseType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@RequestMapping (value = "/{dataSourceName}/{databaseType}", method = RequestMethod.GET)
	public MongoDataSourceMeta get(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType) {
		try{
			logger.debug("Entered in get");
			return this.dataSourceService.get(dataSourceName, databaseType);
		} catch (Exception e){
			logger.error("Exception in DataSourceController get :" + e);
			throw e;
		}
	}

	/**
	 * Delete.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the service response
	 */
	@ApiOperation (value = "dataSourceName ", response = String.class, tags = "dataSourceName[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Deleted"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{dataSourceName}/{databaseType}")
	public ServiceResponse delete(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType) {
		try{
			logger.debug("Entered in delete");
			return this.dataSourceService.delete(dataSourceName, databaseType);
		} catch (Exception e){
			logger.error("Exception in DataSourceController delete :" + e);
			throw e;
		}
	}

	/**
	 * Update.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @param dataSource the data source
	 * @return the service response
	 */
	@ApiOperation (value = "dataSourceName ", response = String.class, tags = "dataSourceName[Update]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PutMapping(value = "/{dataSourceName}/{databaseType}")
	public ServiceResponse update(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType, @RequestBody MongoDataSourceMeta dataSource) {
		logger.debug("Entered in update");
		try{
			return this.dataSourceService.update(dataSourceName, databaseType, dataSource);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the data sources.
	 *
	 * @param databaseType the database type
	 * @return the data sources
	 */
	@ApiOperation (value = "getDataSources ", response = MongoDataSourceMeta.class, tags = "getDataSources using databaseType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping(value = "getDataSources/{databaseType}")
	public List<MongoDataSourceMeta> getDataSources(@PathVariable ("databaseType") String databaseType) {
		logger.debug("Entered in getDataSources");
		try{
			return this.dataSourceService.getDataSources(databaseType);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the collections.
	 *
	 * @param databaseType the database type
	 * @param dataSourceName the data source name
	 * @return the collections
	 */
	@ApiOperation (value = "getCollections ", response = MongoDataSourceMeta.class, tags = "getCollections")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping(value = "getCollections/{databaseType}/{dataSourceName}")
	public List<MongoDataSourceMeta> getCollections(@PathVariable ("databaseType") String databaseType, @PathVariable ("dataSourceName") String dataSourceName) {
		logger.debug("Entered in getCollections");
		try{
			return this.dataSourceService.getCollections(dataSourceName, databaseType);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the all data source details.
	 *
	 * @return the all data source details
	 */
	@ApiOperation (value = "GetAllDataSourceDetails ", response = MongoDataSourceMeta.class, tags = "GetAllDataSourceDetails")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping(value = "getAllDataSourceDetails")
	public List<MongoDataSourceMeta> getAllDataSourceDetails() {
		try{
			logger.debug("Entered in getAllDataSourceDetails");
			return this.dataSourceService.getAllDataSourceDetails();
		} catch (Exception e){
			logger.error("Exception in DataSourceController get :" + e);
			throw e;
		}
	}

	/**
	 * Gets the mongo conn test.
	 *
	 * @param dataSource the data source
	 * @return the mongo conn test
	 */
	@PostMapping(value = "/dbTest")
	public Map<String, Boolean> getMongoConnTest(@RequestBody MongoDataSourceMeta dataSource) {
		try{

			logger.debug("Entered in getMongoConnTest");
			return this.dataSourceService.getMongoConnTest(dataSource);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

}
