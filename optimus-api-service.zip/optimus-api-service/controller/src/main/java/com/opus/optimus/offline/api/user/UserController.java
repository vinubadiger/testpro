package com.opus.optimus.offline.api.user;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.IUserService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.Role;
import com.opus.optimus.ui.services.user.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;


/**
 * The Class UserController exposes api related to user.
 */
@RestController
@RequestMapping ("{actionName}/users")
public class UserController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(UserController.class);

	/** The user service. */
	@Autowired
	private IUserService userService;
	
	@Value ("${security.signing-key}")
	private String signingKey;

	/**
	 * Registers the user.
	 *
	 * @param user the user
	 * @return the service response
	 */

	@PostMapping
	public ServiceResponse registerUser(@RequestBody User user) {
		try{
			log.debug("UserController::register");
			return userService.saveUser(user);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in registerUser :", e);
		} 
	}

	/**
	 * Get the data for all the users.
	 *
	 * @return the users
	 */
	@GetMapping
	public List<User> getUsers() {
		try{
			log.debug("Entered in getUsers");
			return this.userService.getUsers();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getUsers :", e);
		} 
	}

	/**
	 * Gets the user.
	 *
	 * @param userName the user name
	 * @return the user
	 */
	/*
	 * Get the data for a particular user
	 */
	@GetMapping(value = "/{userName}")
	public User getUser(@PathVariable ("userName") String userName) {
		try{
			log.debug("getUser : {}", userName);
			return userService.getUser(userName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getUser :", e);
		} 
	}

	/**
	 * Edit the data for particular user.
	 *
	 * @param userName the user name
	 * @param user the user
	 * @return the service response
	 */
	@PutMapping(value = "/{userName}")
	public ServiceResponse updateUser(@PathVariable ("userName") String userName, @RequestBody User user) {
		try{
			log.debug(user.getEmail());
			return userService.updateUser(userName, user);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in updateUser :", e);
		} 
	}

	/**
	 * Delete the data for particular user.
	 *
	 * @param userName the user name
	 * @return the service response
	 */
	@DeleteMapping(value = "/{userName}")
	public ServiceResponse deleteUser(@PathVariable ("userName") String userName) {
		try{
			log.debug("deleteUser : {}", userName);
			return userService.deleteUser(userName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteUser :", e);
		} 
	}

	/**
	 * Assign single or multiple role(s) to one user.
	 *
	 * @param email the email
	 * @param role the role
	 * @return the string
	 */
	@PostMapping(value = "/{email}")
	public String assignRole(@PathVariable ("email") String email, @RequestBody List<Role> role) {
		try{
			log.debug("assignRole : {}", email);
			return userService.assignRole(email, role);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in assignRole :", e);
		} 
	}

	/**
	 * API that returns the list of users to whom a particular role is already assigned(This is required for "Assign Role" on Roles screen.
	 *
	 * @param roleName the role name
	 * @return the list
	 */

	@GetMapping(value = "/usersassigned/{roleName}")
	public List<User> fetchUsersForSelectedRole(@PathVariable ("roleName") String roleName) {
		try{
			log.debug("fetchUsersForSelectedRole : {}", roleName);
			return userService.fetchUsersForSelectedRole(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in fetchUsersForSelectedRole :", e);
		} 
	}

	/**
	 * Fetch available users.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	@GetMapping (value = "/usersavailable/{roleName}")
	public List<User> fetchAvailableUsers(@PathVariable ("roleName") String roleName) {
		try{
			log.debug("fetchAvailableUsers : {}", roleName);
			return userService.fetchAvailableUsers(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in fetchAvailableUsers :", e);
		} 
	}

	@GetMapping (value = "/loggedinuserrole")
	public Role fetchRoleForLoggedInUser(@RequestHeader(value="Authorization") String jwtToken) {
		List roleList = new ArrayList();
		Role role = new Role();
		try{
			final String SECRET1 = Base64.getEncoder().encodeToString(signingKey.getBytes());
			
			Claims claimsx = Jwts.parser().setSigningKey(SECRET1).parseClaimsJws(jwtToken).getBody();

			log.debug("Role : {} ", claimsx.get("authorities"));
			
			roleList =  (List) claimsx.get("authorities");
	
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in fetchRoleForLoggedInUser :", e);
		} 
		role.setRoleName(roleList.get(0).toString());
		return role;
	}
}
