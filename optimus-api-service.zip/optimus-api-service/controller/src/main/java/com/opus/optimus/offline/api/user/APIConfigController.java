package com.opus.optimus.offline.api.user;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.IApiConfigService;
import com.opus.optimus.offline.services.user.IProfileService;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.ApiConfig;

/**
 * The Class APIConfigController exposes the api for rest api configration for all the endpoints.
 */
@RestController
@RequestMapping("{actionName}/apiconfigs")
public class APIConfigController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(APIConfigController.class);

	/** The api config service. */
	@Autowired
	private IApiConfigService apiConfigService;
	
	/** The profile service. */
	@Autowired
	private IProfileService profileService;

	/**
	 * Registers the REST API.
	 *
	 * @param apiConfig the api config
	 */
	@PostMapping
	public void configRestApi(@RequestBody ApiConfig apiConfig) {
		try {
			log.debug("RestAPIConfigController::ConfigRestApi");
			apiConfigService.saveApiConfig(apiConfig);
		}catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in configRestApi", e);
		} 
		
		
		
	}

	/**
	 * Get the data for all the REST APIs.
	 *
	 * @return the api configs
	 */
	@GetMapping(value = "configs")
	public List<ApiConfig> getApiConfigs() {
		try {
			log.debug("Entered in getApiConfigs");
			
			return this.apiConfigService.getApiConfigs();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getApiConfigs", e);
		} 
	}
	
	/**
	 * Get the data for all the REST APIs for a specific role.
	 *
	 * @param roleName the role name
	 * @return the api configs
	 */
	@GetMapping(value = "configs/{roleName}")
	public Map<String, List<ApiConfig>> getApiConfigs(@PathVariable("roleName") String roleName) {
		try {
			log.debug("Entered in getApiConfigs");
			return this.apiConfigService.getApiConfigs(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getApiConfigs with roleName", e);
		} 
	}

	/**
	 * Get the data for a particular REST API.
	 *
	 * @param configId the config id
	 * @return the api config
	 */
	@GetMapping(value = "/{configId}")
	public ApiConfig getApiConfig(@PathVariable("configId") String configId) {
		try {
			log.debug(configId);
			return apiConfigService.getApiConfig(configId);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getApiConfig with roleName", e);
		} 
	}

	/**
	 * Edit the data for particular REST API.
	 *
	 * @param configId the config id
	 * @param apiConfig the api config
	 * @return the string
	 */
	@PutMapping(value = "/{configId}")
	public String updateApiConfig(@PathVariable("configId") String configId, @RequestBody ApiConfig apiConfig) {
		try {
			log.debug(configId);
			return apiConfigService.updateApiConfig(configId, apiConfig);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in updateApiConfig with roleName", e);
		} 
	}

	/**
	 * Delete the data for particular REST API.
	 *
	 * @param configId the config id 
	 * @return the string
	 */
	@DeleteMapping(value = "/{configId}")
	public String deleteInstitution(@PathVariable("configId") String configId) {
		try {
			log.debug(configId);
			return apiConfigService.deleteApiConfig(configId);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteApiConfig with roleName", e);
		}  
	}
	
	/**
	 * Fetch the permissions for menu screen icons
	 * @param roleName
	 * @return
	 */
	@GetMapping(value = "configs/homescreenpermissions/{roleName}")
	public List<String> getHomeScreenPermissions(@PathVariable("roleName") String roleName) {
		try {
			log.debug("Entered in getHomeScreenPermissions");
			return this.apiConfigService.getHomeScreenPermissions(roleName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getHomeScreenPermissions with roleName", e);
		}   
	}
}
