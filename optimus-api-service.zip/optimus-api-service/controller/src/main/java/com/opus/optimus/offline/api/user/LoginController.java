package com.opus.optimus.offline.api.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.ILoginService;
import com.opus.optimus.ui.services.user.Login;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api (value = "/recon", description = "REST Apis related to Login!!!")
@RequestMapping ("/")
public class LoginController {

	public static final Logger log = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private ILoginService loginService;

	/**
	 * @param login
	 * @return
	 */
	@ApiOperation (value = "Login ", response = Login.class, tags = "Login")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Login"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping(value = "/login")
	public ResponseEntity<String> validateLogin(@RequestBody Login login) {

		log.debug("LoginController:validateLogin:Username-" + login.getUserName());
		String result = loginService.validateUser(login);

		if (result.equals("email & password exists")){
			log.debug("LoginController:validateLogin:Welcome To Recon");
			return new ResponseEntity<>("Ok", HttpStatus.ACCEPTED);
		} else{
			return new ResponseEntity<>("Not ok", HttpStatus.NOT_ACCEPTABLE);
		}

	}

}