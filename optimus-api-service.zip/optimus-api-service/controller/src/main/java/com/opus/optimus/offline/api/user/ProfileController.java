package com.opus.optimus.offline.api.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.IProfileService;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.user.Profile;

/**
 * The Class ProfileController exposes api related to user profiles.
 */
@RestController
@RequestMapping("{actionName}/profiles")
public class ProfileController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(ProfileController.class);

	/** The profile service. */
	@Autowired
	private IProfileService profileService;

	/**
	 * Registers the profile.
	 *
	 * @param profile the profile
	 */
	@PostMapping
	public void registerProfile(@RequestBody Profile profile) {
		try {
			log.debug("ProfileController::registerProfile");
			profileService.saveProfile(profile);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in registerProfile with roleName", e);
		} 
	}

	/**
	 * Get the data for all the profiles.
	 *
	 * @return the profiles
	 */
	@GetMapping
	public List<Profile> getProfiles() {
		try {
			log.debug("Entered in getProfiles");
			return this.profileService.getProfiles();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getProfiles :", e);
		} 
	}

	/**
	 * Edit the data for particular profile Get the data for a particular profile.
	 *
	 * @param profileId the profile id
	 * @return the profile
	 */
	@GetMapping(value = "/{profileId}")
	public Profile getProfile(@PathVariable("profileId") String profileId) {
		try {
			log.debug(profileId);
			return profileService.getProfile(profileId);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getProfile :", e);
		} 
	}

	/**
	 * Update profile.
	 *
	 * @param profile the profile
	 * @return the string
	 */
	@PutMapping
	public String updateProfile(@RequestBody Profile profile) {
		try {
			
			return profileService.updateProfile(profile);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in updateProfile :", e);
		} 
	}

	/**
	 * Delete profile.
	 *
	 * @param profileId the profile id
	 * @return the string
	 */
	@DeleteMapping(value = "/{profileId}")
	public String deleteProfile(@PathVariable("profileId") String profileId) {
		try {
			log.debug(profileId);
			return profileService.deleteProfile(profileId);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteProfile :", e);
		} 
	}
}
