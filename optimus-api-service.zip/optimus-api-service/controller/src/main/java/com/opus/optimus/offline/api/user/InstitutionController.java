package com.opus.optimus.offline.api.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.services.user.IInstitutionService;
import com.opus.optimus.ui.services.user.Institution;

/**
 * The Class InstitutionController exposes api related to institution details.
 */
@RestController
@RequestMapping("{actionName}/institution")
public class InstitutionController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(InstitutionController.class);

	/** The institution service. */
	@Autowired
	private IInstitutionService institutionService;

	/**
	 * Registers the institution.
	 *
	 * @param institution the institution
	 */
	@PostMapping
	public void registerInstitution(@RequestBody Institution institution) {
		try {
			log.debug("InstitutionController::registerInstitution");
			institutionService.saveInstitution(institution);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Get the data for all the insitution.
	 *
	 * @return the institutions
	 */
	@GetMapping
	public List<Institution> getInstitutions() {
		try {
			log.debug("Entered in getInstitutions");
			return this.institutionService.getInstitutions();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Get the data for a particular institution.
	 *
	 * @param instId the inst id
	 * @return the institution
	 */
	@GetMapping(value = "/{instId}")
	public Institution getInstitution(@PathVariable("instId") String instId) {
		try {
			log.debug(instId);
			return institutionService.getInstitution(instId);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Edit the data for particular institution.
	 *
	 * @param instId the inst id
	 * @param institution the institution
	 * @return the string
	 */
	@PutMapping(value = "/{instId}")
	public String updateInstitution(@PathVariable("instId") String instId, @RequestBody Institution institution) {
		try {
			log.debug(instId);
			return institutionService.updateInstitution(institution, instId);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Delete the data for particular institution.
	 *
	 * @param instId the inst id
	 * @return the string
	 */
	@DeleteMapping(value = "/{instId}")
	public String deleteInstitution(@PathVariable("instId") String instId) {
		try {
			log.debug(instId);
			return institutionService.deleteInstitution(instId);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

}
