package com.opus.optimus.offline.api.taskmanager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.services.taskmanager.JobInfoDataService;
import com.opus.optimus.ui.services.exception.GenericException;
import com.opus.optimus.ui.services.scheduler.WigdetResult;
import com.opus.optimus.ui.services.statistics.ExecutionTime;
import com.opus.optimus.ui.services.statistics.ExecutionTimePerSource;
import com.opus.optimus.ui.services.statistics.FailedFiles;
import com.opus.optimus.ui.services.statistics.FailedFilesWithSource;
import com.opus.optimus.ui.services.statistics.FailureAnalysisWithSourceAndFile;
import com.opus.optimus.ui.services.statistics.FailureInfoSummary;
import com.opus.optimus.ui.services.statistics.FileProcessedWithActualFile;
import com.opus.optimus.ui.services.statistics.JobInfoSummary;
import com.opus.optimus.ui.services.statistics.RootCauseAnalysisTable;

/**
 * Controller for Dashboard API exposes api related to Job Info.
 *
 * @author manjusha.dhamdhere
 */
@RestController
@RequestMapping ("{actionName}/jobinfo")
public class JobInfoTaskController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(JobInfoTaskController.class);

	/** The jobinfo service. */
	@Autowired
	private JobInfoDataService jobinfoService;

	/**
	 * This Controller will return Count according to status of job. Dashboard L1:: Widget 1 : File Processing Count
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@GetMapping (path = { "/countwigdet/{startDate}/{endDate}/{workflowType}", "/countwigdet/{startDate}/{endDate}/{workflowType}/{projectName}" })
	List<WigdetResult> aggregate(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{

			return jobinfoService.aggregate(startDate, endDate, projectName, workflowType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This controller return count of Success and Failed job's group by workflow name and workfloe type. Dashboard L1:: Widget 2 : File Processing
	 * Distribution
	 *
	 * @param status the status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@GetMapping (path = { "/workflow/statistics/{status}/{startDate}/{endDate}/{workflowType}", "/workflow/statistics/{status}/{startDate}/{endDate}/{workflowType}/{projectName}" })
	List<
					JobInfoSummary> aggregateGraph(@PathVariable ("status") String status, @PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{

			return jobinfoService.workflowStatistics(status, startDate, endDate, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This controller return Record Error Count according to stepType using different filters according to conditions. Dashboard L1:: Widget 3 : File
	 * Failure Reason Codes Dashboard L2:: Widget 6 : Failure Records Analysis by Source (For Failed Records option)
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the map
	 */
	@GetMapping (path = { "/failureResult/{startDate}/{endDate}/{workflowType}" })
	Map<
					String,
					Long> failureStatistics(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @RequestParam (value = "projectName", required = false) String projectName, @RequestParam (value = "workflowName", required = false) String workflowName, @RequestParam (value = "sourceFile", required = false) String sourceFile) {
		try{
			return jobinfoService.failureStatistics(startDate, endDate, workflowType, projectName, workflowName, sourceFile);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This Controller return count of: 1. Source Failed, Total Source 2. Files Failed, Total Files 3. Records Failed, Total Records Dashboard L2::
	 * Widget 5 : Failure Summary
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failure info summary
	 */
	@GetMapping (path = { "/failureAnalysis/{startDate}/{endDate}/{workflowType}", "/failureAnalysis/{startDate}/{endDate}/{workflowType}/{projectName}" })
	FailureInfoSummary failureAnalysisData(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{

			return jobinfoService.failureAnalysis(startDate, endDate, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This Controller return Record level error count group by project name according to given step, or for all steps. Dashboard L2:: Widget 7 :
	 * Error Split
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorType the error type
	 * @return the map
	 */
	@GetMapping (path = { "/failurePieChart/{startDate}/{endDate}/{workflowType}" })
	Map<
					String,
					Long> failureAnalysisPieChart(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @RequestParam (value = "projectName", required = false) String projectName, @RequestParam (value = "errorType", required = false) String errorType) {
		try{

			return jobinfoService.failurerAnalysisPieChart(startDate, endDate, workflowType, projectName, errorType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This Controller return Average Processing Time Per Source and record Processed Per Sec Dashboard L3:: Widget 9 : Processing Analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the execution time
	 */
	@GetMapping (path = { "/executionTime/{startDate}/{endDate}/{workflowType}", "/executionTime/{startDate}/{endDate}/{workflowType}/{projectName}" })
	ExecutionTime executionTime(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{

			return jobinfoService.processiongTimeCalculation(startDate, endDate, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This Controller return Record error count with file name and stepType as description (Record Level root cause) Dashboard L2:: Widget 8 : Root
	 * Cause Analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@GetMapping (path = { "/rootCause/{startDate}/{endDate}/{workflowType}", "/rootCause/{startDate}/{endDate}/{workflowType}/{projectName}", "/rootCause/{startDate}/{endDate}/{workflowType}/{projectName}/{workflowName}" })
	List<
					RootCauseAnalysisTable> rootCauseTable(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName, @PathVariable (required = false) String workflowName) {
		try{

			return jobinfoService.failureAnalysisRootCauseAnalysisTable(startDate, endDate, workflowType, projectName, workflowName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * Gets the source and file name.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the source and file name
	 */
	/**
	 * This Controller return all Workflow Name and sourceFiles within given Date Range and project name Dashboard L2:: Widget 6 : Failure Records
	 * Analysis by Source / File
	 * 
	 * @param startDate
	 * @param endDate
	 * @param workflowType
	 * @param projectName
	 * @return
	 */
	@GetMapping (path = { "/sourceandfile/{startDate}/{endDate}/{workflowType}", "/sourceandfile/{startDate}/{endDate}/{workflowType}/{projectName}" })
	List<
					FailureAnalysisWithSourceAndFile> getSourceAndFileName(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{
			return jobinfoService.sourceFilesGroupByWorkflowName(startDate, endDate, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This Controller return Average execution time per sec with Source name Dashboard L3:: Widget 10 : Processing Time.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the execution time with source
	 */
	@GetMapping (path = { "/timewithsource/{startDate}/{endDate}/{workflowType}", "/timewithsource/{startDate}/{endDate}/{workflowType}/{projectName}" })
	List<ExecutionTimePerSource> getExecutionTimeWithSource(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{
			return jobinfoService.executionTimeWithSource(startDate, endDate, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This controller will return File Failed Reason and count, if the file is failed within given date range. Also we can find failed file reason
	 * using ProjectName and WorkflowName.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@GetMapping (path = { "/failedFiles/{startDate}/{endDate}/{workflowType}", "/failedFiles/{startDate}/{endDate}/{workflowType}/{projectName}", "/failedFiles/{startDate}/{endDate}/{workflowType}/{projectName}/{workflowName}" })
	List<
					FailedFiles> failureAnalysisFailedFiles(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName, @PathVariable (required = false) String workflowName) {
		try{

			return jobinfoService.failureAnalysisFailedFiles(startDate, endDate, workflowType, projectName, workflowName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This controller will return count of failed files group by project name. Also we can apply filter as request parameter for 'ProjectName' and
	 * 'errorType'.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorType the error type
	 * @return the list
	 */
	@GetMapping (path = { "/failedFileswithProject/{startDate}/{endDate}/{workflowType}" })
	List<
					FailedFilesWithSource> failureAnalysisFailedFilesAndProjects(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType, @RequestParam (value = "projectName", required = false) String projectName, @RequestParam (value = "errorType", required = false) String errorType) {
		try{
			return jobinfoService.failureAnalysisFailedFilesAndProjects(startDate, endDate, workflowType, projectName, errorType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This will return overview data, like: number of files expected and number of files processed with respect to date and source.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the job info processed data day wise
	 */
	@GetMapping (path = { "/getJobInfodata/{startDate}/{endDate}/{workflowType}", "/getJobInfodata/{startDate}/{endDate}/{workflowType}/{projectName}" })
	List<FileProcessedWithActualFile> getJobInfoProcessedDataDayWise(@PathVariable String startDate, @PathVariable String endDate, @PathVariable String workflowType, @PathVariable (required = false) String projectName) {
		try{

			SimpleDateFormat formatt = new SimpleDateFormat("MMM-dd-yyyy");
			Date startDate1 = formatt.parse(startDate);
			Date endDate1 = formatt.parse(endDate);

			return jobinfoService.getJobInfoProcessedDataDayWise(startDate1, endDate1, workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw new GenericException(e);
		}
	}

	/**
	 * This will return all failed sources for given ProjectName.
	 *
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failed source
	 */
	@GetMapping (path = { "/failedSource/{workflowType}/{projectName}" })
	List<JobInfo> getFailedSource(@PathVariable String workflowType, @PathVariable String projectName) {
		try{
			return jobinfoService.failedSource(workflowType, projectName);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

	/**
	 * This will return all projects executed within given date range.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @return the project within date range
	 */
	@GetMapping (path = { "/getProject/{startDate}/{endDate}/{workflowType}" })
	List<JobInfo> getProjectWithinDateRange(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable String workflowType) {
		try{
			return jobinfoService.projectWithinDateRange(startDate, endDate, workflowType);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw e;
		}
	}

}
