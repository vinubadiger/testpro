package com.opus.optimus.offline.repository.workflow;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Interface WorkflowRepository.
 */
@Repository
public interface WorkflowRepository extends MongoRepository<Workflow, String> {

	/**
	 * Find work flow by project name.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	Workflow findWorkFlowByProjectName(String projectName, String workflowName, String workflowType);

	/**
	 * Find work flow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the workflow
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 } ] }")
	Workflow findWorkFlow(String projectName, String workflowName);

	/**
	 * Find work flow by project name.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, {'workflowType' : ?1} ] }")
	List<Workflow> findWorkFlowByProjectName(String projectName, String workflowType);

	/**
	 * Gets the work flow.
	 *
	 * @param projectName the project name
	 * @return the work flow
	 */
	@Query ("{projectName:'?0'}")
	List<Workflow> getWorkFlow(String projectName);

	/**
	 * Find ETL work flows.
	 *
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Query ("{'workflowType':'?0', stepConfigs : {'$exists': true}}")
	List<Workflow> findETLWorkFlows(String workflowType);

}
