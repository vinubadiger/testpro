package com.opus.optimus.offline.repository.user;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.Login;

/**
 * The Interface LoginRepository.
 */
@Repository
public interface LoginRepository extends MongoRepository<Login, String> {
	
	/**
	 * Find user by user name.
	 *
	 * @param userName the user name
	 * @return the login
	 */
	@Query ("{userName:'?0'}")
	Login findUserByUserName(String userName);

}
