package com.opus.optimus.offline.repository.user;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.Role;

/**
 * The Interface RoleRepository.
 */
@Repository
public interface RoleRepository extends MongoRepository<Role, String> {
	
	/**
	 * Find by role name.
	 *
	 * @param roleName the role name
	 * @return the role
	 */
	@Query ("{roleName:'?0'}")
	Role findByRoleName(String roleName);
}
