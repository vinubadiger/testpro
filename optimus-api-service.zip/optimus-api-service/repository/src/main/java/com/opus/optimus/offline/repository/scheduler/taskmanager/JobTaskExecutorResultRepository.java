package com.opus.optimus.offline.repository.scheduler.taskmanager;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

/**
 * The Interface JobTaskExecutorResultRepository.
 */
@Repository
public interface JobTaskExecutorResultRepository extends MongoRepository<JobTaskExecutorResult, String> {

	/**
	 * Find all job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the list
	 */
	@Query ("{'jobId':'?0'}")
	List<JobTaskExecutorResult> findAllJobTaskExecutorResultbyId(String jobId);

	/**
	 * Find by ids.
	 *
	 * @param jobInfoIdList the job info id list
	 * @return the list
	 */
	@Query ("{'jobId': { $in: ?0 } })")
	List<JobTaskExecutorResult> findByIds(List<String> jobInfoIdList);
}
