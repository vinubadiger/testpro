package com.opus.optimus.offline.repository.workflow;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.project.Project;

/**
 * The Interface ProjectRepository.
 */
@Repository
public interface ProjectRepository extends MongoRepository<Project, String> {

	/**
	 * Find project by project name.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	@Query ("{projectName:'?0'}")
	Project findProjectByProjectName(String projectName);
}
