package com.opus.optimus.offline.repository.workflow;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;

/**
 * The Interface DataSourceRepository.
 */
@Repository
public interface DataSourceRepository extends MongoRepository<MongoDataSourceMeta, String> {

	/**
	 * Find by data source.
	 *
	 * @param datasourceName the datasource name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	@Query (value = "{ $and: [ { 'dataSourceName' : ?0 }, { 'databaseType' : ?1 } ] }")
	MongoDataSourceMeta findByDataSource(String datasourceName, String databaseType);

	/**
	 * Find bydatabase type like.
	 *
	 * @param databaseType the database type
	 * @return the list
	 */
	@Query (value = "{ 'databaseType' : ?0 }", fields = "{ 'dataSourceName' : 1, 'databaseType' : 1}")
	List<MongoDataSourceMeta> findBydatabaseTypeLike(String databaseType);

	/**
	 * Find bydatabase type like.
	 *
	 * @param databaseType the database type
	 * @param dataSourceName the data source name
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'databaseType' : ?0 }, { 'dataSourceName' : ?1 } ] }", fields = "{ 'dataSourceName' : 1, 'databaseType' : 1, 'collections' : 1}")
	List<MongoDataSourceMeta> findBydatabaseTypeLike(String databaseType, String dataSourceName);

}
