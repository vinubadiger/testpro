package com.opus.optimus.offline.repository.recon;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.recon.Activity;

// TODO: Auto-generated Javadoc
/**
 * The Interface ReconWorkflowRepository.
 */
@Repository
public interface ReconWorkflowRepository extends MongoRepository<Activity, String> {

	/**
	 * Find recon source.
	 *
	 * @param projectName the project name
	 * @param name the name
	 * @param workflowType the workflow type
	 * @return the activity
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'name' : ?1 },{'workflowType' : ?2} ] }")
	Activity findReconSource(String projectName, String name, String workflowType);

	/**
	 * Gets the all.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the all
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, {'workflowType' : ?1} ] }")
	List<Activity> getAll(String projectName, String workflowType);

	/**
	 * Gets the activity.
	 *
	 * @return the activity
	 */
	@Query (value = "{}", fields = "{'name':1,'projectName':1,'dbReaderSteps.sourceDefinition.sourceName':1,'dbReaderSteps.stepName':1}")
	List<Activity> getActivity();
	
	/**
	 * 
	 * @param name
	 * @param workflowType
	 * @return
	 */
	@Query (value = "{ $and: [ { 'name' : ?0 }, {'workflowType' : ?1} ] }")
	Activity get(String name, String workflowType);
}
