package com.opusconsulting.pegasus.formula.codegen;

public class FormulaCodeInfo {
    String className;
    String code;
    CodeMetaData codeMetaData;

    public FormulaCodeInfo(String className, String code, CodeMetaData codeMetaData) {
        this.className = className;
        this.code = code;
        this.codeMetaData = codeMetaData;
    }

    public String getClassName() {
        return className;
    }

    public String getCode() {
        return code;
    }

    public CodeMetaData getCodeMetaData() {
        return codeMetaData;
    }
}
