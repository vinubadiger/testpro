package com.opusconsulting.pegasus.formula.codegen.impl;

import com.opusconsulting.pegasus.formula.codegen.INameGenerator;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

@Component
public class NameGenerator implements INameGenerator {
    AtomicInteger current = new AtomicInteger(0);

    @Override
    public String getNewName() {
        int value = current.incrementAndGet();
        return "NG" + value;
    }
}
