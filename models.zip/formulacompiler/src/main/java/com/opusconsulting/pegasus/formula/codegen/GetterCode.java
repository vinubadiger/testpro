package com.opusconsulting.pegasus.formula.codegen;

import java.util.List;

public class GetterCode {
    List<String> importClasses;
    String code;
    List<String> embeddedCodeBlock;

    public List<String> getImportClasses() {
        return importClasses;
    }

    public void setImportClasses(List<String> importClasses) {
        this.importClasses = importClasses;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<String> getEmbeddedCodeBlock() {
        return embeddedCodeBlock;
    }

    public void setEmbeddedCodeBlock(List<String> embeddedCodeBlock) {
        this.embeddedCodeBlock = embeddedCodeBlock;
    }
}