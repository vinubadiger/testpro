package com.opusconsulting.pegasus.formula.exception;

public interface FormulaExceptionCodes {
	public static final String FORMULA_GENERAL_EXCEPTION = "FRM-GEN-001";
	public static final String FORMULA_COMPILATION_EXCEPTION = "FRM-COM-001";
}
