package com.opusconsulting.pegasus.formula.codegen;

public interface ICodeProvider {
    GetterCode getGetterCode(String names);

    SetterCode getSetterCode(String names);
    
    String getDataClassName();
}