package com.opusconsulting.pegasus.formula;

public interface ICondition {	
    boolean check(IRecord record);
}
