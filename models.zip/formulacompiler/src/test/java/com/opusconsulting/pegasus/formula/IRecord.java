package com.opusconsulting.pegasus.formula;

public interface IRecord {
    int getFieldId(String fieldName);

    <T> T getValue(int fieldId);

    <T> void setValue(int fieldId, T value);

    boolean fieldExists(int fieldId);
}
