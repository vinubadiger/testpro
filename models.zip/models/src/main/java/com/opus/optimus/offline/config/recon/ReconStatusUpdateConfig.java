package com.opus.optimus.offline.config.recon;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.recon.subtypes.SummaryField;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ReconStatusUpdateConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;

	@NonNull
	private String stepName;
	private String stepType;
	private String activityName;
	private String label;
	
	// Summary Fields
	@NonNull
	private SummaryField sourceA;
	@NonNull
	private SummaryField sourceB;

	@Override
	@JsonGetter ("stepType")
	public String getStepType() {
		return StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE;
	}
}
