package com.opus.optimus.offline.config.recon.subtypes;

public enum ReconSubStatus {
    Exact,
    MatchWithinTolerance,
    MatchBeyondTolerance,
    Aged,
    MultipleMatches,
    ForceMatch,
    Default  //open/pending/new
}
