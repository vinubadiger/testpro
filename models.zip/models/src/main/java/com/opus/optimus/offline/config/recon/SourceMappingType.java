package com.opus.optimus.offline.config.recon;

public enum SourceMappingType {
        OneToOne, OneToMany, ManyToOne, ManyToMany
    }

