package com.opus.optimus.offline.config.validator;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class ValidatorConfig {
	private String name;
	private IScriptConfig scriptConfig;
	private String errorDesc;

}
