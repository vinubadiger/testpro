package com.opus.optimus.offline.config.field.impl;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class MongoDBFieldConfig implements IFieldConfig {

	private short fieldIndex;
	private String name;
	private FieldType type;

	// for date, datetime
	private String format;

	private int maxSize;

	// isImpliedDecimal
	private boolean implicitDecimal;

	private short noOfDecimals; // 1, 2, 3, 4; default is 2

	private String recordFieldName; // TODO need to discuss
	// private String type;

	private boolean primaryField;
	
	
	private String sourceFieldName;
	private String targetFieldName;
	private FieldType sourceDataType;
	private FieldType targetDataType;

}
