package com.opus.optimus.offline.config.recon.subtypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor 
@AllArgsConstructor
public class AndClause {
	SourceField lhsField;
	Operator operator;
	SourceField rhsField;
}
