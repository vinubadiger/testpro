package com.opus.optimus.offline.config.casemanagement;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@Document
@NoArgsConstructor
public class CaseResponse {
	String access_token;

	String instance_url;

	String id;

	String token_type;

	String issued_at;

	String signature;
}
