package com.opus.optimus.offline.config.reader;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class ExcelReaderConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	public static final String EXCEL_READER_STEPTYPE = StepTypeConstants.EXCEL_READER_STEPTYPE;

	@NonNull
	private String name;

	private String label;

	private String charEncoding;

	private String layoutDefinition;

	private int topRowsToSkip;

	private int noOfHeaderRecs;

	private boolean processAllSheets;

	private String sheetsToProcess[];

	private String stepType;

	private Map<String, String> sectionDetails;

	private Map<String, ExcelRecordExtractorConfig> recordExtractorConfig;

	boolean multipleSection;

	boolean columnHeader;

	@Override
	@JsonSetter("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	@JsonGetter("stepType")
	public String getStepType() {
		return EXCEL_READER_STEPTYPE;
	}
}
