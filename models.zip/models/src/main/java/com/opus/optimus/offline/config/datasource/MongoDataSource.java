package com.opus.optimus.offline.config.datasource;

import java.util.List;
import java.util.stream.Collectors;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class MongoDataSource implements IDataSource {
	
	private MongoClient mongoClient;
	
	@NonNull
	private MongoDataSourceMeta dataSourceMetaData; 
	
	public void init() {
		  final List<ServerAddress> serverAddresses = dataSourceMetaData.getAddressMetadatas().stream().map(addressMetaData -> {
			  return new ServerAddress(addressMetaData.getIpAddress(), addressMetaData.getPort());
		  }).collect(Collectors.toList());
		  
		  final MongoClientOptions mongoClientOptions = MongoClientOptions.builder().applicationName("MongoDBWriter").build();
		  
		  if(!dataSourceMetaData.isAuthenticationRequired()) {
			  mongoClient = new MongoClient(serverAddresses, mongoClientOptions);
		  } else {
			  MongoCredential credential = MongoCredential.createScramSha1Credential(dataSourceMetaData.getAuthMetaData().getUserName(), dataSourceMetaData.getDatabaseName(), dataSourceMetaData.getAuthMetaData().getPassword().toCharArray());
			  mongoClient = new MongoClient(serverAddresses, credential, mongoClientOptions);
			
		  }
	}
	
	public MongoDatabase getDatabase() throws DataSourceInitializationException {
		if(this.mongoClient == null)
			throw new DataSourceInitializationException("Failed to initialize the datasource. Please check the configuration/logs.");
		return this.mongoClient.getDatabase(dataSourceMetaData.getDatabaseName());
	}
	
	public MongoClient getMongoClient() {
		return mongoClient;
	}
	
}
