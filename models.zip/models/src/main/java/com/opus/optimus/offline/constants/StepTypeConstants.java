package com.opus.optimus.offline.constants;

public final class StepTypeConstants {

	private StepTypeConstants() {
	}

	public static final String ReconWorkflowType = "RECON";
	public static final String ETLWorkflowType = "ETL";

	public static final String FILE_READER_STEPTYPE = "FileReader";
	public static final String EXCEL_READER_STEPTYPE = "ExcelReader";
	public static final String MONGODB_WRITER_STEPTYPE = "MongoDBWriter";
	public static final String VALIDATOR_STEPTYPE = "Validator";
	public static final String TRANSFORMER_STEPTYPE = "Transformer";
	public static final String DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE = "DefaultGlobalErrorHandler";
	public static final String SALESFORCE_CASE_CREATOR = "SalesForceCase";

	public static final String RECON_CONFIG_STEP = "ReconciliationConfig";
	public static final String MONGO_DBREADER_STEP_TYPE = "MongoDBReader";
	public static final String RECONSTATUSUPDATE_STEPTYPE = "ReconStatusUpdate";
	public static final String RECONCASECREATION_STEPTYPE = "ReconCaseCreation";

}