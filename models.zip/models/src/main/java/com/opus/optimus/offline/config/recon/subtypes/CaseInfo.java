package com.opus.optimus.offline.config.recon.subtypes;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CaseInfo {

    public enum CaseStatus {
        OPEN, CLOSED
    }
	
	private String caseID;
	private CaseStatus status;
	private String comment;
	private Date closureDate;
}
