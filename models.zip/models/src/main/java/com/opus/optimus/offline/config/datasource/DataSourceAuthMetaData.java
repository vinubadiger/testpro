package com.opus.optimus.offline.config.datasource;

import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.offline.constants.AnnotationConstants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class DataSourceAuthMetaData {
	
	@Field (AnnotationConstants.DATABASE_USERNAME)
	private String userName;
	
	@Field (AnnotationConstants.DATABASE_PWORD)
	private String password;
}
