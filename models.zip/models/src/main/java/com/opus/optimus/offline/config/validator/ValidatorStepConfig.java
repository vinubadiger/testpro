package com.opus.optimus.offline.config.validator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
@Builder
@Data
public class ValidatorStepConfig implements IStepConfig {

	public static final String VALIDATOR_STEPTYPE = StepTypeConstants.VALIDATOR_STEPTYPE;

	@NonNull
	private String name;
	private String sectionName;
	private String lable;
	private List<ValidatorConfig> validators;
	private String stepType;

	@Override
	@JsonSetter("stepName")
	public String getStepType() {
		return VALIDATOR_STEPTYPE;
	}

	@Override
	public String getStepName() {
		return name;
	}

}
