package com.opus.optimus.offline.config.recon.subtypes;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReconControlInfo {
	private String activityName;
	private String jobId;
	private ReconStatus status;
	private ReconSubStatus subStatus;
	private String ruleId;
	private double amount;
	private double tolerance;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date processingDate;
	private CaseInfo caseInfo;
	private Map<String, String> supportingData;
	private Map<String, List<String>> relatedRecords;
	private String updatedBy;
	private String updatedRemark;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updatedDate;
}
