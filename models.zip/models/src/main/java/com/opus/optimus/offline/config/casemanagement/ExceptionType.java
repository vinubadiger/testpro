package com.opus.optimus.offline.config.casemanagement;

/**
 * The Enum for set ExceptionType.
 *
 * @author Yashkumar.Thakur
 */
public enum ExceptionType {

	/** The fatal. */
	FATAL,
	/** The error. */
	ERROR

}
