package com.opus.optimus.offline.config.reader;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
@Builder
@Data
public class TextFileReaderConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	public static final String FILE_READER_STEPTYPE = StepTypeConstants.FILE_READER_STEPTYPE;

	@NonNull
	private String name;

	private String charEncoding;

	private String label;

	private String layoutDefinition;

	private String stepType;

	@JsonProperty("recordExtractorConfig")
	private ITextRecordExtractorConfig recordExtractorConfig;

	private Map<String, IScriptConfig> sectionDetails;

	private Map<String, ITextFieldExtractorConfig> fieldExtractorConfig;

	@Override
	@JsonSetter("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	@JsonGetter("stepType")
	public String getStepType() {
		return FILE_READER_STEPTYPE;
	}
}
