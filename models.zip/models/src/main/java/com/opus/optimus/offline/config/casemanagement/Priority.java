package com.opus.optimus.offline.config.casemanagement;

/**
 * The Enum for set Priority.
 *
 * @author Yashkumar.Thakur
 */
public enum Priority {

	/** The high. */
	HIGH,
	/** The medium. */
	MEDIUM,
	/** The low. */
	LOW
}
