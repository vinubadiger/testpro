package com.opus.optimus.offline.runtime.common.api.record

import com.opus.optimus.offline.runtime.common.api.record.impl.Schema
import org.codehaus.groovy.runtime.metaclass.MethodSelectionException
import org.spockframework.util.Pair
import spock.lang.Specification

class SchemaSpecification extends Specification {

    def "Direct schema creation check"() {
        when: "flat schema created"
        def schema = new Schema()

        then: "schema should be created only using builder"
        thrown MethodSelectionException
    }

    def "Flat schema creation"() {
        setup: "Data setup"
        def fields = [
                Pair.of("boolean_0", FieldType.BOOLEAN),
                Pair.of("string_1", FieldType.STRING),
                Pair.of("bytes_2", FieldType.BYTES),
                Pair.of("int_3", FieldType.INT),
                Pair.of("long_4", FieldType.LONG),
                Pair.of("float_5", FieldType.FLOAT),
                Pair.of("double_6", FieldType.DOUBLE),
                Pair.of("datetime_7", FieldType.DATETIME)
        ]

        when: "flat schema created"
        def schema = SchemaUtil.instance.createSchema("Simple", fields)

        then: "schema should be created"
        schema != null
        schema.name == "Simple"
        schema.getFields().size() == fields.size()

        fields.eachWithIndex { item, index ->
            assert item.first() == schema.getFields().get(index).getName()
            assert item.second() == schema.getFields().get(index).getType()
        }
    }

    def "Structured schema creation"() {
        setup: "Data setup"
        def innerObjectFields = [
                Pair.of("boolean_0", FieldType.BOOLEAN),
                Pair.of("long_1", FieldType.LONG)
        ]
        def fields = [
                Pair.of("string_0", FieldType.STRING),
                Pair.of("array_string_1", Pair.of(true, FieldType.STRING)),
                Pair.of("object_2", Pair.of(false, innerObjectFields)),
                Pair.of("array_object_3", Pair.of(true, innerObjectFields))
        ]

        when: "flat schema created"
        def schema = SchemaUtil.instance.createSchema("Simple", fields)

        then: "schema should be created"
        schema != null
        schema.name == "Simple"
        schema.getFields().size() == fields.size()

        // String type
        def string_0 = schema.getFields().get(0)
        string_0.getName() == "string_0"
        string_0.getType() == FieldType.STRING
        string_0.getCollectionOrRecordSchema() == null
        string_0.getCollectionType() == null

        // String[] type
        def array_string_1 = schema.getFields().get(1)
        array_string_1.getName() == "array_string_1"
        array_string_1.getType() == FieldType.ARRAY
        array_string_1.getCollectionOrRecordSchema() == null
        array_string_1.getCollectionType() == FieldType.STRING

        // Record type
        def object_2 = schema.getFields().get(2)
        object_2.getName() == "object_2"
        object_2.getType() == FieldType.RECORD
        object_2.getCollectionOrRecordSchema() != null
        object_2.getCollectionType() == null
        object_2.getCollectionOrRecordSchema().getFields().size() == 2

        // Record[] type
        def array_object_3 = schema.getFields().get(3)
        array_object_3.getName() == "array_object_3"
        array_object_3.getType() == FieldType.ARRAY
        array_object_3.getCollectionOrRecordSchema() != null
        array_object_3.getCollectionType() == FieldType.RECORD
        array_object_3.getCollectionOrRecordSchema().getFields().size() == 2
    }
}
