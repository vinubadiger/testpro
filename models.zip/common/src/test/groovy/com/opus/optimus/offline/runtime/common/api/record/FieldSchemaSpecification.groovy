package com.opus.optimus.offline.runtime.common.api.record

import com.opus.optimus.offline.runtime.common.api.record.impl.FieldSchema
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema
import spock.lang.Specification
import spock.lang.Unroll

class FieldSchemaSpecification extends Specification {
    final static def DUMMY_NAME = "dummy"

    @Unroll
    def "Primitive type creation #fieldType"() {
        when:
        def fieldSchema = new FieldSchema(fieldName, fieldType)

        then:
        notThrown IllegalArgumentException
        fieldSchema.getName() == fieldName
        fieldSchema.getType() == fieldType
        fieldSchema.getCollectionType() == null
        fieldSchema.getCollectionOrRecordSchema() == null

        where:
        fieldName  | fieldType
        DUMMY_NAME | FieldType.STRING
        DUMMY_NAME | FieldType.BYTES
        DUMMY_NAME | FieldType.INT
        DUMMY_NAME | FieldType.LONG
        DUMMY_NAME | FieldType.FLOAT
        DUMMY_NAME | FieldType.DOUBLE
        DUMMY_NAME | FieldType.BOOLEAN
        DUMMY_NAME | FieldType.DATETIME
    }

    @Unroll
    def "IllegalArgument for primitive constructor"() {
        when:
        new FieldSchema(fieldName, fieldType)

        then:
        thrown IllegalArgumentException

        where:
        fieldName  | fieldType
        DUMMY_NAME | FieldType.RECORD
        DUMMY_NAME | FieldType.ARRAY
    }

    def "Record type creation"() {
        when:
        def fieldSchema = new FieldSchema(DUMMY_NAME, new Schema.Builder().name("record").build())

        then:
        notThrown IllegalArgumentException
        fieldSchema.getName() == DUMMY_NAME
        fieldSchema.getType() == FieldType.RECORD
        fieldSchema.getCollectionType() == null
        fieldSchema.getCollectionOrRecordSchema() != null
    }

    @Unroll
    def "Collection Primitive type creation #fieldType"() {
        when:
        def fieldSchema = new FieldSchema(fieldName, true, fieldType)

        then:
        notThrown IllegalArgumentException
        fieldSchema.getName() == fieldName
        fieldSchema.getType() == FieldType.ARRAY
        fieldSchema.getCollectionType() == fieldType
        fieldSchema.getCollectionOrRecordSchema() == null

        where:
        fieldName  | fieldType
        DUMMY_NAME | FieldType.STRING
        DUMMY_NAME | FieldType.BYTES
        DUMMY_NAME | FieldType.INT
        DUMMY_NAME | FieldType.LONG
        DUMMY_NAME | FieldType.FLOAT
        DUMMY_NAME | FieldType.DOUBLE
        DUMMY_NAME | FieldType.BOOLEAN
        DUMMY_NAME | FieldType.DATETIME
    }

    @Unroll
    def "IllegalArgument for collection/non-collection primitive constructor - Collection(#isCollection) FieldType(#fieldType)"() {
        when:
        new FieldSchema(fieldName, isCollection, fieldType)

        then:
        thrown IllegalArgumentException

        where:
        fieldName  | isCollection | fieldType
        DUMMY_NAME | true         | FieldType.RECORD
        DUMMY_NAME | true         | FieldType.ARRAY
        DUMMY_NAME | false        | FieldType.RECORD
        DUMMY_NAME | false        | FieldType.ARRAY
    }

    def "Collection of record type creation"() {
        when:
        def fieldSchema = new FieldSchema(DUMMY_NAME, true, new Schema.Builder().name("record").build())

        then:
        notThrown IllegalArgumentException
        fieldSchema.getName() == DUMMY_NAME
        fieldSchema.getType() == FieldType.ARRAY
        fieldSchema.getCollectionType() == FieldType.RECORD
        fieldSchema.getCollectionOrRecordSchema() != null
    }

    def "Non-collection record type creation"() {
        when:
        def fieldSchema = new FieldSchema(DUMMY_NAME, false, new Schema.Builder().name("record").build())

        then:
        notThrown IllegalArgumentException
        fieldSchema.getName() == DUMMY_NAME
        fieldSchema.getType() == FieldType.RECORD
        fieldSchema.getCollectionType() == null
        fieldSchema.getCollectionOrRecordSchema() != null
    }

}
