package com.opus.optimus.offline.runtime.common.api.datasource.exception;

/**
 * The Class DataSourceInitializationException.
 */
public class DataSourceInitializationException extends Exception {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3066922081397685177L;

	/**
	 * Instantiates a new data source initialization exception.
	 *
	 * @param message - The exception message
	 */
	public DataSourceInitializationException(String message) {
		super(message);
	}
}
