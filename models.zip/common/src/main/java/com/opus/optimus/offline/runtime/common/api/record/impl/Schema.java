package com.opus.optimus.offline.runtime.common.api.record.impl;

import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.eclipse.collections.api.list.ImmutableList;
import org.eclipse.collections.impl.factory.Lists;

import java.util.ArrayList;
import java.util.List;



/**
 * Instantiates a new schema.
 *
 * @param name - The field name
 * @param fields the fields
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Schema implements ISchema {
    
    /** The name. */
    String name;
    
    /** The fields. */
    ImmutableList<IFieldSchema> fields;
        
    /**
     * Builder.
     *
     * @return the builder
     */
    public static Builder builder() {
    	return new Builder();
    }
    
    /**
     * The Class Builder.
     */
    public static class Builder {
        
        /** The name. */
        String name;
        
        /** The fields. */
        List<IFieldSchema> fields = new ArrayList<>();

        /**
         * 
         * Instantiates a new builder.
         */
        public Builder() {}
        
        /**
         * Name.
         *
         * @param name the name
         * @return the builder
         */
        public Builder name(String name) {
            this.name = name;
            return this;
        }

        /**
         * Adds the field.
         *
         * @param fieldSchema the field schema
         * @return the builder
         */
        public Builder addField(IFieldSchema fieldSchema) {
            fields.add(fieldSchema);
            return this;
        }

        /**
         * Builds the.
         *
         * @return the schema
         */
        public Schema build() {
            return new Schema(this.name, Lists.immutable.withAll(fields));
        }
    }
}
