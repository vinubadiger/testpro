// Generated from D:\MY_Work\Recon\Backend\opus-optimus-runtime\excelformulaParser\src\main\antlr\ExcelFormula.g4 by ANTLR 4.2.2
package com.opusconsulting.optimus.core.excelgrammer.antlr4.parser;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ExcelFormulaParser}.
 */
public interface ExcelFormulaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(@NotNull ExcelFormulaParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(@NotNull ExcelFormulaParser.ExpressionContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#constant}.
	 * @param ctx the parse tree
	 */
	void enterConstant(@NotNull ExcelFormulaParser.ConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#constant}.
	 * @param ctx the parse tree
	 */
	void exitConstant(@NotNull ExcelFormulaParser.ConstantContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#stringConstant}.
	 * @param ctx the parse tree
	 */
	void enterStringConstant(@NotNull ExcelFormulaParser.StringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#stringConstant}.
	 * @param ctx the parse tree
	 */
	void exitStringConstant(@NotNull ExcelFormulaParser.StringConstantContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(@NotNull ExcelFormulaParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(@NotNull ExcelFormulaParser.FunctionContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#variable}.
	 * @param ctx the parse tree
	 */
	void enterVariable(@NotNull ExcelFormulaParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#variable}.
	 * @param ctx the parse tree
	 */
	void exitVariable(@NotNull ExcelFormulaParser.VariableContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#model}.
	 * @param ctx the parse tree
	 */
	void enterModel(@NotNull ExcelFormulaParser.ModelContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#model}.
	 * @param ctx the parse tree
	 */
	void exitModel(@NotNull ExcelFormulaParser.ModelContext ctx);

	/**
	 * Enter a parse tree produced by {@link ExcelFormulaParser#numberConstant}.
	 * @param ctx the parse tree
	 */
	void enterNumberConstant(@NotNull ExcelFormulaParser.NumberConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link ExcelFormulaParser#numberConstant}.
	 * @param ctx the parse tree
	 */
	void exitNumberConstant(@NotNull ExcelFormulaParser.NumberConstantContext ctx);
}