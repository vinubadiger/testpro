package com.opusconsulting.optimus.core.excelgrammer.visitor;

import java.util.List;
import java.util.stream.Collectors;

import com.opusconsulting.optimus.core.excelformula.models.Expression;
import com.opusconsulting.optimus.core.excelformula.models.Function;
import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.optimus.core.excelformula.models.NumberConstant;
import com.opusconsulting.optimus.core.excelformula.models.StringConstant;
import com.opusconsulting.optimus.core.excelformula.models.Variable;

import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaBaseVisitor;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.ConstantContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.ExpressionContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.FunctionContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.ModelContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.NumberConstantContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.StringConstantContext;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.VariableContext;

public class VisitorImpl extends ExcelFormulaBaseVisitor<Model>{

	@Override
	public Model visitModel(ModelContext ctx) {
		//Model expr = super.visitModel(ctx);
		Model expr = ctx.expression().accept(this);
		Model model = new Model();
		model.setExpression((Expression)expr);
		return model;
	}
	
	@Override
	public Model visitExpression(ExpressionContext ctx) {
		Model expr = super.visitExpression(ctx);
		return expr;
	}
	
	@Override
	public Model visitConstant(ConstantContext ctx) {
		Model expr = super.visitConstant(ctx);
		return expr;
	}
	
	@Override
	public Model visitFunction(FunctionContext ctx) {
		Function func = new Function();
		func.setName(ctx.name.getText());
		@SuppressWarnings("unchecked")
		List<Expression> params = (List<Expression>)(Object)ctx.expression()
			.stream()
			.map(exprCtx -> exprCtx.accept(this))
			.collect(Collectors.toList());
		func.setParams(params);
		return func;
	}
	
	@Override
	public Model visitNumberConstant(NumberConstantContext ctx) {
		NumberConstant numberConst = new NumberConstant();
		numberConst.setInteger(ctx.integer.getText());
		if (ctx.fraction != null) {
			numberConst.setFraction(ctx.fraction.getText());			
		}
		numberConst.setText(ctx.getText());
		return numberConst;
	}
	
	@Override
	public Model visitStringConstant(StringConstantContext ctx) {
		StringConstant strConstant = new StringConstant();
		strConstant.setValue(ctx.getText());
		strConstant.setText(ctx.getText());
		return strConstant;
	}	

	@Override
	public Model visitVariable(VariableContext ctx) {
		Variable var = new Variable();
		var.setName(ctx.name.getText());
		var.setText(ctx.getText());
		return var;
	}
}
