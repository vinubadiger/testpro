package com.opusconsulting.optimus.core.excelformula.models;

public class StringConstant extends Constant {
	private String value;
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
