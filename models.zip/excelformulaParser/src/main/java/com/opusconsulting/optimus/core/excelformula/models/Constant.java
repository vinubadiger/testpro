package com.opusconsulting.optimus.core.excelformula.models;

public abstract class Constant extends Expression {	
	
	public Constant() {
		super.setType(ExpressionType.Constant);
	}	
}
