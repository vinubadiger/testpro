package com.opusconsulting.optimus.core.excelformula.models;

public abstract class Expression extends Model {
	private ExpressionType type;
	private String text;
	
	public ExpressionType getType() {
		return type;
	}
	protected void setType(ExpressionType type) {
		this.type = type;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}	
}
