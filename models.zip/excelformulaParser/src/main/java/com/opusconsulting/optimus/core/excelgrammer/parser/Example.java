package com.opusconsulting.optimus.core.excelgrammer.parser;

import java.io.IOException;

import com.opusconsulting.optimus.core.excelformula.models.Function;
import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.optimus.core.excelformula.models.NumberConstant;
import com.opusconsulting.optimus.core.excelformula.models.StringConstant;
import com.opusconsulting.optimus.core.excelformula.models.Variable;

public class Example {

    public static void main(String[] args) throws IOException {
        ParserFacade parserFacade = new ParserFacade();
        //AstPrinter astPrinter = new AstPrinter();
        Model mdl = parserFacade.parse("123.00A");
        System.out.println(" Number Constant = " + ((NumberConstant)(mdl.getExpression())).getInteger() + "."
        		+ ((NumberConstant)(mdl.getExpression())).getFraction());
        mdl = parserFacade.parse("123");
        System.out.println(" Number Constant = " + ((NumberConstant)(mdl.getExpression())).getInteger());
        mdl = parserFacade.parse("DEAN");
        System.out.println(" Variable  = " + mdl.getExpression().getType() + " " + ((Variable)(mdl.getExpression())).getName());
        mdl = parserFacade.parse("DE01");
        System.out.println(" Variable  = " + mdl.getExpression().getType() + " " + ((Variable)(mdl.getExpression())).getName());
        mdl = parserFacade.parse("_DEAN");
        System.out.println(" Variable  = " + mdl.getExpression().getType() + " " + ((Variable)(mdl.getExpression())).getName());
        mdl = parserFacade.parse("\"12DE01\"");
        System.out.println(" String Constant  = " + mdl.getExpression().getType() + " " + ((StringConstant)(mdl.getExpression())).getValue());
        mdl = parserFacade.parse("\"123.01\"");
        System.out.println(" String Constant = " + mdl.getExpression().getType() + " " + ((StringConstant)(mdl.getExpression())).getValue());

        mdl = parserFacade.parse("ISSTR(DE01)");
        System.out.println("ISSTR(DE01) Function = " + mdl.getExpression().getType() + " " + ((Function)(mdl.getExpression())).getName() + " & paramSize = " + ((Function)(mdl.getExpression())).getParams().size());
    
        mdl = parserFacade.parse("ISSTR(\"DE01\")");
        System.out.println("ISSTR(\"DE01\") Function = " + mdl.getExpression().getType() + " " + ((Function)(mdl.getExpression())).getName() + " & paramSize = " + ((Function)(mdl.getExpression())).getParams().size());

        mdl = parserFacade.parse("EXACT(DE01, \"T E\")");
        System.out.println("ISSTR(DE01) Function = " + mdl.getExpression().getType() + " " + ((Function)(mdl.getExpression())).getName() + " & paramSize = " + ((Function)(mdl.getExpression())).getParams().size());

        mdl = parserFacade.parse("EXACT(ISSTR(1DE), \"T E\")");
        System.out.println("ISSTR(DE01) Function = " + mdl.getExpression().getType() + " " + ((Function)(mdl.getExpression())).getName() + " & paramSize = " + ((Function)(mdl.getExpression())).getParams().size());
    }
}
