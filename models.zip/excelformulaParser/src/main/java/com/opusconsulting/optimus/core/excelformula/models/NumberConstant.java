package com.opusconsulting.optimus.core.excelformula.models;

public class NumberConstant extends Constant {
	private String integer;
	private String fraction;
	public String getInteger() {
		return integer;
	}
	public void setInteger(String integer) {
		this.integer = integer;
	}
	public String getFraction() {
		return fraction;
	}
	public void setFraction(String fraction) {
		this.fraction = fraction;
	}
}
