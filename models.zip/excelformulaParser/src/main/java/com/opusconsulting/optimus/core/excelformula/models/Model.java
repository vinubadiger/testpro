package com.opusconsulting.optimus.core.excelformula.models;

public class Model {
	private Expression expression;

	public Expression getExpression() {
		return expression;
	}

	public void setExpression(Expression expression) {
		this.expression = expression;
	}
}
