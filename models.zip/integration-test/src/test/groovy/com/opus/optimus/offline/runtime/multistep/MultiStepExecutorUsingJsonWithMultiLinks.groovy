package com.opus.optimus.offline.runtime.multistep

import java.util.concurrent.TimeoutException

import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodProcess
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Shared
import spock.lang.Specification

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class MultiStepExecutorUsingJsonWithMultiLinks extends Specification {

	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	MapperFactory mapperFactory

	@Shared
	MongodExecutable mongodExecutable;
	@Shared
	MongodProcess mongod;
	@Shared
	def dbHostIP = "localhost";
	@Shared
	def dbPort = 27017;
	@Shared
	def databaseName = "local";//"samsonDb";
	@Shared
	def collectionNameHeader = "Header";
	@Shared
	def collectionNameData = "Data";

	@Shared
	MongoClient mongo;
	@Shared
	MongoDatabase mongoDataBase;
	@Shared
	MongoDataSource mongoDataSource;

	def setupSpec() {
		MongodStarter starter = MongodStarter.getDefaultInstance();
		IMongodConfig mongodConfig = new MongodConfigBuilder()
				.version(Version.Main.DEVELOPMENT)
				.net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
				.build();
		mongodExecutable = starter.prepare(mongodConfig);
		mongod = mongodExecutable.start();
		mongo = new MongoClient(dbHostIP, dbPort);
		mongoDataBase = mongo.getDatabase(databaseName);
	}

	def "Reader - Writter multistep execution using JSON"() {
		setup:
		def Reader = "Source"
		def MongoDBWriterHeader = "DB"
		def MongoDBWriterData = "Database"

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		mongoDataSource.init();

		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		jsonStream = getClass().getResourceAsStream("/MultiStepJsonWithLinks.json")
		def workflowConfig = mapper.readValue(jsonStream, WorkflowConfig.class)

		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFileForLinks.csv").getFile())

		String inputFileLocation = "./src/test/resources/testFileForLinks.csv";

		when:
		def result = localJobTaskExecutor.execute()

		def emitter = localJobTaskExecutor.getInBoundQueue(Reader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove

		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)

		//		For DB Header
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterHeader).get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 2
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionNameHeader);
		Document searchDocument = new Document();
		searchDocument.append("NO", 111);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		println("record count: " + resultCollection.count());
		receivedData.size() == resultCollection.count()

		println jobTaskExecutorResult

		// For DB Data
		def receiver1 = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterData).get(0).getReceiver()
		def receivedData1 = ReceiverUtil.collectDataFromReceiver(receiver1)
		receivedData1.size() == 8
		MongoCollection<Document> resultCollection1 = mongoDataBase.getCollection(collectionNameData);
		Document searchDocument1 = new Document();
		searchDocument1.append("NO", 4);
		println("Document Filter: " + searchDocument1);
		Document searchResult1 = resultCollection1.find(searchDocument1).first();
		println("Document Found: " + searchResult1);
		println("record count: " + resultCollection1.count());
		receivedData1.size() == resultCollection1.count()

		println jobTaskExecutorResult


	}

	def cleanupSpec() {
		if (mongo != null)
			mongo.close()
		if (mongod != null) {
			mongod.deleteTempFiles();
			mongod.stop();
		}
		if (mongodExecutable) {
			mongodExecutable.stop();
		}

	}

}