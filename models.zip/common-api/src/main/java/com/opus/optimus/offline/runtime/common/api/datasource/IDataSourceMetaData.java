package com.opus.optimus.offline.runtime.common.api.datasource;

/**
 * The Interface IDataSourceMetaData.
 */
public interface IDataSourceMetaData {
	
}
