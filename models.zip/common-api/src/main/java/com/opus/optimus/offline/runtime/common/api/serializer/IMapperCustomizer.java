package com.opus.optimus.offline.runtime.common.api.serializer;

/**
 * The Interface IMapperCustomizer.
 *
 * @param <T> the generic type
 */
@FunctionalInterface
public interface IMapperCustomizer<T> {
    
    /**
     * Customize.
     *
     * @param data the data
     */
    void customize(T data);
}
