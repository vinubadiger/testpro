package com.opus.optimus.offline.runtime.step.reconciliation;

public interface IKeyIdentifier<T> {
    String getKey(T data);
}
