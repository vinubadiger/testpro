package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.config.recon.subtypes.AndClause;
import com.opus.optimus.offline.config.recon.subtypes.OrClause;
import com.opus.optimus.offline.config.recon.subtypes.SourceField;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReconKeyIdentifier implements IKeyIdentifier<IMessage> {
    static final Logger logger = LoggerFactory.getLogger(ReconKeyIdentifier.class);
    private static final String SOURCE_FIELD_LHS_FILED_IND = "LHS";
    private static final String SOURCE_FIELD_RHS_FILED_IND = "RHS";

    private ScriptCreatorFactory scriptCreatorFactory;

    OrClause matchingClause;

    final Map<String, IScript<IRecord, ?>> andClauseFieldScripts = new HashMap<>();

    public ReconKeyIdentifier(OrClause matchingClause) {
        super();
        this.matchingClause = matchingClause;
        this.scriptCreatorFactory = BeanHelper.getScriptCreatorFactory();
        init();
    }

    private void init() {
        IntStream.range(0, this.matchingClause.getAndClauses().size()).forEach(andClauseIndex -> {
            createAndLoadFieldScript(andClauseIndex, SOURCE_FIELD_LHS_FILED_IND,
                    this.matchingClause.getAndClauses().get(andClauseIndex).getLhsField().getFormulaConfig());
            createAndLoadFieldScript(andClauseIndex, SOURCE_FIELD_RHS_FILED_IND,
                    this.matchingClause.getAndClauses().get(andClauseIndex).getRhsField().getFormulaConfig());
        });
    }

    /**
     * This method is used to create and load the field script.
     * @param andClauseIndex
     * @param fieldIndicatorKey
     * @param scriptConfig
     */
    private void createAndLoadFieldScript(int andClauseIndex, String fieldIndicatorKey, IScriptConfig scriptConfig) {
        IScript<IRecord, ?> lhsScript = scriptCreatorFactory.createScript(scriptConfig);
        andClauseFieldScripts.put(buildFieldScriptMapKey(fieldIndicatorKey, andClauseIndex), lhsScript);
    }

    /**
     * This method is used to build the field script map key.
     * @param fieldIndicatorKey
     * @param andClauseIndex
     * @return String
     */
    private String buildFieldScriptMapKey(String fieldIndicatorKey, int andClauseIndex) {
        final StringBuilder mapKeyBuilder = new StringBuilder();
        mapKeyBuilder.append(andClauseIndex);
        mapKeyBuilder.append("_");
        mapKeyBuilder.append(fieldIndicatorKey);
        return mapKeyBuilder.toString();
    }

    @Override
    public String getKey(IMessage message) {
    	if(message.getData() == null || !IRecord.class.isAssignableFrom(message.getData().getClass())) {
			logger.error(
					"Invalid data send in the message for the key identifier. Expected : com.opus.optimus.offline.runtime.common.api.record.IRecord, Received: {}",
					message.getData().getClass());
			return null;
    	}
    	IRecord data = (IRecord)message.getData();
        return IntStream.range(0, this.matchingClause.getAndClauses().size()).mapToObj(andClauseIndex -> {
            try {
                final AndClause andClause = this.matchingClause.getAndClauses().get(andClauseIndex);
                if (isRecordSourceField(data, andClause.getLhsField())) {
                    return andClauseFieldScripts.get(buildFieldScriptMapKey(SOURCE_FIELD_LHS_FILED_IND, andClauseIndex))
                            .execute(data);
                } else if (isRecordSourceField(data, andClause.getRhsField())) {
                    return andClauseFieldScripts.get(buildFieldScriptMapKey(SOURCE_FIELD_RHS_FILED_IND, andClauseIndex))
                            .execute(data);
                } else {
                    logger.error(
                            "Invalid AND clause configured for the matching clause. LHS/RHS source mismatch with Record souce information.");
                    return null;
                }
            } catch (Exception exception) {
                logger.error("Error while build the Recon key for AND clause: Error Message: {}",
                        exception.getMessage(), exception);
                return null;
            }
        }).filter(evaluatedValue -> evaluatedValue != null)
                .collect(Collectors.mapping(Object::toString, Collectors.joining("-")));
    }

    /**
     * This method is used to check whether record source field is present or not
     * @param data
     * @param field
     * @return boolean
     */
    private boolean isRecordSourceField(IRecord data, SourceField field) {
        if (field == null || StringUtils.isEmpty(field.getSourceName()))
            return false;
        return field.getSourceName().equalsIgnoreCase(data.getSchema().getName());
    }
}
