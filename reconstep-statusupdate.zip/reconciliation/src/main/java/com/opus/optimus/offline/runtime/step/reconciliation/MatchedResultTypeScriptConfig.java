package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MatchedResultTypeScriptConfig implements IScriptConfig {
    public final static String TYPE = "step_link.matched_result_type";

    List<MatchedResultType> matchedResultTypes;

    @Override
    public String getType() {
        return TYPE;
    }
}
