package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

import java.util.List;

public class MatchedResultTypeScript implements IScript<IMessage, Boolean> {
    List<MatchedResultType> matchedResultTypes;

    public MatchedResultTypeScript(List<MatchedResultType> matchedResultTypes) {
        this.matchedResultTypes = matchedResultTypes;
    }

    @Override
    public Boolean execute(IMessage message) {
        if (message.getData() instanceof ReconciliationMatchResult) {
            ReconciliationMatchResult<IMessage> data = (ReconciliationMatchResult<IMessage>) message.getData();
            return (matchedResultTypes.indexOf(data.getType()) != -1);
        }

        return false;
    }
}
