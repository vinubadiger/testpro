package com.opus.optimus.offline.runtime.step.reconciliation.util;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.impl.FieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordMetaData;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;

@Component
public class Utility {
	@Autowired
	RecordFactory recordFactory;
	
	public RecordMetaData buildRecordMetaData(List<IFieldConfig> fieldConfigs, String sectionName) {
		final Schema schema = buildSchema(fieldConfigs, sectionName);
		recordFactory.registerSchema(schema);
		final RecordMetaData recordMetaData = new RecordMetaData(schema);
		return recordMetaData;
	}
	
	public Schema buildSchema(List<IFieldConfig> fieldConfigs, String sectionName) {
		Schema.Builder builder = Schema.builder();
		builder.name(sectionName);
		
		fieldConfigs.sort(new Comparator<IFieldConfig>() {
			@Override
			public int compare(IFieldConfig o1, IFieldConfig o2) {
				return o1.getFieldIndex() - o2.getFieldIndex();
			}
		});
		
		fieldConfigs.forEach(fieldConfig -> {
			builder.addField(new FieldSchema(fieldConfig.getName(), fieldConfig.getType()));
		});
		return builder.build();
	}
	
	public IRecord buildRecord(List<IFieldConfig> fieldConfigs, Map<String, Object> values, String sectionName) {
		IRecord record = recordFactory.createRecord(sectionName);
		fieldConfigs.forEach(fieldConfig -> {
			int fldIndex = fieldConfig.getFieldIndex() - 1;
			record.setValue(fldIndex, values.get(fieldConfig.getName()));
		});
		return record;
	}
}
