package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessage

class MapBasedRecordMatcher implements IRecordMatcher<IMessage> {
    RuleType ruleType
    List<String> matchFields

    MapBasedRecordMatcher(RuleType ruleType, List<String> matchFields) {
        this.ruleType = ruleType
        this.matchFields = matchFields
    }

    @Override
    RecordMatcherResult check(IMessage lhs, IMessage rhs) {
        def matchedList = matchFields.grep {
            lhs.getData().get(it) != rhs.getData().get(it)
        }

        return new RecordMatcherResult(matchedList.size() == 0, ruleType, new HashMap<String, Object>())
    }
}
