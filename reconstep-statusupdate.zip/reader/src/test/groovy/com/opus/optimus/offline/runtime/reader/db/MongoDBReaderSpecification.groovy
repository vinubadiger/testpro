package com.opus.optimus.offline.runtime.reader.db

import com.mongodb.MongoClient
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.db.MongoDBReaderHelper
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.time.ZonedDateTime

@ContextConfiguration(classes = TestReaderConfiguration.class)
class MongoDBReaderSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    MongoDBReaderHelper mongoDBReaderHelper

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    IMessageFactory messageFactory

    def "Mongo DB reader execution - Successful"() {
        setup:

        def mapper = mapperFactory.getMapper()
        //register the data source
        def jsonStream = getClass().getResourceAsStream("/json/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

        //set up embedded mongo
        def dbHostIP = "localhost";
        def dbPort = 27017;

        MongodStarter starter = MongodStarter.getDefaultInstance();
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.DEVELOPMENT)
                .net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
                .build();

        def mongodExecutable = starter.prepare(mongodConfig);
        def mongod = mongodExecutable.start();

        //initialize data source factory
        mongoDataSource.init();
        dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);

        def mongo = new MongoClient(dbHostIP, dbPort);
        def mongoDataBase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());


        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/json/MongoDBReaderConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getStepConfig()]

        def mongoCollection = mongoDataBase.getCollection(testWorkflowConfig.getStepConfig().getSourceDefinition().getCollectionName())

        //prepare the Local Job Task Executor
        def jobId = "mongoDBReaderJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        //insert sample records to mongo db
        def sampleDataJsonStream = getClass().getResourceAsStream("/json/sampleDBReaderRecords.txt")
        def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
        def sampleRecordLine = sampleRecordBufferedReader.readLine();
        while (sampleRecordLine != null) {
            def dbObject = Document.parse(sampleRecordLine)
            println("db object" + dbObject)
            mongoCollection.insertOne(dbObject)
            sampleRecordLine = sampleRecordBufferedReader.readLine();
        }

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).get(0).getReceiver()

        emitter.emit(messageFactory.createMessage("START"))
        emitter.emit(messageFactory.createEndMessage())

        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 3
        receivedData.forEach { iRecord ->
            def fieldIndex = iRecord.getFieldId("transactionID")
            def fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "123456789"

            fieldIndex = iRecord.getFieldId("recordReferenceID")
            fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "11221122"
        }
        cleanup:
        if (mongo != null) mongo.close()
        if (mongod != null) {
            mongod.deleteTempFiles();
            mongod.stop();
        }
        if (mongodExecutable != null) mongodExecutable.stop();
    }


    def "Mongo DB reader execution - Find by Date - Successful"() {
        setup:

        def mapper = mapperFactory.getMapper()
        //register the data source
        def jsonStream = getClass().getResourceAsStream("/json/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

        //set up embedded mongo
        def dbHostIP = "localhost";
        def dbPort = 27017;

        MongodStarter starter = MongodStarter.getDefaultInstance();
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.DEVELOPMENT)
                .net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
                .build();

        def mongodExecutable = starter.prepare(mongodConfig);
        def mongod = mongodExecutable.start();

        //initialize data source factory
        mongoDataSource.init();
        dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);

        def mongo = new MongoClient(dbHostIP, dbPort);
        def mongoDataBase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());


        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/json/MongoDBReaderConfigWithDateCriteria.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getStepConfig()]

        def mongoCollection = mongoDataBase.getCollection(testWorkflowConfig.getStepConfig().getSourceDefinition().getCollectionName())

        //prepare the Local Job Task Executor
        def jobId = "mongoDBReaderJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        //insert sample records to mongo db
        def sampleDataJsonStream = getClass().getResourceAsStream("/json/sampleDBReaderRecordsWithDate.txt")
        def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
        def sampleRecordLine = sampleRecordBufferedReader.readLine();
        while (sampleRecordLine != null) {
            def dbObject = Document.parse(sampleRecordLine)
            println("db object" + dbObject)
            mongoCollection.insertOne(dbObject)
            sampleRecordLine = sampleRecordBufferedReader.readLine();
        }

        def whereClauseDate = ZonedDateTime.now().plusDays(2);
        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).get(0).getReceiver()

        emitter.emit(messageFactory.createMessage("START"))
        emitter.emit(messageFactory.createEndMessage())

        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 2
        receivedData.forEach { iRecord ->
            def fieldIndex = iRecord.getFieldId("transactionID")
            def fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "123456789"

            fieldIndex = iRecord.getFieldId("recordReferenceID")
            fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "11221122"

            fieldIndex = iRecord.getFieldId("transactionDate")
            fieldValue = iRecord.getValue(fieldIndex)
            fieldValue.before(java.util.Date.from(whereClauseDate.toInstant())) == true
        }
        cleanup:
        if (mongo != null) mongo.close()
        if (mongod != null) {
            mongod.deleteTempFiles();
            mongod.stop();
        }
        if (mongodExecutable != null) mongodExecutable.stop();
    }


    def "Mongo DB reader execution - Find by Date & Recon Control Fields - Successful"() {
        setup:

        def mapper = mapperFactory.getMapper()
        //register the data source
        def jsonStream = getClass().getResourceAsStream("/json/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

        //set up embedded mongo
        def dbHostIP = "localhost";
        def dbPort = 27017;

        MongodStarter starter = MongodStarter.getDefaultInstance();
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.DEVELOPMENT)
                .net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
                .build();

        def mongodExecutable = starter.prepare(mongodConfig);
        def mongod = mongodExecutable.start();

        //initialize data source factory
        mongoDataSource.init();
        dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);

        def mongo = new MongoClient(dbHostIP, dbPort);
        def mongoDataBase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());


        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/json/MongoDBReaderConfigWithDateCriteria.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getStepConfig()]

        def mongoCollection = mongoDataBase.getCollection(testWorkflowConfig.getStepConfig().getSourceDefinition().getCollectionName())

        //prepare the Local Job Task Executor
        def jobId = "mongoDBReaderJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        //insert sample records to mongo db
        def sampleDataJsonStream = getClass().getResourceAsStream("/json/sampleDBRecordsWithDateAndReconCtrlFlds.txt")
        def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
        def sampleRecordLine = sampleRecordBufferedReader.readLine();
        while (sampleRecordLine != null) {
            def dbObject = Document.parse(sampleRecordLine)
            println("db object" + dbObject)
            mongoCollection.insertOne(dbObject)
            sampleRecordLine = sampleRecordBufferedReader.readLine();
        }

        def whereClauseDate = ZonedDateTime.now().plusDays(2);
        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).get(0).getReceiver()

        emitter.emit(messageFactory.createMessage("START"))
        emitter.emit(messageFactory.createEndMessage())

        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 2
        receivedData.forEach { iRecord ->
            def fieldIndex = iRecord.getFieldId("transactionID")
            def fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "123456789"

            fieldIndex = iRecord.getFieldId("recordReferenceID")
            fieldValue = iRecord.getValue(fieldIndex)
            fieldValue == "11221122"

            fieldIndex = iRecord.getFieldId("transactionDate")
            fieldValue = iRecord.getValue(fieldIndex)
            fieldValue.before(java.util.Date.from(whereClauseDate.toInstant())) == true

            fieldIndex = iRecord.getFieldId("reconControlFields")
            if (fieldIndex != -1) {
                fieldValue = iRecord.getValue(fieldIndex)
                if (fieldValue != null) { //For the fresh records, the recon control fields will be null
                    fieldValue.getClass().getName() == "org.bson.Document"
                    fieldValue.getString("activityName") == "Amex"
                    fieldValue.getString("status") == "UNRECONCILED"
                    fieldValue.getString("subStatus") != "Aged"
                }
            }
        }
        cleanup:
        if (mongo != null) mongo.close()
        if (mongod != null) {
            mongod.deleteTempFiles();
            mongod.stop();
        }
        if (mongodExecutable != null) mongodExecutable.stop();
    }
}
