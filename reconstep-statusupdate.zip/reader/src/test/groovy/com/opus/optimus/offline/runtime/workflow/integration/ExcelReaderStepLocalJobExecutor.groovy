package com.opus.optimus.offline.runtime.workflow.integration

import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelReaderStepLocalJobExecutor extends Specification {

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    MapperFactory mapperFactory

    def "Reader step execution"() {
        setup:


        def excelReaderConfig = new ExcelReaderConfig();
        def object;

        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
        object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
        excelReaderConfig = object.stepConfig;

        /*
        def tstStream = getClass().getResourceAsStream("/json/wkflwConfigtest.json")
        def tstobject = mapper.readValue(tstStream, WorkflowConfig.class)
        println( tstobject)
        */

        /*Map<String, Object> props = new HashMap<String, Object>();
         props.put(ExcelReaderHelper.READER_FILENAME,"./src/test/resources/testXLSX1.xlsx");*/
        String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";


        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [excelReaderConfig]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue("name").getEmitter()

        emitter.emit(messageFactory.createMessage(inputFileLocation))
        emitter.emit(messageFactory.createEndMessage())

        result.get()

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue("name").get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        println("Size----------->" + receivedData.size());
        receivedData.size() == 10
    }
}
