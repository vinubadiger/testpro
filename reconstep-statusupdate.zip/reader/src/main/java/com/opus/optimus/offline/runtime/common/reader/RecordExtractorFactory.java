package com.opus.optimus.offline.runtime.common.reader;


import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig;
import com.opus.optimus.offline.config.record.impl.FixedRecordExtractorConfig;
import com.opus.optimus.offline.runtime.common.reader.record.IRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.record.impl.DelimitedRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.record.impl.FixedRecordExtractor;

/**
 * A factory for creating RecordExtractor objects.
 *
 * @author Ram
 */

public class RecordExtractorFactory {
	private RecordExtractorFactory() {}

	/**
	 * Gets the extractor.
	 *
	 * @param config - The field extractor configuration
	 * @return the extractor
	 */
	@SuppressWarnings("rawtypes")
	public static IRecordExtractor getExtractor(ITextRecordExtractorConfig config) {		
		if (config instanceof DelimitedRecordExtractorConfig) {
			return new DelimitedRecordExtractor();
		}
		else if(config instanceof FixedRecordExtractorConfig) {
			return new FixedRecordExtractor();
		}
		return null;
	}
}
