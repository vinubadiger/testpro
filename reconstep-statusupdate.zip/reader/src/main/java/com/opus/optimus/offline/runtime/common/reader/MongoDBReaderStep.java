package com.opus.optimus.offline.runtime.common.reader;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.db.MongoDBReaderHelper;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.util.SchemaBuilder;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * The Class MongoDBReaderStep.
 *
 * @author Anup.Warke
 */

@Component(StepTypeConstants.MONGO_DBREADER_STEP_TYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MongoDBReaderStep extends AbstractStep<MongoDBReaderConfig> {
	
	/** The Constant logger. */
	static final Logger logger = LoggerFactory.getLogger(MongoDBReaderStep.class);
	
	/** The Constant MONGO_OBJECT_ID_RECORD_FIELD_NAME. */
	public static final String MONGO_OBJECT_ID_RECORD_FIELD_NAME = "OID";
	
	/** The Constant MONGO_RECON_CONTROL_RECORD_FIELD_NAME. */
	public static final String MONGO_RECON_CONTROL_RECORD_FIELD_NAME = "reconControlFields";
	
	/** The message factory. */
	@Autowired
	IMessageFactory messageFactory;
	
	/** The mongo DB reader helper. */
	@Autowired
	private MongoDBReaderHelper mongoDBReaderHelper;
	
	/** The record factory. */
	@Autowired
	IRecordFactory recordFactory;
	
	/**
	 * Instantiates a new mongo DB reader step.
	 *
	 * @param config the configuration 
	 */
	public MongoDBReaderStep(MongoDBReaderConfig config) {
		super(config);
	}
	
	/**
	 * Initialize the helper.
	 *
	 * @throws ReaderException the reader exception
	 */
	public boolean doStop() {
        return forceStop.get();
	}
	
	@PostConstruct
	public void initHelper() throws ReaderException {
		if(!verifyIfCustomFieldsRegistered(MONGO_OBJECT_ID_RECORD_FIELD_NAME)) { //TODO In future, UI will add these field config by default for the OID and Recon control fields
			loadOIDFieldConfig();
		}
		if(!verifyIfCustomFieldsRegistered(MONGO_RECON_CONTROL_RECORD_FIELD_NAME)) { //TODO In future, UI will add these field config by default for the OID and Recon control fields
			loadReconControlFieldConfig();
		}
		final Schema schema = SchemaBuilder.buildDBReaderSchema(this.config.getSourceDefinition().getSourceName(),
				this.config.getSourceDefinition().getFieldConfigs());
		recordFactory.registerSchema(schema);
		mongoDBReaderHelper.init(this.config);
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		try {
			mongoDBReaderHelper.process(this, new IReaderEventHandler<IRecord>() {
				@Override
				public void onDataError(Throwable cause, ISourceReference sourceReference) {
					ErrorDetails errorDetails = ErrorDetails.builder().userDetails(cause.getMessage()).errorDetail(cause).severity(Severity.ERROR).build();
					emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, sourceReference));
				}
				
				@Override
				public void onData(IRecord record, ISourceReference sourceReference) {
					logger.info("Record parsed : " + record);
					emitter.emit(messageFactory.createMessage(MessageType.DATA, record, sourceReference));
				}
			});
		} catch (Exception exception) {
			logger.error("System Error occured : {}", exception);
			//prepare DB Source reference
			ISourceReference sourceReference = DBSourceReference.builder().dataSourceName(config.getSourceDefinition().getDataSourceName())
					.collectionName(config.getSourceDefinition().getCollectionName()).build();
			final ErrorDetails errorDetails = ErrorDetails.builder().userDetails(exception.getMessage()).errorDetail(exception).severity(Severity.FATAL).build();
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, sourceReference));
		}
		
	}
	
	/**
	 * Load OID field config.
	 */
	private void loadOIDFieldConfig() {
		// create a Field Config
		config.getSourceDefinition().getFieldConfigs()
				.add(MongoDBFieldConfig.builder().type(FieldType.STRING).name(MONGO_OBJECT_ID_RECORD_FIELD_NAME)
						.fieldIndex((short) (this.config.getSourceDefinition().getFieldConfigs().size() + 1))
						.sourceDataType(FieldType.STRING).targetDataType(FieldType.STRING)
						.sourceFieldName(MONGO_OBJECT_ID_RECORD_FIELD_NAME)
						.targetFieldName(MONGO_OBJECT_ID_RECORD_FIELD_NAME).build());
	}
	
	/**
	 * Load recon control field config.
	 */
	private void loadReconControlFieldConfig() {
		config.getSourceDefinition().getFieldConfigs()
				.add(MongoDBFieldConfig.builder().type(FieldType.OBJECT).name(MONGO_RECON_CONTROL_RECORD_FIELD_NAME)
						.fieldIndex((short) (this.config.getSourceDefinition().getFieldConfigs().size() + 1))
						.sourceDataType(FieldType.OBJECT).targetDataType(FieldType.OBJECT)
						.sourceFieldName(MONGO_RECON_CONTROL_RECORD_FIELD_NAME)
						.targetFieldName(MONGO_RECON_CONTROL_RECORD_FIELD_NAME).build());
	}
	
	/**
	 * Verify if custom fields registered.
	 *
	 * @param fieldName - The field name
	 * @return true, if successful
	 */
	private boolean verifyIfCustomFieldsRegistered(String fieldName) {
		return this.config.getSourceDefinition().getFieldConfigs().stream()
				.anyMatch(fieldConfig -> fieldConfig.getTargetFieldName().equalsIgnoreCase(fieldName));
	}

}
