package com.opus.optimus.offline.runtime.common.reader.field.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.FieldFormatException;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.field.IFieldExtractor;
import com.opus.optimus.offline.runtime.common.reader.field.formatter.FieldFormatterImpl;
import com.opus.optimus.offline.runtime.common.reader.util.SchemaBuilder;

import lombok.Getter;

/**
 * The Class DelimitedFieldExtractor for fields extractor from row data.
 * 
 * @author Manjusha.Dhamdhere
 *
 */
public class DelimitedFieldExtractor implements IFieldExtractor<String> {

	private static final Logger logger = LoggerFactory.getLogger(DelimitedFieldExtractor.class);

	/** The configuration object */
	private DelimitedFieldExtractorConfig config;

	/** The schema. */
	@Getter
	private Schema schema;

	/** The record factory. */
	private IRecordFactory recordFactory;

	@Override
	public void setRecordFactory(IRecordFactory recordFactory) {
		this.recordFactory = recordFactory;
	}

	@Override
	public IRecord getRecord(String rawRecord) throws ReaderException {

		List<String> tokenizedRecord = processedRecord(config.getDelimiter(), rawRecord);
		// Check for size of fields
		int maxfieldCount = config.getFieldConfigs().size();
		if (tokenizedRecord.size() < (maxfieldCount - 1)) {
			logger.error("Expected {} , fields, But Found {} Number of fields", maxfieldCount, tokenizedRecord.size());
			throw new ReaderException(ExceptionCodes.MISSING_FIELDS,
					"Expected " + maxfieldCount + " fields, But Found " + tokenizedRecord.size() + " Number of fields");
		}

		IRecord record = recordFactory.createRecord(config.getSectionName());
		try {
			for (IFieldConfig fieldConfig : config.getFieldConfigs()) {
				int fldIndex = fieldConfig.getFieldIndex() - 1;
				if (tokenizedRecord.size() == fldIndex)
					record.setValue(fldIndex, FieldFormatterImpl.populateField(fieldConfig, null));
				else
					record.setValue(fldIndex,
							FieldFormatterImpl.populateField(fieldConfig, tokenizedRecord.get(fldIndex)));
			}
		} catch (FieldFormatException exp) {
			logger.error("Error while formatting fields in reader: {} ,{}" , exp.getMessage() ,exp);
			throw new ReaderException(ExceptionCodes.FIELD_FORMAT_EXCEPTION, exp.getMessage());
		}
		return record;
	}

	/**
	 * Processed record.
	 *
	 * @param delimiter -
	 *            The delimiter reader
	 * @param recordRawData -
	 *            The record raw data
	 * @return the list of split words
	 */
	private List<String> processedRecord(String delimiter, String recordRawData) {
		char[] delimiterChar = delimiter.toCharArray();

		List<String> words = new ArrayList<>();
		String fieldData;
		boolean notInsideComma = true;
		int start = 0;
		for (int i = 0; i < recordRawData.length() - 1; i++) {
			if (recordRawData.charAt(i) == delimiterChar[0] && notInsideComma) {

				fieldData = recordRawData.substring(start, i);

				if (fieldData.startsWith("\"")) {
					words.add(recordRawData.substring(start + 1, i - 1));
				} else {

					words.add(fieldData);
				}

				start = i + 1;
			} else if (recordRawData.charAt(i) == '"') {
				notInsideComma = !notInsideComma;
			}
		}

		if (recordRawData.substring(start).startsWith("\"")) {
			words.add(recordRawData.substring(start + 1, recordRawData.length() - 1));
		} else {
			words.add(recordRawData.substring(start));
		}

		return words;

	}

	@Override
	public void init(IBaseConfig config) {
		this.config = (DelimitedFieldExtractorConfig) config;

		schema = SchemaBuilder.buildSchema(this.config.getSectionName(), this.config.getFieldConfigs());

		recordFactory.registerSchema(schema);
	}
}
