package com.opus.optimus.offline.runtime.common.reader.util;

import java.util.List;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.impl.FieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;

/**
 * The Class SchemaBuilder for creating record schema.
 *
 * @author Ram
 */
public class SchemaBuilder {

	/**
	 * Instantiates a new schema builder.
	 */
	private SchemaBuilder() {
	    throw new IllegalStateException("Utility class, at least one non-public, non-implict constructor to be there");
	  }
	
	/**
	 * Builds the schema.
	 *
	 * @param sectionName - The section name
	 * @param fieldConfigs - The field configurations
	 * @return the schema
	 */
	public static Schema buildSchema(String sectionName, List<? extends IFieldConfig> fieldConfigs) {
		Schema.Builder builder = Schema.builder();
		builder.name(sectionName);

		fieldConfigs.sort((o1, o2) -> {
				return o1.getFieldIndex() - o2.getFieldIndex();			
		});

		fieldConfigs.forEach(fieldConfig -> builder.addField(new FieldSchema(fieldConfig.getName(), fieldConfig.getType())));
		return builder.build();
	}

	/**
	 * Builds the DB reader schema.
	 *
	 * @param sectionName -
	 *            The section name from reader configuration 
	 * @param fieldConfigs -
	 *            The field configuration
	 * @return the schema
	 */
	public static Schema buildDBReaderSchema(String sectionName, List<MongoDBFieldConfig> fieldConfigs) {
		Schema.Builder builder = Schema.builder();
		builder.name(sectionName);

		fieldConfigs.sort((o2, o1) -> {			
				return o1.getFieldIndex() - o2.getFieldIndex();			
		});

		fieldConfigs.forEach(fieldConfig -> builder
				.addField(new FieldSchema(fieldConfig.getTargetFieldName(), fieldConfig.getTargetDataType())));

		return builder.build();
	}
}
