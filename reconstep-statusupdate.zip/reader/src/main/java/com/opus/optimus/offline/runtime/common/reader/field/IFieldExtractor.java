package com.opus.optimus.offline.runtime.common.reader.field;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;

/**
 * The Interface IFieldExtractor.
 *
 * @param <T>
 *            the generic type
 * 
 * @author Ram
 */

public interface IFieldExtractor<T> {

	/**
	 * Gets the record.
	 *
	 * @param rawRecord -
	 *            The raw record
	 * @return the record
	 * @throws ReaderException
	 *             the reader exception
	 */
	IRecord getRecord(T rawRecord) throws ReaderException;

	/**
	 * Gets the schema of record.
	 *
	 * @return the schema
	 */
	Schema getSchema();

	/**
	 * Initialize the.
	 *
	 * @param config
	 *            the configuration
	 */
	void init(IBaseConfig config);

	/**
	 * Sets the record factory.
	 *
	 * @param recordFactory -
	 *            The new record factory
	 */
	void setRecordFactory(IRecordFactory recordFactory);

}
