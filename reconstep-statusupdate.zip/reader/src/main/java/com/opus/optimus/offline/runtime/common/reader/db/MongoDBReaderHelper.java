package com.opus.optimus.offline.runtime.common.reader.db;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.mongodb.MongoException;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.subtypes.AndClause;
import com.opus.optimus.offline.config.recon.subtypes.Operator;
import com.opus.optimus.offline.config.recon.subtypes.OrClause;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SourceField;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler;
import com.opus.optimus.offline.runtime.common.reader.MongoDBReaderStep;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

/**
 * The Class MongoDBReaderHelper for reading data from Mongo DB
 *
 * @author Anup.Warke
 */

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MongoDBReaderHelper {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(MongoDBReaderHelper.class);

	/** The Constant SCRIPT_MAP_RSH_FIELD_KEY. */
	static final String SCRIPT_MAP_RSH_FIELD_KEY = "RHS";
	
	/** The Constant SCRIPT_MAP_LSH_FIELD_KEY. */
	static final String SCRIPT_MAP_LSH_FIELD_KEY = "LHS";
	
	/** The Constant MONGO_DB_OBJECT_ID_KEY. */
	static final String MONGO_DB_OBJECT_ID_KEY = "_id";
	
	/** The Constant RECON_CONTROL_FIELD_PROPERTY_KEY. */
	static final String RECON_CONTROL_FIELD_PROPERTY_KEY = "reconControlFields";
	
	/** The Constant RECON_CONTROL_FIELD_SUB_STATUS_PROPERTY_KEY. */
	static final String RECON_CONTROL_FIELD_SUB_STATUS_PROPERTY_KEY = "subStatus";
	
	/** The Constant RECON_CONTROL_FIELD_STATUS_PROPERTY_KEY. */
	static final String RECON_CONTROL_FIELD_STATUS_PROPERTY_KEY = "status";

	/** The Constant IN_CLAUSE_VALUE_SEPARATOR. */
	static final String IN_CLAUSE_VALUE_SEPARATOR = ",";

	/** The data source factory. */
	@Autowired
	private DataSourceFactory dataSourceFactory;

	/** The record factory. */
	@Autowired
	IRecordFactory recordFactory;
	
	/** The script creator factory. */
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	/** The config. */
	private MongoDBReaderConfig config;
	
	/** The database. */
	private MongoDatabase database;
	
	/** The mongo template. */
	private MongoTemplate mongoTemplate;
	
	/** The field value script map. */
	private Map<String, IScript> fieldValueScriptMap = new HashMap<>();

	/**
	 * Initialize step 
	 *
	 * @param config - The Database reader configuration
	 * @throws ReaderException the reader exception
	 */
	public void init(final MongoDBReaderConfig config) throws ReaderException {
		this.config = config;
		try{
			final IDataSource dataSource = dataSourceFactory.getDataSource(this.config.getSourceDefinition().getDataSourceName());
			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				// get the database
				this.database = mongoDataSource.getDatabase();
				// build the template
				this.mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), this.database.getName());
			} else{
				throw new NoSuchDataSourceAvailableException("Incorrect datasource identified. Please check configuration.");
			}
		} catch (NoSuchDataSourceAvailableException dataSourceAvailableException){
			logger.error("Error occured while initializing Mongo DB writer :{}", dataSourceAvailableException);
			throw new ReaderException("Failed to initialize DB reader :", dataSourceAvailableException);
		} catch (DataSourceInitializationException e){
			logger.error("Error occured while initializing Mongo DB writer.", e);
			throw new ReaderException("Failed to initialize DB Writer.", e);
		}
		//build script from the script configuration if any available
		buildScript(config);
	}

	/**
	 * Process.
	 *
	 * @param eventHandler - The DB reader event handler
	 */
	public void process(MongoDBReaderStep stepInstance, final IReaderEventHandler<IRecord> eventHandler) {
		Query query = buildReaderQuery();
		logger.info("Activity Name: {}, Source - {} , Query for Source - {} ",
				config.getSourceDefinition().getActivityName(), config.getSourceDefinition().getSourceName(), query);
		this.mongoTemplate.executeQuery(query, config.getSourceDefinition().getCollectionName(), (document) -> {
			if (stepInstance != null && stepInstance.doStop()){
				logger.info("Job aborted due to some FATAL error. Please check the error details.");
				throw new MongoException("Job aborted due to some FATAL error. Please check the error details.");
			}
			logger.debug("Record found for Activity Name: {}, Source - {} :: {}",
					config.getSourceDefinition().getActivityName(), config.getSourceDefinition().getSourceName(),
					document);
			// prepare DB Source reference
			ISourceReference sourceReference = DBSourceReference.builder().rawRecordData(document.toJson())
					.dataSourceName(config.getSourceDefinition().getDataSourceName())
					.collectionName(config.getSourceDefinition().getCollectionName())
					.schemaName(this.database.getName()).build();
			try{
				IRecord record = createIRecordFromDocument(document);
				logger.debug("IRecord built successfully for Activity Name: {}, Source - {} :: {}",
						config.getSourceDefinition().getActivityName(), config.getSourceDefinition().getSourceName(),
						document);
				eventHandler.onData(record, sourceReference);
			} catch (ReaderException readerException){
				logger.error("Reader exception occured while processing the record.", readerException);
				eventHandler.onDataError(readerException, sourceReference);
			} catch (Exception exception){
				logger.error("Application exception occured while processing the record.", exception);
				eventHandler.onDataError(exception, sourceReference);
			}
		});
	}

	/**
	 * Creates the I record from document.
	 *
	 * @param document - The document
	 * @return the i record
	 * @throws ReaderException the reader exception
	 */
	private IRecord createIRecordFromDocument(Document document) throws ReaderException {
		IRecord record = recordFactory.createRecord(config.getSourceDefinition().getSourceName());
		
		IntStream.range(0, config.getSourceDefinition().getFieldConfigs().size()).forEach(fldIndex -> {
			MongoDBFieldConfig fieldConfig = config.getSourceDefinition().getFieldConfigs().get(fldIndex);
			if(fieldConfig.getTargetFieldName().equalsIgnoreCase(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME)) {
				record.setValue(fldIndex, document.getObjectId(MONGO_DB_OBJECT_ID_KEY).toHexString());
			} else {
				record.setValue(fldIndex, document.get(fieldConfig.getTargetFieldName()));
			}
		});
		
		return record;
	}

	/**
	 * Builds the reader query.
	 *
	 * @return the query
	 */
	private Query buildReaderQuery() {
		final Query query = new Query();
		final Criteria readerOrCriteria = new Criteria();
		//build aged status criteria
		final Criteria reconControlFieldCriteria = buildReconControlCriteria();
		
		Criteria[] andCriterias = IntStream.range(0, config.getSelectionCriteria().getOrClauseSections().size()).mapToObj(orClauseIndex -> {
			final Criteria readerAndCriteria = new Criteria();
			OrClause orClause = config.getSelectionCriteria().getOrClauseSections().get(orClauseIndex); 
			List<Criteria> fieldCriterias = IntStream.range(0, orClause.getAndClauses().size()).mapToObj(andClauseIndex -> {
				return buildMongoDbCriteria(orClauseIndex, andClauseIndex, orClause.getAndClauses().get(andClauseIndex));
			}).collect(Collectors.toList());  
			fieldCriterias.add(reconControlFieldCriteria); // add the recon control field criteria
			readerAndCriteria.andOperator(fieldCriterias.toArray(new Criteria[fieldCriterias.size()]));// connect all field criteria with AND condition
			return readerAndCriteria;
		}).toArray(size -> new Criteria[size]);
		readerOrCriteria.orOperator(andCriterias); // connect all AND criteria with OR condition
		
		query.addCriteria(readerOrCriteria);
		return query;
	}

	/**
	 * Builds the recon control criteria.
	 *
	 * @return the criteria
	 */
	private Criteria buildReconControlCriteria() {
		Criteria reconControlFieldsCriteria = new Criteria();
		reconControlFieldsCriteria.orOperator(buildReconControlFieldNotExistsCriteria(),
				buildReconCtrlFldActivityExistsCriteria(), buildReconControlFieldExistsCriteria());
		return reconControlFieldsCriteria;
	}

	/**
	 * Builds the recon ctrl fld activity exists criteria.
	 *
	 * @return the criteria
	 */
	private Criteria buildReconCtrlFldActivityExistsCriteria() {
		 return Criteria.where(RECON_CONTROL_FIELD_PROPERTY_KEY).exists(true).and(buildReconControlCriteriaKey(null))
			.exists(false);
	}

	/**
	 * Builds the recon control field not exists criteria.
	 *
	 * @return the criteria
	 */
	private Criteria buildReconControlFieldNotExistsCriteria() {
		return Criteria.where(RECON_CONTROL_FIELD_PROPERTY_KEY).exists(false);
	}

	/**
	 * Builds the recon control field exists criteria.
	 *
	 * @return the criteria
	 */
	private Criteria buildReconControlFieldExistsCriteria() {
		return Criteria.where(RECON_CONTROL_FIELD_PROPERTY_KEY).exists(true).and(buildReconControlCriteriaKey(null))
				.exists(true).and(buildReconControlCriteriaKey(RECON_CONTROL_FIELD_SUB_STATUS_PROPERTY_KEY))
				.ne(ReconSubStatus.Aged).and(buildReconControlCriteriaKey(RECON_CONTROL_FIELD_STATUS_PROPERTY_KEY))
				.is(ReconStatus.UNRECONCILED);
	}

	/**
	 * Builds the recon control criteria key.
	 *
	 * @param propertyName - The property name
	 * @return the string
	 */
	private String buildReconControlCriteriaKey(String propertyName) {
		StringBuilder agedStatusWhereClauseKeyBuilder = new StringBuilder();
		agedStatusWhereClauseKeyBuilder.append(RECON_CONTROL_FIELD_PROPERTY_KEY);
		agedStatusWhereClauseKeyBuilder.append(".");
		agedStatusWhereClauseKeyBuilder.append(config.getSourceDefinition().getActivityName());
		if(!StringUtils.isEmpty(propertyName)) {
			agedStatusWhereClauseKeyBuilder.append(".");
			agedStatusWhereClauseKeyBuilder.append(propertyName);
		}
		return agedStatusWhereClauseKeyBuilder.toString();
	}

	/**
	 * Builds the mongo db criteria.
	 *
	 * @param orClauseIndex - The or clause index
	 * @param andClauseIndex - The and clause index
	 * @param readerAndClause - The reader and clause
	 * @return the criteria
	 */
	private Criteria buildMongoDbCriteria(int orClauseIndex, int andClauseIndex, AndClause readerAndClause) {
		//lhs execution
		final IScript lhsFieldScript = fieldValueScriptMap.get(buildScriptKey(orClauseIndex, andClauseIndex, SCRIPT_MAP_LSH_FIELD_KEY, readerAndClause.getLhsField(), readerAndClause.getOperator()));
		final Object lhsField = lhsFieldScript.execute(null);
		if(!String.class.isAssignableFrom(lhsField.getClass())) {
			logger.error("ERROR: LHS field is not of String type. Please check the configuration.");
			logger.error("Received: "
					+ " LHS Field Name/Formula: " + ((ExcelScriptConfig)readerAndClause.getLhsField().getFormulaConfig()).getFormulaText() 
					+ ", Operator: " + readerAndClause.getOperator().getOperatorLiteral() 
					+ ", RHS Field Name/Formula:: " + ((ExcelScriptConfig)readerAndClause.getRhsField().getFormulaConfig()).getFormulaText() );
			return null;
		}
		
		Criteria readerAndCriteria = Criteria.where((String)lhsField);
		//rhs execution
		final IScript rhsFieldScript = fieldValueScriptMap.get(buildScriptKey(orClauseIndex, andClauseIndex, SCRIPT_MAP_RSH_FIELD_KEY, readerAndClause.getRhsField(), readerAndClause.getOperator()));
		final Object rhsField = rhsFieldScript.execute(null);
		
		if(rhsField == null) {
			logger.error("Where clause can not be applied. "
					+ "for LHS Field Name/Formula: " + ((ExcelScriptConfig)readerAndClause.getLhsField().getFormulaConfig()).getFormulaText() 
					+ ", Operator: " + readerAndClause.getOperator().getOperatorLiteral() 
					+ ", RHS Field Name/Formula:: " + ((ExcelScriptConfig)readerAndClause.getRhsField().getFormulaConfig()).getFormulaText() );
		}
		
		switch (readerAndClause.getOperator().getOperatorLiteral()) {
		case EQUAL:
			readerAndCriteria.is(rhsField);
			break;
		case GT:
			readerAndCriteria.gt(rhsField);
			break;
		case GTE:
			readerAndCriteria.gte(rhsField);
			break;
		case IN:
			readerAndCriteria.in(buildInClauseCollection(rhsField));
			break;
		case LT:
			readerAndCriteria.lt(rhsField);
			break;
		case LTE:
			readerAndCriteria.lte(rhsField);
			break;
		case NOTEQUAL:
			readerAndCriteria.ne(rhsField);
			break;
		case NOTIN:
			readerAndCriteria.nin(rhsField);
			break;
		default:
			break;
		}
		return readerAndCriteria;
	}
	
	/**
	 * Builds the in clause collection.
	 *
	 * @param rhsField - the right hand side field
	 * @return the list
	 */
	private List buildInClauseCollection(Object rhsField) {
		if(String.class.isAssignableFrom(rhsField.getClass())) {
			return Arrays.asList(((String) rhsField).split(IN_CLAUSE_VALUE_SEPARATOR)).stream()
					.map(value -> value.trim()).collect(Collectors.toList());
		} else {
			return Arrays.asList(rhsField);
		}
	}

	/**
	 * Builds the script.
	 *
	 * @param config the configuration
	 */
	private void buildScript(MongoDBReaderConfig config) {
		IntStream.range(0, config.getSelectionCriteria().getOrClauseSections().size()).forEach(orClauseIndex -> {
			List<AndClause> andClauses = config.getSelectionCriteria().getOrClauseSections().get(orClauseIndex).getAndClauses();
			IntStream.range(0, andClauses.size()).forEach(andClauseIndex -> {
				AndClause andClause = andClauses.get(andClauseIndex);
				IScript lhsFieldScript = scriptCreatorFactory.createScript(andClause.getLhsField().getFormulaConfig());
				IScript rhsFieldScript = scriptCreatorFactory.createScript(andClause.getRhsField().getFormulaConfig());
				fieldValueScriptMap.put(buildScriptKey(orClauseIndex, andClauseIndex, SCRIPT_MAP_LSH_FIELD_KEY, andClause.getLhsField(), andClause.getOperator()), lhsFieldScript);
				fieldValueScriptMap.put(buildScriptKey(orClauseIndex, andClauseIndex, SCRIPT_MAP_RSH_FIELD_KEY, andClause.getRhsField(), andClause.getOperator()), rhsFieldScript);
			});
		});
	}

	/**
	 * Builds the script key.
	 *
	 * @param parentIndex - The parent index
	 * @param subIndex - The sub index
	 * @param helperCharecter - The helper character
	 * @param field - The field
	 * @param operator - The operator
	 * @return the string
	 */
	private String buildScriptKey(int parentIndex, int subIndex, String helperCharecter, SourceField field, Operator operator) {
		StringBuilder fieldScriptMapKeyBuilder = new StringBuilder();
		fieldScriptMapKeyBuilder.append(parentIndex);
		fieldScriptMapKeyBuilder.append("_");
		fieldScriptMapKeyBuilder.append(subIndex);
		fieldScriptMapKeyBuilder.append("_");
		fieldScriptMapKeyBuilder.append(helperCharecter);
		fieldScriptMapKeyBuilder.append("_");
		fieldScriptMapKeyBuilder.append(field.getSourceName());
		fieldScriptMapKeyBuilder.append("_");
		fieldScriptMapKeyBuilder.append(operator.getOperatorLiteral());
		return fieldScriptMapKeyBuilder.toString();
	}
}

