package com.opus.optimus.offline.runtime.common.reader.exception;

public class FieldFormatException extends ReaderException {
	private static final long serialVersionUID = 1L;

	public FieldFormatException() {		
		super(ExceptionCodes.FIELD_FORMAT_EXCEPTION, "");
	}

	public FieldFormatException(Throwable cause) {
		super(ExceptionCodes.FIELD_FORMAT_EXCEPTION, cause);
	}
	
	public FieldFormatException(String reason) {
		super(ExceptionCodes.FIELD_FORMAT_EXCEPTION, reason);
	}
	
	public FieldFormatException(String reason, Throwable cause) {
		super(ExceptionCodes.FIELD_FORMAT_EXCEPTION, reason);
		this.initCause(cause);
	}

}
