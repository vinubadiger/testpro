package com.opus.optimus.offline.runtime.common.reconcase;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.CaseCreation;
import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.config.recon.ReconCaseCreationStepConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.step.reconciliation.MatchedResultType;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

@Component(StepTypeConstants.RECONCASECREATION_STEPTYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ReconCaseCreationStep extends MapStep<ReconCaseCreationStepConfig> implements IJobTaskInfoAware {
	private static final Logger logger = LoggerFactory.getLogger(ReconCaseCreationStep.class);

	public ReconCaseCreationStep(ReconCaseCreationStepConfig config) {
		super(config);
	}
	

	@SuppressWarnings("rawtypes")
	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		ReconciliationMatchResult reconciliationMatchResult = (ReconciliationMatchResult)data;
		String description="";
		String subject="";

		try {
			if (reconciliationMatchResult.getType() == MatchedResultType.UNEXPECTED_MULTIPLE_RECORDS) {

			} else if (reconciliationMatchResult.getType() == MatchedResultType.UNMATCHED) {

			}

			return (R) CaseCreation.builder().referenceId("").status("").origin("").priority(Priority.MEDIUM)
					.exceptionType(Severity.ERROR).subject(subject).description(description)
					.batchTypeNameInstanceId("").fileUsedForUpload("").contactName("").contactSkypeName("").reason("")
					.activity("").project("").workflowName("").build();

		} catch (Exception exception) {
			logger.error("Error while recon case creation step execution :{}", exception);
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails(exception.getMessage()).errorDetail(exception).build();
			throw new RecordProcessingException(errorDetails);
		}

	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {

	}
}
