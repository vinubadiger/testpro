package com.opus.optimus.offline.runtime.common.reconcase.utility;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

@Component
public class CaseCreationVelocityUtil {
    VelocityEngine ve;

    @Lazy
    @PostConstruct
    public void init() {
        ve = new VelocityEngine();
    }


    public String execute(String fileName, Map<String, Object> variables) {
        Template t = ve.getTemplate(fileName);
        VelocityContext context = new VelocityContext();

        for (Map.Entry<String, Object> variableEntry : variables.entrySet()) {
            context.put(variableEntry.getKey(), variableEntry.getValue());
        }

        context.put("String", String.class);
        context.put("NEWLINE", "\n");

        StringWriter writer = new StringWriter();
        t.merge(context, writer);
        return writer.toString();
    }

}
