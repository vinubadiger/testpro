package com.opus.optimus.offline.runtime.script.code;

import org.springframework.stereotype.Component;

import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.SetterCode;

/**
 * The Class RawTextCodeProvider.
 */
@Component("RawTextTypeData")
public class RawTextCodeProvider implements ICodeProvider {
	
	/** The input data variable name. */
	static final String INPUT_DATA_VARIABLE_NAME = "request";
	
	@Override
	public String getDataClassName() {
		return String.class.getName();
	}

	@Override
	public GetterCode getGetterCode(String arg0) {
		GetterCode getterCode = new GetterCode();
		getterCode.setCode(INPUT_DATA_VARIABLE_NAME);
        return getterCode;
	}

	@Override
	public SetterCode getSetterCode(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
