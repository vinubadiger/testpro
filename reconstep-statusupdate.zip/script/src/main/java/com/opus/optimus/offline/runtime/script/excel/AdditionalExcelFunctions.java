package com.opus.optimus.offline.runtime.script.excel;

import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

/**
 * The Class AdditionalExcelFunctions.
 */
public class AdditionalExcelFunctions {
	private AdditionalExcelFunctions() {}
	
	/**
	 * Recordtype Function
	 *
	 * @param message - The input message type data 
	 * @return the string
	 */
	public static String RECORDTYPE(IMessage message) {
		if(message.getData() != null && IRecord.class.isAssignableFrom(message.getData().getClass())){
			return ((IRecord)message.getData()).getSchema().getName();
		} else {
			return "";
		}
	}
}
