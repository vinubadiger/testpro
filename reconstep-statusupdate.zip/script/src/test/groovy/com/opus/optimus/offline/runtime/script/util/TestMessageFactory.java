package com.opus.optimus.offline.runtime.script.util;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.Message;

@Component
public class TestMessageFactory implements IMessageFactory {
    public IMessage createMessage(Serializable data) {
        return createMessage(MessageType.DATA, data);
    }

    @Override
    public IMessage createMessage(MessageType type, Serializable data) {
        return createMessage(type, data, null);
    }

    @Override
    public IMessage createMessage(MessageType type, Serializable data, ISourceReference reference) {
        Message message = new Message();
        message.setType(type);
        message.setData(data);
        message.setSourceReference(reference);
        return message;
    }

    @Override
    public IMessage createEndMessage() {
        return createMessage(MessageType.END, null);
    }
}