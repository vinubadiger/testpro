package com.opus.optimus.offline.runtime.script

import java.time.ZoneId
import java.time.temporal.ChronoField

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.TestMessageFactory
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import spock.lang.Specification

@ContextConfiguration(classes= ScriptTestConfiguration.class)
class ExcelScriptTestSpecification extends Specification {
	
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;
	
	@Autowired
	TestMessageFactory messageFactory
	
	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;
	
	def "ExcelScript IRecordCondition EXACT execution"() {
		setup:
		def formulaText = "EXACT(transType, \"settlement\")"
		def fieldName = "transType"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(true)
									.type("excel.IRecord-script").build() 
									
		
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "settlement");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null) 
			result = conditionScript.execute(record)
		then:
		conditionScript != null
		result == true
	}
	
	def "ExcelScript IRecordValueProvider SUBSTR execution"() {
		setup:
		def formulaText = "SUBSTR(processingCode, 0, 2)"
		def fieldName = "processingCode"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
									
		
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "100000");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		result == "10"
	}
	
	def "ExcelScript IRecordCondition STARTSWITH execution"() {
		setup:
		def formulaText = "STARTSWITH(\"DT\")"
		def rawText = "DT10020181601TESTOPUS"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(true)
									.type("excel.rawtext-script").build()
		
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null)
			result = conditionScript.execute(rawText)
		then:
		conditionScript != null
		result == true
	}
	
	def "ExcelScript IRecordCondition PEEK execution"() {
		setup:
		def formulaText = "PEEK(5,13)"
		def rawText = "DT10020181601TESTOPUS"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.rawtext-script").build()
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueProviderScript != null)
			result = valueProviderScript.execute(rawText)
		then:
		valueProviderScript != null
		result == "20181601"
	}
	
	def "ExcelScript IMessage RECORDTYPE execution"() {
		setup:
		def formulaText = "RECORDTYPE()"
		def fieldName = "processingCode"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.imessage-script").build()
									
		
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "100000");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		IMessage message = messageFactory.createMessage(record);
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(message)
		then:
		valueProviderScript != null
		result == "data"
	}
	
	
	def "ExcelScript IRecordCondition CONCAT execution"() {
		setup:
		def formulaText = "CONCAT(\"Opus\",\"Recon\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == "OpusRecon"
	}
	

	
	def "ExcelScript IRecordCondition INDEXOF execution"() {
		setup:
		def formulaText = "INDEXOF(Name,\"P\")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "OPUS-RECON-2019");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			println("-------------"+valueProviderScript.execute(record))
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == 1
	}
	
	
	def "ExcelScript IRecordCondition LENGTH execution"() {
		setup:
		def formulaText = "LENGTH(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "OPUS-RECON-2019");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == 15
	}
	
	def "ExcelScript IRecordCondition INT execution"() {
		setup:
		def formulaText = "INT(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "10");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == 10
		result.getClass() == java.lang.Integer
	}
	
	def "ExcelScript IRecordCondition LONG execution"() {
		setup:
		def formulaText = "LONG(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "35");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == 35
		result.getClass() == java.lang.Long
	}
	
	def "ExcelScript IRecordCondition LOWER execution"() {
		setup:
		def formulaText = "LOWER(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Opus-Y-Recon-K.");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "opus-y-recon-k."
	}
	
	def "ExcelScript IRecordCondition NOW execution"() {
		setup:
		def formulaText = "NOW()"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build();
									DateTimeFormatter dtfs = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
									DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
									SimpleDateFormat mdyFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm");
									LocalDateTime now = LocalDateTime.now();
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null) 
		then:
		valueProviderScript != null
		println(now)
		println(mdyFormat.format(result))
		(dtfs.format(now))!=null
		(dtf.format(now))==(mdyFormat.format(result))
	}
	
	def "ExcelScript IRecordCondition REPLACE execution"() {
		setup:
		def formulaText = "REPLACE(Name,\"Mr.\",\" \")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Mr.John Willy");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == " John Willy"
	}
	
	def "ExcelScript IRecordCondition REPLACEALL execution"() {
		setup:
		def formulaText = "REPLACEALL(Web,\"com\",\"net\")"
		def fieldName = "Web"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Our .com site : https://www.opusconsulting.com");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "Our .net site : https://www.opusconsulting.net"
	}
	
	def "ExcelScript IRecordCondition STR execution"() {
		setup:
		def formulaText = "STR(Contacts)"
		def fieldName = "Contacts"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.LONG)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, 8983112800l);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "8983112800"
		result.getClass() == java.lang.String
	}
	
	
	def "ExcelScript IRecordCondition SUM execution"() {
		setup:
		def formulaText = "SUM(\"5.5\",\"6.0\",\"8\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		

		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == 19.5
	}
	
	def "ExcelScript IRecordCondition UPPER execution"() {
		setup:
		def formulaText = "UPPER(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Opus-Y-Recon-K.");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "OPUS-Y-RECON-K."
	}
	
	
	def "ExcelScript IRecordCondition TRIM execution"() {
		setup:
		def formulaText = "TRIM(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "      Opus-Y-Recon-K.        ");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "Opus-Y-Recon-K."
	}
	
	def "ExcelScript IRecordCondition NOT execution"() {
		setup:
		def formulaText = "NOT(EXACT(1,1))"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}
	
	def "ExcelScript IRecordCondition Right PAD execution"() {
		setup:
		def formulaText = "RPAD(Name,10,\"0\")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Alex");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "Alex0000000000"
	}
	
	def "ExcelScript IRecordCondition LEFT PAD execution"() {
		setup:
		def formulaText = "LPAD(Name,10,\"0\")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Alex");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "0000000000Alex"
	}
	
	
	def "ExcelScript IRecordCondition Literal execution"() {
		setup:
		def formulaText = "\"settlement\""
		def fieldName = "transType"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null)
			result = valueScript.execute(null)
		then:
		valueScript != null
		result == "settlement"
	}
	
	def "ExcelScript IRecordCondition STRTODATE execution"() {
		setup:
		def formulaText = "STRTODATE(\"06-Dec-18\",\"dd-MMM-yy\")"
		
		def excelScriptConfig = ExcelScriptConfig.builder()
									.formulaText(formulaText)
									.conditional(false)
									.type("excel.IRecord-script").build()
		
		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null) {
			try {
			result = valueScript.execute(null)
			} catch(Exception e) {
				//e.printStackTrace()
			}
		}
		then:
		valueScript != null
		println(result)
		(result instanceof java.util.Date) == true
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.DAY_OF_MONTH) == 06
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.MONTH_OF_YEAR) == 12
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.YEAR) == 2018
	}

}
