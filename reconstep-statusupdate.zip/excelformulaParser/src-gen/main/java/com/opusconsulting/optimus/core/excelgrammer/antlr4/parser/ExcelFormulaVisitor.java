// Generated from D:\MY_Work\Recon\Backend\opus-optimus-runtime\excelformulaParser\src\main\antlr\ExcelFormula.g4 by ANTLR 4.2.2
package com.opusconsulting.optimus.core.excelgrammer.antlr4.parser;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ExcelFormulaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ExcelFormulaVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(@NotNull ExcelFormulaParser.ExpressionContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#constant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant(@NotNull ExcelFormulaParser.ConstantContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#stringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringConstant(@NotNull ExcelFormulaParser.StringConstantContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#function}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunction(@NotNull ExcelFormulaParser.FunctionContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(@NotNull ExcelFormulaParser.VariableContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#model}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModel(@NotNull ExcelFormulaParser.ModelContext ctx);

	/**
	 * Visit a parse tree produced by {@link ExcelFormulaParser#numberConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberConstant(@NotNull ExcelFormulaParser.NumberConstantContext ctx);
}