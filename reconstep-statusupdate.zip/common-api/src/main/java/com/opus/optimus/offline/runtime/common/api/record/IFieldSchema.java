package com.opus.optimus.offline.runtime.common.api.record;

/**
 * The Interface IFieldSchema.
 */
public interface IFieldSchema {
    
    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();

    /**
     * Gets the type.
     *
     * @return the type
     */
    FieldType getType();

    /**
     * Gets the collection type.
     *
     * @return the collection type
     */
    FieldType getCollectionType();

    /**
     * Gets the collection or record schema.
     *
     * @return the collection or record schema
     */
    ISchema getCollectionOrRecordSchema();
}
