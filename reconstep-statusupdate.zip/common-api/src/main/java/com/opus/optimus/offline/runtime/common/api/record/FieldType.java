package com.opus.optimus.offline.runtime.common.api.record;

/**
 * The Enums of FieldType.
 */
public enum FieldType {
    
    /** The record. */
    RECORD,
    
    /** The array. */
    ARRAY,
    
    /** The string. */
    STRING,
    
    /** The bytes. */
    BYTES,
    
    /** The int. */
    INT,
    
    /** The long. */
    LONG,
    
    /** The float. */
    FLOAT,
    
    /** The double. */
    DOUBLE,
    
    /** The boolean. */
    BOOLEAN,
    
    /** The datetime. */
    DATETIME,
    
    /** The date. */
    DATE,
    
    /** The object. */
    OBJECT
}
