package com.opus.optimus.offline.runtime.common.api.record

import spock.lang.Specification

class RecordFactorySpecification extends Specification {
}
