package com.opus.optimus.offline.runtime.common.api.record

import spock.lang.Specification

class RecordSpecification extends Specification {


}
