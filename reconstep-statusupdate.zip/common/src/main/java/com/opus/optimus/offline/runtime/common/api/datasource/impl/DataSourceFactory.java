package com.opus.optimus.offline.runtime.common.api.datasource.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;

/**
 * This is factory class for all types of the database.
 *
 * @author Anup.Warke
 */

@Component
public class DataSourceFactory {
	
	/** The data source cache. */
	private final Map<String, IDataSource> dataSourceCache = new HashMap<>();

	/**
	 * Gets the data source.
	 *
	 * @param dataSourceName - The data source name
	 * @return The current data source
	 * @throws NoSuchDataSourceAvailableException the no such data source available exception
	 */
	public IDataSource getDataSource(String dataSourceName) throws NoSuchDataSourceAvailableException {
		final IDataSource dataSource = dataSourceCache.get(dataSourceName);
		if(dataSource == null)
			throw new NoSuchDataSourceAvailableException("No Datasource registered/available with provided name.");
		return dataSource;
	}
	
	/**
	 * Register.
	 *
	 * @param dataSourceName - The all available data source name
	 * @param dataSource - The data source property 
	 */
	public void register(String dataSourceName, IDataSource dataSource) {
		this.dataSourceCache.put(dataSourceName, dataSource);
	}
	
}
