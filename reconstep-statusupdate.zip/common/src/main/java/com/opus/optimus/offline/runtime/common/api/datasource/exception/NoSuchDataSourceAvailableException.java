package com.opus.optimus.offline.runtime.common.api.datasource.exception;

/**
 * The Class NoSuchDataSourceAvailableException.
 */
public class NoSuchDataSourceAvailableException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4742626926121238744L;

	/**
	 * Instantiates a new no such data source available exception.
	 *
	 * @param message - The exception message
	 */
	public NoSuchDataSourceAvailableException(String message) {
		super(message);
	}
}
