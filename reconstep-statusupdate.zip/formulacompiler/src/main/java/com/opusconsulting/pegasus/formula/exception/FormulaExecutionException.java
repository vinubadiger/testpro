package com.opusconsulting.pegasus.formula.exception;

public class FormulaExecutionException extends RuntimeException {
	
	/*
	 * Extending RuntimeException, because we can't throws exception from Excel
	 * function
	 */ 
	
	private static final long serialVersionUID = 1L;
	private final String errorCode;
	
	public FormulaExecutionException(String errorCode, String reason, Throwable cause) {
		super(reason, cause);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}
}
