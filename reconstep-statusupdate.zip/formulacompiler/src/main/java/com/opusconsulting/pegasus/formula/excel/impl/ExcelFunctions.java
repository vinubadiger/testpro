package com.opusconsulting.pegasus.formula.excel.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.formula.exception.FormulaExceptionCodes;
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException;

/**
 * This class includes all EXCEL base function implementations used as a part of
 * formulas
 * 
 * @author Anup.Warke
 */
public class ExcelFunctions {

	private ExcelFunctions() {
	}

	private static final Logger logger = LoggerFactory.getLogger(ExcelFunctions.class);

	public static <T> boolean EXACT(T lhs, T rhs) {
		if (lhs == null || rhs == null) {
			return false;
		}
		if (String.class.isAssignableFrom(lhs.getClass()) && String.class.isAssignableFrom(rhs.getClass())) {
			return ((String) lhs).equalsIgnoreCase((String) rhs);
		} else {
			return lhs.equals(rhs);
		}
	}

	public static <T> String SUBSTR(T str, int startIndex, int endIndex) {
		if (str == null) {
			logger.warn("Input string is null");
			return null;
		} else if (String.class.isAssignableFrom(str.getClass())) {
			return ((String) str).substring(startIndex, endIndex);
		} else {
			logger.warn("Input string is not castable to string");
			return "";
		}

	}

	public static String PEEK(String sourceText, int startIndex, int endIndex) {
		if (sourceText == null || !String.class.isAssignableFrom(sourceText.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		}
		return sourceText.substring(startIndex, endIndex);
	}

	public static String CONCAT(Object... vals) {
		StringBuilder resultBuilder = new StringBuilder();
		if (vals == null) {
			logger.warn("Input string is null");
			return resultBuilder.toString();
		}
		for (Object value : vals) {
			if (value != null && value.getClass().isAssignableFrom(String.class)) {
				resultBuilder.append(value);
			}
		}
		return resultBuilder.toString();
	}

	public static Integer INDEXOF(Object sourceTarget, String subString) {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())) {
			logger.warn("Input string is null or non string type");
			return -1;
		}
		return ((String) sourceTarget).indexOf(subString);
	}

	public static Integer LENGTH(Object sourceTarget) {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())) {
			logger.warn("Input string is null or non string type");
			return -1;
		}
		return ((String) sourceTarget).length();
	}

	public static <T> Integer INT(T sourceTarget) {
		try {
			if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())) {
				logger.warn("Input string is null or non string type");
				return 0;
			}
			return Integer.parseInt((String) sourceTarget);
		} catch (NumberFormatException exception) {
			logger.error("Error while convereting to INT. Error message:" + exception.getMessage());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION,
					"Error while convereting to INT. Error message:" + exception.getMessage(), exception);
		}

	}

	public static <T> Long LONG(T sourceTarget) {
		try {
			if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())) {
				logger.warn("Input string is null or non string type");
				return 0l;
			}
			return Long.parseLong((String) sourceTarget);
		} catch (NumberFormatException exception) {
			logger.error("Error while convereting to LONG. Error message:" + exception.getMessage());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION,
					"Error while convereting to LONG. Error message:" + exception.getMessage(), exception);
		}
	}

	public static <T> String LOWER(T sourceTarget) throws FormulaExecutionException {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		}
		return ((String) sourceTarget).toLowerCase();
	}

	public static Date NOW() {
		final ZonedDateTime now = ZonedDateTime.now();
		return Date.from(now.toInstant());
	}

	public static <T> String REPLACE(T oldStr, String matchStr, String replaceStr) {
		if (oldStr == null || !String.class.isAssignableFrom(oldStr.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		} else if (matchStr == null || replaceStr == null) {
			logger.warn("Matching, replace string is null or non string type");
			return (String) oldStr;
		} else {
			return ((String) oldStr).replace(matchStr, replaceStr);
		}
	}

	public static <T> String REPLACEALL(T oldStr, String matchStr, String replaceStr) {
		if (oldStr == null || !String.class.isAssignableFrom(oldStr.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		} else if (matchStr == null || replaceStr == null) {
			logger.warn("Matching, replace string is null or non string type");
			return (String) oldStr;
		} else {
			return ((String) oldStr).replaceAll(matchStr, replaceStr);
		}
	}

	public static boolean STARTSWITH(String str, String pattern) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())) {
			logger.warn("Input string is null or non string type");
			return false;
		}
		return str.startsWith(pattern);
	}

	public static <T> String STR(T val) {
		if (val == null) {
			logger.warn("Input string is null or non string type");
			return null;
		}

		return String.valueOf(val);
	}

	public static <T> Double SUM(T... is) {
		if (is == null) {
			logger.warn("Input values is string or non number type");
			return 0.0;
		} else {
			double sum = 0;
			for (T t : is) {
				try {
					sum += Double.parseDouble(t.toString());
				} catch (Exception exception) {
					logger.error("Error while Sum foumula. Error for:", t.toString());
					throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION,
							"Error while Sum foumula. Error message:" + exception.getMessage(), exception);
				}
			}
			return sum;
		}
	}

	public static <T> String UPPER(T str) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		}
		return ((String) str).toUpperCase();
	}

	public static <T> String TRIM(T str) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		}
		return ((String) str).trim();
	}

	public static Boolean NOT(Boolean bool) {
		if (bool == null || !Boolean.class.isAssignableFrom(bool.getClass())) {
			logger.warn("Input is non boolean type or not produce boolean result");
			return false;
		}
		return !((boolean) bool);
	}

	public static <T> String LPAD(T str, int count, String ch) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		} else if (ch == null) {
			logger.warn("Input for padding string is null or non string type");
			return (String) str;
		} else {
			String newStr = "";
			for (int i = 0; i < count; i++) {
				newStr += ch;
			}
			newStr += str;
			return newStr;
		}
	}

	public static <T> String RPAD(T str, int count, String ch) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())) {
			logger.warn("Input string is null or non string type");
			return null;
		} else if (ch == null) {
			logger.warn("Input for padding string is null or non string type");
			return (String) str;
		} else {
			String newStr = "";
			newStr += (String) str;
			for (int i = 0; i < count; i++) {
				newStr += ch;
			}
			return newStr;
		}
	}

	public static Date MANIPULATEDATE(Date date, int number, String dmy) {
		LocalDateTime dateTime = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
		switch (dmy) {
		case "dd":
			LocalDateTime days = dateTime.plusDays(number);
			return Date.from(days.atZone(ZoneId.systemDefault()).toInstant());
		case "MM":
			LocalDateTime month = dateTime.plusMonths(number);
			return Date.from(month.atZone(ZoneId.systemDefault()).toInstant());
		case "yyyy":
			LocalDateTime year = dateTime.plusYears(number);
			return Date.from(year.atZone(ZoneId.systemDefault()).toInstant());
		case "HH":
			LocalDateTime hours = dateTime.plusHours(number);
			return Date.from(hours.atZone(ZoneId.systemDefault()).toInstant());
		case "mm":
			LocalDateTime minutes = dateTime.plusMinutes(number);
			return Date.from(minutes.atZone(ZoneId.systemDefault()).toInstant());
		case "ss":
			LocalDateTime seconds = dateTime.plusSeconds(number);
			return Date.from(seconds.atZone(ZoneId.systemDefault()).toInstant());
		default:
			LocalDateTime blank = dateTime.plusDays(number);
			return Date.from(blank.atZone(ZoneId.systemDefault()).toInstant());
		}
	}

	public static <T> Date STRTODATE(T inputDateInString, String inputDateStringFormat) {
		if (String.class.isAssignableFrom(inputDateInString.getClass())) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(inputDateStringFormat);
			try {
				return dateFormat.parse((String) inputDateInString);
			} catch (ParseException exception) {
				logger.error(
						"Error while conveting string to date in STRTODATE. Input Value: {}, Specified Format: {}",
						inputDateInString, inputDateStringFormat);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION,
						"Error while conveting string to date in STRTODATE.. Error message:" + exception.getMessage(),
						exception);
			}
		} else {
			logger.error(
					"Error while conveting string to date in STRTODATE. Expected data type is String, Given data type is : {}",
					(inputDateInString == null ? "No input available." : inputDateInString.getClass()),
					inputDateInString, inputDateStringFormat);
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION,
					"Error while conveting string to date in STRTODATE.. Error message: Expected data type is String, Given data type is : "
							+ inputDateInString.getClass(),
					null);
		}

	}
}
