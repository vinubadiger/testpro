package com.opusconsulting.pegasus.formula;

import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;
import java.util.Random;

public class SpringMain {
	
    public static void main(String[] args) throws Exception {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[]{"formula-spring.xml"}, true);

        FormulaCodeGenerator formulaCodeGenerator = (FormulaCodeGenerator) applicationContext.getBean("formulaCodeGenerator");
        JavaCodeCompiler compiler = (JavaCodeCompiler) applicationContext.getBean(JavaCodeCompiler.class);

        CodeMetaData codeMetaData = new CodeMetaData();
        codeMetaData.setPackageName("com.opusconsulting.pegasus.formula");
        codeMetaData.addImport("com.opusconsulting.pegasus.formula.ICondition");
        codeMetaData.addImport("static com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions.*");
        codeMetaData.addImport("com.opusconsulting.pegasus.formula.IRecord");
        codeMetaData.addImport("java.util.Map");
        codeMetaData.setImplementClasses(Arrays.asList("ICondition")); // for returning boolean
        //codeMetaData.setImplementClasses(Arrays.asList("IValueGetter")); // for returning value

        FunctionMetaData functionMetaData = new FunctionMetaData();
        functionMetaData.setName("checkeql");
        functionMetaData.setReturnType("String");
        //functionMetaData.setName("check");
        //functionMetaData.setReturnType("boolean");
        functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", "IMessage"),
                new ParamMetaData("ctx", "IFlowContext"),
                new ParamMetaData("tag", "Map<String, Object>")));
        codeMetaData.setCallFunctionMetaData(functionMetaData);

        //FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create("DE12", codeMetaData, new CodeProvider("request"));
        //FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create("IF(_DE01, \"T R\", \"FA\")", codeMetaData, new CodeProvider("request"));
        FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create("EQUAL(CONCAT(field1, \"Test\", STR(5)), \"5\")", codeMetaData, new CodeProvider("request"));
        formulaCodeInfo.getClassName();
        System.out.println(formulaCodeInfo.getCode());

        /*      
        Class<Object> conditionClass = compiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());
 		ICondition condition = (ICondition) conditionClass.newInstance();
        condition.check(new IMessage() {
            @Override
            public String getField1() {
                return "FIELD1";
            }
        }, null, null);
        */
    }
}
