package com.opus.optimus.offline.config.recon.subtypes;

import java.util.List;

import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;

import lombok.Data;

@Data
public class EtlSource {
	String sourceName; // Actual Workflow Name ex: Amex, VISA
	String dataSourceName;
	String collectionName;
	String activityName;
	List<MongoDBFieldConfig> fieldConfigs;
}
