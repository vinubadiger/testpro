package com.opus.optimus.offline.config.recon.subtypes;

import java.util.List;
import java.util.Map;

import com.opus.optimus.offline.runtime.workflow.api.IMessage;

import lombok.Data;

@Data
public class ReconResult {
	 ReconStatus status ; 
	 ReconSubStatus subStatus; 
	 Map<String, List<IMessage>> selectedRecords;
	 String ruleId;
	 double tolerance; // <Only in case of UnReconciled beyond tolerance or Reconciled within tolerance    
}
