package com.opus.optimus.offline.config.transformer;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TransformerConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;
	public static final String TRANSFORMER_STEPTYPE = "Transformer";

	@NonNull
	private String name;

	private String lable;
	private String stepType;
	private String sourceSectionName;
	private String transformedSectionName;
	private List<AdditionalTransformerConfig> additionalTransformerConfigs;

	@Override
	@JsonSetter("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	@JsonGetter("stepType")
	public String getStepType() {
		return TRANSFORMER_STEPTYPE;
	}
}
