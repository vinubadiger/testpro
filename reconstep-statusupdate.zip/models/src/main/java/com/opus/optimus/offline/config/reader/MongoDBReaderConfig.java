package com.opus.optimus.offline.config.reader;

import com.opus.optimus.offline.config.recon.subtypes.EtlSource;
import com.opus.optimus.offline.config.recon.subtypes.SelectionCriteria;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MongoDBReaderConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;
	private String stepName;// Source-A or Source-B
	private String stepType;

	private EtlSource sourceDefinition;

	SelectionCriteria selectionCriteria;

	@Override
	public String getStepType() {
		return StepTypeConstants.MONGO_DBREADER_STEP_TYPE;
	}

}
