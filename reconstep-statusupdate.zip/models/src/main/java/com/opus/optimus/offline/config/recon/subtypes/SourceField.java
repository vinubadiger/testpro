package com.opus.optimus.offline.config.recon.subtypes;

import org.antlr.v4.runtime.misc.NotNull;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor 
@AllArgsConstructor
public class SourceField {
	@NotNull
	String sourceName; // Amex, VISA
	IScriptConfig formulaConfig;
}
