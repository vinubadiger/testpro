package com.opus.optimus.offline.config.recon;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Builder;
import lombok.Data;

/**
 * The Class ReconCaseCreationStepConfig.
 *
 * @author Yashkumar.Thakur
 */

@Builder
@Data
public class ReconCaseCreationStepConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	/** The template type. */
	private String template;

	/** The Constant RECONCASECREATION_STEPTYPE. */
	public static final String RECONCASECREATION_STEPTYPE = "ReconCaseCreation";

	/** The name. */
	private String name;

	@Override
	public String getStepName() {
		return name;
	}

	@Override
	public String getStepType() {
		return RECONCASECREATION_STEPTYPE;
	}
}
