package com.opus.optimus.offline.constants;

public final class AnnotationConstants {

	private AnnotationConstants() {
	}

	public static final String DEFAULT_TIME_ZONE = "Asia/Kolkata";

	// DataSourceAuthMetaData
	public static final String DATABASE_USERNAME = "userName";
	public static final String DATABASE_PWORD = "password";

	// MongoDBDataSourceMetaData
	public static final String DATASOURCE_NAME = "datasource_name";
	public static final String DATABASE_TYPE = "database_type";
	public static final String DATABASE_NAME = "database_name";
	public static final String AUTHENTICATION_REQUIRED = "authentication_required";
	public static final String AUTH_METADATA = "authMetaData";
	public static final String ADDRESS_METADATA = "addressMetadatas";
	public static final String COLLECTIONS = "collections";

	// ServerAddressMetadata
	public static final String SERVER_IP_ADDRESS = "ipAddress";
	public static final String SERVER_PORT = "port";

	// Step
	public static final String STEP_NAME = "stepname";
	public static final String STEP_TYPE = "steptype";
	public static final String WORKFLOW_ID = "workflowid";
	public static final String WORKFLOW_NAME = "workflowname";
	public static final String WORKFLOW_TYPE = "workflowtype";
	public static final String PROJECT_NAME = "project_name";
	public static final String STEP_CONFIG = "stepconfig";

	// Workflow
	public static final String WORKFLOW_COLLECTION_NAME = "Workflow";
	public static final String PROJECT_ID = "project_id";
	public static final String WORKFLOW_DESCRIPTION = "workflow_desc";
	public static final String CREATED_DATE = "created_date";
	public static final String MODIFIED_DATE = "modified_date";
	public static final String CREATED_BY = "created_by";
	public static final String LAST_UPDATED_BY = "last_updated_by";
	public static final String LINKS = "links";
	public static final String STEPS = "steps";
	public static final String FLOW_DATA = "flow_data";

	/*
	 * //Project public static final String PROJECT_COLLECTION_NAME = "Project"; public static final String INSTITUTION_ID = "institution_id"; public
	 * static final String PROJECT_DESCRIPTION = "project_desc"; //BatchDefinition public static final String BATCH_DEFINATION_COLLECTION_NAME =
	 * "batch_definition"; public static final String NEXT_TRIGGER_TIME = "next_trigger_time"; public static final String PREVIOUS_TRIGGER_TIME =
	 * "previous_trigger_time"; public static final String SCHEDULAR_POLICY = "scheduler_policy"; //BatchMonitor public static final String
	 * BATCH_MONITOR_COLLECTION_NAME = "batch_monitor"; public static final String BATCH_INSTANCE_ID = "batch_instance_id"; public static final String
	 * CREATED_TIME = "created_time"; public static final String START_TIME = "start_time"; public static final String END_TIME = "end_time"; public
	 * static final String TRIGGER_TYPE = "trigger_type"; public static final String EXECUTION_STATUS = "execution_status"; public static final String
	 * RECORDS_PROCESSED = "records_processed"; public static final String RECORDS_PASSED = "records_passed"; public static final String
	 * RECORDS_FAILED = "records_failed"; public static final String SOURCE_INFORMATION = "source_information"; public static final String
	 * EXCEPTION_LOGS = "exception_logs";
	 */
}
