
package com.opus.optimus.offline.config.fieldextractor;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.opus.optimus.offline.config.IBaseConfig;

@JsonTypeInfo (use = Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "type", visible = true)
public interface ITextFieldExtractorConfig extends IBaseConfig {

	public String getType();
}
