package com.opus.optimus.offline.config.record.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.field.impl.ExcelFieldConfig;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class ExcelRecordExtractorConfig implements ITextRecordExtractorConfig {
	public static final String RECORDTYPE = "ExcelRecordExtractorConfig";

	private String sectionName;
	private List<ExcelFieldConfig> fieldConfigs;
	private String type;
	
	
	@Override
	@JsonGetter ("type")
	public String getType() {
		return RECORDTYPE;
	}
}
