package com.opus.optimus.offline.config.datasource;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.offline.constants.AnnotationConstants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Document (collection = "MongoDataSourceMeta")
public class MongoDataSourceMeta {	
	@Id
	private String id;

	@Field (AnnotationConstants.DATASOURCE_NAME)
	private String dataSourceName;
	
	@Field (AnnotationConstants.DATABASE_TYPE)
	private String databaseType;
	
	@Field (AnnotationConstants.DATABASE_NAME)
	private String databaseName;
	
	@Field (AnnotationConstants.AUTHENTICATION_REQUIRED)
	private boolean authenticationRequired;
	
	@Field (AnnotationConstants.AUTH_METADATA)
	private DataSourceAuthMetaData authMetaData;
	
	@Field (AnnotationConstants.ADDRESS_METADATA)
	private List<ServerAddressMetadata> addressMetadatas;
	
	@Field (AnnotationConstants.COLLECTIONS)
	private List<String> collections;
}
