package com.opus.optimus.offline.config.casemanagement;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.workflow.exception.Severity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class CaseCreation implements Serializable {

	String referenceId;

	String status;

	String origin;

	Priority priority; // enum

	Severity exceptionType; // enum

	String subject;

	String description;

	String batchTypeNameInstanceId;

	String runDataTime;

	String fileUsedForUpload;

	String contactName;

	String contactSkypeName;

	String reason;

	String activity;

	String project;

	String workflowName;

}
