package com.opus.optimus.offline.config.recon;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReconSourceSummary {
	private String stepName;//Source A or Source B
	private String sourceName;
	private Long recordCount;
	private Double totalAmount;
	private Double totalVarianceAmnt;

	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date transactionDate;
}
