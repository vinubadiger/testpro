package com.opus.optimus.offline.config.fieldextractor.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig;
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class DelimitedFieldExtractorConfig implements ITextFieldExtractorConfig {

	public static final String TYPE_CONFIG = "DelimitedFieldExtractorConfig";

	private String sectionName;
	private String delimiter;
	
	private String type;
	
	private List<DelimitedFieldConfig> fieldConfigs;

	@Override
	@JsonGetter ("type")
	public String getType() {
		return TYPE_CONFIG;
	}
}
