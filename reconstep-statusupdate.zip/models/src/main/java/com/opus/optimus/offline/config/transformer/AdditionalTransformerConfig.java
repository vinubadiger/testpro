package com.opus.optimus.offline.config.transformer;

import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class AdditionalTransformerConfig {
	private String fieldName;
	private FieldType fieldType;
	private IScriptConfig scriptConfig; 
}
