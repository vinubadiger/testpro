package com.opus.optimus.offline.runtime.taskmanager.workflow.integration;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobResultService;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutor;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepositoryFactory;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager;
import com.opus.optimus.offline.runtime.workflow.api.event.impl.LogJobEventEmitter;
import com.opus.optimus.offline.runtime.workflow.api.impl.JobConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper;
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor;
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * This class is used for executing all work flow based on jobId,jobTaskId,gruopIdand workFlowName.
 *
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class WorkflowTaskExecutor implements ITaskExecutor {
    @Autowired
    IMessageFactory messageFactory;

    @Autowired
    IWorkflowConfigRepositoryFactory repositoryFactory;

    @Autowired
    IJobResultService jobResultService;

    @Autowired(required = false)
    IJobEventManager jobEventManager;

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder;

    String jobId;
    String jobTaskId;
    String groupId;
    String workflowName;
    String errorHandlingWorkflowName;
    Map<String, List<String>> stepInputs;

    LocalJobTaskExecutor localJobTaskExecutor;

    public WorkflowTaskExecutor(String jobId, String jobTaskId, String groupId, String workflowName,
                                String errorHandlingWorkflowName,
                                Map<String, List<String>> stepInputs) {
        this.jobId = jobId;
        this.jobTaskId = jobTaskId;
        this.groupId = groupId;
        this.workflowName = workflowName;
        this.errorHandlingWorkflowName = errorHandlingWorkflowName;
        this.stepInputs = stepInputs;
    }

    @PostConstruct
    public void init() {
        IWorkflowConfigRepository configRepository = repositoryFactory.create(groupId);
        JobConfig jobConfig = new JobConfig(workflowName, errorHandlingWorkflowName);

        localJobTaskExecutor = executorBuilder.buildWith(jobId, jobTaskId, jobConfig, configRepository);

        IJobEventEmitter emitter = (jobEventManager != null) ? jobEventManager.getEmitter() : new LogJobEventEmitter();
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(emitter));
    }

    @Override
    public CompletableFuture<JobTaskExecutorResult> execute() {
        CompletableFuture<JobTaskExecutorResult> result = localJobTaskExecutor.execute();

        if (stepInputs != null) {
            for (Map.Entry<String, List<String>> stepNameWithInputs : stepInputs.entrySet()) {
                IQueue inBoundQueue = localJobTaskExecutor.getInBoundQueue(workflowName, stepNameWithInputs.getKey());
                IEmitter emitter = inBoundQueue.getEmitter(null);

                for (String input : stepNameWithInputs.getValue()) {
                    emitter.emit(messageFactory.createMessage(input));
                }

                emitter.end(messageFactory.createEndMessage());
            }
        }

        return result.thenApply(executorResult -> {
            jobResultService.saveJobTaskResult(jobId, jobTaskId, executorResult);
            return executorResult;
        });
    }
}
