package com.opus.optimus.offline.runtime.taskmanager.workflow.integration;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueue;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutor;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutorFactory;
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

@Component
public class WorkflowTaskExecutorFactory implements ITaskExecutorFactory, BeanFactoryAware {

    BeanFactory beanFactory;
    
    String GLOBAL_ERROR_WORKFLOW_NAME = "defaultInMemoryGlobalErrorWorkflow";
    static final Logger logger = LoggerFactory.getLogger(WorkflowTaskExecutorFactory.class);

    @Override
    public ITaskExecutor newTaskExecutor(String jobId, JobTask jobTask) {

        String jobTaskId = jobTask.getTaskId();
        ExecutionInfo executionInfo = jobTask.getExecutionInfo();
        String groupId = executionInfo.getGroupId();
        String workflowId = executionInfo.getId();
		String errorHandlingWorkflowId = StringUtils.isEmpty(executionInfo.getErrorHandlingId())
				? GLOBAL_ERROR_WORKFLOW_NAME
				: executionInfo.getErrorHandlingId();
        Map<String, List<String>> stepInputs = executionInfo.getStepInputs();

        try {
                 return beanFactory.getBean(WorkflowTaskExecutor.class, jobId, jobTaskId, groupId,
                    workflowId, errorHandlingWorkflowId, stepInputs);
           
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        return null;
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }
}
