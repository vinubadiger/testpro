package com.opus.optimus.offline.runtime.taskmanager.integration

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails.JobErrorDetailsBuilder
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails

/**
 * @author prashant.dongare
 *
 */
@Component
class JobErrorDetailsService implements IJobErrorDetailsService {
	
	@Autowired
	JobErrorDetailsRepositoryTest errorDetailsLogRepository;

	@Override
	public void logErrorDetails(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo) {
		//build the details to log into repository
		final JobErrorDetails jobErrorDetails = buildJobErrorDetailsToLog(errorDetails, sourceReference, jobTaskInfo);
		errorDetailsLogRepository.save(jobErrorDetails);
	}
	
	/**
	 * This method is used to create the job error details.
	 * @param errorDetails - The name which holds information of Error Details
	 * @param sourceReference - The name which holds information of Source reference
	 * @param jobTaskInfo - The name which holds information of job task
	 * @return JobErrorDetails - The name which holds information of job error details
	 */
	private JobErrorDetails buildJobErrorDetailsToLog(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo) {
		JobErrorDetailsBuilder errorDetailsBuilder = JobErrorDetails.builder()
				.jobId(jobTaskInfo == null ? null : jobTaskInfo.getJobId())
				.errorMessage(errorDetails.getUserDetails())
				.errorType(errorDetails.getSeverity().name());
		if(errorDetails.getErrorDetail() != null &&
				RecordProcessingException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass()) &&
				sourceReference != null &&
				FileSourceReference.class.isAssignableFrom(sourceReference.getClass())) {
			final FileSourceReference fileSourceReference = (FileSourceReference)sourceReference;
			errorDetailsBuilder.rowIndex(fileSourceReference.getRowIndex()).rawRecordData(fileSourceReference.getRawRecordData());
		}

		if(errorDetails.getErrorDetail() != null &&
				ReaderException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())) {
			errorDetailsBuilder.reasonCode(((ReaderException)errorDetails.getErrorDetail()).getErrorCode());
		}
		
		return errorDetailsBuilder.build();
	}


	@Override
	public JobErrorDetails getjobErrorDetails(String jobId) {
		
		return errorDetailsLogRepository.findByjobId(jobId)
	}

	

}
