package com.opus.optimus.offline.runtime.taskmanager.integration

import com.fasterxml.jackson.databind.type.TypeFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskReceiver
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager
import com.opus.optimus.offline.runtime.workflow.api.impl.InMemoryWorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import org.apache.curator.test.TestingServer
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Ignore
import spock.lang.Specification

import java.util.concurrent.TimeUnit

@ContextConfiguration(classes = TestTaskManagerIntegrationConfiguration.class)
class TaskManagerSpecification extends Specification {

    @Autowired
    ITaskManagerAdmin taskManagerAdmin

    @Autowired
    ITaskManager taskManager

    @Autowired
    ITaskReceiver taskReceiver

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    TestWorkflowConfigRepositoryFactory repositoryFactory

    @Autowired
    JobResultService jobResultService //testJobResultService

    @Autowired
    IJobEventManager eventManager

    @Ignore
    def "Create and execute job"() {

        setup:
        def server = new TestingServer(2181)
        server.start()
        //CuratorFramework curatorFramework = CuratorFrameworkFactory.builder(). connectString(server.getConnectString()).sessionTimeoutMs(1000).retryPolicy(new RetryNTimes(3, 1000)).build()
        //curatorFramework.start()

        taskManagerAdmin.start()
        taskReceiver.start()

        def allJobEvents = new ArrayList()
        def eventReceiver = { IJobEvent evt -> println 'Event received'; println evt; allJobEvents.add(evt) }
        eventManager.registerReceiver(eventReceiver)

        def groupId = "GlobalHandlingScenario"
        def workflowType = "Workflow"

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def ErrorOnDataStage1 = "ErrorOnDataStage1"
        def ErrorOnDataStage2 = "ErrorOnDataStage2"
        def Success = "Success"
        def Error = "Error"
        def errorNumbersStage1 = (100..120)
        def errorNumbersStage2 = (220..230)

        def jsonStream = getClass().getResourceAsStream("/" + groupId + ".json")
        def mapper = mapperFactory.getMapper()
        def typeReference =
                TypeFactory.defaultInstance().constructCollectionType(List.class, WorkflowConfig.class);
        def workflowConfigs = mapper.readValue(jsonStream, typeReference)

        def memoryWorkflowConfigRepository = new InMemoryWorkflowConfigRepository()
        workflowConfigs.each { memoryWorkflowConfigRepository.addWorkflowConfig(it) }
        repositoryFactory.addWorkflowConfigRepository(groupId, memoryWorkflowConfigRepository)

        when:
        def stepInputs = new HashMap()
        stepInputs.put("SequenceNumberGenerator", Arrays.asList("START"))
        def executionInfo = new ExecutionInfo(groupId, "Main", workflowType, "GlobalErrorHandler",
                workflowType, stepInputs)

        def jobTask1 = JobTask.builder()
                .taskId("Job_Task_1")
                .executionInfo(executionInfo)
                .build()

        def jobId = taskManager.createJob("Job1", Arrays.asList(jobTask1))
        def jobRunResult = taskManager.runJob(jobId)

        def jobResult = jobRunResult.get(500, TimeUnit.SECONDS)

        then:
        noExceptionThrown()
        println(jobResult)
        def info = taskManager.getJobInfo(jobId)
        info.status == JobStatus.COMPLETED_SUCCESS

        jobResult.taskResults != null
        jobResult.taskResults.size() == 1

        def jobTaskExecutorResult = jobResult.taskResults.get(0)
        jobTaskExecutorResult != null

        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 5
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, Success, Error, ErrorOnDataStage1, ErrorOnDataStage2].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def successResult = stepExecutionResults.grep { it -> it.stepName == Success }
        successResult != null
        successResult.size() == 1
        def successExpectedData = (1..256).grep {
            it in errorNumbersStage1 == false && it in errorNumbersStage2 == false
        }
        successExpectedData.size() == successResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def errorResult = stepExecutionResults.grep { it -> it.stepName == Error }
        errorResult != null
        errorResult.size() == 1
        def errorExpectedData = errorNumbersStage1 + errorNumbersStage2
        errorExpectedData.size() == errorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.errorCount }

        allJobEvents.size() > 0

        def jobResultInStore = jobResultService.findById(jobId)
        jobResultInStore.taskResults != null
        jobResultInStore.taskResults.size() == 1

        cleanup:
        eventManager.unRegisterReceiver(eventReceiver)

        jobResultService.clear()
        repositoryFactory.removeWorkflowConfigRepository(groupId)
        taskReceiver.stop()
        taskManagerAdmin.stop()
        server.stop()
    }

}