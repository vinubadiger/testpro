package com.opus.optimus.offline.runtime.taskmanager.integration

import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class JobInfoService implements IJobInfoService {
    @Autowired
    JobInfoRepository repository

    @Override
    public JobInfo save(JobInfo jobInfo) {
        return repository.save(jobInfo);
    }

    @Override
    public JobInfo findById(String jobId) {
        def jobInfo = repository.findById(jobId)
        return jobInfo.isPresent() ? jobInfo.get() : null
    }

    @Override
    public JobInfo updateStatusAndGet(String jobId, JobStatus status) throws InvalidJobStatusException {
        def jobInfo = repository.findById(jobId)
        if (!jobInfo.isPresent()) {
            return null
        }

        jobInfo.get().status = status;
        save(jobInfo.get())

        return jobInfo.get()
    }

    @Override
    public JobInfo updateStatus(String jobId, JobStatus status) {
        updateStatusAndGet(jobId, status)
    }

    @Override
    public List<JobInfo> findByStatus(JobStatus status) {
        return null;
    }

    @Override
    public void deleteById(String jobId) {

    }
}
