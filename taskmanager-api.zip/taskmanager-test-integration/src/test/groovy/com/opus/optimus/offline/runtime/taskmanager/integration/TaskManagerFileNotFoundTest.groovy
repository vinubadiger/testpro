package com.opus.optimus.offline.runtime.taskmanager.integration

import com.fasterxml.jackson.databind.type.TypeFactory
import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.datasource.ServerAddressMetadata
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskReceiver
import com.opus.optimus.offline.runtime.taskmanager.model.ErrorReason
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager
import com.opus.optimus.offline.runtime.workflow.api.impl.InMemoryWorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.config.datasource.MongoDataSource
import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodProcess
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import org.apache.curator.test.TestingServer
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

import java.util.concurrent.TimeUnit

/**
 * @author prashant.dongare
 *
 */
@ContextConfiguration(classes = TestTaskManagerIntegrationConfiguration.class)
class TaskManagerFileNotFoundTest extends Specification {


    @Autowired
    ITaskManagerAdmin taskManagerAdmin

    @Autowired
    ITaskManager taskManager

    @Autowired
    ITaskReceiver taskReceiver

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    TestWorkflowConfigRepositoryFactory repositoryFactory

    @Autowired
    JobResultService jobResultService //testJobResultService

    @Autowired
    JobErrorDetailsService jobErrorDetailsService;

    @Autowired
    IJobEventManager eventManager

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    JobInfoRepository repository

    @Shared
    MongodExecutable mongodExecutable;
    @Shared
    MongodProcess mongod;
    @Shared
    def dbHostIP = "localhost";
    @Shared
    def dbPort = 27017;
    @Shared
    def databaseName = "test";//"samsonDb";
    @Shared
    def collectionName = "samson";
    @Shared
    MongoDataSource mongoDataSource;
    @Shared
    MongoClient mongo;
    @Shared
    MongoDatabase mongoDataBase;

    def setupSpec() {

        MongodStarter starter = MongodStarter.getDefaultInstance();
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.DEVELOPMENT)
                .net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
                .build();
        mongo = new MongoClient(dbHostIP, dbPort);
        mongoDataBase = mongo.getDatabase(databaseName);

        mongodExecutable = starter.prepare(mongodConfig);
        mongod = mongodExecutable.start();

        List<ServerAddressMetadata> serverAddresses = new ArrayList<>();
        serverAddresses.add(ServerAddressMetadata.builder().ipAddress("localhost").port(27017).build());
        MongoDataSourceMeta mongoDbDataSourceMetaData = MongoDataSourceMeta.builder()
                .dataSourceName("samsonMongoDataSource")
                .databaseType("MongoDB")
                .databaseName("local")
                .authenticationRequired(false)
                .addressMetadatas(serverAddresses).build();

        mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
        mongoDataSource.init();
    }

    @Ignore
    def "Create and execute job"() {

        setup:
        dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);
        def server = new TestingServer(2181)
        server.start()
        //CuratorFramework curatorFramework = CuratorFrameworkFactory.builder(). connectString(server.getConnectString()).sessionTimeoutMs(1000).retryPolicy(new RetryNTimes(3, 1000)).build()
        //curatorFramework.start()

        taskManagerAdmin.start()
        taskReceiver.start()

        def allJobEvents = new ArrayList()
        def eventReceiver = { IJobEvent evt -> println 'Event received'; println evt; allJobEvents.add(evt) }
        eventManager.registerReceiver(eventReceiver)

        def groupId = "GlobalHandlingScenario"
        def workflowType = "Workflow"

        def Source = "Source"
        def Success = "Success"
        def Error = "Error"

        def jsonStream = getClass().getResourceAsStream("/jsonFromUi.json")
        def mapper = mapperFactory.getMapper()
        def typeReference =
                TypeFactory.defaultInstance().constructCollectionType(List.class, WorkflowConfig.class);
        def workflowConfigs = mapper.readValue(jsonStream, typeReference)

        def memoryWorkflowConfigRepository = new InMemoryWorkflowConfigRepository()
        workflowConfigs.each { memoryWorkflowConfigRepository.addWorkflowConfig(it) }
        repositoryFactory.addWorkflowConfigRepository(groupId, memoryWorkflowConfigRepository)

        when:
        String inputFileLocation = "./src/test/resources/testFile123.csv";
        def stepInputs = new HashMap()
        stepInputs.put("Source", Arrays.asList(inputFileLocation))

        def executionInfo = new ExecutionInfo(groupId, "Main", workflowType, "defaultInMemoryGlobalErrorWorkflow",
                workflowType, stepInputs)

        def jobTask1 = JobTask.builder()
                .taskId("Job_Task_1")
                .executionInfo(executionInfo)
                .build()

        def jobId = taskManager.createJob("Job1", Arrays.asList(jobTask1))
        def jobRunResult = taskManager.runJob(jobId)

        def jobResult = jobRunResult.get(500, TimeUnit.SECONDS)

        then:
        noExceptionThrown()
        println(jobResult)
        def jobErrorDetails = jobErrorDetailsService.getjobErrorDetails(jobId)
        jobErrorDetails.errorType == "FATAL"
        jobErrorDetails.errorMessage != null
        jobErrorDetails.reasonCode != null

        def errorReason = new ErrorReason()
        errorReason.setErrorCode(jobErrorDetails.getReasonCode())
        errorReason.setExceptionType(jobErrorDetails.getErrorType())
        def info = taskManager.getJobInfo(jobId)
        info.setErrorReason(errorReason)
        info.status == JobStatus.COMPLETED_FAILED
        info.errorReason != null


        jobResult.taskResults != null
        jobResult.taskResults.size() == 1

        def jobTaskExecutorResult = jobResult.taskResults.get(0)
        jobTaskExecutorResult != null

        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 3 //as we have total 3 steps as a part of config.
        // Checking with MongoDB data
        MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
        Document searchDocument = new Document();
        searchDocument.append("Column2", 4l);
        println("Document Filter: " + searchDocument);
        Document searchResult = resultCollection.find(searchDocument).first();
        println("Document Found: " + searchResult);
        println("record count: " + resultCollection.count());

        for (int i = 0; i < stepExecutionResults.size(); i++) {
            def stepExecutionResult = stepExecutionResults.get(i);
            if (stepExecutionResult != null && stepExecutionResult.getStepName().equalsIgnoreCase("Source")) {
                collectInboudDataCount(stepExecutionResult) == 1
                collectOutboudDataCount(stepExecutionResult) == 8

                collectInboudErrorCount(stepExecutionResult) == 0
                collectOutboudErrorCount(stepExecutionResult) == 0
            } else if (stepExecutionResult != null && stepExecutionResult.getStepName().equalsIgnoreCase("DB")) {
                collectInboudDataCount(stepExecutionResult) == 8
                collectOutboudDataCount(stepExecutionResult) == 8

                collectInboudErrorCount(stepExecutionResult) == 0
                collectOutboudErrorCount(stepExecutionResult) == 0
            } else {
                collectInboudDataCount(stepExecutionResult) == 0
                collectOutboudDataCount(stepExecutionResult) == 0

                collectInboudErrorCount(stepExecutionResult) == 0
                collectOutboudErrorCount(stepExecutionResult) == 0
            }
        }


        cleanup:
        eventManager.unRegisterReceiver(eventReceiver)

        jobResultService.clear()
        repositoryFactory.removeWorkflowConfigRepository(groupId)
        taskReceiver.stop()
        taskManagerAdmin.stop()
        server.stop()
    }

    def collectInboudDataCount(stepExecutionResult) {
        def totalInboudDataCount = 0

        stepExecutionResult.getInstanceStats().forEachValue { instanceStat ->
            totalInboudDataCount += instanceStat.getInbound().getDataCount()
        }
        return totalInboudDataCount
    }

    def collectOutboudDataCount(stepExecutionResult) {
        def totalOutboudDataCount = 0

        stepExecutionResult.getInstanceStats().forEachValue { instanceStat ->
            totalOutboudDataCount += instanceStat.getOutbound().getDataCount()
        }
        return totalOutboudDataCount
    }

    def collectInboudErrorCount(stepExecutionResult) {
        def totalInboudDataCount = 0

        stepExecutionResult.getInstanceStats().forEachValue { instanceStat ->
            totalInboudDataCount += instanceStat.getInbound().getErrorCount()
        }
        return totalInboudDataCount
    }

    def collectOutboudErrorCount(stepExecutionResult) {
        def totalOutboudDataCount = 0

        stepExecutionResult.getInstanceStats().forEachValue { instanceStat ->
            totalOutboudDataCount += instanceStat.getOutbound().getErrorCount()
        }
        return totalOutboudDataCount
    }

    def cleanupSpec() {
        if (mongod != null) {
            mongod.deleteTempFiles();
            mongod.stop();
        }
        if (mongodExecutable) {
            mongodExecutable.stop();
        }

    }


}
