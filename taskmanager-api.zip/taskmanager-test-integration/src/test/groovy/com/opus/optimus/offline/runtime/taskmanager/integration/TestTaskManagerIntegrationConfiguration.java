package com.opus.optimus.offline.runtime.taskmanager.integration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.map.repository.config.EnableMapRepositories;

import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
@ComponentScan ("com.opus.optimus.offline")
@EnableMapRepositories(mapType = WeakHashMap.class)
public class TestTaskManagerIntegrationConfiguration {

	@Bean
	ExecutorService getExecutorService() {
		return Executors.newCachedThreadPool();
	}
}
