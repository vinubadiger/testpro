package com.opus.optimus.offline.runtime.taskmanager.integration;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;

/**
 * @author prashant.dongare
 *
 */
@Repository
public interface JobErrorDetailsRepositoryTest extends MongoRepository<JobErrorDetails, String> {
	@Query("{ 'jobId' : ?0 }")
	JobErrorDetails findByjobId(String jobId);
	
}
