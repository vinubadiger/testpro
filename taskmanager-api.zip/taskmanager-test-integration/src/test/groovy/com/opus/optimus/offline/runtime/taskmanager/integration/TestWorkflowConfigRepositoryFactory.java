package com.opus.optimus.offline.runtime.taskmanager.integration;

import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepositoryFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class TestWorkflowConfigRepositoryFactory implements IWorkflowConfigRepositoryFactory {

    Map<String, IWorkflowConfigRepository> groupBasedRepository = new HashMap<>();

    public void addWorkflowConfigRepository(String groupId, IWorkflowConfigRepository repository) {
        groupBasedRepository.put(groupId, repository);
    }

    public void removeWorkflowConfigRepository(String groupId) {
        groupBasedRepository.remove(groupId);
    }

    @Override
    public IWorkflowConfigRepository create(String groupId) {
        return groupBasedRepository.get(groupId);
    }
}
