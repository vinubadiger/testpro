package com.opus.optimus.offline.runtime.taskmanager.integration;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;

@Repository
public interface JobInfoRepository extends CrudRepository<JobInfo, String> {}
