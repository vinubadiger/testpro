package com.opus.optimus.offline.runtime.taskmanager.integration

import com.opus.optimus.offline.runtime.taskmanager.api.IJobResultService
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult
import org.eclipse.collections.api.multimap.list.MutableListMultimap
import org.eclipse.collections.impl.factory.Multimaps
import org.springframework.stereotype.Component

@Component
class JobResultService implements IJobResultService {
    MutableListMultimap<String, JobTaskExecutorResult> jobTaskResults = Multimaps.mutable.list.empty().asSynchronized()

    @Override
    public JobResult findById(String jobId) {
        def executorResults = jobTaskResults.get(jobId)
        if (executorResults == null) {
            return null
        }

        return new JobResult(executorResults.asList())
    }


    @Override
    public JobResult saveJobTaskResult(String jobId, String jobTaskId, JobTaskExecutorResult jobTaskExecutorResult) {
        jobTaskResults.put(jobId, jobTaskExecutorResult)
        return null
    }

    public void clear() {
        jobTaskResults.clear()
    }
}
