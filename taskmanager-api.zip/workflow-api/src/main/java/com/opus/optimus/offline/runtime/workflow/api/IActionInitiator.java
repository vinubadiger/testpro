package com.opus.optimus.offline.runtime.workflow.api;

public interface IActionInitiator {
    String getJobId();

    String getJobTaskId();

    String getWorkflowName();

    String getStepName();

    String getStepType();
}
