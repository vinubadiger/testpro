package com.opus.optimus.offline.runtime.workflow.api;

public interface ICustomizableInBoundQueueSupport {
    String getQueueCreatorName();
}
