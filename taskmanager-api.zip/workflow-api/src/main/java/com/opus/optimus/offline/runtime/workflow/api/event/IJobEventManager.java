package com.opus.optimus.offline.runtime.workflow.api.event;

public interface IJobEventManager {
    IJobEventEmitter getEmitter();

    void registerReceiver(IJobEventReceiver receiver);

    void unRegisterReceiver(IJobEventReceiver receiver);
}
