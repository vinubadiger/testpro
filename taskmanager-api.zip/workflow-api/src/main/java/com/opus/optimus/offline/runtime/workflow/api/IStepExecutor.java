package com.opus.optimus.offline.runtime.workflow.api;

import java.util.concurrent.CompletableFuture;

public interface IStepExecutor<T> {
    CompletableFuture<T> start();

    void abort();
}
