package com.opus.optimus.offline.runtime.workflow.api;

import java.io.Serializable;

public interface IContext extends Serializable {

    // instance level variable

    // instance group level variable

    // job level variable

    // key based variable

}
