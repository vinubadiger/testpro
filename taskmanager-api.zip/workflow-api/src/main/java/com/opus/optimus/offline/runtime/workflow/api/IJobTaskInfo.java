package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.workflow.api.event.IMachine;

public interface IJobTaskInfo {
    IMachine getMachine();
    String getJobId();
    String getJobTaskId();
}
