package com.opus.optimus.offline.runtime.workflow.api;

public interface IJobActionEventListener {
    void onAbort(IActionInitiator actionInitiator, String reason, Exception exceptionIfAny,
                 ISourceReference sourceReferenceIfAny);
}
