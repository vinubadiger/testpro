package com.opus.optimus.offline.runtime.workflow.api;

import java.io.Serializable;

public interface IMessageFactory {
    IMessage createMessage(Serializable data);

    IMessage createMessage(MessageType type, Serializable data);

    IMessage createMessage(MessageType type, Serializable data, ISourceReference reference);

    IMessage createEndMessage();
}
