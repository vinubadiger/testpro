package com.opus.optimus.offline.runtime.workflow.api;

import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@ToString
public class StepInstanceStats {
    Long startTime = 0L;
    Long totalExecutionTime = 0L;

    LinkStats inbound;
    LinkStats outbound;

    IStepInstanceSummary stepLevelSummary;

    Map<String, Long> exceptionCounts = new HashMap<>();

    OperationStatus status;

    public void startExecutionTime() {
        startTime = System.currentTimeMillis();
    }

    public void stopExecutionTime() {
        totalExecutionTime = System.currentTimeMillis() - startTime;
    }

    public LinkStats getInbound() {
        return inbound;
    }

    public void setInbound(LinkStats inbound) {
        this.inbound = inbound;
    }

    public LinkStats getOutbound() {
        return outbound;
    }

    public void setOutbound(LinkStats outbound) {
        this.outbound = outbound;
    }

    public IStepInstanceSummary getStepLevelSummary() {
        return stepLevelSummary;
    }

    public void setStepLevelSummary(IStepInstanceSummary stepLevelSummary) {
        this.stepLevelSummary = stepLevelSummary;
    }

    public void incExceptionCount(String type) {
        Long exceptionCount = exceptionCounts.getOrDefault(type, 0L);
        exceptionCounts.put(type, exceptionCount + 1);
    }

    public boolean hasExceptions() {
        return exceptionCounts.size() > 0;
    }

    public OperationStatus getStatus() {
        return status;
    }

    public void setStatus(OperationStatus status) {
        this.status = status;
    }
}
