package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepCreator {
    IStep create(IStepConfig stepConfig);
}
