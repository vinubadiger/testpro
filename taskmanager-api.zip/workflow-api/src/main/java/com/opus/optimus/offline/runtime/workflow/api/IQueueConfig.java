package com.opus.optimus.offline.runtime.workflow.api;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

@JsonTypeInfo(use = NAME, property = "@type")
public interface IQueueConfig {
}
