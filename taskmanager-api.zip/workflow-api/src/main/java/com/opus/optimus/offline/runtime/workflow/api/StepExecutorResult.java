package com.opus.optimus.offline.runtime.workflow.api;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.collections.api.map.ImmutableMap;
import org.eclipse.collections.impl.factory.Maps;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@NoArgsConstructor
public class StepExecutorResult {
    long startTime;
    long totalExecutionTime;

    String workflowName;
    String stepName;
    String stepType;
    Map<Integer, StepInstanceStats> instanceStats = new ConcurrentHashMap<>();

    public StepExecutorResult(String workflowName, String stepName, String stepType) {
        this.workflowName = workflowName;
        this.stepName = stepName;
        this.stepType = stepType;
    }

    public void startExecutionTime() {
        startTime = System.currentTimeMillis();
    }

    public void stopExecutionTime() {
        totalExecutionTime = System.currentTimeMillis() - startTime;
    }

    public void addInstanceStats(Integer instanceId, StepInstanceStats stats) {
        instanceStats.put(instanceId, stats);
    }

    public ImmutableMap<Integer, StepInstanceStats> getInstanceStats() {
        return Maps.immutable.withAll(instanceStats);
    }

    public OperationStatus getStatus() {
        OperationStatus status = OperationStatus.COMPLETED;
        for (StepInstanceStats stats : instanceStats.values()) {
            if (stats.status.equals(OperationStatus.ERROR)) {
                return OperationStatus.ERROR;
            }

            if (stats.status.equals(OperationStatus.ABORTED)) {
                return OperationStatus.ABORTED;
            }

            if (stats.status.equals(OperationStatus.COMPLETED_WITH_ERRORS)) {
                status = OperationStatus.COMPLETED_WITH_ERRORS;
            }
        }

        return status;
    }
}
