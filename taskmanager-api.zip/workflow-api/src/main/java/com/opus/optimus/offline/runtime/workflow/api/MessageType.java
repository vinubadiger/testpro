package com.opus.optimus.offline.runtime.workflow.api;

public enum MessageType {
    DATA, ERROR, END
}
