package com.opus.optimus.offline.runtime.workflow.api;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

@JsonTypeInfo(use = NAME, property = "type")
public interface IStepLink {
    String getName();

    String getFrom();

    String getTo();

    int getPriority();

    boolean isErrorHandlingLink();

    IStepLinkConfig getConfig();

    IScriptConfig getCondition();
}
