package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepTaskCreatorFactory {
    IStepTaskCreatorBuilder getBuilder(String creatorName);
}
