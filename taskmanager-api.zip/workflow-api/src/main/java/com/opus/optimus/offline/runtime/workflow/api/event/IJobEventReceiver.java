package com.opus.optimus.offline.runtime.workflow.api.event;

public interface IJobEventReceiver {
    void onEvent(IJobEvent event);
}
