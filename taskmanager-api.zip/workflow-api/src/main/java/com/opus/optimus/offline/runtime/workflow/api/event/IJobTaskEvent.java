package com.opus.optimus.offline.runtime.workflow.api.event;

public interface IJobTaskEvent extends IJobEvent {
    String getJobTaskId();
}
