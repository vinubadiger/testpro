package com.opus.optimus.offline.runtime.workflow.api.event;

public interface IStepExecutorEvent extends IJobTaskEvent {
    String getWorkflowName();

    String getStepName();

    String getStepType();
}
