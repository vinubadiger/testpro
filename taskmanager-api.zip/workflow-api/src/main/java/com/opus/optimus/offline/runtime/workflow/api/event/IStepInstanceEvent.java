package com.opus.optimus.offline.runtime.workflow.api.event;

import com.opus.optimus.offline.runtime.workflow.api.StepInstanceStats;

public interface IStepInstanceEvent extends IStepExecutorEvent {
    int getInstanceId();

    StepInstanceStats getStats();
}
