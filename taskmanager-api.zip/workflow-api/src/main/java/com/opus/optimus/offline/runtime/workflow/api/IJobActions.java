package com.opus.optimus.offline.runtime.workflow.api;

public interface IJobActions {
    void abort(IActionInitiator actionInitiator, String reason, Throwable exceptionIfAny,
               ISourceReference sourceReferenceIfAny);
}
