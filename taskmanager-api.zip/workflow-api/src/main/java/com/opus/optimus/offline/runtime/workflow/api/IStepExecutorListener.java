package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepExecutorListener {
    void onGroupStart(String groupName);

    void onGroupEnd(String groupName);

    void onStepEnd(boolean forceEnd);
}
