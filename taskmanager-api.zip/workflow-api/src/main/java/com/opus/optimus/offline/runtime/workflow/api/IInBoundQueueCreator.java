package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.queue.api.IQueue;

public interface IInBoundQueueCreator<C extends IQueueConfig> {
    IQueue createQueue(C queueConfig, IStepConfig stepConfig);

    boolean isSharedQueue();

    C getDefaultConfig();
}
