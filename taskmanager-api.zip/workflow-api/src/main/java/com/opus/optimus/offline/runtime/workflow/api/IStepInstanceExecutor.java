package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepInstanceExecutor extends Runnable {
    int getInstanceId();

    void abort();

    void invokeStepEnd(boolean forceEnd);

    boolean supportStepEnd();
}
