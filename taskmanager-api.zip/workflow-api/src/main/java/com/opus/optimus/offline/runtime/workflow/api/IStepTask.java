package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IReceiver;

public interface IStepTask {
    String getType();

    Integer getId();

    String getWorkflowName();

    IStepConfig getStepConfig();

    IReceiver getReceiver();

    IEmitter getEmitter();
}
