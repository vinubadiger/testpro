package com.opus.optimus.offline.runtime.workflow.api.event;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

@JsonTypeInfo(use = NAME, property = "@type")
public interface IMachine {
    String getId();
}
