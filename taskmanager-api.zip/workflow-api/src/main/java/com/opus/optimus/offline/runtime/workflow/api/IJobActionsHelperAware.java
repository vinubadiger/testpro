package com.opus.optimus.offline.runtime.workflow.api;

public interface IJobActionsHelperAware {
    void setJobActionsHelper(IJobActionsHelper helper);
}
