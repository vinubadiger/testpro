package com.opus.optimus.offline.runtime.workflow.api;

import org.eclipse.collections.api.map.ImmutableMap;

import java.io.Serializable;

public interface IMessage extends Serializable {
    void setType(MessageType type);

    MessageType getType();

    <T extends Serializable> void addHeader(String name, T value);

    <T extends Serializable> T getHeaderValue(String name);

    ImmutableMap<String, Serializable> getHeader();

    void setData(Serializable data);

    Serializable getData();

    void setSourceReference(ISourceReference sourceReference);

    ISourceReference getSourceReference();
}
