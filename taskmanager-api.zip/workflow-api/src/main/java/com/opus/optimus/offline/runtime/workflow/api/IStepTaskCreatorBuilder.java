package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;

public interface IStepTaskCreatorBuilder {
    IStepTaskCreator buildWith(String workflowName, IStepConfig stepConfig,
                               IQueue inBoundQueue, IEmitter outBoundEmitter,
                               IStepExecutorConfig stepExecutorConfig);

    IStepExecutorConfig getDefaultStepExecutorConfig();
}
