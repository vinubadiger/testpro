package com.opus.optimus.offline.runtime.workflow.api.event;

public interface IJobEventEmitter {
    void emit(IJobEvent event);
}
