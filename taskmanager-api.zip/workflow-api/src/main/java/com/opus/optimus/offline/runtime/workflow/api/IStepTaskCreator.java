package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepTaskCreator {
    IStepConfig getStepConfig();

    boolean hasNext();

    IStepTask next();
}
