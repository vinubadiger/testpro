package com.opus.optimus.offline.runtime.workflow.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "JobResult")
public class JobTaskExecutorResult {
    String jobId;
    String jobTaskId;
    long startTime;
    long totalExecutionTime;
    List<StepExecutorResult> stepExecutorResults;
    String workflowName;
    String projectName;
    String workflowType;
    String groupId;

    String sourceFile;

    public JobTaskExecutorResult(String jobId1, String jobTaskId1) {
        this.jobId = jobId1;
        this.jobTaskId = jobTaskId1;
    }

    public void startExecutionTime() {
        this.startTime = System.currentTimeMillis();
    }

    public void stopExecutionTime() {
        this.totalExecutionTime = System.currentTimeMillis() - this.startTime;
    }

    public OperationStatus getStatus() {
        if (this.stepExecutorResults == null) {
            return null;
        }

        OperationStatus status = OperationStatus.COMPLETED;
        for (StepExecutorResult stepExecutorResult : this.stepExecutorResults) {
            if (stepExecutorResult == null) {
                continue;
            }

            OperationStatus stepExecutorResultStatus = stepExecutorResult.getStatus();
            if (stepExecutorResultStatus.equals(OperationStatus.ERROR)) {
                return OperationStatus.ERROR;
            }

            if (stepExecutorResultStatus.equals(OperationStatus.ABORTED)) {
                return OperationStatus.ABORTED;
            }

            if (stepExecutorResultStatus.equals(OperationStatus.COMPLETED_WITH_ERRORS)) {
                status = OperationStatus.COMPLETED_WITH_ERRORS;
            }
        }

        return status;
    }
}
