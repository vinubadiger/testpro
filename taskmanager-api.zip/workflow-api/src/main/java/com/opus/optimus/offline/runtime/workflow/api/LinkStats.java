package com.opus.optimus.offline.runtime.workflow.api;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class LinkStats {
    Long dataCount = 0L;
    Long errorCount = 0L;
    Long endCount = 0L;
    Long unknownCount = 0L;

    public void incDataCount() {
        dataCount += 1;
    }

    public void incErrorCount() {
        errorCount += 1;
    }

    public void incEndCount() {
        endCount += 1;
    }

    public void incUnknownCount() {
        unknownCount += 1;
    }
}
