package com.opus.optimus.offline.runtime.workflow.api;

public interface ITaskTrackingHandler {
    String getName();

    void addTask();

    void endTask(boolean forceEnd);

    boolean hasPendingTasks();

    int getPendingTaskCount();
}
