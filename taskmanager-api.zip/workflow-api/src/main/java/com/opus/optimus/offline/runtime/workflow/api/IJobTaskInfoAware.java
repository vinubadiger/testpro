package com.opus.optimus.offline.runtime.workflow.api;

public interface IJobTaskInfoAware {
    void setJobTaskInfo(IJobTaskInfo jobTaskInfo);
}
