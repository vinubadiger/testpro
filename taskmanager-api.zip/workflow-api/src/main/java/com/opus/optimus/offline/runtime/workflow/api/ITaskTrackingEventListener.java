package com.opus.optimus.offline.runtime.workflow.api;

public interface ITaskTrackingEventListener {
    void onTaskEnd(ITaskTrackingHandler handler, boolean forceEnd);

    void onTrackingEnd(ITaskTrackingHandler handler, boolean forceEnd);
}
