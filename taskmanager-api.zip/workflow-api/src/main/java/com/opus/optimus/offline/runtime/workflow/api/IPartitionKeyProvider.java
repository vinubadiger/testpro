package com.opus.optimus.offline.runtime.workflow.api;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

@JsonTypeInfo(use = NAME, property = "@type")
public interface IPartitionKeyProvider {
    <I extends Serializable, R extends Serializable> R getPartitionKey(I message);
}
