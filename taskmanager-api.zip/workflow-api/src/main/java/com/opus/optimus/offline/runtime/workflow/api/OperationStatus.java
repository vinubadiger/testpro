package com.opus.optimus.offline.runtime.workflow.api;

public enum OperationStatus {
    COMPLETED, COMPLETED_WITH_ERRORS, ABORTED, ERROR
}
