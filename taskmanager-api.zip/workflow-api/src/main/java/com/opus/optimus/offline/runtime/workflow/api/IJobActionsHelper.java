package com.opus.optimus.offline.runtime.workflow.api;

public interface IJobActionsHelper {
    void abort(String reason, Throwable exceptionIfAny, ISourceReference sourceReferenceIfAny);
}
