package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;

import java.util.List;

public interface IStep {
    String getName();

    void process(IMessage data, IEmitter emitter);

    void stop(boolean force);

    List<IDependency> getExecutionDependencies();

    IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter);

    void onStepEnd(boolean forceEnd, IEmitter emitter);
}
