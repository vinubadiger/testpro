package com.opus.optimus.offline.runtime.workflow.api;

public interface IStepInstanceExecutorListener {
    void onStart(int instanceId);

    void onEnd(int instanceId, StepInstanceStats stats);

    void onGroupStart(int instanceId, String groupReference);

    void onGroupEnd(int instanceId, String groupReference);

    boolean onNoMessage(int instanceId);

    boolean onEndMessage(int instanceId);

    boolean onException(int instanceId, IMessage message, StepInstanceStats stats, Exception exception);
}
