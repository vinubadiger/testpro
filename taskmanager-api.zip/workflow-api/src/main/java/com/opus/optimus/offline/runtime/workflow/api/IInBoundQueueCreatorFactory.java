package com.opus.optimus.offline.runtime.workflow.api;

public interface IInBoundQueueCreatorFactory {
    IInBoundQueueCreator getCreator(String creatorName);
}
