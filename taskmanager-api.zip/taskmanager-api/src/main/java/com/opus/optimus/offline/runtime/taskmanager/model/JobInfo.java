package com.opus.optimus.offline.runtime.taskmanager.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document (collection = "JobInfo")
public class JobInfo {
	@Id
	String id;
	String name;
	JobStatus status;
	List<JobTask> jobTasks;
	String workflowName;
	String projectName;
	String workflowType;
	String groupId;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	Date createdTime;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	Date startedTime;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
	Date finishedTime;

	long processingTime;

	List<JobStatistics> jobStatistics;
	long readCount; // FileReader's outbound's dataCount + errorCount
	long skippedCount; // Has to be fetched from Step-instance Summary
	long errorCount; // Sum of all steps' Error count
	long loadCount; // Writers inbound's dataCount

	SourceInfo sourceInfo;

	ErrorReason errorReason;
}
