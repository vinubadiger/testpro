package com.opus.optimus.offline.runtime.taskmanager.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class JobStatistics {
	String stepName;
	String stepType;
	long processedCount;
	long errorCount;
}
