package com.opus.optimus.offline.runtime.taskmanager.model;

import lombok.Data;

@Data
public class ErrorReason {
	String errorCode; // code
	String exceptionType;// ReasonCode readable
}
