package com.opus.optimus.offline.runtime.taskmanager.exception;

public class CustomException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String errorMessage;
	int errorCode;

	public CustomException(String errorMessage, int errorCode) {
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
	}

}
