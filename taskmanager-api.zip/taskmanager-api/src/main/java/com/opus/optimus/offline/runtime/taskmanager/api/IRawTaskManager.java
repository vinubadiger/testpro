package com.opus.optimus.offline.runtime.taskmanager.api;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

public interface IRawTaskManager {
    void start();

    void stop();

    String generateJobId();

    CompletableFuture<Void> submitJob(String jobId, List<JobTask> jobTask);

    void cancelJob(String jobId);

    void addListener(IRawTaskManagerListener listener);

    void removeListener(IRawTaskManagerListener listener);
}
