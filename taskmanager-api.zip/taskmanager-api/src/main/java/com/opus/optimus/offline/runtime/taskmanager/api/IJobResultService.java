package com.opus.optimus.offline.runtime.taskmanager.api;

import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

public interface IJobResultService {
	JobResult findById(String jobId);

	JobResult saveJobTaskResult(String jobId, String jobTaskId, JobTaskExecutorResult jobTaskExecutorResult);
}
