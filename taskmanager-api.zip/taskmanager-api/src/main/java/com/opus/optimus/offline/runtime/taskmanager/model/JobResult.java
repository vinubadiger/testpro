package com.opus.optimus.offline.runtime.taskmanager.model;

import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobResult {
    List<JobTaskExecutorResult> taskResults;
}
