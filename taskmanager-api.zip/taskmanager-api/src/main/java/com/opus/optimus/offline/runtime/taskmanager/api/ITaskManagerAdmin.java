package com.opus.optimus.offline.runtime.taskmanager.api;

public interface ITaskManagerAdmin {
    void start();

    void stop();
}
