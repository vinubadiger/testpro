package com.opus.optimus.offline.runtime.taskmanager.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobTask {
    String taskId;
    ExecutionInfo executionInfo;

//    List<JobTask> nextTasks; - Reserved for future requirements
}
