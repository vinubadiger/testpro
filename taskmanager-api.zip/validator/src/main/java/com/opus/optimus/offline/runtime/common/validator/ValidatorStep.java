package com.opus.optimus.offline.runtime.common.validator;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.validator.ValidatorConfig;
import com.opus.optimus.offline.config.validator.ValidatorStepConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * The Class ValidatorStep.
 *
 * @author Manjusha.Dhamdhere
 */

@Component(StepTypeConstants.VALIDATOR_STEPTYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ValidatorStep extends MapStep<ValidatorStepConfig> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ValidatorStep.class);
	
	/** The hash map for script configurations  */
	private Map<IScript, String> scriptConfigs;

	/** The script creator factory. */
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	/**
	 * Instantiates a new validator step.
	 *
	 * @param config the validator configuration object 
	 */
	public ValidatorStep(ValidatorStepConfig config) {
		super(config);
	}

	/**
	 * Initializing the vaidator step
	 */
	@PostConstruct
	public void init() {
		scriptConfigs = new HashMap<IScript, String>();
		
		this.scriptConfigs = config.getValidators().stream().collect(
				Collectors.toMap(e -> scriptCreatorFactory.createScript(e.getScriptConfig()), ValidatorConfig::getErrorDesc));
		
		/*config.getValidatorScripts().forEach(validatorScriptConfig -> {
			this.scriptConfigs.put(scriptCreatorFactory.createScript(validatorScriptConfig),
					validatorScriptConfig.getErrorDesc());
		});*/

	}

	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		final StringBuilder validationErrors = new StringBuilder(); 

		this.scriptConfigs.forEach((scripts, errorMessage) -> {

			if (!(Boolean) scripts.execute((IRecord) data)) {
				validationErrors.append(errorMessage);
				validationErrors.append(" , ");
			}
		});
		
		if (!StringUtils.isEmpty(validationErrors.toString())) {
			logger.error("Validation Error Found: {}", validationErrors);
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails(validationErrors.toString()).build();
			throw new RecordProcessingException(errorDetails);
		}

		return (R) data;
	}
}
