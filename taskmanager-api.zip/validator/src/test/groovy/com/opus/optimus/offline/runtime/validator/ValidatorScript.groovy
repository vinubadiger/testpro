package com.opus.optimus.offline.runtime.validator


import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.script.api.IScript
import com.opus.optimus.offline.runtime.validator.script.TestValidatorScriptConfig

class ValidatorScript implements IScript<IRecord, Boolean> {
	private TestValidatorScriptConfig config;

	ValidatorScript(TestValidatorScriptConfig config) {
		this.config = config
	}

	@Override
	Boolean execute(IRecord record) {
		int fieldIndex = record.getFieldId(config.getFieldName());
		Object recordValue = record.getValue(fieldIndex);
		
		if(recordValue.equals(config.getValue())) {
			return true
		} else {
			return false
		}
	}
}
