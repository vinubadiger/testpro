package com.opus.optimus.offline.runtime.validator.script;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.Data;

/**
 * This is the test validator script which check the field value with the provided value. this is conditional type of script config
 * @author Manjusha.Dhamdhere
 *
 */
@Data
public class TestValidatorScriptConfig implements IScriptConfig {
	
	private String type;
	private String fieldName;
	private Object value;

}
