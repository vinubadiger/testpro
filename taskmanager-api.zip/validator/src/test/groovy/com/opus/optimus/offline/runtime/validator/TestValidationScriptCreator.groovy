package com.opus.optimus.offline.runtime.validator

import org.springframework.stereotype.Component

import com.opus.optimus.offline.config.validator.ValidatorConfig
import com.opus.optimus.offline.runtime.script.api.IScript
import com.opus.optimus.offline.runtime.script.api.IScriptConfig
import com.opus.optimus.offline.runtime.script.api.IScriptCreator

@Component("test-validator-script")
class TestValidationScriptCreator implements IScriptCreator {
	@Override
	IScript create(IScriptConfig config) {
		return new ValidatorScript(config);
	}
}
