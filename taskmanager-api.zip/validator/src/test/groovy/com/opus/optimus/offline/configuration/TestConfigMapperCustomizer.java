package com.opus.optimus.offline.configuration;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;
import com.opus.optimus.offline.runtime.validator.script.TestValidatorScriptConfig;

@Component
public class TestConfigMapperCustomizer implements IMapperCustomizer<ObjectMapper> {

	@Override
	public void customize(ObjectMapper mapper) {
        mapper.registerSubtypes(new NamedType(TestValidatorScriptConfig.class, "test-validator-script"));
	}
}
