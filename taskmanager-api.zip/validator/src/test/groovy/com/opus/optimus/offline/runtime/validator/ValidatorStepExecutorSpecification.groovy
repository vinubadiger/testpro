package com.opus.optimus.offline.runtime.validator

import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder

import java.util.concurrent.Executors
import java.util.concurrent.TimeoutException

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.validator.ValidatorStepConfig
import com.opus.optimus.offline.configuration.TestValidatorConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.validator.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.validator.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import spock.lang.Specification

@ContextConfiguration(classes = TestValidatorConfiguration.class)
class ValidatorStepExecutorSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	@Qualifier("validatorUtility")
	Utility utility;

	@Autowired
	MapperFactory mapperFactory

	def "Validator step execution - Valid Condition "() {
		setup:

		def validatorConfig = new ValidatorStepConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Validator.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		validatorConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("transRef")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("transAmount")
				.type(FieldType.FLOAT)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [validatorConfig]

		def executorService = Executors.newCachedThreadPool()

		def localJobTaskExecutor = executorBuilder.buildWith("JOB2", "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("validatorStepDemo").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "samsonData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("transRef", "000000002");
		testRecordFieldValues.put("transAmount", "300");

		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("validatorStepDemo").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 1

		println()
		JobTaskExecutorResult != null
		def stepExecutionResults = JobTaskExecutorResult.stepExecutorResults
		stepExecutionResults != null
		println(stepExecutionResults .getClass())
		stepExecutionResults.size() == 1
		1 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
		0 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.errorCount }
		println JobTaskExecutorResult
	}

	//	Test 2
	def "Validator step execution - Invalid Condition "() {
		setup:

		def validatorConfig = new ValidatorStepConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Validator.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		validatorConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("transRef")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("transAmt")
				.type(FieldType.FLOAT)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [validatorConfig]

		def executorService = Executors.newCachedThreadPool()

		def localJobTaskExecutor = executorBuilder.buildWith("JOB2", "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("validatorStepDemo").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "samsonData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("transRef", "000000001");
		testRecordFieldValues.put("transAmt", "250");

		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("validatorStepDemo").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		//		For Invalid data no record will be returned
		receivedData.size() == 0

		println()
		JobTaskExecutorResult != null
		def stepExecutionResults = JobTaskExecutorResult.stepExecutorResults
		stepExecutionResults != null
		println(stepExecutionResults .getClass())
		stepExecutionResults.size() == 1
		0 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
		1 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.errorCount }
		println JobTaskExecutorResult
	}
	
	def "Validator step execution - Excel Script Condition "() {
		setup:

		def validatorConfig = new ValidatorStepConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/ValidatorWithExcelScript.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		validatorConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("transType")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("transAmt")
				.type(FieldType.FLOAT)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [validatorConfig]

		def executorService = Executors.newCachedThreadPool()

		def localJobTaskExecutor = executorBuilder.buildWith("JOB2", "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("validatorStepDemo").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "samsonData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("transType", "settlement");
		testRecordFieldValues.put("transAmt", "350");

		//record 2
		Map<String, Object> testRecordFieldValues1 = new HashMap<>();
		testRecordFieldValues1.put("transType", "settlement");
		testRecordFieldValues1.put("transAmt", "360");
		
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");
		IRecord record1 = utility.buildRecord(recordFieldConfigs, testRecordFieldValues1, "samsonData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createMessage(record1))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("validatorStepDemo").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 1

		println()
		JobTaskExecutorResult != null
		def stepExecutionResults = JobTaskExecutorResult.stepExecutorResults
		stepExecutionResults != null
		println(stepExecutionResults .getClass())
		stepExecutionResults.size() == 1
		1 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
		1 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.errorCount }
		println JobTaskExecutorResult
	}

}
