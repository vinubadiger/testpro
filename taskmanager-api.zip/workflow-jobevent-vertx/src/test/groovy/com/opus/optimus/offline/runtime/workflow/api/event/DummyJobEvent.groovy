package com.opus.optimus.offline.runtime.workflow.api.event

class DummyJobEvent implements IJobEvent {
    long time;
    String eventType;
    IMachine machine;
    String jobId;
    String message;

    DummyJobEvent() {
    }

    DummyJobEvent(String message) {
        this.message = message
    }

    long getTime() {
        return time
    }

    void setTime(long time) {
        this.time = time
    }

    String getEventType() {
        return eventType
    }

    void setEventType(String eventType) {
        this.eventType = eventType
    }

    IMachine getMachine() {
        return machine
    }

    void setMachine(IMachine machine) {
        this.machine = machine
    }

    String getJobId() {
        return jobId
    }

    void setJobId(String jobId) {
        this.jobId = jobId
    }

    String getMessage() {
        return message
    }

    void setMessage(String message) {
        this.message = message
    }
}
