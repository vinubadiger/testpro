package com.opus.optimus.offline.runtime.workflow.api.event

import com.opus.optimus.offline.runtime.workflow.api.event.impl.StepExecutorEvent
import com.opus.optimus.offline.runtime.workflow.api.event.impl.StepInstanceEvent
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification
import spock.util.concurrent.BlockingVariable

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@ContextConfiguration(classes = TestWorkflowVertxConfiguration.class)
class VertxJobEventManagerSpecification extends Specification {
    @Autowired
    IJobEventManager eventManager

    def "Test PubSub"() {
        when:
        def messages = []
        def blocking = new BlockingVariable<Boolean>(10)
        def eventReceiver = { evt -> messages.add(evt); blocking.set(true); }
        eventManager.registerReceiver(eventReceiver)

        then:
        eventManager.getEmitter().emit(new DummyJobEvent("Message 1"))
        blocking.get()

        messages.size() == 1
        messages.get(0).message == "Message 1"
    }

    def "Test workflow events"() {
        when:
        def messages = []
        def countDownLatch = new CountDownLatch(2)
        def eventReceiver = { evt -> messages.add(evt); countDownLatch.countDown(); }
        eventManager.registerReceiver(eventReceiver)

        then:
        def stepExecutionEvent = new StepExecutorEvent()
        stepExecutionEvent.setStepName "Step 1"
        stepExecutionEvent.setJobId "Job Id 1"
        eventManager.getEmitter().emit(stepExecutionEvent)

        def stepInstanceEvent = new StepInstanceEvent()
        stepInstanceEvent.setStepName "Step 2"
        stepInstanceEvent.setJobId "Job Id 2"
        stepInstanceEvent.setInstanceId 3
        eventManager.getEmitter().emit(stepInstanceEvent)

        countDownLatch.await(3, TimeUnit.SECONDS)

        messages.size() == 2

        def stepInstanceEvents = messages.grep { it instanceof StepInstanceEvent }
        stepInstanceEvents.size() == 1
        with(stepInstanceEvents.get(0)) {
            stepName == stepInstanceEvent.stepName
            instanceId == stepInstanceEvent.instanceId
        }

        messages.removeAll { it instanceof StepInstanceEvent }
        messages.size() == 1
        with(messages.get(0)) {
            stepName == stepExecutionEvent.stepName
        }
    }


}
