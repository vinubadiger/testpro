package com.opus.optimus.offline.runtime.workflow.api.event;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan ("com.opus.optimus.offline.runtime")
public class TestWorkflowVertxConfiguration {
}
