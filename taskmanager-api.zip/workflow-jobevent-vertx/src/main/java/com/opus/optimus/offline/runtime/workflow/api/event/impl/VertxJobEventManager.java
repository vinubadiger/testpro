package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventReceiver;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.eventbus.MessageConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class VertxJobEventManager implements IJobEventManager, IJobEventEmitter {
    public static final String ADDRESS = "JOB_EVENTS";

    private EventBus eventBus;
    private Map<IJobEventReceiver, MessageConsumer<String>> consumers = new ConcurrentHashMap<>();

    @Autowired
    MapperFactory mapperFactory;

    public VertxJobEventManager() {
        eventBus = Vertx.vertx().eventBus();
    }

    @Override
    public IJobEventEmitter getEmitter() {
        return this;
    }

    @Override
    public void registerReceiver(IJobEventReceiver receiver) {
        MessageConsumer<String> consumer = eventBus.consumer(ADDRESS, message -> receiver.onEvent(convertToPojo(message.body())));
        consumers.put(receiver, consumer);
    }

    @Override
    public void unRegisterReceiver(IJobEventReceiver receiver) {
        MessageConsumer<String> messageConsumer = consumers.get(receiver);
        if (messageConsumer != null) {
            messageConsumer.unregister();
        }
    }

    @Override
    public void emit(IJobEvent event) {
        String eventString = convertToJson(event);
        if (eventString != null) {
            eventBus.publish(ADDRESS, eventString);
        }
    }

    private String convertToJson(IJobEvent event) {
        ObjectMapper mapper = mapperFactory.getMapper();
        try {
            return mapper.writeValueAsString(event);
        } catch (JsonProcessingException e) {
            e.printStackTrace();    // TODO log
        }

        return null;
    }

    private IJobEvent convertToPojo(String data) {
        ObjectMapper mapper = mapperFactory.getMapper();

        try {
            return mapper.readValue(data, IJobEvent.class);
        } catch (IOException e) {
            e.printStackTrace();    // TODO log
        }

        return null;
    }
}
