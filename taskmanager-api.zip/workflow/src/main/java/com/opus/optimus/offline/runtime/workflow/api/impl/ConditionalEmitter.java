package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;
import java.util.List;

import org.eclipse.collections.api.tuple.Pair;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

public class ConditionalEmitter implements IEmitter {
    List<Pair<IScript<IMessage, Boolean>, IEmitter>> conditionBasedEmitters;
    boolean stopOnHit;

    public ConditionalEmitter(List<Pair<IScript<IMessage, Boolean>, IEmitter>> conditionBasedEmitters) {
        this(conditionBasedEmitters, true);
    }

    public ConditionalEmitter(List<Pair<IScript<IMessage, Boolean>, IEmitter>> conditionBasedEmitters, boolean stopOnHit) {
        this.conditionBasedEmitters = conditionBasedEmitters;
        this.stopOnHit = stopOnHit;
    }

    @Override
    public <T extends Serializable> void emit(T data) {
        for (Pair<IScript<IMessage, Boolean>, IEmitter> conditionBasedEmitter : conditionBasedEmitters) {
            IScript condition = conditionBasedEmitter.getOne();
            if (condition.execute(data).equals(false)) {
                continue;
            }

            IEmitter emitter = conditionBasedEmitter.getTwo();
            emitter.emit(data);

            if (stopOnHit == true) {
                return;
            }
        }
    }

    @Override
    public <T extends Serializable> void end(T data) {
        for (Pair<IScript<IMessage, Boolean>, IEmitter> conditionBasedEmitter : conditionBasedEmitters) {
            IEmitter emitter = conditionBasedEmitter.getTwo();
            emitter.end(data);
        }
    }

}
