package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import com.opus.optimus.offline.runtime.workflow.api.StepInstanceStats;
import com.opus.optimus.offline.runtime.workflow.api.event.IStepInstanceEvent;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class StepInstanceEvent extends StepExecutorEvent implements IStepInstanceEvent {
    int instanceId;
    StepInstanceStats stats;
}
