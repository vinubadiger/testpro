package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper;

public interface IJobEventEmitterHelperAware {
    void setJobEventEmitterHelper(JobEventEmitterHelper helper);
}
