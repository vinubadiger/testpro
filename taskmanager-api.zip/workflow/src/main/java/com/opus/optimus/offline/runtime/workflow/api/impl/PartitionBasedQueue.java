package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.*;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueue;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueueConfig;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionKeyProvider;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionReceiverConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PartitionBasedQueue implements IQueue, IEmitter {
    private static final Logger logger = LoggerFactory.getLogger(PartitionBasedQueue.class);

    PartitionBasedQueueConfig config;
    IPartitionKeyProvider keyProvider;

    List<IQueue> queues;
    List<IEmitter> emitters;

    public PartitionBasedQueue(PartitionBasedQueueConfig config, IPartitionKeyProvider keyProvider) {
        this.config = config;
        this.keyProvider = (keyProvider == null) ? new RandomPartitionKeyProvider() : keyProvider;

        LocalQueueConfig localQueueConfig = config.getLocalQueueConfig() == null ? LocalJobTaskExecutor.DEFAULT_LOCAL_QUEUE_CONFIG : config.getLocalQueueConfig();
        queues = IntStream.range(0, config.getNoOfPartitions())
                .mapToObj((index) -> new LocalQueue(localQueueConfig))
                .collect(Collectors.toList());

        emitters = queues.stream()
                .map(queue -> queue.getEmitter(null))  // TODO need to change this for remote queues
                .collect(Collectors.toList());
    }

    @Override
    public IReceiver getReceiver(IReceiverConfig receiverConfig) {
        if (receiverConfig instanceof IPartitionReceiverConfig) {
            int partitionId = ((IPartitionReceiverConfig) receiverConfig).getPartitionId();
            if (partitionId >= config.getNoOfPartitions()) {
                logger.error("Invalid partition index({}) mentioned to get receiver", partitionId);
                return null;
            }

            return queues.get(partitionId).getReceiver(receiverConfig);
        }

        logger.error("Invalid receiver config type ({}) to get receiver index({}) mentioned to get receiver",
                receiverConfig == null ? "NULL" : receiverConfig.getClass().getCanonicalName());
        return null;
    }

    @Override
    public IEmitter getEmitter(IEmitterConfig emitterConfig) {
        return this;
    }

    @Override
    public <T extends Serializable> void emit(T data) {
        Serializable partitionKey = keyProvider.getPartitionKey(data);

        int partitionIndex = config.getPartitionIdentifier().getPartitionIndex(partitionKey);
        if (partitionIndex >= config.getNoOfPartitions()) {
            logger.error("Invalid partition index({}) for data {}", partitionIndex, data);
            return;
        }

        emitters.get(partitionIndex).emit(data);
    }

    @Override
    public <T extends Serializable> void end(T data) {
        emitters.stream().forEach(emitter -> emitter.end(data));
    }
}
