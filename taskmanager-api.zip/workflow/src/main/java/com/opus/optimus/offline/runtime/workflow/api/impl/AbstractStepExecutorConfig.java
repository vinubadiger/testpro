package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public abstract class AbstractStepExecutorConfig implements IStepExecutorConfig {
    int maxNoOfTasks;
    int maxNoOfConcurrentTasks;
}
