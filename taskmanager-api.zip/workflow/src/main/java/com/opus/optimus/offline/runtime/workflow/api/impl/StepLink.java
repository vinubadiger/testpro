package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import com.opus.optimus.offline.runtime.workflow.api.IStepLinkConfig;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StepLink implements IStepLink {
    String name;
    String from;
    String to;
    String type;
    int priority = 0;
    boolean errorHandlingLink;
    IStepLinkConfig config; // Not used
    IScriptConfig condition;
    boolean stopOnHit = false;  // TODO remove

    public StepLink(String from, String to) {
        this(from, to, null);
    }

    public StepLink(String from, String to, IScriptConfig condition) {
        this(from, to, condition, false);
    }

    public StepLink(String from, String to, IScriptConfig condition, boolean stopOnHit) {
        this(from + "$" + to, from, to, 0, null, condition, stopOnHit);
    }

    public StepLink(String name, String from, String to, int priority, IStepLinkConfig config, IScriptConfig condition, boolean stopOnHit) {
        this.name = name;
        this.from = from;
        this.to = to;
        this.priority = priority;
        this.config = config;
        this.condition = condition;
        this.stopOnHit = stopOnHit;
    }

    public StepLink setErrorHandlingLink(boolean errorHandlingLink) {
        this.errorHandlingLink = errorHandlingLink;
        return this;
    }
}
