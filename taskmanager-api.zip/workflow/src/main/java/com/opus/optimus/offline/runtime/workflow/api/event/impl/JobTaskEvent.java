package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobTaskEvent;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class JobTaskEvent extends JobEvent implements IJobTaskEvent {
    String jobTaskId;
    OperationStatus status;
}
