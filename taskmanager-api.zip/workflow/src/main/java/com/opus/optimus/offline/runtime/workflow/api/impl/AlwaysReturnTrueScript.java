package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

public class AlwaysReturnTrueScript implements IScript<IMessage, Boolean> {
    @Override
    public Boolean execute(IMessage data) {
        return true;
    }
}
