package com.opus.optimus.offline.runtime.workflow.exception;

public enum Severity {
	ERROR, FATAL;
}
