package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueueConfig;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionIdentifier;
import com.opus.optimus.offline.runtime.workflow.api.IQueueConfig;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class PartitionBasedQueueConfig implements IQueueConfig {
    int noOfPartitions;
    IPartitionIdentifier partitionIdentifier;
    LocalQueueConfig localQueueConfig;  // Need to change this to IQueueConfig
}
