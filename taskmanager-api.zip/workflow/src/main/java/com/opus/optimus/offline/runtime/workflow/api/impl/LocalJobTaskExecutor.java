package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.eclipse.collections.api.map.MutableMap;
import org.eclipse.collections.api.multimap.list.MutableListMultimap;
import org.eclipse.collections.api.tuple.Pair;
import org.eclipse.collections.impl.factory.Maps;
import org.eclipse.collections.impl.factory.Multimaps;
import org.eclipse.collections.impl.tuple.Tuples;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueue;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueueConfig;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IActionInitiator;
import com.opus.optimus.offline.runtime.workflow.api.ICustomizableInBoundQueueSupport;
import com.opus.optimus.offline.runtime.workflow.api.ICustomizableTaskCreatorSupport;
import com.opus.optimus.offline.runtime.workflow.api.ICustomizeErrorHandlingSupport;
import com.opus.optimus.offline.runtime.workflow.api.IEmbeddedSubWorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreator;
import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IJobActions;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IQueueConfig;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepExecutor;
import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorBuilder;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.StepExecutorResult;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class LocalJobTaskExecutor implements IJobActions {
	private static final Logger logger = LoggerFactory.getLogger(LocalJobTaskExecutor.class);
    public static final LocalQueueConfig DEFAULT_LOCAL_QUEUE_CONFIG = new LocalQueueConfig(1024, 100);
    public static final IStepExecutorConfig DEFAULT_STEP_EXECUTION_CONFIG = new LocalStepExecutorConfig(4, 4, DEFAULT_LOCAL_QUEUE_CONFIG);
    public static final IScript<IMessage, Boolean> DEFAULT_LINK_SCRIPT = new AlwaysReturnTrueScript();
    private static final String DEFAULT_STEP_TASK_CREATOR_NAME = "static";

    @Autowired
    StepInstanceExecutorCreatorFactory instanceExecutorCreatorFactory;

    @Autowired
    ExecutorService executorService;

    @Autowired
    ScriptCreatorFactory scriptCreatorFactory;

    @Autowired
    IStepTaskCreatorFactory stepTaskCreatorFactory;

    @Autowired
    IInBoundQueueCreatorFactory inBoundQueueCreatorFactory;

    String jobId;
    String jobTaskId;
    JobConfig jobConfig;
    CachedWorkflowConfigRepository workflowConfigRepository;
    JobEventEmitterHelper jobEventEmitterHelper;
    JobActionsHelper jobActionsHelper;
    private boolean testEnabled = false;

    MutableMap<String, WorkflowConfigHelper> workflowConfigHelpers = Maps.mutable.empty();
    MutableMap<Pair<String, String>, IQueue> inBoundQueues = Maps.mutable.empty();
    MutableListMultimap<Pair<String, String>, IQueue> outBoundQueues = Multimaps.mutable.list.empty();
    MutableMap<Pair<String, String>, IEmitter> outBoundEmitters = Maps.mutable.empty();
    Pair<String, String> globalErrorStartStep;
    int globalErrorStartInLinkCount = 0;
    JobTaskExecutorResult taskExecutorResult;
    List<IStepExecutor> allStepExecutors = new ArrayList<>();
    Map<Pair<String, String>, Pair<String, String>> inBoundQueueRemapping = new HashMap<>();
    Map<Pair<String, String>, Pair<String, String>> outBoundQueueRemapping = new HashMap<>();

    LocalJobTaskExecutor(String jobId, String jobTaskId, JobConfig jobConfig, IWorkflowConfigRepository workflowConfigRepository) {
        this.jobId = jobId;
        this.jobTaskId = jobTaskId;
        this.jobConfig = jobConfig;
        this.workflowConfigRepository = new CachedWorkflowConfigRepository(workflowConfigRepository);
    }

    LocalJobTaskExecutor(String jobId, String jobTaskId, WorkflowConfig workflowConfig, WorkflowExecutionConfig workflowExecutionConfig) {
        this(jobId, jobTaskId, new JobConfig(workflowConfig.getName(), null),
                new InMemoryWorkflowConfigRepository()
                        .addWorkflowConfig(workflowConfig)
                        .addWorkflowExecutionConfig(jobTaskId, workflowConfig.getName(), workflowExecutionConfig));
    }

    public CompletableFuture<JobTaskExecutorResult> execute() {
    	logger.debug("LocalJobTaskExecutor execute()");
        taskExecutorResult = new JobTaskExecutorResult(jobId, jobTaskId);
        taskExecutorResult.startExecutionTime();

        jobEventEmitterHelper = jobEventEmitterHelper.createNew()
                .jobId(jobId)
                .jobTaskId(jobTaskId)
                .build();

        jobEventEmitterHelper.startJobTaskExecutor();

        if (jobActionsHelper == null) {
            jobActionsHelper = new JobActionsHelper(this);
        }
        jobActionsHelper = jobActionsHelper.createNew()
                .jobId(jobId)
                .jobTaskId(jobTaskId)
                .build();

        globalErrorStartStep = getGlobalErrorHandlingWorkflowStartStep();

        Map<Pair<String, String>, Boolean> stepsToRun = getStepsToRun();
        stepsToRun.entrySet().stream()
                .forEach(this::createAndAddInBoundQueueIfRequired);

        stepsToRun.entrySet().stream()
                .forEach(this::createAndAddOutBoundEmitter);

        /*List<Future<Boolean>> */
        List<Future<StepExecutorResult>> executorCompletionStatus = stepsToRun.entrySet().stream()
                .flatMap(this::createStepExecutor)
                .map(this::startExecutor)
                .collect(Collectors.toList());

        CompletableFuture<Void> result = CompletableFuture.allOf(executorCompletionStatus.toArray(new CompletableFuture[executorCompletionStatus.size()]));
        logger.debug("LocalJobTaskExecutor execute triggered. waiting for result...");
        return result.thenApply((v) -> {
        	logger.debug("LocalJobTaskExecutor execute completed. Result received.");
        	List<StepExecutorResult> stepExecutorResults = executorCompletionStatus.stream().map(r -> {
                try {
                    return r.get();
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
                return null;
            }).collect(Collectors.toList());
            taskExecutorResult.stopExecutionTime();
            taskExecutorResult.setStepExecutorResults(stepExecutorResults);
            jobEventEmitterHelper.endJobTaskExecutor(taskExecutorResult.getStatus());
            return taskExecutorResult;
        });
    }

    private Pair<String, String> getGlobalErrorHandlingWorkflowStartStep() {
        String globalErrorHandlingWorkflowName = jobConfig.getGlobalErrorHandlingWorkflowName();
        if (StringUtils.isEmpty(globalErrorHandlingWorkflowName)) {
            return null;
        }

        WorkflowConfig config = workflowConfigRepository.getConfig(globalErrorHandlingWorkflowName);
        String startStepName = config.getStartStepName();
        startStepName = StringUtils.isEmpty(startStepName) ? WorkflowConfig.DEFAULT_START_STEP_NAME : startStepName;

        WorkflowConfigHelper configHelper = new WorkflowConfigHelper(config);
        IStepConfig startStepConfig = configHelper.getStepConfig(startStepName);
        if (startStepConfig == null) {
            throw new RuntimeException("Start step not mentioned for global error handling workflow - " + globalErrorHandlingWorkflowName);
        }

        return Tuples.pair(globalErrorHandlingWorkflowName, startStepConfig.getStepName());
    }

    private Future<StepExecutorResult> startExecutor(IStepExecutor executor) {
        return executor.start();
    }

    private synchronized Stream<IStepExecutor> createStepExecutor(Map.Entry<Pair<String, String>, Boolean> stepToRun) {
        Pair<String, String> stepIdentifier = stepToRun.getKey();
        String workflowName = stepIdentifier.getOne();
        String stepName = stepIdentifier.getTwo();
        IStepConfig stepConfig = getStepConfig(workflowName, stepName);
        if (stepConfig instanceof IEmbeddedSubWorkflowConfig) {
            return Stream.empty();
        }

        IStepTaskCreator stepTaskCreator = null;
        String stepTaskCreatorName = DEFAULT_STEP_TASK_CREATOR_NAME;
        if (stepConfig instanceof ICustomizableTaskCreatorSupport) {
            stepTaskCreatorName = ((ICustomizableTaskCreatorSupport) stepConfig).getStepTaskCreatorName();
        }

        IStepTaskCreatorBuilder builder = stepTaskCreatorFactory.getBuilder(stepTaskCreatorName);
        IStepExecutorConfig stepExecutorConfig = getStepExecutorConfig(stepToRun.getKey());
        stepExecutorConfig = stepExecutorConfig == null ? builder.getDefaultStepExecutorConfig() : stepExecutorConfig;

        Pair<String, String> inBoundRemapStepIdentifier = inBoundQueueRemapping.get(stepIdentifier);
        IQueue inBoundQueue = (inBoundRemapStepIdentifier != null) ? inBoundQueues.get(inBoundRemapStepIdentifier) : inBoundQueues.get(stepIdentifier);

        Pair<String, String> outBoundRemapStepIdentifier = outBoundQueueRemapping.get(stepIdentifier);
        IEmitter outEmitter = (outBoundRemapStepIdentifier != null) ? outBoundEmitters.get(outBoundRemapStepIdentifier) : outBoundEmitters.get(stepIdentifier);

        stepTaskCreator = builder.buildWith(workflowName, stepConfig, inBoundQueue, outEmitter, stepExecutorConfig);

        StepExecutor stepExecutor = new StepExecutor(workflowName, stepName, stepExecutorConfig, stepTaskCreator, null);
        stepExecutor.setInstanceExecutorCreatorFactory(instanceExecutorCreatorFactory);
        stepExecutor.setExecutorService(executorService);
        stepExecutor.setJobEventEmitterHelper(jobEventEmitterHelper);
        stepExecutor.setJobActionsHelper(jobActionsHelper);

        String remappedWorkflowName = workflowName;
        String remappedStepName = stepName;
        if (inBoundRemapStepIdentifier != null) {
            remappedWorkflowName = inBoundRemapStepIdentifier.getOne();
            remappedStepName = inBoundRemapStepIdentifier.getTwo();
        }

        WorkflowConfigHelper workflowConfigHelper = workflowConfigHelpers.get(remappedWorkflowName);
        int noOfInBoundConnections;
        if (globalErrorStartStep != null && stepIdentifier.equals(globalErrorStartStep)) {
            noOfInBoundConnections = globalErrorStartInLinkCount;
        } else {
            List<IStepLink> inBoundStepLinks = workflowConfigHelper.getInBoundStepLinks(remappedStepName);
            noOfInBoundConnections = (inBoundStepLinks == null) ? 1 : inBoundStepLinks.size();
        }
        stepExecutor.setNoOfInBoundConnections(noOfInBoundConnections);

        String queueCreatorName = "local";
        if (stepConfig instanceof ICustomizableInBoundQueueSupport) {
            queueCreatorName = ((ICustomizableInBoundQueueSupport) stepConfig).getQueueCreatorName();
        }

        IInBoundQueueCreator inBoundQueueCreator = getInBoundQueueCreator(queueCreatorName);
        stepExecutor.setSharedQueue(inBoundQueueCreator.isSharedQueue());

        allStepExecutors.add(stepExecutor);
        return Stream.of(stepExecutor);
    }

    private Map.Entry<Pair<String, String>, Boolean> createAndAddOutBoundEmitter(Map.Entry<Pair<String, String>, Boolean> stepToRun) {
        Pair<String, String> stepIdentifier = stepToRun.getKey();
        String workflowName = stepIdentifier.getOne();
        String stepName = stepIdentifier.getTwo();
        WorkflowConfigHelper workflowConfigHelper = workflowConfigHelpers.get(workflowName);
        IStepConfig stepConfig = workflowConfigHelper.getStepConfig(stepName);
        boolean callGlobalErrorEvenWhenHandled = false;
        if (stepConfig instanceof ICustomizeErrorHandlingSupport) {
            callGlobalErrorEvenWhenHandled = ((ICustomizeErrorHandlingSupport) stepConfig).callGlobalErrorEvenWhenHandled();
        }

        IEmitter globalErrorEmitter = null;
        IQueue globalErrorStepInBoundQueue = null;
        if (globalErrorStartStep != null && globalErrorStartStep.getOne().equals(workflowName) == false) {
            globalErrorStepInBoundQueue = getInBoundQueue(globalErrorStartStep.getOne(), globalErrorStartStep.getTwo());
            globalErrorEmitter = globalErrorStepInBoundQueue.getEmitter(null);
            outBoundQueues.put(stepIdentifier, globalErrorStepInBoundQueue);
            if((stepConfig instanceof IEmbeddedSubWorkflowConfig) == false) {
            	globalErrorStartInLinkCount++;
            }
        }

        List<IStepLink> outBoundStepLinks = workflowConfigHelper.getOutBoundStepLinks(stepName);
        if (outBoundStepLinks == null) {
            IEmitter defaultEmitter = null;
            if (testEnabled == true) {
                LocalQueue localQueue = new LocalQueue(DEFAULT_LOCAL_QUEUE_CONFIG);
                outBoundQueues.put(stepIdentifier, localQueue);
                defaultEmitter = localQueue.getEmitter(null);
            }
            outBoundEmitters.put(stepIdentifier, new ErrorHandlerEmitter(globalErrorEmitter, null, defaultEmitter, callGlobalErrorEvenWhenHandled));
        } else if (outBoundStepLinks != null && outBoundStepLinks.size() == 1) {
            IStepLink outBoundStepLink = outBoundStepLinks.get(0);
            String toStepName = outBoundStepLink.getTo();
            IQueue toStepInBoundQueue = inBoundQueues.get(Tuples.pair(workflowName, toStepName));
            IEmitter defaultEmitter = outBoundStepLink.isErrorHandlingLink() ? null : toStepInBoundQueue.getEmitter(null);
            IEmitter errorEmitter = outBoundStepLink.isErrorHandlingLink() ? toStepInBoundQueue.getEmitter(null) : null;

            outBoundQueues.put(stepIdentifier, toStepInBoundQueue);
            outBoundEmitters.put(stepIdentifier, new ErrorHandlerEmitter(globalErrorEmitter, errorEmitter, defaultEmitter, callGlobalErrorEvenWhenHandled));
        } else {
            List<IStepLink> errorHandlingLinks = outBoundStepLinks.stream()
                    .filter(link -> link.isErrorHandlingLink())
                    .collect(Collectors.toList());
            if (errorHandlingLinks != null && errorHandlingLinks.size() > 1) {
                throw new RuntimeException("Multiple error handling links for step - " + stepIdentifier);
            }

            IEmitter errorEmitter = null;
            if (errorHandlingLinks != null && errorHandlingLinks.size() == 1) {
                IStepLink errorHandlingLink = errorHandlingLinks.get(0);
                String toStepName = errorHandlingLink.getTo();
                IQueue toStepInBoundQueue = inBoundQueues.get(Tuples.pair(workflowName, toStepName));
                errorEmitter = toStepInBoundQueue.getEmitter(null);
            }

            List<Pair<IScript<IMessage, Boolean>, IEmitter>> conditionBasedEmitters = outBoundStepLinks.stream()
                    .filter(link -> !link.isErrorHandlingLink())
                    .map(stepLink -> this.createScriptAndEmitter(workflowName, stepLink))
                    .collect(Collectors.toList());
            outBoundEmitters.put(stepIdentifier, new ErrorHandlerEmitter(globalErrorEmitter, errorEmitter,
                    new ConditionalEmitter(conditionBasedEmitters), callGlobalErrorEvenWhenHandled));

            List<IQueue> stepOutBoundQueues = outBoundStepLinks.stream()
                    .map(link -> getInBoundQueue(workflowName, link.getTo()))
                    .collect(Collectors.toList());
            outBoundQueues.putAll(stepIdentifier, stepOutBoundQueues);
        }

        return stepToRun;
    }

    private Pair<IScript<IMessage, Boolean>, IEmitter> createScriptAndEmitter(String workflowName, IStepLink stepLink) {
        IScriptConfig conditionConfig = stepLink.getCondition();
        IScript script = (conditionConfig != null) ? scriptCreatorFactory.createScript(conditionConfig) : DEFAULT_LINK_SCRIPT;
        String toStepName = stepLink.getTo();
        IQueue toStepInBoundQueue = getInBoundQueue(workflowName, toStepName);
        return Tuples.pair(script, toStepInBoundQueue.getEmitter(null));
    }

    private Map.Entry<Pair<String, String>, Boolean> createAndAddInBoundQueueIfRequired(Map.Entry<Pair<String, String>, Boolean> stepToRun) {
        Pair<String, String> stepIdentifier = stepToRun.getKey();
        Boolean isRemoteRunAlso = stepToRun.getValue();
        IQueue queue = createInBoundQueueIfRequired(stepIdentifier, isRemoteRunAlso);
        inBoundQueues.put(stepIdentifier, queue);
        return stepToRun;
    }

    private IQueue createInBoundQueueIfRequired(Pair<String, String> stepIdentifier, Boolean isRemoteRunAlso) {
        if (isRemoteRunAlso == true) {
            throw new RuntimeException("Distributed execution not supported now !!! Step name - " + stepIdentifier);
        }

        String workflowName = stepIdentifier.getOne();
        String stepName = stepIdentifier.getTwo();
        IStepConfig stepConfig = getStepConfig(workflowName, stepName);

        String queueCreatorName = "local";
        if (stepConfig instanceof ICustomizableInBoundQueueSupport) {
            queueCreatorName = ((ICustomizableInBoundQueueSupport) stepConfig).getQueueCreatorName();
        }

        IInBoundQueueCreator creator = getInBoundQueueCreator(queueCreatorName);

        IStepExecutorConfig stepExecutorConfig = getStepExecutorConfig(stepIdentifier);
        IQueueConfig queueConfig = creator.getDefaultConfig();
        if (stepExecutorConfig != null && stepExecutorConfig.getQueueConfig() != null) {
            queueConfig = stepExecutorConfig.getQueueConfig();
        }

        return creator.createQueue(queueConfig, stepConfig);
    }

    private IStepConfig getStepConfig(String workflowName, String stepName) {
        WorkflowConfigHelper workflowConfigHelper = workflowConfigHelpers.get(workflowName);
        return workflowConfigHelper.getStepConfig(stepName);
    }

    private IStepExecutorConfig getStepExecutorConfig(Pair<String, String> stepIdentifier) {
        WorkflowExecutionConfig executionConfig = workflowConfigRepository.getExecutionConfig(jobTaskId, stepIdentifier.getOne());
        if (executionConfig == null) {
            return null;
        }

        return executionConfig.getStepExecutorConfig(stepIdentifier.getTwo());
    }

    private Map<Pair<String, String>, Boolean> getStepsToRun() {
        List<String> workflowNames = getAllRequiredWorkflowNames();

        return workflowNames.stream()
                .map(workflowConfigRepository::getConfig)
                .map(this::createAndAddWorkflowConfigHelper)
                .flatMap(config -> getStepsToRun(config).entrySet().stream())
                .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));
    }

    private WorkflowConfig createAndAddWorkflowConfigHelper(WorkflowConfig config) {
        WorkflowConfigHelper workflowConfigHelper = new WorkflowConfigHelper(config);
        workflowConfigHelpers.put(config.getName(), workflowConfigHelper);
        return config;
    }

    private List<String> getAllRequiredWorkflowNames() {
        String startWorkflowName = jobConfig.getStartWorkflowName();
        List<String> workflowNames = new ArrayList<>();
        workflowNames.add(startWorkflowName);

        List<String> dependentWorkflowNames = getDependentWorkflowNames();
        workflowNames.addAll(dependentWorkflowNames);

        List<String> subWorkflowNames = workflowNames.stream()
                .flatMap(this::findAndAddSubWorkflow)
                .collect(Collectors.toList());
        workflowNames.addAll(subWorkflowNames);

        return workflowNames;
    }

    private List<String> getDependentWorkflowNames() {
        List<String> dependencies = new ArrayList<>();

        String globalErrorHandlingWorkflowName = jobConfig.getGlobalErrorHandlingWorkflowName();
        if (!StringUtils.isEmpty(globalErrorHandlingWorkflowName)) {
            dependencies.add(globalErrorHandlingWorkflowName);
        }

        return dependencies;
    }

    private Stream<String> findAndAddSubWorkflow(String workflowName) {
        List<String> subWorkflowNames = new ArrayList<>();

        WorkflowConfig config = workflowConfigRepository.getConfig(workflowName);
        for (IStepConfig stepConfig : config.getStepConfigs()) {
            if (stepConfig instanceof IEmbeddedSubWorkflowConfig) {
                IEmbeddedSubWorkflowConfig embeddedWorkflowConfig = (IEmbeddedSubWorkflowConfig) stepConfig;
                String embeddedWorkflowName = getEmbeddedWorkflowName(workflowName, stepConfig.getStepName());

                WorkflowConfig subWorkflowConfig = embeddedWorkflowConfig.getWorkflowConfig();
                Pair<String, String> subWorkflowStartStep = Tuples.pair(subWorkflowConfig.getName(), subWorkflowConfig.getStartStepName());
                Pair<String, String> subWorkflowEndStep = Tuples.pair(subWorkflowConfig.getName(), subWorkflowConfig.getEndStepName());
                Pair<String, String> parentStep = Tuples.pair(workflowName, stepConfig.getStepName());

                inBoundQueueRemapping.put(subWorkflowStartStep, parentStep);
                outBoundQueueRemapping.put(subWorkflowEndStep, parentStep);

                workflowConfigRepository.addConfig(embeddedWorkflowName, subWorkflowConfig);
                subWorkflowNames.add(embeddedWorkflowName);
            }
        }

        return subWorkflowNames.stream();
    }

    private String getEmbeddedWorkflowName(String workflowName, String stepName) {
        return workflowName + "." + stepName;
    }

    public IInBoundQueueCreator getInBoundQueueCreator(String queueCreatorName) {
        return inBoundQueueCreatorFactory.getCreator(queueCreatorName);
    }

    private Map<Pair<String, String>, Boolean> getStepsToRun(WorkflowConfig workflowConfig) {
        String workflowName = workflowConfig.getName();

        return workflowConfig.getStepConfigs().stream()
                .filter(config -> isLocalRunRequired(workflowName, config))
                .map(config -> Tuples.pair(Tuples.pair(workflowName, config.getStepName()), runsRemotelyAlso(workflowName, config)))
                .collect(Collectors.toMap(e -> e.getOne(), e -> e.getTwo()));
    }

    private boolean isLocalRunRequired(String workflowName, IStepConfig stepConfig) {
        return true;    // Need to change to support distributed execution
    }

    private Boolean runsRemotelyAlso(String workflowName, IStepConfig config) {
        return false;    // Need to change to support distributed execution
    }

    public boolean isTestEnabled() {
        return testEnabled;
    }

    public void setTestEnabled(boolean testEnabled) {
        this.testEnabled = testEnabled;
    }

    public void setInstanceExecutorCreatorFactory(StepInstanceExecutorCreatorFactory instanceExecutorCreatorFactory) {
        this.instanceExecutorCreatorFactory = instanceExecutorCreatorFactory;
    }

    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    public void setScriptCreatorFactory(ScriptCreatorFactory scriptCreatorFactory) {
        this.scriptCreatorFactory = scriptCreatorFactory;
    }

    public void setJobEventEmitterHelper(JobEventEmitterHelper jobEventEmitterHelper) {
        this.jobEventEmitterHelper = jobEventEmitterHelper;
    }

    public void setJobActionsHelper(JobActionsHelper jobActionsHelper) {
        this.jobActionsHelper = jobActionsHelper;
    }

    private IQueue getInBoundQueue(Pair<String, String> stepIdentifier) {
        return inBoundQueues.get(stepIdentifier);
    }

    public List<IQueue> getOutBoundQueue(Pair<String, String> stepIdentifier) {
        return outBoundQueues.get(stepIdentifier);
    }

    public IQueue getInBoundQueue(String stepName) {
        return getInBoundQueue(WorkflowConfig.DEFAULT_WORKFLOW_NAME, stepName);
    }

    public IQueue getInBoundQueue(String workflowName, String stepName) {
        return inBoundQueues.get(Tuples.pair(workflowName, stepName));
    }

    public List<IQueue> getOutBoundQueue(String stepName) {
        return getOutBoundQueue(WorkflowConfig.DEFAULT_WORKFLOW_NAME, stepName);
    }

    public List<IQueue> getOutBoundQueue(String workflowName, String stepName) {
        return outBoundQueues.get(Tuples.pair(workflowName, stepName));
    }

    public void setInBoundQueueCreatorFactory(IInBoundQueueCreatorFactory inBoundQueueCreatorFactory) {
        this.inBoundQueueCreatorFactory = inBoundQueueCreatorFactory;
    }

    public void setStepTaskCreatorFactory(IStepTaskCreatorFactory stepTaskCreatorFactory) {
        this.stepTaskCreatorFactory = stepTaskCreatorFactory;
    }

    public synchronized void abort() {
        allStepExecutors.stream().forEach(executor -> executor.abort());
        allStepExecutors.clear();
    }

    @Override
    public void abort(IActionInitiator actionInitiator, String reason, Throwable exceptionIfAny, ISourceReference sourceReferenceIfAny) {
        abort();
    }
}
