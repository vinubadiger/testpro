package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

public class StopJobException extends RuntimeException {
    ISourceReference sourceReference;

    public StopJobException(String reason, Throwable cause, ISourceReference sourceReference) {
        super(reason, cause);
        this.sourceReference = sourceReference;
    }

    public StopJobException(String reason, ISourceReference sourceReference) {
        super(reason);
        this.sourceReference = sourceReference;
    }

    public ISourceReference getSourceReference() {
        return sourceReference;
    }
}
