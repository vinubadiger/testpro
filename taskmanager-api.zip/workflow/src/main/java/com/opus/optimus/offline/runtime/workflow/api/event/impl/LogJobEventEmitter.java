package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;

public class LogJobEventEmitter implements IJobEventEmitter {
    Logger logger = LoggerFactory.getLogger(LogJobEventEmitter.class);

    @Override
    public void emit(IJobEvent event) {
        logger.info("{}", event);
    }
}
