package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IPartitionKeyProvider;

import java.io.Serializable;
import java.util.Random;

public class RandomPartitionKeyProvider implements IPartitionKeyProvider {
    Random random;

    public RandomPartitionKeyProvider() {
        random = new Random();
    }

    @Override
    public <I extends Serializable, R extends Serializable> R getPartitionKey(I message) {
        int randomValue = random.nextInt();
        if (randomValue < 0) {
            randomValue = -1 * randomValue;
        }
        return (R) Integer.valueOf(randomValue);
    }
}
