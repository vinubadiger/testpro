package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IQueueConfig;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class LocalStepExecutorConfig extends AbstractStepExecutorConfig {
    IQueueConfig queueConfig;

    public LocalStepExecutorConfig(int maxNoOfTasks, int maxNoOfConcurrentTasks, IQueueConfig queueConfig) {
        super(maxNoOfTasks, maxNoOfConcurrentTasks);
        this.queueConfig = queueConfig;
    }
}
