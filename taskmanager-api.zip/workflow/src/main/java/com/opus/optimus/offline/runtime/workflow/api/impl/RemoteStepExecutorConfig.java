package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.List;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RemoteStepExecutorConfig implements IStepConfig {
    public final static String REMOTE = "remote";
    String stepName = REMOTE;
    String stepType = REMOTE;

    List<RemoteJVMStepExecutorConfig> remoteJVMConfigs;
}
