package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.collections.api.map.ImmutableMap;
import org.eclipse.collections.impl.factory.Maps;

import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;

public class Message implements IMessage {
	private static final long serialVersionUID = 1L;
	//private static final String EMPTY = "";
    //private static final Map<String, Serializable> IMMUTABLE_EMPTY_MAP = Maps.immutable.<String, Serializable>empty().castToMap();

    MessageType type;
    Map<String, Serializable> headers = new HashMap<>();
    Serializable data;
    ISourceReference sourceReference;

    @Override
    public void setType(MessageType type) {
        this.type = type;
    }

    @Override
    public MessageType getType() {
        return type;
    }

    @Override
    public <T extends Serializable> void addHeader(String name, T value) {
        headers.put(name, value);
    }

    @Override
    public <T extends Serializable> T getHeaderValue(String name) {
        return (T) headers.get(name);
    }

    @Override
    public ImmutableMap<String, Serializable> getHeader() {
        return Maps.immutable.ofMap(headers); // TODO check
    }

    @Override
    public void setData(Serializable data) {
        this.data = data;
    }

    @Override
    public Serializable getData() {
        return data;
    }

    @Override
    public ISourceReference getSourceReference() {
        return sourceReference;
    }

    @Override
    public void setSourceReference(ISourceReference sourceReference) {
        this.sourceReference = sourceReference;
    }
}
