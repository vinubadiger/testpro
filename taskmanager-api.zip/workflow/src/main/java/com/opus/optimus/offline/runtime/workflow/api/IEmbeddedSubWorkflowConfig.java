package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;

public interface IEmbeddedSubWorkflowConfig {
    WorkflowConfig getWorkflowConfig();
}
