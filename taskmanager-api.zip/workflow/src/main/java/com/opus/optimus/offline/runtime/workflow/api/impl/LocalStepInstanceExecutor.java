package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.atomic.AtomicBoolean;

@Component("local.stepInstanceExecutor")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class LocalStepInstanceExecutor implements IStepInstanceExecutor, IJobEventEmitterHelperAware, IJobActionsHelperAware {

    Logger logger = LoggerFactory.getLogger(LocalStepInstanceExecutor.class);

    @Autowired
    StepCreatorFactory stepCreatorFactory;

    @Autowired
    IMessageFactory factory;

    private IStepTask stepTask;
    private IStepInstanceExecutorListener listener;

    private IStepConfig stepConfig;
    private IStep step;
    private StatisticsReceiverDelegator receiver;
    private StatisticsEmitterDelegator emitter;

    private StepInstanceStats stats = new StepInstanceStats();
    private final AtomicBoolean canStop = new AtomicBoolean(false);
    private final AtomicBoolean abort = new AtomicBoolean(false);
    private JobEventEmitterHelper jobEventEmitterHelper;
    private IJobActionsHelper jobActionsHelper;

    public LocalStepInstanceExecutor(IStepTask stepTask, IStepInstanceExecutorListener listener) {
        this.stepTask = stepTask;
        this.listener = listener;
    }

    @PostConstruct
    void init() {
        this.stepConfig = stepTask.getStepConfig();
        this.step = stepCreatorFactory.createStep(this.stepConfig);
    }

    @Override
    public int getInstanceId() {
        return stepTask.getId();
    }

    @Override
    public void abort() {
        abort.set(true);
        canStop.set(true);
        step.stop(true);
    }

    @Override
    public void invokeStepEnd(boolean forceEnd) {
        step.onStepEnd(forceEnd, emitter);

        if (emitter != null) {
            emitter.end(factory.createEndMessage());
        }

    }

    public IStep getStep() {
        return step;
    }

    @Override
    public boolean supportStepEnd() {
        return true;
    }

    @Override
    public void run() {
        stats.startExecutionTime();
        jobEventEmitterHelper = jobEventEmitterHelper
                .createNew()
                .workflowName(stepTask.getWorkflowName())
                .stepName(step.getName())
                .stepType(stepConfig.getStepType())
                .instanceId(stepTask.getId().intValue())
                .build();

        if (step instanceof IJobTaskInfoAware) {
            ((IJobTaskInfoAware) step).setJobTaskInfo(new JobTaskInfo(jobEventEmitterHelper.machine,
                    jobEventEmitterHelper.jobId, jobEventEmitterHelper.jobTaskId));
        }

        if (step instanceof IInstanceIdAware) {
            ((IInstanceIdAware) step).setInstanceId(getInstanceId());
        }

        jobEventEmitterHelper.startStepInstanceExecutor();

        receiver = new StatisticsReceiverDelegator(stepTask.getReceiver());
        emitter = new StatisticsEmitterDelegator(stepTask.getEmitter());

        listener.onStart(stepTask.getId());

        try {
            while (!canStop.get()) {
                processMessageIfAvailable();
            }
        } finally {
            IStepInstanceSummary summary = step.onInstanceEnd(abort.get(), emitter);
            stats.setStatus(OperationStatus.COMPLETED);
            if (abort.get()) {
                stats.setStatus(OperationStatus.ABORTED);
            } else if (stats.hasExceptions()) {
                stats.setStatus(OperationStatus.COMPLETED_WITH_ERRORS);
            }
            stats.setStepLevelSummary(summary);

            stats.stopExecutionTime();
            stats.setInbound(receiver.getLinkStats());
            stats.setOutbound(emitter.getLinkStats());
            jobEventEmitterHelper.endStepInstanceExecutor(abort.get(), stats);

            listener.onEnd(stepTask.getId(), stats);
        }
    }

    private void processMessageIfAvailable() {
        IMessage message = null;
        try {
            message = receiver.getNext();
            if (message == null) {
                boolean canProceed = listener.onNoMessage(stepTask.getId());
                if (canProceed == false) {
                    canStop.set(true);
                }

                return;
            }

            switch (message.getType()) {
                case DATA: {
                    step.process(message, emitter);
                    break;
                }
                case ERROR: {
                    step.process(message, emitter);
                    break;
                }
                case END: {
                    boolean canStopInstance = listener.onEndMessage(stepTask.getId());
                    canStop.set(canStopInstance);
                    break;
                }
            }

        } catch (StopJobException exception) {
            logger.info("Stop job execution thrown in step {}", stepConfig.getStepName());
            jobActionsHelper.abort(exception.getMessage(), exception.getCause(), exception.sourceReference);
            abort();
            stats.incExceptionCount((message != null && message.getType() != null) ? message.getType().name() : "null");
        } catch (Exception exception) {
            exception.printStackTrace();
            boolean canProceed = listener.onException(stepTask.getId(), message, stats, exception);
            if (canProceed == false) {
                jobActionsHelper.abort(exception.getMessage(), exception.getCause(), (message != null) ? message.getSourceReference() : null);
                abort();
            }
            stats.incExceptionCount((message != null && message.getType() != null) ? message.getType().name() : "null");
        }
    }

    @Override
    public void setJobEventEmitterHelper(JobEventEmitterHelper helper) {
        this.jobEventEmitterHelper = helper;
    }

    @Override
    public void setJobActionsHelper(IJobActionsHelper jobActionsHelper) {
        this.jobActionsHelper = jobActionsHelper;
    }
}