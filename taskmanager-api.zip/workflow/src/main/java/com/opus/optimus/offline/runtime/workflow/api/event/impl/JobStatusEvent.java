package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class JobStatusEvent extends JobEvent {
    String status;
}
