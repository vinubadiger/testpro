package com.opus.optimus.offline.runtime.workflow.api;

public interface IWorkflowConfigRepositoryFactory {
    IWorkflowConfigRepository create(String groupId);
}
