package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutor;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutorCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutorListener;
import com.opus.optimus.offline.runtime.workflow.api.IStepTask;

@Component
public class StepInstanceExecutorCreatorFactory {
    private final static String TYPE = ".stepInstanceExecutorCreator";
    public final static String DEFAULT = "local" + TYPE;

    @Autowired
    Map<String, IStepInstanceExecutorCreator> stepInstanceExecutorCreators;

    public IStepInstanceExecutor create(IStepTask stepTask, IStepInstanceExecutorListener listener) {
        String beanName = stepTask.getType() + TYPE;

        IStepInstanceExecutorCreator creator = stepInstanceExecutorCreators.get(beanName);

        creator = creator == null ? stepInstanceExecutorCreators.get(DEFAULT) : creator;
        if (creator == null) {
            throw new RuntimeException("No step instance executor creator found for task type " + stepTask.getType());
        }

        return creator.create(stepTask, listener);
    }

}
