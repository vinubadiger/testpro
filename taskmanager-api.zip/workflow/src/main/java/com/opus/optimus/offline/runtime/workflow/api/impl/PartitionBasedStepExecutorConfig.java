package com.opus.optimus.offline.runtime.workflow.api.impl;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class PartitionBasedStepExecutorConfig extends AbstractStepExecutorConfig {
    PartitionBasedQueueConfig queueConfig;

    public PartitionBasedStepExecutorConfig(int maxNoOfTasks, int maxNoOfConcurrentTasks, PartitionBasedQueueConfig queueConfig) {
        super(maxNoOfTasks, maxNoOfConcurrentTasks);
        this.queueConfig = queueConfig;
    }
}
