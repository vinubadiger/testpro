package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueue;
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueueConfig;
import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import org.springframework.stereotype.Component;

@Component("inBoundQueueCreator.local")
public class LocalInBoundQueueCreator implements IInBoundQueueCreator<LocalQueueConfig> {
    public static final LocalQueueConfig DEFAULT_LOCAL_QUEUE_CONFIG = new LocalQueueConfig(1024, 100);

    @Override
    public IQueue createQueue(LocalQueueConfig queueConfig, IStepConfig stepConfig) {
        return new LocalQueue(queueConfig);
    }

    @Override
    public boolean isSharedQueue() {
        return true;
    }

    @Override
    public LocalQueueConfig getDefaultConfig() {
        return DEFAULT_LOCAL_QUEUE_CONFIG;
    }
}
