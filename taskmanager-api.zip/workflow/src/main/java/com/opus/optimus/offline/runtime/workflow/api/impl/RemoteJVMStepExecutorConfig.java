package com.opus.optimus.offline.runtime.workflow.api.impl;

public class RemoteJVMStepExecutorConfig {
    IPubSubConfig pubSubConfig;
    IPollConfig pollConfig;
}
