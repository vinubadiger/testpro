package com.opus.optimus.offline.runtime.workflow.api.impl;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutor;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutorCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutorListener;
import com.opus.optimus.offline.runtime.workflow.api.IStepTask;

@Component("local.stepInstanceExecutorCreator")
public class DefaultStepInstanceExecutorCreator implements IStepInstanceExecutorCreator, BeanFactoryAware {
    BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    @Override
    public IStepInstanceExecutor create(IStepTask stepTask, IStepInstanceExecutorListener listener) {
        String type = stepTask.getType();

        boolean singleton = beanFactory.isSingleton(type);
        if (singleton == true) {
            throw new RuntimeException("StepInstanceExecutor component should be scoped as prototype ..." + type + " is singleton...");
        }

        return (IStepInstanceExecutor) beanFactory.getBean(type, stepTask, listener);
    }
}
