package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

public class EndStepConfig implements IStepConfig {
    public final static String STEP_TYPE = "end";

    @Override
    public String getStepName() {
        return STEP_TYPE;
    }

    @Override
    public String getStepType() {
        return STEP_TYPE;
    }
}
