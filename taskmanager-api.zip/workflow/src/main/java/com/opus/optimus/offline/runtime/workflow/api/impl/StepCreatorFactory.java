package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.workflow.api.IStep;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepCreator;

@Component
public class StepCreatorFactory {
    private final static String TYPE = ".stepCreator";
    private final static String DEFAULT = "default" + TYPE;

    @Autowired
    Map<String, IStepCreator> stepCreators;

    public IStep createStep(IStepConfig config) {
        String stepCreatorComponentName = config.getStepType() + TYPE;

        IStepCreator stepCreator = stepCreators.get(stepCreatorComponentName);

        stepCreator = stepCreator == null ? stepCreators.get(DEFAULT) : stepCreator;
        if (stepCreator == null) {
            throw new RuntimeException("No step creator found for step type " + config.getStepType());
        }

        return stepCreator.create(config);
    }
}
