package com.opus.optimus.offline.runtime.workflow.api.impl;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component(EndStepConfig.STEP_TYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class EndStep extends MapStep<EndStepConfig> {

    public EndStep(EndStepConfig config) {
        super(config);
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
        return (R) data;
    }
}
