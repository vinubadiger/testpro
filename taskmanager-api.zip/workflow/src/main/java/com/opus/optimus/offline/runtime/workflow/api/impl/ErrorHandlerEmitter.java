package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;

public class ErrorHandlerEmitter implements IEmitter {
    IEmitter globalErrorEmitter;
    IEmitter errorEmitter;
    IEmitter defaultEmitter;
    boolean callGlobalErrorEvenWhenHandled = false;

    public ErrorHandlerEmitter(IEmitter globalErrorEmitter, IEmitter errorEmitter, IEmitter defaultEmitter,
                               boolean callGlobalErrorEvenWhenHandled) {
        this.globalErrorEmitter = globalErrorEmitter;
        this.errorEmitter = errorEmitter;
        this.defaultEmitter = defaultEmitter;
        this.callGlobalErrorEvenWhenHandled = callGlobalErrorEvenWhenHandled;
    }

    @Override
    public <T extends Serializable> void emit(T data) {
        IMessage message = (IMessage) data;
        MessageType type = message.getType();
        type = (type == null) ? MessageType.DATA : type;

        if (type.equals(MessageType.ERROR)) {
            if (errorEmitter != null) {
                errorEmitter.emit(data);

                if (callGlobalErrorEvenWhenHandled == false) {
                    return;
                }
            }

            if (globalErrorEmitter != null) {
                globalErrorEmitter.emit(data);
            }

            return;
        }

        if (defaultEmitter != null) {
            defaultEmitter.emit(data);
        }
    }

    @Override
    public <T extends Serializable> void end(T data) {
        if (globalErrorEmitter != null) {
            globalErrorEmitter.end(data);
        }

        if (errorEmitter != null) {
            errorEmitter.end(data);
        }

        if (defaultEmitter != null) {
            defaultEmitter.end(data);
        }
    }
}
