package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.HashMap;
import java.util.Map;

public class JobExecutionConfig {
    // Job task id -> [ Workflow name -> WorkflowExecutionConfig ]
    private Map<String, Map<String, WorkflowExecutionConfig>> jobTaskIdBasedStepExecutorConfigs = new HashMap<>();

    public WorkflowExecutionConfig getWorkflowExecutionConfig(String jobTaskId, String workflowName) {
        Map<String, WorkflowExecutionConfig> workflowExecutorConfigs = jobTaskIdBasedStepExecutorConfigs.get(jobTaskId);
        if (workflowExecutorConfigs == null) {
            return null;
        }

        return workflowExecutorConfigs.get(workflowName);
    }

    public void addWorkflowExecutionConfig(String jobTaskId, String workflowName, WorkflowExecutionConfig config) {
        Map<String, WorkflowExecutionConfig> workflowExecutorConfigs = jobTaskIdBasedStepExecutorConfigs.get(jobTaskId);
        if (workflowExecutorConfigs == null) {
            workflowExecutorConfigs = new HashMap<>();
            jobTaskIdBasedStepExecutorConfigs.put(jobTaskId, workflowExecutorConfigs);
        }

        workflowExecutorConfigs.put(workflowName, config);
    }

}
