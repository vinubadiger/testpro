package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.*;
import com.opus.optimus.offline.runtime.workflow.api.event.impl.VoidJobEventEmitter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

public class StepExecutor implements IStepExecutor<StepExecutorResult>, IStepInstanceExecutorListener, ITaskTrackingEventListener {

    //    @Autowired
    StepInstanceExecutorCreatorFactory instanceExecutorCreatorFactory;

    ExecutorService executorService;

    private String workflowName;
    private String stepName;
    private IStepExecutorConfig config;
    private IStepTaskCreator localTaskCreator;
    private IStepExecutorListener listener;
    private JobEventEmitterHelper jobEventEmitterHelper;
    private int noOfInBoundConnections = 1;

    public IStepInstanceExecutor lastStepInstanceExecutor = null;
    private ITaskTrackingHandler taskTrackingHandler;
    private AtomicBoolean endOfMessage = new AtomicBoolean(false);
    private CompletableFuture<StepExecutorResult> finalStepExecutorResult = new CompletableFuture<>();
    private StepExecutorResult stepExecutorResult;
    private int noOfEndMessageReceived = 0;
    private final AtomicBoolean abort = new AtomicBoolean(false);
    private List<IStepInstanceExecutor> allInstanceExecutors = new ArrayList<>();
    private JobActionsHelper jobActionsHelper;
    private boolean isSharedQueue = true;
    private Map<Integer, Integer> instanceBasedEndMessageReceived = new ConcurrentHashMap<>();

    public StepExecutor(String workflowName, String stepName, IStepExecutorConfig config, IStepTaskCreator localTaskCreator,
                        IStepExecutorListener listener) {
        this.workflowName = workflowName;
        this.stepName = stepName;
        this.config = config;
        this.localTaskCreator = localTaskCreator;
        this.listener = listener;
    }

    @Override
    public synchronized CompletableFuture<StepExecutorResult> start() {
        IStepConfig stepConfig = localTaskCreator.getStepConfig();
        stepExecutorResult = new StepExecutorResult(workflowName, stepName, stepConfig.getStepType());
        stepExecutorResult.startExecutionTime();

        if (jobEventEmitterHelper == null) {
            jobEventEmitterHelper = new JobEventEmitterHelper(new VoidJobEventEmitter());
        }

        jobEventEmitterHelper = jobEventEmitterHelper.createNew()
                .workflowName(workflowName)
                .stepName(stepName)
                .stepType(stepConfig.getStepType())
                .build();

        if (jobActionsHelper == null) {
            jobActionsHelper = new JobActionsHelper(null);
        }

        jobActionsHelper = jobActionsHelper.createNew()
                .workflowName(workflowName)
                .stepName(stepName)
                .stepType(stepConfig.getStepType())
                .build();

        jobEventEmitterHelper.startStepExecutor();
        taskTrackingHandler = new TaskTrackingHandler(this);

        int maxNoOfConcurrentTasks = config.getMaxNoOfConcurrentTasks();
        while (localTaskCreator.hasNext() && taskTrackingHandler.getPendingTaskCount() < maxNoOfConcurrentTasks) {
            startStepTaskIfRequired();
        }

        return finalStepExecutorResult;
    }

    @Override
    public synchronized void abort() {
        abort.set(true);

        allInstanceExecutors.stream().forEach(instanceExecutor -> instanceExecutor.abort());
        allInstanceExecutors.clear();
    }

    public synchronized void startStepTaskIfRequired() {
        if (localTaskCreator.hasNext() == false || abort.get() == true) {
            return;
        }

        IStepTask stepTask = localTaskCreator.next();
        IStepInstanceExecutor instanceExecutor = instanceExecutorCreatorFactory.create(stepTask, this);
        if (instanceExecutor.supportStepEnd()) {
            this.lastStepInstanceExecutor = instanceExecutor;
        }
        if (instanceExecutor instanceof IJobEventEmitterHelperAware) {
            ((IJobEventEmitterHelperAware) instanceExecutor).setJobEventEmitterHelper(jobEventEmitterHelper);
        }
        if (instanceExecutor instanceof IJobActionsHelperAware) {
            ((IJobActionsHelperAware) instanceExecutor).setJobActionsHelper(jobActionsHelper);
        }
        instanceBasedEndMessageReceived.put(instanceExecutor.getInstanceId(), 0);
        taskTrackingHandler.addTask();
        allInstanceExecutors.add(instanceExecutor);
        executorService.submit(instanceExecutor);
    }

    public String getStepName() {
        return stepName;
    }

    public void setInstanceExecutorCreatorFactory(StepInstanceExecutorCreatorFactory instanceExecutorCreatorFactory) {
        this.instanceExecutorCreatorFactory = instanceExecutorCreatorFactory;
    }

    public void setExecutorService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    @Override
    public synchronized void onStart(int instanceId) {

    }

    @Override
    public synchronized void onEnd(int instanceId, StepInstanceStats stats) {
        taskTrackingHandler.endTask(false);
        stepExecutorResult.addInstanceStats(instanceId, stats);
    }

    @Override
    public synchronized void onGroupStart(int instanceId, String groupReference) {

    }

    @Override
    public synchronized void onGroupEnd(int instanceId, String groupReference) {

    }

    @Override
    public synchronized boolean onNoMessage(int instanceId) {
        return !endOfMessage.get();
    }

    @Override
    public synchronized boolean onEndMessage(int instanceId) {
        if (isSharedQueue == true) {
            noOfEndMessageReceived++;
            if (noOfEndMessageReceived == noOfInBoundConnections) {
                endOfMessage.set(true);
                return true;
            }
        } else {
            Integer instanceEndMessageCount = instanceBasedEndMessageReceived.getOrDefault(instanceId, 0);
            instanceEndMessageCount++;
            instanceBasedEndMessageReceived.put(instanceId, instanceEndMessageCount);
            if (instanceEndMessageCount == noOfInBoundConnections) {
                if (localTaskCreator.hasNext() == false) {
                    // no other available instance to create
                    Optional<Integer> uncompletedInstances = instanceBasedEndMessageReceived.values().stream()
                            .filter(value -> value != noOfInBoundConnections)
                            .findFirst();
                    if (uncompletedInstances.isPresent() == false) {
                        endOfMessage.set(true);
                    }
                }

                return true;
            }
        }

        return false;
    }

    @Override
    public boolean onException(int instanceId, IMessage message, StepInstanceStats stats, Exception exception) {
        return false;
    }

    @Override
    public synchronized void onTaskEnd(ITaskTrackingHandler handler, boolean forceEnd) {
        startStepTaskIfRequired();
    }

    @Override
    public synchronized void onTrackingEnd(ITaskTrackingHandler handler, boolean forceEnd) {
        if (lastStepInstanceExecutor != null) {
            jobEventEmitterHelper.startOnStepEnd();
            try {
                lastStepInstanceExecutor.invokeStepEnd(!endOfMessage.get());
            } catch (Throwable ex) {
                ex.printStackTrace();
            }
            jobEventEmitterHelper.endOnStepEnd();
        }

        if (listener != null) {
            listener.onStepEnd(!endOfMessage.get());
        }

        jobEventEmitterHelper.endStepExecutor();
        stepExecutorResult.stopExecutionTime();
        finalStepExecutorResult.complete(stepExecutorResult);
    }

    public void setJobEventEmitterHelper(JobEventEmitterHelper jobEventEmitterHelper) {
        this.jobEventEmitterHelper = jobEventEmitterHelper;
    }

    public void setNoOfInBoundConnections(int noOfInBoundConnections) {
        this.noOfInBoundConnections = noOfInBoundConnections;
    }

    public void setJobActionsHelper(JobActionsHelper jobActionsHelper) {
        this.jobActionsHelper = jobActionsHelper;
    }

    public void setSharedQueue(boolean isSharedQueue) {
        this.isSharedQueue = isSharedQueue;
    }
}
