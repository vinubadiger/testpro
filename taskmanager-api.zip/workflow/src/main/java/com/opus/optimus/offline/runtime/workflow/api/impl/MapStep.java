package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;

public abstract class MapStep<C extends IStepConfig> extends AbstractStep<C> {
    @Autowired
    protected IMessageFactory factory;

    protected boolean withSourceReference = true;

    public MapStep(C config) {
        super(config);
    }

    @Override
    public void process(IMessage message, IEmitter emitter) {
        Serializable data = message.getData();
        Serializable result = null;
        MessageType messageType = MessageType.DATA;
        try {
            result = doProcess(data);
        } catch (RecordProcessingException ex) {
            messageType = MessageType.ERROR;
            result = ex.getErrorDetails();
        }

        if (result != null) {
            ISourceReference sourceReference = withSourceReference == true ? message.getSourceReference() : null;
            emitter.emit(factory.createMessage(messageType, result, sourceReference));
        }
    }

    protected abstract <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException;
}
