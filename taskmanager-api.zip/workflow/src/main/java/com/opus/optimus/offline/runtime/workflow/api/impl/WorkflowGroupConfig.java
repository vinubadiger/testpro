package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.List;

import lombok.Data;

@Data
public class WorkflowGroupConfig {
    String name;

    List<WorkflowConfig> workflowConfigs;

    String globalErrorHandlingWorkflowName;
}
