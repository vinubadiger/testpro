package com.opus.optimus.offline.runtime.workflow.api;

import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig;

public interface IWorkflowConfigRepository {
	WorkflowConfig getConfig(String workflowName);

    WorkflowExecutionConfig getExecutionConfig(String jobTaskId, String workflowName);
}
