package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IActionInitiator;
import com.opus.optimus.offline.runtime.workflow.api.IJobActions;
import com.opus.optimus.offline.runtime.workflow.api.IJobActionsHelper;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobActionsHelper implements IJobActionsHelper {
    IJobActions jobActions;
    String jobId;
    String jobTaskId;
    String workflowName;
    String stepName;
    String stepType;

    public JobActionsHelper(IJobActions jobActions) {
        this.jobActions = jobActions;
    }

    public JobActionsHelperBuilder createNew() {
        return builder()
                .jobActions(jobActions)
                .jobId(jobId)
                .jobTaskId(jobTaskId)
                .workflowName(workflowName)
                .stepName(stepName)
                .stepType(stepType);
    }

    public void abort(String reason, Throwable exceptionIfAny, ISourceReference sourceReferenceIfAny) {
        if (jobActions == null) {
            return;
        }
        IActionInitiator initiator = new ActionInitiator(jobId, jobTaskId, workflowName, stepName, stepType);
        jobActions.abort(initiator, reason, exceptionIfAny, sourceReferenceIfAny);
    }

}
