package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IPartitionIdentifier;

import java.io.Serializable;

public class StaticPartitionIdentifier implements IPartitionIdentifier {
    @Override
    public <T extends Serializable> int getPartitionIndex(T message) {
        return 0;
    }
}
