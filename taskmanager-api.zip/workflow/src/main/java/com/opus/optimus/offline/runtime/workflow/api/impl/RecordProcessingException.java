package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

public class RecordProcessingException extends Exception {
    Serializable errorDetails;

    public RecordProcessingException(Serializable errorDetails) {
        this.errorDetails = errorDetails;
    }

    public <T extends Serializable> T getErrorDetails() {
        return (T) errorDetails;
    }

}
