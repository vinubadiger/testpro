package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import com.opus.optimus.offline.runtime.workflow.api.event.IMachine;

import lombok.Data;

@Data
public class Machine implements IMachine {
    String id;
}
