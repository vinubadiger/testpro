package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.HashMap;
import java.util.Map;

import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;

public class InMemoryWorkflowConfigRepository implements IWorkflowConfigRepository {
	Map<String, WorkflowConfig> workflowConfigs = new HashMap<>();
    JobExecutionConfig jobExecutionConfig = new JobExecutionConfig();

    @Override
    public WorkflowConfig getConfig(String workflowName) {
        return workflowConfigs.get(workflowName);
    }

    @Override
    public WorkflowExecutionConfig getExecutionConfig(String jobTaskId, String workflowName) {
        return jobExecutionConfig.getWorkflowExecutionConfig(jobTaskId, workflowName);
    }

    public InMemoryWorkflowConfigRepository addWorkflowConfig(WorkflowConfig workflowConfig) {
        workflowConfigs.put(workflowConfig.getName(), workflowConfig);
        return this;
    }

    public InMemoryWorkflowConfigRepository addWorkflowExecutionConfig(String jobTaskId, String workflowName,
                                                                       WorkflowExecutionConfig config) {
        jobExecutionConfig.addWorkflowExecutionConfig(jobTaskId, workflowName, config);
        return this;
    }
}
