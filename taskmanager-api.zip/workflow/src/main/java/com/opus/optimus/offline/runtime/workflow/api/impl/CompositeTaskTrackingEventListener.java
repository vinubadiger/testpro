package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.List;

import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingEventListener;
import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingHandler;

public class CompositeTaskTrackingEventListener implements ITaskTrackingEventListener {
    List<ITaskTrackingEventListener> listeners;

    public CompositeTaskTrackingEventListener(List<ITaskTrackingEventListener> listeners) {
        this.listeners = listeners;
    }

    @Override
    public void onTaskEnd(ITaskTrackingHandler handler, boolean success) {
        for (ITaskTrackingEventListener listener : listeners) {
            listener.onTaskEnd(handler, success);
        }
    }

    @Override
    public void onTrackingEnd(ITaskTrackingHandler handler, boolean success) {
        for (ITaskTrackingEventListener listener : listeners) {
            listener.onTrackingEnd(handler, success);
        }
    }
}
