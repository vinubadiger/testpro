package com.opus.optimus.offline.runtime.workflow.api.impl;

public class IPollConfig {
}
