package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;

@Component
public class JobEventMapperCustomizer implements IMapperCustomizer<ObjectMapper> {
    @Override
    public void customize(ObjectMapper mapper) {
        mapper.registerSubtypes(new NamedType(JobEvent.class, "jobEvent.JobEvent"));
        mapper.registerSubtypes(new NamedType(JobStatusEvent.class, "jobEvent.JobStatusEvent"));
        mapper.registerSubtypes(new NamedType(JobTaskEvent.class, "jobEvent.JobTaskEvent"));
        mapper.registerSubtypes(new NamedType(StepExecutorEvent.class, "jobEvent.StepExecutorEvent"));
        mapper.registerSubtypes(new NamedType(StepInstanceEvent.class, "jobEvent.StepInstanceEvent"));

    }
}
