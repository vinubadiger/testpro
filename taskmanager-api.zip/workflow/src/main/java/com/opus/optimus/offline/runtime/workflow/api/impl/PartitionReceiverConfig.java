package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IReceiverConfig;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionReceiverConfig;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PartitionReceiverConfig implements IReceiverConfig, IPartitionReceiverConfig {
    int partitionId;
}
