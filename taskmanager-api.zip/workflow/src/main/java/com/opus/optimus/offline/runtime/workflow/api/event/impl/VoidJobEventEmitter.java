package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;

public class VoidJobEventEmitter implements IJobEventEmitter {
    @Override
    public void emit(IJobEvent event) {
        // Nothing to do
    }
}
