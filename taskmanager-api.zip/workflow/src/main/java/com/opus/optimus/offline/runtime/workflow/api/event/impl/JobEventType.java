package com.opus.optimus.offline.runtime.workflow.api.event.impl;

public enum JobEventType {
    START_JOB,
    END_JOB,
    START_JOB_TASK_EXECUTOR,
    END_JOB_TASK_EXECUTOR,
    START_STEP_EXECUTOR,
    END_STEP_EXECUTOR,
    START_STEP_INSTANCE_EXECUTOR,
    END_STEP_INSTANCE_EXECUTOR,
    START_ON_STEP_END,
    END_ON_STEP_END
}
