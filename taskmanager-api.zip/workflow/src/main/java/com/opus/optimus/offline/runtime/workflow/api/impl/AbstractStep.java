package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IDependency;
import com.opus.optimus.offline.runtime.workflow.api.IStep;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceSummary;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class AbstractStep<C extends IStepConfig> implements IStep {
    protected C config;
    protected AtomicBoolean forceStop = new AtomicBoolean(false);

    public AbstractStep(C config) {
        this.config = config;
    }

    @Override
    public String getName() {
        return config.getStepName();
    }

    @Override
    public void stop(boolean force) {
        forceStop.set(force);
    }

    @Override
    public List<IDependency> getExecutionDependencies() {
        return new ArrayList<>();
    }

    @Override
    public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
        // TODO
        return null;
    }

    @Override
    public void onStepEnd(boolean forceEnd, IEmitter emitter) {
    }
}
