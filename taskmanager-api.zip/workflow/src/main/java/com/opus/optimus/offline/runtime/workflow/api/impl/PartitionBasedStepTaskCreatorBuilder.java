package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorBuilder;
import org.springframework.stereotype.Component;

@Component("stepTaskCreatorBuilder.partition")
public class PartitionBasedStepTaskCreatorBuilder implements IStepTaskCreatorBuilder {
    @Override
    public IStepTaskCreator buildWith(String workflowName, IStepConfig stepConfig, IQueue inBoundQueue, IEmitter outBoundEmitter,
                                      IStepExecutorConfig stepExecutorConfig) {
        if (stepExecutorConfig instanceof PartitionBasedStepExecutorConfig == false) {
            throw new RuntimeException("Invalid step execution config(" + stepExecutorConfig.getClass().getCanonicalName()
                    + ") to partition based step task creator");
        }

        if (inBoundQueue instanceof PartitionBasedQueue == false) {
            throw new RuntimeException("Invalid inBoundQueue type(" + inBoundQueue.getClass().getCanonicalName()
                    + ") to partition based step task creator");
        }

        PartitionBasedStepExecutorConfig partitionBasedStepExecutorConfig = (PartitionBasedStepExecutorConfig) stepExecutorConfig;
        return new PartitionBasedStepTaskCreator(workflowName, stepConfig, (PartitionBasedQueue) inBoundQueue, outBoundEmitter, partitionBasedStepExecutorConfig);
    }

    @Override
    public IStepExecutorConfig getDefaultStepExecutorConfig() {
        PartitionBasedQueueConfig queueConfig = new PartitionBasedQueueConfig(1, new StaticPartitionIdentifier(), LocalJobTaskExecutor.DEFAULT_LOCAL_QUEUE_CONFIG);
        return new PartitionBasedStepExecutorConfig(1, 1, queueConfig);
    }
}
