package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceExecutorListener;

public class RemoteStepExecutorMonitor implements Runnable {
    RemoteStepExecutorConfig config;
    IStepInstanceExecutorListener listener;

    public RemoteStepExecutorMonitor(RemoteStepExecutorConfig config,
                                     IStepInstanceExecutorListener listener) {
        this.config = config;
        this.listener = listener;
    }

    @Override
    public void run() {

    }

}
