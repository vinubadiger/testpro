package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepTask;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator;

import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PartitionBasedStepTaskCreator implements IStepTaskCreator {
    IStepConfig stepConfig;
    Iterator<SimpleStepTask> taskIterator = null;

    public PartitionBasedStepTaskCreator(String workflowName, IStepConfig stepConfig,
                                         PartitionBasedQueue inBoundQueue,
                                         IEmitter outBoundEmitter,
                                         PartitionBasedStepExecutorConfig stepExecutorConfig) {
        this.stepConfig = stepConfig;

        PartitionBasedQueueConfig queueConfig = stepExecutorConfig.getQueueConfig();
        this.taskIterator = IntStream.range(0, queueConfig.getNoOfPartitions())
                .mapToObj(index ->
                        new SimpleStepTask(
                                "local.stepInstanceExecutor",
                                index,
                                workflowName,
                                stepConfig,
                                inBoundQueue.getReceiver(new PartitionReceiverConfig(index)),
                                outBoundEmitter)
                )
                .collect(Collectors.toList())
                .iterator();
    }

    @Override
    public IStepConfig getStepConfig() {
        return stepConfig;
    }

    @Override
    public boolean hasNext() {
        return taskIterator.hasNext();
    }

    @Override
    public IStepTask next() {
        return taskIterator.next();
    }
}
