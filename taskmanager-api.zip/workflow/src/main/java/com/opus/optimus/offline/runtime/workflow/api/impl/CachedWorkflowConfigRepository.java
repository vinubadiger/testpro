package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class CachedWorkflowConfigRepository implements IWorkflowConfigRepository {
    IWorkflowConfigRepository delegate;
    Map<String, WorkflowConfig> workflowConfigs = new ConcurrentHashMap<>();
    Map<String, WorkflowExecutionConfig> executionConfigs = new ConcurrentHashMap<>();

    public CachedWorkflowConfigRepository(IWorkflowConfigRepository delegate) {
        this.delegate = delegate;
    }

    @Override
    public WorkflowConfig getConfig(String workflowName) {
        WorkflowConfig workflowConfig = workflowConfigs.get(workflowName);
        if (workflowConfig != null) {
            return workflowConfig;
        }

        WorkflowConfig config = delegate.getConfig(workflowName);
        if (config == null) {
            return null;
        }

        workflowConfigs.put(workflowName, config);
        return config;
    }

    public void addConfig(String workflowName, WorkflowConfig workflowConfig) {
        workflowConfigs.put(workflowName, workflowConfig);
    }

    @Override
    public WorkflowExecutionConfig getExecutionConfig(String jobTaskId, String workflowName) {
        String key = getKey(jobTaskId, workflowName);
        WorkflowExecutionConfig workflowExecutionConfig = executionConfigs.get(key);
        if (workflowExecutionConfig != null) {
            return workflowExecutionConfig;
        }

        WorkflowExecutionConfig executionConfig = delegate.getExecutionConfig(jobTaskId, workflowName);
        if (executionConfig == null) {
            return null;
        }

        executionConfigs.put(key, executionConfig);
        return executionConfig;
    }

    private String getKey(String jobTaskId, String workflowName) {
        return jobTaskId + "_" + workflowName;
    }

    public void addExecutionConfig(String jobTaskId, String workflowName, WorkflowExecutionConfig executionConfig) {
        String key = getKey(jobTaskId, workflowName);
        executionConfigs.put(key, executionConfig);
    }

}
