package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.opus.optimus.offline.runtime.workflow.api.ITaskStatusPollSupport;
import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingEventListener;
import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingHandler;

public class GroupTaskTrackingHandler implements ITaskTrackingEventListener {
    ITaskTrackingHandler local;
    List<ITaskTrackingHandler> remotes = new ArrayList<>();

    public ITaskTrackingHandler createAndRegisterLocal(ITaskTrackingEventListener listener) {
        local = new TaskTrackingHandler(listener == null ? this : new CompositeTaskTrackingEventListener(Arrays.asList(listener, this)));
        return local;
    }

    public ITaskTrackingHandler createAndRegisterRemote(String name) {
        return null;
    }

    @Override
    public void onTaskEnd(ITaskTrackingHandler handler, boolean success) {

    }

    @Override
    public synchronized void onTrackingEnd(ITaskTrackingHandler handler, boolean success) {
        if (handler.getName().equals(TaskTrackingHandler.NAME)) {
            for (ITaskTrackingHandler remote : remotes) {
                if (remote instanceof ITaskStatusPollSupport) {
                    ((ITaskStatusPollSupport) remote).startPolling();
                }
            }
        }
    }
}
