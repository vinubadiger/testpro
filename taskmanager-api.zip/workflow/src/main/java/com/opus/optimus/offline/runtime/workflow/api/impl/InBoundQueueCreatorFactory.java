package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreator;
import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreatorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class InBoundQueueCreatorFactory implements IInBoundQueueCreatorFactory {

    private final static String PREFIX = "inBoundQueueCreator.";

    @Autowired
    Map<String, IInBoundQueueCreator> creators;

    @Override
    public IInBoundQueueCreator getCreator(String creatorName) {
        String actualCreatorName = PREFIX + creatorName;
        IInBoundQueueCreator inBoundQueueCreator = creators.get(actualCreatorName);
        if (inBoundQueueCreator == null) {
            throw new RuntimeException("Inbound queue creator not registered under the name " + actualCreatorName);
        }

        return inBoundQueueCreator;
    }
}
