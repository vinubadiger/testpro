package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.offline.runtime.workflow.api.StepInstanceStats;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;
import com.opus.optimus.offline.runtime.workflow.api.event.IMachine;
import com.opus.optimus.offline.runtime.workflow.api.event.impl.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobEventEmitterHelper {
    IJobEventEmitter emitter;
    IMachine machine;
    String jobId;
    String jobTaskId;
    String workflowName;
    String stepName;
    String stepType;
    int instanceId;

    public JobEventEmitterHelper(IJobEventEmitter emitter) {
        this.emitter = emitter;
    }

    public JobEventEmitterHelperBuilder createNew() {
        return builder()
                .emitter(emitter)
                .machine(machine)
                .jobId(jobId)
                .jobTaskId(jobTaskId)
                .workflowName(workflowName)
                .stepName(stepName)
                .stepType(stepType)
                .instanceId(instanceId);
    }

    public void startJob() {
        startJob(jobId);
    }

    public void endJob(String status) {
        endJob(jobId, status);
    }

    public void startJob(String jobId) {
        JobEvent event = createJobEvent(jobId, JobEventType.START_JOB);
        emitter.emit(event);
    }

    public void endJob(String jobId, String status) {
        JobStatusEvent event = createJobStatusEvent(jobId, JobEventType.END_JOB, status);
        emitter.emit(event);
    }

    public void startJobTaskExecutor() {
        JobTaskEvent event = createJobTaskEvent(JobEventType.START_JOB_TASK_EXECUTOR);
        emitter.emit(event);
    }

    public void endJobTaskExecutor(OperationStatus status) {
        JobTaskEvent event = createJobTaskEvent(JobEventType.END_JOB_TASK_EXECUTOR);
        event.setStatus(status);
        emitter.emit(event);
    }

    public void startStepExecutor() {
        StepExecutorEvent event = createStepExecutorEvent(JobEventType.START_STEP_EXECUTOR);
        emitter.emit(event);
    }

    public void endStepExecutor() {
        StepExecutorEvent event = createStepExecutorEvent(JobEventType.END_STEP_EXECUTOR);
        emitter.emit(event);
    }

    public void startStepInstanceExecutor() {
        StepInstanceEvent event = createStepInstanceEvent(JobEventType.START_STEP_INSTANCE_EXECUTOR);
        emitter.emit(event);
    }

    public void endStepInstanceExecutor(boolean forceEnd, StepInstanceStats stats) {
        StepInstanceEvent event = createStepInstanceEvent(JobEventType.END_STEP_INSTANCE_EXECUTOR);
        event.setStats(stats);
        emitter.emit(event);
    }

    public void startOnStepEnd() {
        StepExecutorEvent event = createStepExecutorEvent(JobEventType.START_ON_STEP_END);
        emitter.emit(event);
    }

    public void endOnStepEnd() {
        StepExecutorEvent event = createStepExecutorEvent(JobEventType.END_ON_STEP_END);
        emitter.emit(event);
    }

    private JobEvent createJobEvent(JobEventType eventType) {
        return createJobEvent(jobId, eventType);
    }

    private JobEvent createJobEvent(String jobId, JobEventType eventType) {
        JobEvent event = new JobEvent();
        fillJobEvent(event, jobId, eventType);
        return event;
    }

    private JobStatusEvent createJobStatusEvent(String jobId, JobEventType eventType, String status) {
        JobStatusEvent event = new JobStatusEvent();
        fillJobEvent(event, jobId, eventType);
        event.setStatus(status);
        return event;
    }

    private JobTaskEvent createJobTaskEvent(JobEventType eventType) {
        JobTaskEvent event = new JobTaskEvent();
        fillJobTaskEvent(event, eventType);
        return event;
    }

    private StepExecutorEvent createStepExecutorEvent(JobEventType eventType) {
        StepExecutorEvent event = new StepExecutorEvent();
        fillStepExecutorEvent(event, eventType);
        return event;
    }

    private StepInstanceEvent createStepInstanceEvent(JobEventType eventType) {
        StepInstanceEvent event = new StepInstanceEvent();
        fillStepInstanceEvent(event, eventType);
        return event;
    }

    private void fillJobEvent(JobEvent event, String jobId, JobEventType eventType) {
        event.setTime(System.currentTimeMillis());
        event.setEventType(eventType.name());
        event.setMachine(machine);
        event.setJobId(jobId);
    }

    private void fillJobEvent(JobEvent event, JobEventType eventType) {
        fillJobEvent(event, jobId, eventType);
    }

    private void fillJobTaskEvent(JobTaskEvent event, JobEventType eventType) {
        fillJobEvent(event, eventType);
        event.setJobTaskId(jobTaskId);
    }

    private void fillStepExecutorEvent(StepExecutorEvent event, JobEventType eventType) {
        fillJobTaskEvent(event, eventType);
        event.setWorkflowName(workflowName);
        event.setStepName(stepName);
        event.setStepType(stepType);
    }

    private void fillStepInstanceEvent(StepInstanceEvent event, JobEventType eventType) {
        fillStepExecutorEvent(event, eventType);
        event.setInstanceId(instanceId);
    }

}
