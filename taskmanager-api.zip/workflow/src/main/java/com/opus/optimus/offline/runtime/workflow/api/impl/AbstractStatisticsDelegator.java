package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.LinkStats;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;

public class AbstractStatisticsDelegator {
    LinkStats linkStats = new LinkStats();

    protected <T extends Serializable> void updateStats(T message) {
        if (message == null) {
            return;
        }

        MessageType type = null;
        if (message instanceof IMessage) {
            type = ((IMessage) message).getType();
            type = (type == null) ? MessageType.DATA : type;
        }

        updateStatsByMessageType(type);
    }

    protected void updateStatsByMessageType(MessageType type) {
        if (type == null) {
            linkStats.incUnknownCount();
            return;
        }

        switch (type) {
            case DATA: {
                linkStats.incDataCount();
                return;
            }
            case ERROR: {
                linkStats.incErrorCount();
                return;
            }
            case END: {
                linkStats.incEndCount();
                return;
            }
        }
    }

    public LinkStats getLinkStats() {
        return linkStats;
    }

}
