package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;

public class StatisticsEmitterDelegator extends AbstractStatisticsDelegator implements IEmitter {
    IEmitter delegate;

    public StatisticsEmitterDelegator(IEmitter delegate) {
        this.delegate = delegate;
    }

    @Override
    public <T extends Serializable> void emit(T data) {
        updateStats(data);
        delegate.emit(data);
    }

    @Override
    public <T extends Serializable> void end(T data) {
        updateStats(data);
        delegate.end(data);
    }

}
