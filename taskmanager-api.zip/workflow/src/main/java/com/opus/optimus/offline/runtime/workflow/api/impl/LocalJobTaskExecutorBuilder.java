package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;

@Component
public class LocalJobTaskExecutorBuilder implements BeanFactoryAware {
    BeanFactory beanFactory;

    public LocalJobTaskExecutor buildWith(String jobId, String jobTaskId, JobConfig jobConfig, IWorkflowConfigRepository workflowConfigRepository) {
        LocalJobTaskExecutor executor = beanFactory.getBean(LocalJobTaskExecutor.class, jobId, jobTaskId, jobConfig, workflowConfigRepository);
        return executor;
    }

    public LocalJobTaskExecutor buildWith(String jobId, String jobTaskId, WorkflowConfig workflowConfig, WorkflowExecutionConfig workflowExecutionConfig) {
        LocalJobTaskExecutor executor = beanFactory.getBean(LocalJobTaskExecutor.class, jobId, jobTaskId, workflowConfig, workflowExecutionConfig);
        return executor;
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }
}
