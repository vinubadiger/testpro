package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkflowConfig {
    public final static String DEFAULT_WORKFLOW_NAME = "default";

    public final static String DEFAULT_START_STEP_NAME = "start";

    @Builder.Default
    String name = DEFAULT_WORKFLOW_NAME;

    List<IStepConfig> stepConfigs;

    List<IStepLink> stepLinks;

    String startStepName;

    String endStepName;
}
