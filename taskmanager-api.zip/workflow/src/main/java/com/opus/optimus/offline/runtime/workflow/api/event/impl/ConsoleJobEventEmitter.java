package com.opus.optimus.offline.runtime.workflow.api.event.impl;

import java.util.Date;

import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventEmitter;

public class ConsoleJobEventEmitter implements IJobEventEmitter {

    @Override
    public void emit(IJobEvent event) {
        Date date = new Date(event.getTime());
        System.out.println("[" + date + "] (" + Thread.currentThread().getName() + ") - " + event);
    }
}
