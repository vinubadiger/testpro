package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.concurrent.Phaser;

import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingEventListener;
import com.opus.optimus.offline.runtime.workflow.api.ITaskTrackingHandler;

public class TaskTrackingHandler implements ITaskTrackingHandler {
    public static final String NAME = "local";

    private Phaser tasks = new Phaser();
    ITaskTrackingEventListener listener;

    public TaskTrackingHandler(ITaskTrackingEventListener listener) {
        this.listener = listener;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public synchronized void addTask() {
        if (tasks.isTerminated()) {
            tasks = new Phaser();
        }
        tasks.register();
    }

    @Override
    public synchronized void endTask(boolean success) {
        tasks.arriveAndDeregister();

        listener.onTaskEnd(this, success);

        if (hasPendingTasks() == false) {
            listener.onTrackingEnd(this, success);
        }
    }

    @Override
    public synchronized boolean hasPendingTasks() {
        return getPendingTaskCount() > 0;
    }

    @Override
    public synchronized int getPendingTaskCount() {
        return tasks.getUnarrivedParties();
    }

}
