package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorBuilder;
import org.springframework.stereotype.Component;

@Component("stepTaskCreatorBuilder.static")
public class StaticStepTaskCreatorBuilder implements IStepTaskCreatorBuilder {
    @Override
    public IStepTaskCreator buildWith(String workflowName, IStepConfig stepConfig, IQueue inBoundQueue, IEmitter outBoundEmitter,
                                      IStepExecutorConfig stepExecutorConfig) {
        if (stepExecutorConfig instanceof LocalStepExecutorConfig == false) {
            throw new RuntimeException("Invalid step execution config(" + stepExecutorConfig.getClass().getCanonicalName()
                    + ") to static step task creator");
        }

        LocalStepExecutorConfig staticStepExecutorConfig = (LocalStepExecutorConfig) stepExecutorConfig;
        return new StaticStepTaskCreator(staticStepExecutorConfig.getMaxNoOfTasks(),
                workflowName,
                stepConfig,
                inBoundQueue,
                outBoundEmitter);
    }

    @Override
    public IStepExecutorConfig getDefaultStepExecutorConfig() {
        return new LocalStepExecutorConfig(4, 4, LocalJobTaskExecutor.DEFAULT_LOCAL_QUEUE_CONFIG);
    }
}
