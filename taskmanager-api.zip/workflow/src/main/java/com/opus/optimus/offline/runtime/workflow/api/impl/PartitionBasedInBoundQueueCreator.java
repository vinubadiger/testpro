package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.workflow.api.IInBoundQueueCreator;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionKeyProvider;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import org.springframework.stereotype.Component;

@Component("inBoundQueueCreator.partitionBased")
public class PartitionBasedInBoundQueueCreator implements IInBoundQueueCreator<PartitionBasedQueueConfig> {

    @Override
    public IQueue createQueue(PartitionBasedQueueConfig queueConfig, IStepConfig stepConfig) {
        if (stepConfig instanceof IPartitionKeyProvider) {
            return new PartitionBasedQueue(queueConfig, (IPartitionKeyProvider) stepConfig);
        }

        return new PartitionBasedQueue(queueConfig, null);
    }

    @Override
    public boolean isSharedQueue() {
        return false;
    }

    @Override
    public PartitionBasedQueueConfig getDefaultConfig() {
        return new PartitionBasedQueueConfig(1, new StaticPartitionIdentifier(), LocalJobTaskExecutor.DEFAULT_LOCAL_QUEUE_CONFIG);
    }
}
