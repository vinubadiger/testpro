package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkflowExecutionConfig {
    // Step name -> Step executor config
    @Builder.Default
    private Map<String, IStepExecutorConfig> stepExecutorConfigs = new HashMap<>();

    public IStepExecutorConfig getStepExecutorConfig(String stepName) {
        return stepExecutorConfigs.get(stepName);
    }

    public void addStepExecutionConfig(String jobTaskId, String stepName, IStepExecutorConfig executorConfig) {
        stepExecutorConfigs.put(stepName, executorConfig);
    }

}
