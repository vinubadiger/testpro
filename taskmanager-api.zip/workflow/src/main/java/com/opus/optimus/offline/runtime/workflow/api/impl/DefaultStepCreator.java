package com.opus.optimus.offline.runtime.workflow.api.impl;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.workflow.api.IStep;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepCreator;

@Component("default.stepCreator")
public class DefaultStepCreator implements IStepCreator, BeanFactoryAware {
    BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    @Override
    public IStep create(IStepConfig stepConfig) {
        String stepType = stepConfig.getStepType();

        boolean singleton = beanFactory.isSingleton(stepType);
        if (singleton) {
            throw new RuntimeException("Step component should be scoped as prototype ..." + stepType + " is singleton...");
        }

        return (IStep) beanFactory.getBean(stepType, stepConfig);
    }
}
