package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;

public class WorkflowConfigHelper {
    WorkflowConfig workflowConfig;
    Map<String, IStepConfig> stepConfigs;
    Map<String, List<IStepLink>> stepInBoundLinks;
    Map<String, List<IStepLink>> stepOutBoundLinks;


    public WorkflowConfigHelper(WorkflowConfig workflowConfig) {
        this.workflowConfig = workflowConfig;

        init();
    }

    private void init() {
        List<IStepConfig> workflowStepConfigs = workflowConfig.getStepConfigs();
        workflowStepConfigs = workflowStepConfigs == null ? new ArrayList<>() : workflowStepConfigs;

        this.stepConfigs = workflowStepConfigs.stream()
                .collect(Collectors.toMap(IStepConfig::getStepName, e -> e));

        List<IStepLink> stepLinks = workflowConfig.getStepLinks();
        stepLinks = stepLinks == null ? new ArrayList<>() : stepLinks;

        stepInBoundLinks = stepLinks.stream()
                .collect(Collectors.groupingBy(IStepLink::getTo, Collectors.toList()));

        stepOutBoundLinks = stepLinks.stream()
                .collect(Collectors.groupingBy(IStepLink::getFrom, Collectors.toList()));
    }

    public String getWorkflowName() {
        return workflowConfig.getName();
    }

    public List<IStepConfig> getStepConfigs() {
        return workflowConfig.getStepConfigs();
    }

    public IStepConfig getStepConfig(String stepName) {
        return stepConfigs.get(stepName);
    }

    public List<IStepLink> getInBoundStepLinks(String stepName) {
        return stepInBoundLinks.get(stepName);
    }

    public List<IStepLink> getOutBoundStepLinks(String stepName) {
        return stepOutBoundLinks.get(stepName);
    }

    public WorkflowConfig getWorkflowConfig() {
        return workflowConfig;
    }
}
