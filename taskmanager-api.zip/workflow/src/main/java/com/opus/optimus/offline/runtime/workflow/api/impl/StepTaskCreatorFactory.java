package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorBuilder;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreatorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class StepTaskCreatorFactory implements IStepTaskCreatorFactory {
    private final static String PREFIX = "stepTaskCreatorBuilder.";

    @Autowired
    Map<String, IStepTaskCreatorBuilder> creators;

    @Override
    public IStepTaskCreatorBuilder getBuilder(String creatorName) {
        String actualCreatorName = PREFIX + creatorName;
        IStepTaskCreatorBuilder stepTaskCreator = creators.get(actualCreatorName);
        if (stepTaskCreator == null) {
            throw new RuntimeException("Invalid step task creator name - " + creatorName);
        }

        return stepTaskCreator;
    }
}
