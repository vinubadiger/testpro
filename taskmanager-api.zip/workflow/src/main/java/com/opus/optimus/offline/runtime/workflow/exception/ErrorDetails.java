package com.opus.optimus.offline.runtime.workflow.exception;

import java.io.Serializable;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	String userDetails;
	Serializable errorDetail;
	Severity severity;
	String caseId;
	private Map<String, Object> additionalData;
}
