package com.opus.optimus.offline.runtime.workflow.api.impl;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.queue.api.IReceiver;

public class StatisticsReceiverDelegator extends AbstractStatisticsDelegator implements IReceiver {
    IReceiver delegate;

    public StatisticsReceiverDelegator(IReceiver delegate) {
        this.delegate = delegate;
    }

    @Override
    public <T extends Serializable> T getNext() throws Exception {
        Serializable next = delegate.getNext();
        updateStats(next);
        return (T) next;
    }

}
