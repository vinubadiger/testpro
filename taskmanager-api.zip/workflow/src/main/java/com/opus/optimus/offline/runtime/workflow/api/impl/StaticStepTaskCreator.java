package com.opus.optimus.offline.runtime.workflow.api.impl;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.queue.api.IQueue;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepTask;
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator;

import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StaticStepTaskCreator implements IStepTaskCreator {
    IStepConfig stepConfig;
    Iterator<SimpleStepTask> taskIterator = null;

/*    private void init(int noOfTasks, IStepConfig stepConfig,
                                 IQueue inBoundQueue, IQueue outBoundQueue) {
        taskIterator = IntStream.range(0, noOfTasks)
                .mapToObj(index ->
                        new SimpleStepTask(
                                "local.stepInstanceExecutor",
                                index,
                                stepConfig,
                                inBoundQueue == null ? null : inBoundQueue.getReceiver(),
                                outBoundQueue == null ? null : outBoundQueue.getEmitter()))
                .collect(Collectors.toList())
                .iterator();
    }*/

    public StaticStepTaskCreator(int noOfTasks, String workflowName, IStepConfig stepConfig,
                                 IQueue inBoundQueue, IEmitter outBoundEmitter) {
        this.stepConfig = stepConfig;
        taskIterator = IntStream.range(0, noOfTasks)
                .mapToObj(index ->
                        new SimpleStepTask(
                                "local.stepInstanceExecutor",
                                index,
                                workflowName,
                                stepConfig,
                                inBoundQueue == null ? null : inBoundQueue.getReceiver(null),
                                outBoundEmitter))
                .collect(Collectors.toList())
                .iterator();
    }

    @Override
    public IStepConfig getStepConfig() {
        return stepConfig;
    }

    @Override
    public boolean hasNext() {
        return taskIterator.hasNext();
    }

    @Override
    public IStepTask next() {
        return taskIterator.next();
    }
}
