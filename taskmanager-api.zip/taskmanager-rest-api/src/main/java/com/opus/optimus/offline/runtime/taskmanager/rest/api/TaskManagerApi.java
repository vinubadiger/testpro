
package com.opus.optimus.offline.runtime.taskmanager.rest.api;

import java.util.List;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobIdException;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IReconSummary;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

@RestController
@RequestMapping ("/taskmngr")
public class TaskManagerApi {
	private static final Logger logger = LoggerFactory.getLogger(TaskManagerApi.class);

	@Autowired
	private ITaskManager taskManager;
	
	@Autowired
	private IReconSummary reconSummaryService;

	@GetMapping ("/job/{jobId}")
	JobInfo getJobInfo(@PathVariable String jobId) {
		logger.debug("Recevied  getjob command",jobId);
		try{
			return this.taskManager.getJobInfo(jobId);
		} catch (InvalidJobIdException ex){
			throw new RuntimeException("Job Not found (ID) :" + ex.getMessage());
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	@PostMapping ("/job/{name}")
	String createJob(@PathVariable String name, @RequestBody List<JobTask> jobTasks) {
		logger.debug("Recevied  createjob command");
		try{
			return this.taskManager.createJob(name, jobTasks);
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	@GetMapping ("/job/cancel/{jobId}")
	void cancelJob(@PathVariable String jobId) {
		logger.debug("Recevied Job cancel command",jobId);
		try{
			this.taskManager.cancelJob(jobId);
		} catch (InvalidJobIdException e){
			throw new EngineException("Job Not found (ID) :" + e.getMessage());
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	@GetMapping ("/job/run/{jobId}")
	void runJob(@PathVariable String jobId) {
		logger.info("Recevied Job Run command ===>>> "+jobId);
		try{
			this.taskManager.runJob(jobId);
		} catch (InvalidJobIdException e){
			throw new RuntimeException("Job Not found (ID) :" + e.getMessage());
		} catch (InvalidJobStatusException e){
			throw new EngineException(e);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			throw new EngineException(e);
		}
	}

	@GetMapping ("/job/result/{jobId}")
	JobResult getJobResult(@PathVariable String jobId) {
		logger.debug("Recevied Getjobresult command",jobId);
		try{
			return this.taskManager.getJobResult(jobId);
		} catch (InvalidJobIdException e){
			throw new EngineException("Job Not found (ID) :" + e.getMessage());
		}
	}

	@GetMapping ("/job/status/{jobStatus}")
	List<JobInfo> getJobInfos(@PathVariable JobStatus jobStatus) {
		logger.debug("Recevied getJobInfos command",jobStatus);
		try{
			return this.taskManager.getJobInfos(jobStatus);
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	@PostMapping ("/job/createJobResult/{jobId}/{jobTaskId}")
	JobResult createJobTaskResult(@PathVariable String jobId, @PathVariable String jobTaskId, @RequestBody JobTaskExecutorResult jobTaskExecutorResult) {
		logger.debug("Recevied createJobTaskResult command",jobTaskId);
		try{
			return this.taskManager.saveJobTaskResult(jobId, jobTaskId, jobTaskExecutorResult);
		} catch (Exception e){
			throw new EngineException(e);
		}

	}

	@Deprecated
	@GetMapping ("/job/updateReconSummary/{jobId}")
	ConcurrentMap<SummaryKey, List<ReconSourceSummary>> deleteJobById(@PathVariable String jobId) {
		logger.debug("Recevied Delete job command",jobId);
		try{
			return this.reconSummaryService.updateBatchSummary(jobId);
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

}

