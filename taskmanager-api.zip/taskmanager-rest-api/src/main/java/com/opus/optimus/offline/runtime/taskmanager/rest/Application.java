package com.opus.optimus.offline.runtime.taskmanager.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication (scanBasePackages = { "com.opus.optimus.offline", "com.opusconsulting.pegasus.formula" })
@EnableMongoRepositories ("com.opus.optimus.offline.runtime")
public class Application {// extends SpringBootServletInitializer {
	private static final Logger log = LoggerFactory.getLogger(Application.class);

	/*
	 * @Override protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
	 * log.debug("Init: SpringBootServletInitializer SpringApplicationBuilder"); return configureApplication(builder); }
	 */

	public static void main(String[] args) {
		log.debug("Init: SpringBootApplication Main");
		configureApplication(new SpringApplicationBuilder()).run(args);
	}

	private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
		return builder.sources(Application.class);
	}

}
