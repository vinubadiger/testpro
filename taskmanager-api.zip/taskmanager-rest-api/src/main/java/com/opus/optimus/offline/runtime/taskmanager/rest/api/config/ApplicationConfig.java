/**
 * 
 */
package com.opus.optimus.offline.runtime.taskmanager.rest.api.config;

import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskReceiver;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IDataSourceConfigService;

/**
 * @author Rahul.Mohan
 */
@Component
public class ApplicationConfig {

	private static final Logger log = LoggerFactory.getLogger(ApplicationConfig.class);

	@Autowired
	private ApplicationContext applicationContext;

	@PostConstruct
	private void loadConfigs() {
		log.debug("Building and registering data source factories..");
		buildAndRegisterDataSourceFactory();

		log.debug("Starting Task manager..");
		startTaskManager();

		log.debug("Testing Script engine..");
		testClasspathIssue();

	}

	private void startTaskManager() {
		ITaskManagerAdmin taskManagerAdmin = this.applicationContext.getBean(ITaskManagerAdmin.class);
		ITaskReceiver taskReceiver = this.applicationContext.getBean(ITaskReceiver.class);
		if (taskManagerAdmin != null){
			taskManagerAdmin.start();
		}
		if (taskReceiver != null){
			taskReceiver.start();
		}
	}

	private void buildAndRegisterDataSourceFactory() {
		try{
			final IDataSourceConfigService dataSourceConfigService = this.applicationContext.getBean(IDataSourceConfigService.class);
			if (dataSourceConfigService == null){
				log.error("No Bean defined of type IDataSourceConfigService. Cannot load the Data source factory. Please checck the boot logs.");
				return;
			}

			final DataSourceFactory dataSourceFactory = this.applicationContext.getBean(DataSourceFactory.class);
			if (dataSourceFactory == null){
				log.error("No Bean defined of type DataSourceFactory. Cannot load the Data source factory. Please checck the boot logs.");
				return;
			}

			List<MongoDataSourceMeta> dataSourceMetas = dataSourceConfigService.findAllDataSourceConfigs();
			if (dataSourceMetas != null){
				dataSourceMetas.parallelStream().forEach(dataSourceMeta -> {
					final MongoDataSource dataSource = new MongoDataSource(dataSourceMeta);
					dataSource.init();
					dataSourceFactory.register(dataSourceMeta.getDataSourceName(), dataSource);
				});
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	// TODO TO be removed
	private void testClasspathIssue() {
		ScriptCreatorFactory scriptCreatorFactory = this.applicationContext.getBean(ScriptCreatorFactory.class);
		String formulaText = "PEEK(5,13)";
		String rawText = "DT10020181601TESTOPUS";

		IScriptConfig excelScriptConfig = ExcelScriptConfig.builder().formulaText(formulaText).conditional(false).type("excel.rawtext-script").build();

		IScript<? super String, ?> valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig);
		if (valueProviderScript != null){
			String output = (String) valueProviderScript.execute(rawText);
			System.out.println("Formula output:" + output);
		}
	}

}
