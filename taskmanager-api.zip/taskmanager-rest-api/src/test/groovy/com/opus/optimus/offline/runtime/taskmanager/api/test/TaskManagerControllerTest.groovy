package com.opus.optimus.offline.runtime.taskmanager.api.test

import org.junit.Ignore;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import org.json.JSONArray
import org.json.JSONObject
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.AutoConfigureAfter
import org.springframework.boot.autoconfigure.AutoConfigureBefore
import org.springframework.boot.autoconfigure.mongo.embedded.EmbeddedMongoAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest(classes = TestBootApplication.class)
@AutoConfigureMockMvc
@AutoConfigureBefore(EmbeddedMongoAutoConfiguration.class)
@Ignore			//TODO failing inconsistently - Need to find the reason
class TaskManagerControllerTest extends Specification {

	@Autowired
	private MockMvc mvc;

	JobTask jobtask;
	List<JobTask> jobTaskList;
	JSONObject jsonObj;
	JSONArray jsonArray;

	@Autowired
	private ObjectMapper objectMapper;

	def "Create Job" () {
		given:
		String jobId = "data"
		jobtask = JobTask.builder().taskId("123").build();
		jobTaskList = new ArrayList<JobTask>();
		jobTaskList.add(jobtask);

		when:
		MvcResult response = mvc.perform(
		post("/taskmngr/job/{jobId}",jobId).contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(jobTaskList))
		).andReturn()
		then:
		response.getResponse().getStatus() == 200
	}

	def "Get Job" () {
		given:
		String jobId = "data"
		jobtask = JobTask.builder().taskId("456").build();
		jobTaskList = new ArrayList<JobTask>();
		jobTaskList.add(jobtask);

		MvcResult responseOfCreateJob = mvc.perform(
		post("/taskmngr/job/{jobId}",jobId).contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(jobTaskList))
		).andReturn()
		String contentAsString = responseOfCreateJob.getResponse().getContentAsString();

		when:
		MvcResult response = mvc.perform(
		get("/taskmngr/job/{jobId}",contentAsString)
		).andReturn()

		def result = response.getResponse().getContentAsString();
		jsonObj = new JSONObject(result);

		then:
		response.getResponse().getStatus() == 200 && jsonObj.get("name") == jobId
	}

	def "Create Job Result" () {
		given:
		JobTaskExecutorResult jobtaskExecutor = JobTaskExecutorResult.builder().jobTaskId("5").build();

		when:
		MvcResult response = mvc.perform(
		post("/taskmngr/job/createJobResult/{jobId}/{jobTaskId}","4","5")
		.contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(jobtaskExecutor))
		).andReturn()

		then:
		response.getResponse().getStatus() == 200
	}

	def "Get JobResult Test Case" () {

		given:
		String jobId = "data"
		jobtask = JobTask.builder().taskId("123").build();
		jobTaskList = new ArrayList<JobTask>();
		jobTaskList.add(jobtask);

		MvcResult responseOfCreateJob = mvc.perform(
		post("/taskmngr/job/{jobId}",jobId).contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(jobTaskList))
		).andReturn()
		String contentAsString = responseOfCreateJob.getResponse().getContentAsString();

		when:
		MvcResult response = mvc.perform(
		get("/taskmngr/job/result/{jobId}",contentAsString)
		).andReturn()

		then:
		response.getResponse().getStatus() == 200
	}

	def "Delete Job" () {
		given:
		String jobId = "5236e851-3501-4a85-bd22-70f3cc75b075";
		when:
		//delete job
		MvcResult response = mvc.perform(
		get("/taskmngr/job/delete/{jobId}",jobId)
		).andReturn()

		then:
		response.getResponse().getStatus() == 200
	}

	def "Get Job Infos using Job Status" () {

		given:
		boolean checkStatus = true;
		String jobStatus = "WAITING_TO_START"
		when:
		MvcResult response = mvc.perform(
		get("/taskmngr/job/status/{jobStatus}",jobStatus)
		).andReturn()

		String contentAsString = response.getResponse().getContentAsString();
		jsonArray = new JSONArray(contentAsString);
		
		for (int i=0; i < jsonArray.length(); i++) {
			if(jsonArray.getJSONObject(i).get("status") != jobStatus)
				checkStatus=false
		}
		
		then:
		response.getResponse().getStatus() == 200 && checkStatus == true
	}
	
	/*def "Run Job" () {
	
		when:
		MvcResult response = mvc.perform(
		get("/taskmngr/job/run/{jobId}","39497bf9-2083-4353-a7e5-31824ea2355e")
		).andReturn()

		then:
		response.getResponse().getStatus() == 200
	}
	
	def "Cancel Job" () {
		
			when:
			MvcResult response = mvc.perform(
			get("/taskmngr/job/cancel/{jobId}","39497bf9-2083-4353-a7e5-31824ea2355e")
			).andReturn()
	
			then:
			response.getResponse().getStatus() == 200
		}*/
}
