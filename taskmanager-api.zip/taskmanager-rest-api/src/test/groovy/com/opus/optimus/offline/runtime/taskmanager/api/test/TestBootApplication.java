package com.opus.optimus.offline.runtime.taskmanager.api.test;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(scanBasePackages = { "com.opus.optimus.offline" })
//@EnableMongoRepositories ("com.opus.optimus.offline.runtime")
public class TestBootApplication {
}
