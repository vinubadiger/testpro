package com.opus.optimus.offline.runtime.common.writer.exception;

/**
 * The Class WriterException.
 */
public class WriterException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new writer exception.
	 *
	 * @param throwable the throwable
	 */
	public WriterException(Throwable throwable) {
		super(throwable);
	}

	/**
	 * Instantiates a new writer exception.
	 *
	 * @param message the message
	 * @param throwable the throwable
	 */
	public WriterException(String message, Throwable throwable) {
		super(message, throwable);
	}
}
