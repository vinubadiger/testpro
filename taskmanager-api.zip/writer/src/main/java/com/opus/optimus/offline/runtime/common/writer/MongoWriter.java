package com.opus.optimus.offline.runtime.common.writer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mongodb.MongoBulkWriteException;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.InsertOneModel;
import com.mongodb.client.model.UpdateOneModel;
import com.mongodb.client.model.WriteModel;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.writer.exception.WriterException;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;

import lombok.Getter;

/**
 * The Class MongoWriter.
 */
@Component
@Scope("prototype")
public class MongoWriter implements IJobTaskInfoAware {

	static final String ERRORSTATEMENT = "Error occured while bulk write batch commit.";

	/** The Constant DB_BATCH_SIZE. */
	private static final int DB_BATCH_SIZE = 512;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(MongoWriter.class);

	/** The Constant JOB_ID_INFO. */
	public static final String JOB_ID_INFO = "_jobId";

	/**
	 * Gets the config.
	 *
	 * @return the config
	 */
	@Getter
	private MongoDBWriterConfig config;

	/** The data source factory. */
	@Autowired
	private DataSourceFactory dataSourceFactory;

	/** The write model batch. */
	private List<WriteModel<Document>> writeModelBatch = new ArrayList<>();

	/** The database. */
	private MongoDatabase database;

	/** The collection. */
	private MongoCollection<Document> collection;

	/** The job task info. */
	IJobTaskInfo jobTaskInfo;

	/**
	 * Initialize the.
	 *
	 * @param config -
	 *            The configuration of DB writer 
	 * @throws WriterException
	 *             the writer exception
	 */
	public void init(final MongoDBWriterConfig config) throws WriterException {
		this.config = config;
		try {
			final IDataSource dataSource = dataSourceFactory.getDataSource(this.config.getDataSourceName());
			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())) {
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				// get the database
				this.database = mongoDataSource.getDatabase();
				// get the collection
				this.collection = database.getCollection(this.config.getCollectionName());
				if (collection == null) {

					database.createCollection(this.config.getCollectionName());
					collection = database.getCollection(this.config.getCollectionName());
				}
			} else {
				logger.error("Incorrect datasource identified. Please check configuration.");
				throw new NoSuchDataSourceAvailableException(
						"Incorrect datasource identified. Please check configuration.");
			}
		} catch (NoSuchDataSourceAvailableException dataSourceAvailableException) {
			logger.error("Error occured while initializing Mongo DB writer : {}", dataSourceAvailableException);
			throw new WriterException("Failed to initialize DB Writer.", dataSourceAvailableException);
		} catch (DataSourceInitializationException e) {
			logger.error("Error occured while initializing Mongo DB writer : {}", e);
			throw new WriterException("Failed to initialize DB Writer.", e);
		}
	}

	/**
	 * Process.
	 *
	 * @param <T>
	 *            the generic type
	 * @param record -
	 *            The record to write in DB 
	 * @param jobTaskInfo -
	 *            the job task info
	 * @throws WriterException -
	 *             The writer exception
	 */
	public <T extends Serializable> void process(IRecord record, IJobTaskInfo jobTaskInfo) throws WriterException {
		// capture the IMessage from previous step

		if (config.isUpdate()) {
			// build the document to be updated
			final Document updateData = new Document();

			config.getFieldConfigs().stream().filter(fieldConfig -> !(fieldConfig.isPrimaryField()))
					.forEach(fieldConfig -> {
						updateData.append(fieldConfig.getTargetFieldName(), readRecordFieldData(record,
								fieldConfig.getSourceFieldName(), fieldConfig.getTargetDataType()));
					});
			updateData.append(JOB_ID_INFO, (jobTaskInfo != null) ? jobTaskInfo.getJobId() : null);

			final Document updateDocument = new Document().append("$set", updateData);

			// build the criteria document
			final Document filterdocument = new Document();
			config.getFieldConfigs().stream().filter(fieldConfig -> (fieldConfig.isPrimaryField()))
					.forEach(fieldConfig -> {
						filterdocument.append(fieldConfig.getTargetFieldName(), readRecordFieldData(record,
								fieldConfig.getSourceFieldName(), fieldConfig.getTargetDataType()));
					});
			// update document
			writeModelBatch.add(new UpdateOneModel<>(filterdocument, updateDocument));
		} else {
			// build the Document
			final Document document = new Document();
			config.getFieldConfigs().stream().forEach(fieldConfig -> document.put(fieldConfig.getTargetFieldName(),
					readRecordFieldData(record, fieldConfig.getSourceFieldName(), fieldConfig.getTargetDataType())));
			document.append(JOB_ID_INFO, (jobTaskInfo != null) ? jobTaskInfo.getJobId() : null);
			writeModelBatch.add(new InsertOneModel<>(document));
		}
		if (this.writeModelBatch.size() == DB_BATCH_SIZE) {
			batchCommit();
		}
	}

	/**
	 * Read record field data.
	 *
	 * @param record -
	 *            The record to write in DB 
	 * @param recordFieldName -
	 *            The record field name
	 * @param fieldType -
	 *            the field type
	 * @return the object
	 */
	private Object readRecordFieldData(IRecord record, String recordFieldName, FieldType fieldType) {
		// get the field ID
		int fieldIndex = record.getFieldId(recordFieldName);
		// get the field value from record
		Object fieldValue = record.getValue(fieldIndex);
		// convert the field value as per the type feed and return
		return formatFieldValue(fieldValue, fieldType);
	}

	/**
	 * Format field value.
	 *
	 * @param fieldValue
	 *            the field value
	 * @param fieldType
	 *            the field type
	 * @return the object
	 */
	private Object formatFieldValue(Object fieldValue, FieldType fieldType) {
		// TODO convert the field value as per the type feed and return
		return fieldValue;
	}

	/**
	 * Batch commit.
	 *
	 * @throws WriterException
	 *             the writer exception
	 */
	// In case of exception message need to change the return type
	public void batchCommit() throws WriterException {

		if (this.writeModelBatch.isEmpty())
			return;
		try {
			this.collection.bulkWrite(this.writeModelBatch);
		} catch (MongoBulkWriteException bulkWriteException) {
			logger.error(ERRORSTATEMENT, bulkWriteException);
			throw new WriterException(ERRORSTATEMENT, bulkWriteException);
		} catch (MongoException mongoException) {
			logger.error(ERRORSTATEMENT, mongoException);
			throw new WriterException(ERRORSTATEMENT, mongoException);
		} catch (Exception exception) {
			logger.error(ERRORSTATEMENT, exception);
			throw new WriterException(ERRORSTATEMENT, exception);
		} finally {
			this.writeModelBatch.clear();
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}
}
