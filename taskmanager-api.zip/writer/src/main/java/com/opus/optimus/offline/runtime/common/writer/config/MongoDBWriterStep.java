package com.opus.optimus.offline.runtime.common.writer.config;

import com.opus.optimus.offline.config.writer.MongoDBWriterConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.writer.MongoWriter;
import com.opus.optimus.offline.runtime.common.writer.exception.WriterException;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.*;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.Serializable;

/**
 * The Class MongoDBWriterStep.
 */
@Component(StepTypeConstants.MONGODB_WRITER_STEPTYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MongoDBWriterStep extends AbstractStep<MongoDBWriterConfig> implements IJobTaskInfoAware {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(MongoDBWriterStep.class);

	/** The mongo writer helper. */
	@Autowired
	MongoWriter mongoWriterHelper;

	/** The message factory. */
	@Autowired
	IMessageFactory messageFactory;

	/** The job task info. */
	IJobTaskInfo jobTaskInfo;

	/**
	 * Instantiates a new mongo DB writer step.
	 *
	 * @param config
	 *            the config
	 */
	public MongoDBWriterStep(MongoDBWriterConfig config) {
		super(config);
	}

	/**
	 * Initialize the.
	 *
	 * @throws WriterException
	 *             the writer exception
	 */
	@PostConstruct
	public void init() throws WriterException {
		mongoWriterHelper.init(config);
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		Serializable result = data.getData();
		MessageType messageType = MessageType.DATA;
		try {
			mongoWriterHelper.process((IRecord) result, this.jobTaskInfo);
		} catch (Exception e) {
			messageType = MessageType.ERROR;
			result = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails("Error while processing the record for DB writer step.").errorDetail(e).build();
			logger.error("Error while processing the record for DB writer step.{}", e);
		}

		if (result != null) {
			ISourceReference sourceReference = data.getSourceReference();
			emitter.emit(messageFactory.createMessage(messageType, result, sourceReference));
		}
	}

	@Override
	public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
		try {
			mongoWriterHelper.batchCommit();
		} catch (WriterException e) {
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails("Error while batch commit on DB writer step instance END.").errorDetail(e).build();
			logger.error("Error while batch commit on DB writer step instance END : {}", e);
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails));
		}
		return null;
	}

	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		try {
			mongoWriterHelper.batchCommit();
		} catch (WriterException e) {
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails("Error while batch commit on DB writer step END.").errorDetail(e).build();
			logger.error("Error while batch commit on DB writer step END : {}", e);
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails));
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;

	}
}
