package com.opus.optimus.offline.runtime.workflow.util;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Instantiates a new record field configuration.
 *
 * @param fieldIndex the field index
 * @param name the name
 * @param type the type
 */
@AllArgsConstructor

/**
 * Instantiates a new record field configuration.
 */
@NoArgsConstructor
@Builder
@Data
@ToString
public class RecordFieldConfig implements IFieldConfig {
	
	/** The field index. */
	private short fieldIndex;
	
	/** The name. */
	private String name;
	
	/** The type. */
	private FieldType type;
	
	@Override
	public com.opus.optimus.offline.runtime.common.api.record.FieldType getType() {
		return type;
	}
	
	@Override
	public String getFormat() {
		return null;
	}
	
}
