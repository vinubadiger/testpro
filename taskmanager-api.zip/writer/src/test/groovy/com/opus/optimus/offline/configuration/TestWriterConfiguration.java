package com.opus.optimus.offline.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The Class TestWriterConfiguration.
 */
@Configuration
@ComponentScan ("com.opus.optimus.offline")
public class TestWriterConfiguration {

    /**
     * Creates the executor service.
     *
     * @return the executor service
     */
    @Bean
    public ExecutorService createExecutorService() {
        return Executors.newCachedThreadPool();
    }

}
