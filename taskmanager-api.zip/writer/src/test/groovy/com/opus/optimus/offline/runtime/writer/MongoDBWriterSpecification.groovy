package com.opus.optimus.offline.runtime.writer

import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired

import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.util.RecordFieldConfig
import spock.lang.Ignore


//TODO Need to complete the code in case of MongoWriter initialization

class MongoDBWriterSpecification extends AbstractMongoDbWriterSpecification {

	@Autowired
	MapperFactory mapperFactory

	@Ignore
	def "MongoDB writer Insert execution"() {
		setup:
		def noOfRows = 0;
		def tranAmount = 0;

		def mongoDbWriterConfig1 = new MongoDBWriterConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoWritterInsert.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		mongoDbWriterConfig1 = object.stepConfig;

		mongoWriter.init(mongoDbWriterConfig1);

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("transRef")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("transAmt")
				.type(FieldType.FLOAT)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "samsonData");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("transRef", "000000001");
		testRecordFieldValues.put("transAmt", "250");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");

		when:
		mongoWriter.process(record);
		mongoWriter.batchCommit()
		noOfRows++;

		then:
		noOfRows == 1
		MongoCollection<Document> collection = mongoDataBase.getCollection(collectionName);
		Document searchDocument = new Document();
		searchDocument.append("transReference", "000000001");
		println("Document Filter: " + searchDocument);
		Document searchResult = collection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		if(searchResult != null) {
			println("Record saved in Mongo DB: Transaction Reference: " + searchResult.getString("transReference"))
			tranAmount = Double.parseDouble(searchResult.getString("transAmount"));
		}
		tranAmount == 250;
		println("-----------------------END1------------------------------")
	}

	@Ignore
	def "MongoDB writer Update execution"() {
		setup:
		def tranAmount = 0;

		def mongoDbWriterConfig1 = new MongoDBWriterConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoWritterUpdate.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		mongoDbWriterConfig1 = object.stepConfig;

		mongoWriter.init(mongoDbWriterConfig1);

		//insert a sample record before writer process
		Document testRecord = new Document();
		testRecord.put("transReference", "000000002");
		testRecord.put("transAmount", "100");
		MongoCollection<Document> collection = mongoDataBase.getCollection(collectionName);
		collection.insertOne(testRecord);

		//build the record object
		//define the MongoDB field configurations
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("transRef")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("transAmt")
				.type(FieldType.FLOAT)
				.build());
		utility.buildRecordMetaData(recordFieldConfigs, "samsonData");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("transRef", "000000002");
		testRecordFieldValues.put("transAmt", "300");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");

		when:

		mongoWriter.process(record);
		mongoWriter.batchCommit();
		then:
		Document searchDocument = new Document();
		searchDocument.append("transReference", "000000002");
		println("Document Filter: " + searchDocument);
		Document searchResult = collection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		if(searchResult != null) {
			println("Record saved in Mongo DB: Transaction Reference: " + searchResult.getString("transReference"))
			tranAmount = Double.parseDouble(searchResult.getString("transAmount"));
		}
		tranAmount == 300;
	}

}
