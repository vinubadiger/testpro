package com.opus.optimus.offline.runtime.writer

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.DataSourceAuthMetaData
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.datasource.ServerAddressMetadata
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.configuration.TestWriterConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.writer.MongoWriter

import de.flapdoodle.embed.mongo.Command
import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodProcess
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.DownloadConfigBuilder
import de.flapdoodle.embed.mongo.config.ExtractedArtifactStoreBuilder
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.config.RuntimeConfigBuilder
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.config.IRuntimeConfig
import de.flapdoodle.embed.process.extract.ITempNaming
import de.flapdoodle.embed.process.extract.UUIDTempNaming
import de.flapdoodle.embed.process.io.directories.FixedPath
import de.flapdoodle.embed.process.io.directories.IDirectory
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Shared
import spock.lang.Specification

@ContextConfiguration(classes = TestWriterConfiguration.class)
abstract class AbstractMongoDbWriterSpecification extends Specification {
	@Autowired  //TODO to be enable after discussing about the config loading into object
	MongoWriter mongoWriter;

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	@Qualifier("writerUtility")
	Utility utility;
	
	@Autowired
	MapperFactory mapperFactory

	@Shared MongodExecutable mongodExecutable;
	@Shared MongodProcess mongod;
	@Shared def dbHostIP = "localhost";
	@Shared def dbPort = 27017;
	@Shared def databaseName = "local";//"samsonDb";
	@Shared def collectionName = "samson";

	@Shared MongoClient mongo;
	@Shared MongoDatabase mongoDataBase;

	MongoDBWriterConfig mongoDbWriterConfig;

	def setupSpec() {
		IDirectory artifactStorePath = new FixedPath(System.getProperty("user.home") + "/embeddedMongodbCustomPath");
		ITempNaming executableNaming = new UUIDTempNaming();

		Command command = Command.MongoD;

		IRuntimeConfig runtimeConfig = new RuntimeConfigBuilder()
				.defaults(command)
				.artifactStore(new ExtractedArtifactStoreBuilder()
				.defaults(command)
				.download(new DownloadConfigBuilder()
				.defaultsForCommand(command)
				.artifactStorePath(artifactStorePath))
				.executableNaming(executableNaming))
				.build();

		MongodStarter starter = MongodStarter.getInstance(runtimeConfig);//MongodStarter.getDefaultInstance();
		IMongodConfig mongodConfig = new MongodConfigBuilder()
				.version(Version.Main.DEVELOPMENT)
				.net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
				.build();
		mongodExecutable = starter.prepare(mongodConfig);
		mongod = mongodExecutable.start();



		mongo = new MongoClient(dbHostIP, dbPort);
		mongoDataBase = mongo.getDatabase(databaseName);
	}

	def setup() {
		//Initialize the Mongo DB datasource and register with DataSource factory
		try {
			dataSourceFactory.getDataSource("samsonMongoDataSource");
		} catch (NoSuchDataSourceAvailableException exception) {

			def mapper = mapperFactory.getMapper()
			def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
			def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

			MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
			mongoDataSource.init();
			dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);
		}

	}

	def cleanup() {

	}

	def cleanupSpec() {
		mongo.close();
		mongod.deleteTempFiles();
		mongod.stop();
		mongodExecutable.stop();
	}

}
