package com.opus.optimus.offline.configuration;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

/**
 * The Class TestWorkflowConfig.
 */
public class TestWorkflowConfig {
	
	/** The step config. */
	IStepConfig stepConfig;
	
	/**
	 * Gets the step config.
	 *
	 * @return the step config
	 */
	public IStepConfig getStepConfig() {
		return stepConfig;
	}
	
	/**
	 * Sets the step config.
	 *
	 * @param stepConfig the new step config
	 */
	public void setStepConfig(IStepConfig stepConfig) {
		this.stepConfig = stepConfig;
	}
}
