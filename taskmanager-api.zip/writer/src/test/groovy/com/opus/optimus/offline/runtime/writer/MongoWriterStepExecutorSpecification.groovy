package com.opus.optimus.offline.runtime.writer

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.configuration.TestWriterConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.util.RecordFieldConfig
import de.flapdoodle.embed.mongo.Command
import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodProcess
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.*
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.config.IRuntimeConfig
import de.flapdoodle.embed.process.extract.ITempNaming
import de.flapdoodle.embed.process.extract.UUIDTempNaming
import de.flapdoodle.embed.process.io.directories.FixedPath
import de.flapdoodle.embed.process.io.directories.IDirectory
import de.flapdoodle.embed.process.runtime.Network
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.test.context.ContextConfiguration
import spock.lang.Shared
import spock.lang.Specification

@ContextConfiguration(classes = TestWriterConfiguration.class)
class MongoWriterStepExecutorSpecification extends Specification {

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    @Qualifier("writerUtility")
    Utility utility;

    @Autowired
    MapperFactory mapperFactory

    @Shared
    MongodExecutable mongodExecutable;
    @Shared
    MongodProcess mongod;
    @Shared
    def dbHostIP = "localhost";
    @Shared
    def dbPort = 27017;
    @Shared
    def databaseName = "local";//"samsonDb";
    @Shared
    def collectionName = "samson";

    @Shared
    MongoClient mongo;
    @Shared
    MongoDatabase mongoDataBase;


    def setupSpec() {
        IDirectory artifactStorePath = new FixedPath(System.getProperty("user.home") + "/embeddedMongodbCustomPath");
        ITempNaming executableNaming = new UUIDTempNaming();

        Command command = Command.MongoD;

        IRuntimeConfig runtimeConfig = new RuntimeConfigBuilder()
                .defaults(command)
                .artifactStore(new ExtractedArtifactStoreBuilder()
                .defaults(command)
                .download(new DownloadConfigBuilder()
                .defaultsForCommand(command)
                .artifactStorePath(artifactStorePath))
                .executableNaming(executableNaming))
                .build();

        MongodStarter starter = MongodStarter.getInstance(runtimeConfig);//MongodStarter.getDefaultInstance();
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.DEVELOPMENT)
                .net(new Net(dbHostIP, dbPort, Network.localhostIsIPv6()))
                .build();
        mongodExecutable = starter.prepare(mongodConfig);
        mongod = mongodExecutable.start();



        mongo = new MongoClient(dbHostIP, dbPort);
        mongoDataBase = mongo.getDatabase(databaseName);
    }

    //added by 3714
    def "Writer step execution - insert execution"() {
        setup:
        def tranAmount = 0;

        def mongoDbWriterConfig = new MongoDBWriterConfig();
        def object;

        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/MongoWritterInsert.json")
        object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
        mongoDbWriterConfig = object.stepConfig;

        List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("transRef")
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("transAmt")
                .type(FieldType.FLOAT)
                .build());

        jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
        mongoDataSource.init();
        dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);


        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [mongoDbWriterConfig]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB2", "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue("recordWriter").getEmitter()

        utility.buildRecordMetaData(recordFieldConfigs, "samsonData");
        Map<String, Object> testRecordFieldValues = new HashMap<>();
        testRecordFieldValues.put("transRef", "000000001");
        testRecordFieldValues.put("transAmt", "250");

        IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");
        emitter.emit(messageFactory.createMessage(record))
        emitter.emit(messageFactory.createEndMessage())


        result.get()

        then:
        MongoCollection<Document> collection = mongoDataBase.getCollection(collectionName);
        Document searchDocument = new Document();
        searchDocument.append("transReference", "000000001");
        println("Document Filter: " + searchDocument);
        Document searchResult = collection.find(searchDocument).first();
        println("Document Found: " + searchResult);
        if (searchResult != null) {
            println("Record saved in Mongo DB: Transaction Reference: " + searchResult.getString("transReference"))
            tranAmount = Double.parseDouble(searchResult.getString("transAmount"));
        }
        tranAmount == 250;
    }

    def "Single step MongoDB Writer -update execution"() {
        def tranAmount = 0;

        //insert a sample record before writer process
        Document testRecord = new Document();
        testRecord.put("transReference", "000000002");
        testRecord.put("transAmount", "100");
        MongoCollection<Document> collection = mongoDataBase.getCollection(collectionName);
        collection.insertOne(testRecord);

        Document searchDocument1 = new Document();
        searchDocument1.append("transReference", "000000002");
        println("Document Filter: " + searchDocument1);
        Document searchResult1 = collection.find(searchDocument1).first();
        println("Document Found Before Updation : " + searchResult1);

        def mongoDbWriterConfig = new MongoDBWriterConfig();
        def object;

        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/MongoWritterUpdate.json")
        object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
        mongoDbWriterConfig = object.stepConfig;

        List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("transRef")
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("transAmt")
                .type(FieldType.FLOAT)
                .build());

        jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
        mongoDataSource.init();
        dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);


        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [mongoDbWriterConfig]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB2", "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue("recordWriter").getEmitter()

        utility.buildRecordMetaData(recordFieldConfigs, "samsonData");
        Map<String, Object> testRecordFieldValues = new HashMap<>();
        testRecordFieldValues.put("transRef", "000000002");
        testRecordFieldValues.put("transAmt", "300");

        IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "samsonData");
        emitter.emit(messageFactory.createMessage(record))
        emitter.emit(messageFactory.createEndMessage())


        result.get()

        then:
        MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
        Document searchDocument = new Document();
        searchDocument.append("transReference", "000000002");
        println("Document Filter: " + searchDocument);
        Document searchResult = resultCollection.find(searchDocument).first();
        println("Document Found after Updation: " + searchResult);
        if (searchResult != null) {
            println("Record updated in Mongo DB: Transaction Reference: " + searchResult.getString("transReference"))
            tranAmount = Double.parseDouble(searchResult.getString("transAmount"));
        }
        tranAmount == 300;
    }

    def cleanupSpec() {
        mongo.close();
        mongod.deleteTempFiles();
        mongod.stop();
        mongodExecutable.stop();
    }
}
