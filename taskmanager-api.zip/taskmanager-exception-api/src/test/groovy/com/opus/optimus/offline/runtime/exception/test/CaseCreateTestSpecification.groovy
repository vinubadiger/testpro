package com.opus.optimus.offline.runtime.exception.test

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

import org.bson.Document
import org.junit.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.CaseCreation
import com.opus.optimus.offline.config.casemanagement.Priority
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.exception.utility.CaseCreationAuthImpl
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Specification


@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class CaseCreateTestSpecification extends Specification {

	@Autowired
	CaseCreationAuthImpl caseCreationAuthImpl

	def "Etl Case create test"() {;
		setup:
		Severity severity = Severity.FATAL;
		String errorMesaage = "test errorMesaage";
		String projectName = "test projectName";
		String workflowName = "test workflowName ";
		String reason = "Error Type : " + severity + "\n" + "Error Message : " + errorMesaage;
		String jobId = "test JobID";

		when:

		CaseCreation caseCreation = CaseCreation.builder().referenceId(projectName + " " + workflowName).status("New").origin("Data Ingestion")
				.priority(Priority.HIGH).exceptionType(severity).subject("File Not Found").description(errorMesaage)
				.batchTypeNameInstanceId(jobId).fileUsedForUpload("").contactName("0036F00002bqQlEQAU").contactSkypeName("")
				.reason(reason).activity("").project(projectName).workflowName(workflowName).build();

		String caseID = caseCreationAuthImpl.authentication(caseCreation);
		System.out.println("caseID --------->"+caseID);

		then:

		caseID.isEmpty() == false
	}
}
