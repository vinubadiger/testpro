package com.opus.optimus.offline.runtime.exception.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.exception.config.DefaultErrorHandlerStepConfig;
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.StopJobException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * This class is used to as default global handler step
 * Which is responsible for generating job error details at the same time it check the severity of job and if it is
 * FATAL it stop the job.
 *
 */
@Component ("DefaultGlobalErrorHandler")
@Scope (value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DefaultGlobalErrorHandlerStep extends AbstractStep<DefaultErrorHandlerStepConfig> implements IJobTaskInfoAware {
	private static final Logger logger = LoggerFactory.getLogger(DefaultGlobalErrorHandlerStep.class);

	@Autowired
	IJobErrorDetailsService errorDetailsService;

	IJobTaskInfo jobTaskInfo;

	public DefaultGlobalErrorHandlerStep(DefaultErrorHandlerStepConfig config) {
		super(config);
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		ErrorDetails errorDetails = null;
		try{
			// TODO log the data in the database
			IMessage errorStepMessage = (IMessage) data;
			if (!ErrorDetails.class.isAssignableFrom(errorStepMessage.getData().getClass())){
				logger.error("Unknown details provided for the Global Error Handler. Expected: com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails & Actual: {}", data.getClass());
				return;
			}
			errorDetails = (ErrorDetails) errorStepMessage.getData();
			if (null != errorDetails.getErrorDetail()){
				logger.error("Logging error from DefaultGlobalErrorHandlerStep: {}", ((Throwable) errorDetails.getErrorDetail()).getMessage(), errorDetails.getErrorDetail());
			} else{
				logger.error("No log mesage found in DefaultGlobalErrorHandlerStep");
			}
			final ISourceReference sourceReference = errorStepMessage.getSourceReference();
			// log the details to repository
			errorDetailsService.logErrorDetails(errorDetails, sourceReference, jobTaskInfo);
		} catch (Exception exception){
			logger.error("Error while globally handling the errror. Please check the logs", exception);
		}
		// handle FATAL severity
		handleSeverity(errorDetails, data.getSourceReference());
	}

	/**
	 * This method is used to check the severity of job and if it is FATAL then STOP the job
	 * @param errorDetails - The name which holds error details information
	 * @param sourceReference - The field which holds the source reference type
	 */
	private void handleSeverity(ErrorDetails errorDetails, ISourceReference sourceReference) {
		if (errorDetails != null){
			if (Severity.FATAL.equals(errorDetails.getSeverity())){
				logger.error("Error severity is FATAL, Job will be aborted.");
				throw new StopJobException(errorDetails.getUserDetails(), new Exception(errorDetails.getUserDetails()), sourceReference);
			}
		} else{
			logger.info("Error Details is null. Can not handle severity. Please check the logs for more details.");
		}

	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}
	
	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		super.onStepEnd(forceEnd, emitter);
	}
}
