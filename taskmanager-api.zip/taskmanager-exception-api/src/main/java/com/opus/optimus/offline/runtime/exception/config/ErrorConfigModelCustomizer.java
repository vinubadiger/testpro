package com.opus.optimus.offline.runtime.exception.config;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;

@Component
public class ErrorConfigModelCustomizer implements IMapperCustomizer<ObjectMapper> {

	@Override
	public void customize(ObjectMapper objectMapper) {
		objectMapper.registerSubtypes(new NamedType(DefaultErrorHandlerStepConfig.class, StepTypeConstants.DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE));
		objectMapper.registerSubtypes(new NamedType(SalesForceCaseCreatorStepConfig.class, StepTypeConstants.SALESFORCE_CASE_CREATOR));
	}

}
