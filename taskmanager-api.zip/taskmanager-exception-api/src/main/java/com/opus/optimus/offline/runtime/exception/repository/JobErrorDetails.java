package com.opus.optimus.offline.runtime.exception.repository;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@lombok.Builder
@Document(collection="JobErrorDetails")
public class JobErrorDetails {
	
	@org.springframework.data.annotation.Id
	String Id;
	String jobId;
	long rowIndex;
	String rawRecordData;
	String errorType; //FATAL,ERROR
	String errorMessage;
	String reasonCode; 
	String caseId;
}
