package com.opus.optimus.offline.runtime.exception.handler;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.CaseCreation;
import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.runtime.exception.config.SalesForceCaseCreatorStepConfig;
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository;
import com.opus.optimus.offline.runtime.exception.utility.CaseCreationAuthImpl;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * This class is used for creating the case on sales force platform in case if
 * the severity is FATAL or work flow type is RECON
 */
@Component("SalesForceCase")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SalesForceCaseCreatorStep extends MapStep<SalesForceCaseCreatorStepConfig> implements IJobTaskInfoAware {
	private static final Logger logger = LoggerFactory.getLogger(SalesForceCaseCreatorStep.class);

	@Autowired
	IJobInfoService jobInfoService;

	@Autowired
	JobErrorDetailsRepository errorDetailsLogRepository;

	@Autowired
	IJobErrorDetailsService errorDetailsService;

	@Autowired
	CaseCreationAuthImpl caseCreationAuthImpl;

	IJobTaskInfo jobTaskInfo;

	JobInfo jobInfo = null;

	public SalesForceCaseCreatorStep(SalesForceCaseCreatorStepConfig config) {
		super(config);
	}

	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		logger.debug("Recevied doProcess command for SalesForceCaseCreatorStep ");
		String jobId = jobTaskInfo.getJobId();
		if (jobInfo == null) {
			jobInfo = jobInfoService.findById(jobId);
		}
		String workflowType = jobInfo.getWorkflowType();
		ErrorDetails errorDetails = (ErrorDetails) data;
		if (Severity.FATAL.equals(errorDetails.getSeverity())) {
			Severity severity = errorDetails.getSeverity();
			String errorMesaage = errorDetails.getUserDetails();
			String projectName = jobInfo.getWorkflowName();
			String workflowName = jobInfo.getProjectName();
			String reason = "Error Type : " + severity + "\n" + "Error Message : " + errorMesaage;

			try {
				final CaseCreation caseCreation = CaseCreation.builder().referenceId(projectName + " " + workflowName).status("NEW").origin("Data Ingestion")
						.priority(Priority.MEDIUM).exceptionType(severity).subject(workflowType).description(errorMesaage)
						.batchTypeNameInstanceId(jobId).fileUsedForUpload("").contactName("").contactSkypeName("")
						.reason(reason).activity("").project(projectName).workflowName(workflowName).build();

				String caseID = caseCreationAuthImpl.authentication(caseCreation);
				if (caseID != null) {
					errorDetails.setCaseId(caseID);
				}

			} catch (Exception e) {
				logger.error("Error while creating case", e);
			}

		}
		return (R) data;
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}
}
