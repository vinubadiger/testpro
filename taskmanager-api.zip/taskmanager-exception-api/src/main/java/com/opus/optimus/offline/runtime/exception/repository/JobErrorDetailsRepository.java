package com.opus.optimus.offline.runtime.exception.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface JobErrorDetailsRepository extends MongoRepository<JobErrorDetails, String> {
	@Query("{ 'jobId' : ?0 }")
	JobErrorDetails findByjobId(String jobId);
	
}
