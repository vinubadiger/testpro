package com.opus.optimus.offline.runtime.exception.utility;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opus.optimus.offline.config.casemanagement.CaseCreation;
import com.opus.optimus.offline.config.casemanagement.CaseResponse;


/**
 * Generic class for case creation for ETL and RECON work flow.
 *
 * @author Yashkumar.Thakur
 */
@Component
public class CaseCreationAuthImpl {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(CaseCreationAuthImpl.class);

	/** The sales force authentication URL. */
	@Value("${saleforce.authurl:https://login.salesforce.com/services/oauth2/token}")
	String salesForceAuthUlr;

	/** The sales force token. */
	@Value("${saleforce.token:grant_type=password&client_id=3MVG9YDQS5WtC11oFCrdOruZdrf2iNeneeKtiEW250croN0oWzM10xc.YuM16VHS8C4nDg4bpD0rCe5l0Ja.K&client_secret=8408874597168757852+&username=opuscasemanagement@opus.com&password=tempPass@1FrLUIZvfTlsXxyXo1dgkNvoV}")
	String salesForceToken;

	/** The sales force case URL. */
	@Value("${saleforce.casecreationurl:https://ap4.salesforce.com/services/apexrest/v1.0/Recon/CaseCreation/}")
	String salesForceCaseUrl;

	/** The Constant FATAL. */
	static final String FATAL = "FATAL";

	/**
	 * This method is used to create JWT token which is required for authentication
	 * while case generation on sales force.
	 *
	 * @param caseCreation - The case creation configuration
	 * @return the case id.
	 * @throws Exception the exception
	 */
	public  String authentication(CaseCreation caseCreation) throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		final String uri = salesForceAuthUlr;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<String> request = new HttpEntity<>(salesForceToken, headers);
		String recievedtoken = restTemplate.postForObject(uri, request, CaseResponse.class).getAccess_token();
		logger.info("token ====>>{}", recievedtoken);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String date = formatter.format(new Date());
		caseCreation.setRunDataTime(date);

		return caseCreation(caseCreation, recievedtoken, restTemplate);
	}

	/**
	 * This method is used for case creation on sales force platform.
	 *
	 * @author prashant.dongare
	 * @param cases            - The name which holds the case information
	 * @param token            - The name which holds JWT token for the request
	 * @param restTemplate            - RestTemplate reference variable for rest call
	 * @return String - returns the caseId
	 * @throws Exception the exception
	 */
	public String caseCreation(CaseCreation cases, String token, RestTemplate restTemplate) throws Exception {
		String caseId = null;
		try {
			String authtoken = "OAuth " + token;
			logger.info("token created ====>>{}", authtoken);
			final String uri = salesForceCaseUrl;
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authorization", authtoken);
			MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
			map.add("records", cases);
			HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map,
					headers);
			String casedata = restTemplate.postForObject(uri, httpEntity, String.class);
			JSONObject jSONObject = new JSONObject(casedata);
			JSONArray jsonArray = jSONObject.getJSONArray("successList");
			for (int i = 0; i < jsonArray.length(); i++) {
				jSONObject = jsonArray.getJSONObject(i);
				caseId = jSONObject.getString("caseId");
			}
			logger.debug("Case data {} :", casedata);
		} catch (Exception e) {
			logger.error("Error while creating case", e);
			throw e;
		}
		return caseId;
	}
	
	
}
