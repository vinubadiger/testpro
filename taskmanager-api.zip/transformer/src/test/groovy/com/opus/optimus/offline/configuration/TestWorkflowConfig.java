package com.opus.optimus.offline.configuration;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

public class TestWorkflowConfig {
	IStepConfig stepConfig;
	
	public IStepConfig getStepConfig() {
		return stepConfig;
	}
	
	public void setStepConfig(IStepConfig stepConfig) {
		this.stepConfig = stepConfig;
	}
}
