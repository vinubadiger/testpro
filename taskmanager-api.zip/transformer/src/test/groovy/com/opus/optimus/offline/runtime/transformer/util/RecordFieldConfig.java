package com.opus.optimus.offline.runtime.transformer.util;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class RecordFieldConfig implements IFieldConfig {
	private short fieldIndex;
	private String name;
	private FieldType type;
	@Override
	public com.opus.optimus.offline.runtime.common.api.record.FieldType getType() {
		return type;
	}
	@Override
	public String getFormat() {
		return null;
	}
	
}
