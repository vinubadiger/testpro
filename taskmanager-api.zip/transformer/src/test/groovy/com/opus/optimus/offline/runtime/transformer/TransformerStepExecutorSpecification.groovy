package com.opus.optimus.offline.runtime.transformer

import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder

import java.util.concurrent.Executors

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.transformer.TransformerConfig
import com.opus.optimus.offline.configuration.TestTransformerConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.record.impl.Record
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.transformer.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.transformer.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import spock.lang.Specification

@ContextConfiguration(classes = TestTransformerConfiguration.class)
class TransformerStepExecutorSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	@Qualifier("transformerUtility")
	Utility utility;

	@Autowired
	MapperFactory mapperFactory

	def "Transformer step execution"() {
		setup:

		def transformerConfig = new TransformerConfig();
		def errors= 0
		def mapper = mapperFactory.getMapper()
		println("Befor json reader")
		def jsonStream = getClass().getResourceAsStream("/TransformerConfigJSON.json")
		println("after json reader")
		def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		transformerConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("FirstName")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("LastName")
				.type(FieldType.STRING)
				.build());
			recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)3)
				.name("Amount")
				.type(FieldType.STRING)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [transformerConfig]

		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("name").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "EmpData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("FirstName", "Mr.John");
		testRecordFieldValues.put("LastName", "Villy");
		testRecordFieldValues.put("Amount", "00003000");
		//record 2
		Map<String, Object> testRecordFieldValues1 = new HashMap<>();
		testRecordFieldValues1.put("FirstName", "Ms.Siaa");
		testRecordFieldValues1.put("LastName", "Villy");
		testRecordFieldValues1.put("Amount", "00005000");


		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "EmpData");
		IRecord record1 = utility.buildRecord(recordFieldConfigs, testRecordFieldValues1, "EmpData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createMessage(record1))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("name").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		def fields = ((Record)receivedData.getAt(0)).schema.fields.size();
		for(int i=0;i<receivedData.size();i++) {
			for(int j=0;j<fields;j++){
				def recordValue =((Record)receivedData.getAt(i)).getValue(j)
				def recordFieldName=((Record)receivedData.getAt(i)).schema.getFields().get(j).getName()
				println("Id :"+j+recordFieldName+" ::"+recordValue+"::"+recordValue.getClass())
				if(fields-1 == j) {
					def valOperation =recordValue.toString().substring(0, 2)
					if(valOperation == "Mr." || valOperation == "Ms.")
						errors++
				}
				if(!recordFieldName == "Amount" && recordValue.getClass().is(java.lang.Integer))
					errors ++
			}
			println("--------------")
		}
		errors == 0
	}

	def "Transformer step execution With Existing Field"() {
		setup:

		def transformerConfig = new TransformerConfig();
		def errors= 0
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/TransformerConfigJSONExisting.json")
		def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		transformerConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("Name")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("LastName")
				.type(FieldType.STRING)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [transformerConfig]

		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("Transformer").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "EmpData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("Name", "Mr.John");
		testRecordFieldValues.put("LastName", "Villy");
		//record 2
		Map<String, Object> testRecordFieldValues1 = new HashMap<>();
		testRecordFieldValues1.put("Name", "Ms.Siaa");
		testRecordFieldValues1.put("LastName", "Villy");


		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "EmpData");
		IRecord record1 = utility.buildRecord(recordFieldConfigs, testRecordFieldValues1, "EmpData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createMessage(record1))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("Transformer").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)

		def fields = ((Record)receivedData.getAt(0)).schema.fields.size();
		for(int i=0;i<receivedData.size();i++) {
			for(int j=0;j<fields;j++){
				def recordValue =((Record)receivedData.getAt(i)).getValue(j)
				def recordFieldName=((Record)receivedData.getAt(i)).schema.getFields().get(j).getName()
				println(recordFieldName+" ::"+recordValue)
				if(recordValue == "John" || recordValue == "Villy")
					errors++
			}
		}
		errors >= 0
	}
	
	def "Transformer step execution With Date Field"() {
		setup:

		def transformerConfig = new TransformerConfig();
		def errors= 0
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/TransformerConfigJSONDate.json")
		def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		transformerConfig = object.stepConfig;


		//create IREcord for testing
		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name("Name")
				.type(FieldType.STRING)
				.build());
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)2)
				.name("Date")
				.type(FieldType.STRING)
				.build());


		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [transformerConfig]

		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("Transformer").getEmitter()

		utility.buildRecordMetaData(recordFieldConfigs, "EmpData");

		//record 1
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("Name", "Mr.John");
		testRecordFieldValues.put("Date", "20190130");
		//record 2
		Map<String, Object> testRecordFieldValues1 = new HashMap<>();
		testRecordFieldValues1.put("Name", "Ms.Siaa");
		testRecordFieldValues1.put("Date", "201901");


		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "EmpData");
		IRecord record1 = utility.buildRecord(recordFieldConfigs, testRecordFieldValues1, "EmpData");

		emitter.emit(messageFactory.createMessage(record))
		emitter.emit(messageFactory.createMessage(record1))
		emitter.emit(messageFactory.createEndMessage())

		def JobTaskExecutorResult = result.get()

		then:
		def receiver = localJobTaskExecutor.getOutBoundQueue("Transformer").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)

		def fields = ((Record)receivedData.getAt(0)).schema.fields.size();
		for(int i=0;i<receivedData.size();i++) {
			for(int j=0;j<fields;j++){
				def recordValue =((Record)receivedData.getAt(i)).getValue(j)
				def recordFieldName=((Record)receivedData.getAt(i)).schema.getFields().get(j).getName()
				println(recordFieldName+" ::"+recordValue+" ::"+recordValue.getClass())
				if(recordValue.getClass() == java.util.Date )
					errors++
			}
		}
		errors >= 0
	}

}
