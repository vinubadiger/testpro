package com.opus.optimus.offline.runtime.common.transformer;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.transformer.AdditionalTransformerConfig;
import com.opus.optimus.offline.config.transformer.TransformerConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import com.opus.optimus.offline.runtime.common.transformer.util.FieldFormatterImpl;
import com.opus.optimus.offline.runtime.common.transformer.util.TransformerSchemaBuilder;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * The Class TransformerStep.
 *
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
@Component(StepTypeConstants.TRANSFORMER_STEPTYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TransformerStep extends MapStep<TransformerConfig> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(TransformerStep.class);

	/** The script creator factory. */
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	/** The message factory. */
	@Autowired
	IMessageFactory messageFactory;

	/** The hash map of script configurations */
	private Map<String, IScript> scriptConfigs;

	/** The record factory. */
	@Autowired
	private IRecordFactory recordFactory;

	/**
	 * Instantiates a new transformer step.
	 *
	 * @param config
	 *            the configuration
	 */
	public TransformerStep(TransformerConfig config) {
		super(config);
	}

	/**
	 * Initialization the transformer step
	 */
	// For creating script object with field name
	@PostConstruct
	public void init() {
		scriptConfigs = new HashMap<String, IScript>();
		this.scriptConfigs = config.getAdditionalTransformerConfigs().stream()
				.collect(Collectors.toMap(AdditionalTransformerConfig::getFieldName,
						e -> scriptCreatorFactory.createScript(e.getScriptConfig())));
	}

	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		try {
			/*
			 * Creating Schema for Transformer using source schema with addition fields for
			 * transformer
			 */
			ISchema sourceRecordSchema = ((IRecord) data).getSchema();
			IRecord sourceRecord = (IRecord) data;
			StringBuilder targetSectionName = new StringBuilder();
			targetSectionName.append(config.getTransformedSectionName());
			targetSectionName.append("_TransformedSection");
			logger.info("Source Schema name: {}, Transformed schema Name:{} ",sourceRecordSchema.getName(),targetSectionName);
			ISchema targetRecordSchema = TransformerSchemaBuilder.cloneSchema(targetSectionName.toString(),
					sourceRecordSchema, config.getAdditionalTransformerConfigs());
			recordFactory.registerSchema(targetRecordSchema);

			// Creating record
			IRecord targetRecord = recordFactory.createRecord(targetSectionName.toString());
			
			sourceRecordSchema.getFields().stream().forEach(field -> {
				int sourceRecordFieldIndex = ((IRecord) data).getFieldId(field.getName());
				int targetRecordIndex = targetRecord.getFieldId(field.getName());
				targetRecord.setValue(targetRecordIndex, sourceRecord.getValue(sourceRecordFieldIndex));
			});

			for (Entry<String, IScript> entry : scriptConfigs.entrySet()) {
				int additionFieldIndex = targetRecord.getFieldId(entry.getKey());
				targetRecord.setValue(additionFieldIndex, FieldFormatterImpl.populateField(
						targetRecord.getFieldSchema(additionFieldIndex), entry.getValue().execute(sourceRecord)));

			}

			return (R) targetRecord;
		} catch (Exception exception) {
			logger.error("Error while transformation step execution.{}", exception);
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails(exception.getMessage()).errorDetail(exception).build();
			throw new RecordProcessingException(errorDetails);
		}

	}
}
