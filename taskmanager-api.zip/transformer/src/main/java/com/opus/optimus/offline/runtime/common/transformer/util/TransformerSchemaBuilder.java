package com.opus.optimus.offline.runtime.common.transformer.util;

import java.util.List;

import com.opus.optimus.offline.config.transformer.AdditionalTransformerConfig;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.FieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;

/**
 * The Class TransformerSchemaBuilder, creates schema for transformer step
 *
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
/*
 * Record schema builder specific to transformer for creating clone of target
 * schema
 */
public class TransformerSchemaBuilder {

	private TransformerSchemaBuilder() {
		throw new IllegalStateException("Utility class, at least one non-public, non-implict constructor to be there");
	}

	/**
	 * Clone schema, Clones schema from source record and create new schema with new
	 * transformed fields
	 *
	 * @param sectionName -
	 *            The section name for target schema
	 * @param schema -
	 *            The schema
	 * @param additionalTransformerConfigs -
	 *            The additional transformer configuration
	 * @return the schema
	 */
	public static Schema cloneSchema(String sectionName, ISchema schema,
			List<AdditionalTransformerConfig> additionalTransformerConfigs) {
		Schema.Builder builder = Schema.builder();
		builder.name(sectionName);

		additionalTransformerConfigs.stream().forEach(fieldConfig -> {
			builder.addField(new FieldSchema(fieldConfig.getFieldName(), fieldConfig.getFieldType()));
		});

		schema.getFields().stream().forEach(fieldSchema -> {
			if (!additionalTransformerConfigs.stream().anyMatch(
					schemaFieldConfig -> schemaFieldConfig.getFieldName().equalsIgnoreCase(fieldSchema.getName()))) {
				builder.addField(new FieldSchema(fieldSchema.getName(), fieldSchema.getType()));
			}
		});

		return builder.build();
	}

}
