package com.opus.optimus.offline.runtime.common.transformer.util;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * Field formatter for convert supported data types
 * 
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 *
 */
public class FieldFormatterImpl {
	private static final Logger logger = LoggerFactory.getLogger(FieldFormatterImpl.class);

	static final String STATEMENT = "Transformation Field Format Error on Unsupported data type provided for the field ";

	private FieldFormatterImpl() {
	}

	/**
	 * 
	 * @param fldConfig -
	 *            Collection of properties such as data type, field name.
	 * @param fieldValue -
	 *            Actual Data values
	 * @return  Converted data
	 * @throws RecordProcessingException
	 */
	public static Object populateField(IFieldSchema fldConfig, Object fieldValue) throws RecordProcessingException {
		try {
			FieldType dataType = fldConfig.getType();
			logger.debug("FieldValue - {} , DataType - {}", fieldValue, dataType);
			if (fieldValue == null) {
				return fieldValue;
			}
			switch (dataType) {
			case STRING:
				return String.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue : String.valueOf(fieldValue);
			case LONG:
				return Long.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue
						: Long.valueOf(fieldValue.toString().trim());
			case DOUBLE:
				return Double.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue
						: Double.valueOf(fieldValue.toString().trim());
			case FLOAT:
				return Float.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue
						: Float.valueOf(fieldValue.toString().trim());
			case BOOLEAN:
				return Boolean.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue
						: Boolean.valueOf(fieldValue.toString().trim());
			case INT:
				return Integer.class.isAssignableFrom(fieldValue.getClass()) ? fieldValue
						: Integer.valueOf(fieldValue.toString().trim());
			case DATETIME:
			case DATE: {
				if (Date.class.isAssignableFrom(fieldValue.getClass())) {
					return fieldValue;
				} else {
					ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
							.userDetails("invalid input for datetime data type")
							.errorDetail("invalid input for datetime data type" + dataType).build();
					throw new RecordProcessingException(errorDetails);
				}
			}
			default: {
				logger.debug("{} : {} ", STATEMENT, dataType);
				ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR).userDetails(STATEMENT)
						.errorDetail(STATEMENT + dataType).build();
				throw new RecordProcessingException(errorDetails);
			}
			}
		} catch (RecordProcessingException e) {
			throw e;
		} catch (Exception exception) {
			logger.error("Transformation Field Format Error on: {}. For data type: {}, Error: {}", fldConfig.getName(),
					fldConfig.getType(), exception.getMessage());
			ErrorDetails errorDetails = ErrorDetails.builder().severity(Severity.ERROR)
					.userDetails(exception.getMessage()).errorDetail(exception).build();
			throw new RecordProcessingException(errorDetails);
		}
	}
}
