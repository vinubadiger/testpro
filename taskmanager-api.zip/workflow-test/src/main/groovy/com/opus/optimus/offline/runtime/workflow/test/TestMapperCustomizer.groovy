package com.opus.optimus.offline.runtime.workflow.test

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.jsontype.NamedType
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer
import com.opus.optimus.offline.runtime.workflow.api.impl.StepLink
import org.springframework.stereotype.Component

@Component
class TestMapperCustomizer implements IMapperCustomizer<ObjectMapper> {
    @Override
    void customize(ObjectMapper mapper) {
        mapper.registerSubtypes(new NamedType(StepLink.class, "link"));

        mapper.registerSubtypes(new NamedType(DelegatorConfig.class, DelegatorConfig.STEP_TYPE))
        mapper.registerSubtypes(new NamedType(FilterNonDivisibleByConfig.class, FilterNonDivisibleByConfig.STEP_TYPE))
        mapper.registerSubtypes(new NamedType(NumberGeneratorConfig.class, NumberGeneratorConfig.STEP_TYPE))
        mapper.registerSubtypes(new NamedType(ErrorOnDataConfig.class, ErrorOnDataConfig.STEP_TYPE))

        mapper.registerSubtypes(new NamedType(DivisibleScriptConfig.class, DivisibleScriptConfig.TYPE))
    }
}
