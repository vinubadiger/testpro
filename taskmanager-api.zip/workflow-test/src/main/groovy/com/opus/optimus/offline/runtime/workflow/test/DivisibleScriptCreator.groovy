package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.script.api.IScript
import com.opus.optimus.offline.runtime.script.api.IScriptConfig
import com.opus.optimus.offline.runtime.script.api.IScriptCreator
import org.springframework.stereotype.Component

@Component("Divisible")
class DivisibleScriptCreator implements IScriptCreator {
    @Override
    IScript create(IScriptConfig config) {
        return new DivisibleScript(config);
    }
}
