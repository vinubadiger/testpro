package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.script.api.IScript
import com.opus.optimus.offline.runtime.workflow.api.IMessage

class DivisibleScript implements IScript<IMessage, Boolean> {
    DivisibleScriptConfig config;

    DivisibleScript(DivisibleScriptConfig config) {
        this.config = config
    }

    @Override
    Boolean execute(IMessage message) {
        if (config.divisor == 0) {
            return true
        }

        return message.getData() % config.divisor == 0
    }
}
