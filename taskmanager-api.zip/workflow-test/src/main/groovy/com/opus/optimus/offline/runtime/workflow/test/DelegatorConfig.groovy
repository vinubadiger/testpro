package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class DelegatorConfig extends SimpleStepConfig {
    def static STEP_TYPE = "Delegator"

    DelegatorConfig() {
        super("", STEP_TYPE)
    }

    DelegatorConfig(String stepName) {
        super(stepName, STEP_TYPE)
    }
}
