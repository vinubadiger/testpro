package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.ICustomizeErrorHandlingSupport
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class AbortJobOnDataConfig extends SimpleStepConfig implements ICustomizeErrorHandlingSupport {
    def static STEP_TYPE = "AbortOnData"

    List throwErrorOnData
    boolean callGlobalErrorEvenWhenHandled

    AbortJobOnDataConfig() {
        super("", STEP_TYPE)
    }

    AbortJobOnDataConfig(String stepName, List throwErrorOnData) {
        this(stepName, throwErrorOnData, true)
    }

    AbortJobOnDataConfig(String stepName, List throwErrorOnData, boolean callGlobalErrorEvenWhenHandled) {
        super(stepName, STEP_TYPE)
        this.throwErrorOnData = throwErrorOnData
        this.callGlobalErrorEvenWhenHandled = callGlobalErrorEvenWhenHandled
    }

    @Override
    boolean callGlobalErrorEvenWhenHandled() {
        return callGlobalErrorEvenWhenHandled
    }
}
