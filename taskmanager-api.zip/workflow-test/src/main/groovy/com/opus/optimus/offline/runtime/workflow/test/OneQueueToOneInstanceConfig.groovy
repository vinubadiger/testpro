package com.opus.optimus.offline.runtime.workflow.test


import com.opus.optimus.offline.runtime.workflow.api.ICustomizableInBoundQueueSupport
import com.opus.optimus.offline.runtime.workflow.api.ICustomizableTaskCreatorSupport
import com.opus.optimus.offline.runtime.workflow.api.IPartitionKeyProvider
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class OneQueueToOneInstanceConfig extends SimpleStepConfig
        implements ICustomizableInBoundQueueSupport, ICustomizableTaskCreatorSupport, IPartitionKeyProvider {
    OneQueueToOneInstanceConfig(String stepName, String stepType) {
        super(stepName, stepType)
    }

    @Override
    String getQueueCreatorName() {
        return "partitionBased"
    }

    @Override
    String getStepTaskCreatorName() {
        return "partition"
    }

    @Override
    def <I extends Serializable, R extends Serializable> R getPartitionKey(I message) {
        return message.getData()
    }
}
