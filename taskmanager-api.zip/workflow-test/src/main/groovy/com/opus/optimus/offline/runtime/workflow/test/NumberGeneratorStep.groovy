package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.IEmitter
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("NumberGenerator")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class NumberGeneratorStep extends AbstractStep<NumberGeneratorConfig> {

    @Autowired
    IMessageFactory messageFactory;

    NumberGeneratorStep(NumberGeneratorConfig config) {
        super(config)
    }

    @Override
    void process(IMessage data, IEmitter emitter) {
        (config.from..config.to).step(config.step).each {
            if (forceStop.get() == true) {
                return;
            }
            if (config.delayInMs != 0) {
                Thread.sleep(config.delayInMs)
            }
            emitter.emit(messageFactory.createMessage(it))
        }
    }

    @Override
    void onStepEnd(boolean forceEnd, IEmitter emitter) {
        super.onStepEnd(forceEnd, emitter)
        println "Number generator step completed"
    }
}
