package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("ErrorOnData")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class ErrorOnDataStep extends MapStep<ErrorOnDataConfig> {
    ErrorOnDataStep(ErrorOnDataConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
        if (data in config.throwErrorOnData) {
            throw new RecordProcessingException(data)
        }

        return data
    }
}
