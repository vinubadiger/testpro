package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class NumberGeneratorConfig extends SimpleStepConfig {
    def static STEP_TYPE = "NumberGenerator"

    int from;
    int to;
    int step;
    int delayInMs = 0;

    NumberGeneratorConfig() {
    }

    NumberGeneratorConfig(String stepName, int from, int to, int step) {
        this(stepName, from, to, step, 0)
    }

    NumberGeneratorConfig(String stepName, int from, int to, int step, int delayInMs) {
        super(stepName, STEP_TYPE)
        this.from = from
        this.to = to
        this.step = step
        this.delayInMs = delayInMs
    }

}
