package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.script.api.IScriptConfig

class DivisibleScriptConfig implements IScriptConfig {
    def static TYPE = "Divisible"
    String type = TYPE
    int divisor;

    DivisibleScriptConfig() {
    }

    DivisibleScriptConfig(int divisor) {
        this.divisor = divisor
    }

    @Override
    String getType() {
        return type
    }
}
