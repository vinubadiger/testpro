package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.IEmitter
import com.opus.optimus.offline.runtime.queue.api.IQueue
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig
import com.opus.optimus.offline.runtime.workflow.api.IStepExecutorConfig
import com.opus.optimus.offline.runtime.workflow.api.IStepTask
import com.opus.optimus.offline.runtime.workflow.api.IStepTaskCreator
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepTask

import java.util.stream.Collectors
import java.util.stream.IntStream

class OneQueueToOneInstanceTaskCreator implements IStepTaskCreator {
    IStepConfig stepConfig
    Iterator<SimpleStepTask> taskIterator = null;

    OneQueueToOneInstanceTaskCreator(String workflowName, IStepConfig stepConfig, List<IQueue> inBoundQueues, IEmitter outBoundEmitter,
                                     IStepExecutorConfig stepExecutorConfig) {
        this.stepConfig = stepConfig

        this.taskIterator = IntStream.range(0, inBoundQueues.size())
                .mapToObj({
            new SimpleStepTask(
                    "local.stepInstanceExecutor",
                    it,
                    workflowName,
                    stepConfig,
                    inBoundQueues.get(it).getReceiver(),
                    outBoundEmitter)
        })
                .collect(Collectors.toList())
                .iterator();
    }

    @Override
    IStepConfig getStepConfig() {
        return this.stepConfig
    }

    @Override
    boolean hasNext() {
        return taskIterator.hasNext()
    }

    @Override
    IStepTask next() {
        return taskIterator.next()
    }
}
