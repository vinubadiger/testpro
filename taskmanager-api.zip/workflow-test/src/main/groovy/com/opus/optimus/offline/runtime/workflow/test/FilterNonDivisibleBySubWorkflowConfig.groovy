package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig
import com.opus.optimus.offline.runtime.workflow.api.IEmbeddedSubWorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig

class FilterNonDivisibleBySubWorkflowConfig extends SimpleStepConfig implements IEmbeddedSubWorkflowConfig {
    def static STEP_TYPE = "FilterNonDivisibleBySubWorkflow"
    IStepConfig childConfig

    FilterNonDivisibleBySubWorkflowConfig(String stepName, IStepConfig childConfig) {
        super(stepName, STEP_TYPE)
        this.childConfig = childConfig
    }

    @Override
    WorkflowConfig getWorkflowConfig() {
        return new WorkflowConfig.WorkflowConfigBuilder()
                .name('default.' + stepName)
                .stepConfigs(Arrays.asList(childConfig))
                .startStepName(childConfig.stepName)
                .endStepName(childConfig.stepName)
                .build();
    }
}
