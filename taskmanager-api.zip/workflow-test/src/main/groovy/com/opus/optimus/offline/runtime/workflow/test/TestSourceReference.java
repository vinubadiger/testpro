package com.opus.optimus.offline.runtime.workflow.test;

import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

public class TestSourceReference implements ISourceReference {
    @Override
    public String getType() {
        return "test";
    }
}
