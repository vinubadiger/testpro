package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.*

class DataSprayQueue implements IQueue, IEmitter {
    List<IQueue> queues
    List<IEmitter> queueEmitters
    Closure sprayAlgorithm

    DataSprayQueue(List<IQueue> queues, Closure sprayAlgorithm) {
        this.queues = queues
        this.sprayAlgorithm = sprayAlgorithm
        this.queueEmitters = this.queues.collect {
            it.getEmitter()
        }
    }

    @Override
    IReceiver getReceiver(IReceiverConfig config) {
        return null
    }

    @Override
    IEmitter getEmitter(IEmitterConfig config) {
        return this
    }

    @Override
    def <T extends Serializable> void emit(T data) {
        int value = data.getData()
        int queueIndex = sprayAlgorithm.call(value)
        queueEmitters.get(queueIndex).emit(data)
    }

    @Override
    def <T extends Serializable> void end(T data) {
        queueEmitters.each {
            it.end(data)
        }
    }
}
