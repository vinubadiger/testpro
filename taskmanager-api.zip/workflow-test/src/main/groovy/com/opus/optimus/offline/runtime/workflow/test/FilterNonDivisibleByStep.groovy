package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.IEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("FilterNonDivisibleBy")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class FilterNonDivisibleByStep extends MapStep<FilterNonDivisibleByConfig> {
    FilterNonDivisibleByStep(FilterNonDivisibleByConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
        return (data % config.divisibleBy == 0) ? data : null
    }

    @Override
    void onStepEnd(boolean forceEnd, IEmitter emitter) {
        super.onStepEnd(forceEnd, emitter)
        println "FilterNonDivisibleBy " + config.divisibleBy + " step completed"
    }
}
