package com.opus.optimus.offline.runtime.workflow.test


import com.opus.optimus.offline.runtime.workflow.api.impl.JobActionsHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException
import com.opus.optimus.offline.runtime.workflow.api.impl.StopJobException
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("AbortOnData")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class AbortJobOnDataStep extends MapStep<AbortJobOnDataConfig> {
    JobActionsHelper helper;

    AbortJobOnDataStep(AbortJobOnDataConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
        if (data in config.throwErrorOnData) {
            throw new StopJobException('Something went wrong', new Exception('Exception message'), new TestSourceReference());
        }

        return data
    }

}
