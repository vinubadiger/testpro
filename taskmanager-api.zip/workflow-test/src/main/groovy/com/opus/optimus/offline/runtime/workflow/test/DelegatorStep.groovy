package com.opus.optimus.offline.runtime.workflow.test


import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("Delegator")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class DelegatorStep extends MapStep<DelegatorConfig> {
    DelegatorStep(DelegatorConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) {
        return data
    }
}
