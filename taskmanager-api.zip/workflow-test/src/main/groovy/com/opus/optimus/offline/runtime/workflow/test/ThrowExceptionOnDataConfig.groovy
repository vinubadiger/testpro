package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.ICustomizeErrorHandlingSupport
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class ThrowExceptionOnDataConfig extends SimpleStepConfig implements ICustomizeErrorHandlingSupport {
    def static STEP_TYPE = "ThrowExceptionOnData"

    List throwExceptionOnData
    boolean callGlobalErrorEvenWhenHandled

    ThrowExceptionOnDataConfig() {
        super("", STEP_TYPE)
    }

    ThrowExceptionOnDataConfig(String stepName, List throwErrorOnData) {
        this(stepName, throwErrorOnData, true)
    }

    ThrowExceptionOnDataConfig(String stepName, List throwErrorOnData, boolean callGlobalErrorEvenWhenHandled) {
        super(stepName, STEP_TYPE)
        this.throwExceptionOnData = throwErrorOnData
        this.callGlobalErrorEvenWhenHandled = callGlobalErrorEvenWhenHandled
    }

    @Override
    boolean callGlobalErrorEvenWhenHandled() {
        return callGlobalErrorEvenWhenHandled
    }
}
