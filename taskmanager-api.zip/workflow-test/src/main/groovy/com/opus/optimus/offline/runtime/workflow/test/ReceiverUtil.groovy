package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.IReceiver
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.MessageType

class ReceiverUtil {
    static <T> List<T> collectDataFromReceiver(IReceiver receiver) throws Exception {
        IMessage message = receiver.getNext();
        List<T> datas = new ArrayList<>()
        while (message != null && message.getType() == MessageType.DATA) {
            datas.add(message.getData())
            message = receiver.getNext()
        }
        return datas
    }
}
