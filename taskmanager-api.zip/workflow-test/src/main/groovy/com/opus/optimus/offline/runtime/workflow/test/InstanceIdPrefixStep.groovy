package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.IInstanceIdAware
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("InstanceIdPrefix")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class InstanceIdPrefixStep extends MapStep<SimpleStepConfig> implements IInstanceIdAware {
    int instanceId

    InstanceIdPrefixStep(SimpleStepConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) {
        return data + '-' + instanceId
    }

    @Override
    void setInstanceId(int instanceId) {
        this.instanceId = instanceId
    }
}
