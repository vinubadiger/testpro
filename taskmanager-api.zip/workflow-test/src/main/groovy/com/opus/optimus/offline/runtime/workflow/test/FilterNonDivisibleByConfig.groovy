package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class FilterNonDivisibleByConfig extends SimpleStepConfig {
    def static STEP_TYPE = "FilterNonDivisibleBy"

    int divisibleBy

    FilterNonDivisibleByConfig() {
        super("", STEP_TYPE)
    }

    FilterNonDivisibleByConfig(String stepName, int divisibleBy) {
        super(stepName, STEP_TYPE)
        this.divisibleBy = divisibleBy
    }
}
