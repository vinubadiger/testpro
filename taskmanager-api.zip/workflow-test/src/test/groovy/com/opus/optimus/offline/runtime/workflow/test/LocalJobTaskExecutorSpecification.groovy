package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEvent
import com.opus.optimus.offline.runtime.workflow.api.event.IStepExecutorEvent
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.event.impl.LogJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import org.apache.commons.lang.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification
import spock.lang.Unroll

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestWorkflowConfiguration.class)
class LocalJobTaskExecutorSpecification extends Specification {

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    MapperFactory mapperFactory

    def "Single step execution"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [new FilterNonDivisibleByConfig("AnyName", 2)]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue("AnyName").getEmitter()

        (1..64).each { emitter.emit(messageFactory.createMessage(it)) }
        emitter.emit(messageFactory.createEndMessage())
        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue("AnyName").get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 32
        def sort = receivedData.sort()
        sort == (2..64).step(2)

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 1
        stepExecutionResults.get(0).stepType == workflowConfig.stepConfigs.get(0).getStepType()
        64 == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        receivedData.size() == stepExecutionResults.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
        println jobTaskExecutorResult
    }

    def "Linking 3 step execution"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def FilterBy2 = "FilterBy2"
        def FilterBy3 = "FilterBy3"

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 512, 1)
        def filterBy2Config = new FilterNonDivisibleByConfig(FilterBy2, 2)
        def filterBy3Config = new FilterNonDivisibleByConfig(FilterBy3, 3)

        workflowConfig.stepConfigs = [numberGeneratorConfig, filterBy2Config, filterBy3Config]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, FilterBy2),
                new StepLink(FilterBy2, FilterBy3)
        ]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(FilterBy3).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 85
        def sort = receivedData.sort()
        sort == (6..512).step(6)

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 3
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, FilterBy2, FilterBy3].sort()
        stepExecutionResults.collect { it -> it.stepType }.sort() == [numberGeneratorConfig.stepType, filterBy2Config.stepType, filterBy3Config.stepType].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def filterBy2Result = stepExecutionResults.grep { it -> it.stepName == FilterBy2 }
        filterBy2Result != null
        filterBy2Result.size() == 1
        512 == filterBy2Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def filterBy3Result = stepExecutionResults.grep { it -> it.stepName == FilterBy3 }
        filterBy3Result != null
        filterBy3Result.size() == 1
        256 == filterBy3Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        println jobTaskExecutorResult
    }

    def "Conditional routing - Split based on divisor"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def DivisibleBy2 = "DivisibleBy2"
        def DivisibleBy3 = "DivisibleBy3"
        def Others = "Others"

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1)
        def divisibleBy2Config = new DelegatorConfig(DivisibleBy2)
        def divisibleBy3Config = new DelegatorConfig(DivisibleBy3)
        def othersConfig = new DelegatorConfig(Others)

        workflowConfig.stepConfigs = [numberGeneratorConfig, divisibleBy2Config, divisibleBy3Config, othersConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, DivisibleBy2, new DivisibleScriptConfig(2)),
                new StepLink(SequenceNumberGenerator, DivisibleBy3, new DivisibleScriptConfig(3)),
                new StepLink(SequenceNumberGenerator, Others, new DivisibleScriptConfig(0))
        ]

//        println mapperFactory.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(workflowConfig)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def divisibleBy2Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy2).get(0).getReceiver()
        def divisibleBy2Data = ReceiverUtil.collectDataFromReceiver(divisibleBy2Receiver)
        def divisibleBy2ExpectedData = (1..256).grep { it % 2 == 0 }
        divisibleBy2Data.size() == divisibleBy2ExpectedData.size()
        divisibleBy2Data.sort() == divisibleBy2ExpectedData

        def divisibleBy3Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy3).get(0).getReceiver()
        def divisibleBy3Data = ReceiverUtil.collectDataFromReceiver(divisibleBy3Receiver)
        def divisibleBy3ExpectedData = (1..256).grep { it % 2 != 0 && it % 3 == 0 }
        divisibleBy3Data.size() == divisibleBy3ExpectedData.size()
        divisibleBy3Data.sort() == divisibleBy3ExpectedData

        def othersReceiver = localJobTaskExecutor.getOutBoundQueue(Others).get(0).getReceiver()
        def othersData = ReceiverUtil.collectDataFromReceiver(othersReceiver)
        def othersExpectedData = (1..256).grep { it % 2 != 0 && it % 3 != 0 }
        othersData.size() == othersExpectedData.size()
        othersData.sort() == othersExpectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, DivisibleBy2, DivisibleBy3, Others].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy2Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy2 }
        divisibleBy2Result != null
        divisibleBy2Result.size() == 1
        divisibleBy2Data.size() == divisibleBy2Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy3Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy3 }
        divisibleBy3Result != null
        divisibleBy3Result.size() == 1
        divisibleBy3Data.size() == divisibleBy3Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def othersResult = stepExecutionResults.grep { it -> it.stepName == Others }
        othersResult != null
        othersResult.size() == 1
        othersData.size() == othersResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        println jobTaskExecutorResult
    }

    def "Conditional routing - Split based on divisor using JSON"() {
        setup:
        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def DivisibleBy2 = "DivisibleBy2"
        def DivisibleBy3 = "DivisibleBy3"
        def Others = "Others"
        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/SplitBasedOnDivisor.json")
        def workflowConfig = mapper.readValue(jsonStream, WorkflowConfig.class)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def divisibleBy2Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy2).get(0).getReceiver()
        def divisibleBy2Data = ReceiverUtil.collectDataFromReceiver(divisibleBy2Receiver)
        def divisibleBy2ExpectedData = (1..256).grep { it % 2 == 0 }
        divisibleBy2Data.size() == divisibleBy2ExpectedData.size()
        divisibleBy2Data.sort() == divisibleBy2ExpectedData

        def divisibleBy3Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy3).get(0).getReceiver()
        def divisibleBy3Data = ReceiverUtil.collectDataFromReceiver(divisibleBy3Receiver)
        def divisibleBy3ExpectedData = (1..256).grep { it % 2 != 0 && it % 3 == 0 }
        divisibleBy3Data.size() == divisibleBy3ExpectedData.size()
        divisibleBy3Data.sort() == divisibleBy3ExpectedData

        def othersReceiver = localJobTaskExecutor.getOutBoundQueue(Others).get(0).getReceiver()
        def othersData = ReceiverUtil.collectDataFromReceiver(othersReceiver)
        def othersExpectedData = (1..256).grep { it % 2 != 0 && it % 3 != 0 }
        othersData.size() == othersExpectedData.size()
        othersData.sort() == othersExpectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, DivisibleBy2, DivisibleBy3, Others].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy2Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy2 }
        divisibleBy2Result != null
        divisibleBy2Result.size() == 1
        divisibleBy2Data.size() == divisibleBy2Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy3Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy3 }
        divisibleBy3Result != null
        divisibleBy3Result.size() == 1
        divisibleBy3Data.size() == divisibleBy3Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def othersResult = stepExecutionResults.grep { it -> it.stepName == Others }
        othersResult != null
        othersResult.size() == 1
        othersData.size() == othersResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        println jobTaskExecutorResult
    }

    def "Error based routing"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def ErrorOnData = "ErrorOnData"
        def Success = "Success"
        def Error = "Error"

        def errorNumbers = [121, 132]

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1)
        def errorOnDataConfig = new ErrorOnDataConfig(ErrorOnData, errorNumbers)
        def successConfig = new DelegatorConfig(Success)
        def errorConfig = new DelegatorConfig(Error)

        workflowConfig.stepConfigs = [numberGeneratorConfig, errorOnDataConfig, successConfig, errorConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, ErrorOnData),
                new StepLink(ErrorOnData, Success),
                new StepLink(ErrorOnData, Error).setErrorHandlingLink(true)
        ]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def successReceiver = localJobTaskExecutor.getOutBoundQueue(Success).get(0).getReceiver()
        def successData = ReceiverUtil.collectDataFromReceiver(successReceiver)
        def successExpectedData = (1..256).grep { it in errorNumbers == false }
        successData.size() == successExpectedData.size()
        successData.sort() == successExpectedData
        println successData

        def errorReceiver = localJobTaskExecutor.getOutBoundQueue(Error).get(0).getReceiver()
        def errorData = ReceiverUtil.collectDataFromReceiver(errorReceiver)
        def errorExpectedData = errorNumbers
        errorData.size() == errorExpectedData.size()
        errorData.sort() == errorExpectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, Success, Error, ErrorOnData].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def successResult = stepExecutionResults.grep { it -> it.stepName == Success }
        successResult != null
        successResult.size() == 1
        successExpectedData.size() == successResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def errorResult = stepExecutionResults.grep { it -> it.stepName == Error }
        errorResult != null
        errorResult.size() == 1
        errorExpectedData.size() == errorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.errorCount }

        println jobTaskExecutorResult
    }

    def "Global error handling only"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def globalErrorHandlingWorkflowConfig = new WorkflowConfig()

        def MainWorkflowName = "Main"
        def GlobalErrorHandlingWorkflowName = "GlobalErrorHandler"

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def ErrorOnDataStage1 = "ErrorOnDataStage1"
        def ErrorOnDataStage2 = "ErrorOnDataStage2"
        def Success = "Success"
        def Error = "Error"

        def errorNumbersStage1 = (100..120)
        def errorNumbersStage2 = (220..230)

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1)
        def errorOnDataConfigStage1 = new ErrorOnDataConfig(ErrorOnDataStage1, errorNumbersStage1)

        def errorOnDataConfigStage2 = new ErrorOnDataConfig(ErrorOnDataStage2, errorNumbersStage2)
        def successConfig = new DelegatorConfig(Success)
        def errorConfig = new DelegatorConfig(Error)

        def allJobEvents = Collections.synchronizedList(new ArrayList())
        def consoleEmitter = new ConsoleJobEventEmitter()
        def eventCollectorAndConsoleEmitter = { IJobEvent evt -> allJobEvents.add(evt); consoleEmitter.emit(evt); }

        workflowConfig.name = MainWorkflowName
        workflowConfig.stepConfigs = [numberGeneratorConfig, errorOnDataConfigStage1, errorOnDataConfigStage2, successConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, ErrorOnDataStage1),
                new StepLink(ErrorOnDataStage1, ErrorOnDataStage2),
                new StepLink(ErrorOnDataStage2, Success)
        ]

        globalErrorHandlingWorkflowConfig.name = GlobalErrorHandlingWorkflowName
        globalErrorHandlingWorkflowConfig.stepConfigs = [errorConfig]
        globalErrorHandlingWorkflowConfig.setStartStepName(Error)

//        println mapperFactory.getMapper().writeValueAsString(Arrays.asList(workflowConfig, globalErrorHandlingWorkflowConfig))

        def configRepository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowConfig(globalErrorHandlingWorkflowConfig)

        def jobConfig = new JobConfig(MainWorkflowName, GlobalErrorHandlingWorkflowName)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", jobConfig, configRepository)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(eventCollectorAndConsoleEmitter))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(MainWorkflowName, SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        // TODO better mechanism to get data queue
        def successReceiver = localJobTaskExecutor.getOutBoundQueue(MainWorkflowName, Success).get(1).getReceiver()
        def successData = ReceiverUtil.collectDataFromReceiver(successReceiver)
        def successExpectedData = (1..256).grep {
            it in errorNumbersStage1 == false && it in errorNumbersStage2 == false
        }
        successData.size() == successExpectedData.size()
        successData.sort() == successExpectedData
        println successData

        def errorReceiver = localJobTaskExecutor.getOutBoundQueue(GlobalErrorHandlingWorkflowName, Error).get(0).getReceiver()
        def errorData = ReceiverUtil.collectDataFromReceiver(errorReceiver)
        def errorExpectedData = errorNumbersStage1 + errorNumbersStage2
        errorData.size() == errorExpectedData.size()
        errorData.sort() == errorExpectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 5
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, Success, Error, ErrorOnDataStage1, ErrorOnDataStage2].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def successResult = stepExecutionResults.grep { it -> it.stepName == Success }
        successResult != null
        successResult.size() == 1
        successExpectedData.size() == successResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def errorResult = stepExecutionResults.grep { it -> it.stepName == Error }
        errorResult != null
        errorResult.size() == 1
        errorExpectedData.size() == errorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.errorCount }

        // all event which has step name should also contain step type
        def emptyStepNameOrTypeList = allJobEvents.grep { evt -> (evt instanceof IStepExecutorEvent) && (StringUtils.isEmpty(evt.stepName) || StringUtils.isEmpty(evt.stepType)) }
        emptyStepNameOrTypeList.size() == 0

        println jobTaskExecutorResult
    }

    @Unroll
    def "Combining global error & step level error handling - callGlobalErrorEvenWhenHandled: #callGlobalErrorEvenWhenHandled"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def globalErrorHandlingWorkflowConfig = new WorkflowConfig()

        def MainWorkflowName = "Main"
        def GlobalErrorHandlingWorkflowName = "GlobalErrorHandler"

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def ErrorOnDataStage1 = "ErrorOnDataStage1"
        def ErrorHandlerForStage1 = "ErrorHandlerForStage1"
        def ErrorOnDataStage2 = "ErrorOnDataStage2"
        def Success = "Success"
        def Error = "Error"

        def errorNumbersStage1 = (100..120)
        def errorNumbersStage2 = (220..230)

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1)
        def errorOnDataConfigStage1 = new ErrorOnDataConfig(ErrorOnDataStage1, errorNumbersStage1, callGlobalErrorEvenWhenHandled)
        def errorHandlerForStage1Config = new DelegatorConfig(ErrorHandlerForStage1)

        def errorOnDataConfigStage2 = new ErrorOnDataConfig(ErrorOnDataStage2, errorNumbersStage2)
        def successConfig = new DelegatorConfig(Success)
        def errorConfig = new DelegatorConfig(Error)

        workflowConfig.name = MainWorkflowName
        workflowConfig.stepConfigs = [numberGeneratorConfig, errorOnDataConfigStage1, errorOnDataConfigStage2, errorHandlerForStage1Config, successConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, ErrorOnDataStage1),
                new StepLink(ErrorOnDataStage1, ErrorHandlerForStage1).setErrorHandlingLink(true),
                new StepLink(ErrorOnDataStage1, ErrorOnDataStage2),
                new StepLink(ErrorOnDataStage2, Success)
        ]

        globalErrorHandlingWorkflowConfig.name = GlobalErrorHandlingWorkflowName
        globalErrorHandlingWorkflowConfig.stepConfigs = [errorConfig]
        globalErrorHandlingWorkflowConfig.setStartStepName(Error)

        def configRepository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowConfig(globalErrorHandlingWorkflowConfig)

        def jobConfig = new JobConfig(MainWorkflowName, GlobalErrorHandlingWorkflowName)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", jobConfig, configRepository)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new LogJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(MainWorkflowName, SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        // TODO better mechanism to get data queue
        def successReceiver = localJobTaskExecutor.getOutBoundQueue(MainWorkflowName, Success).get(1).getReceiver()
        def successData = ReceiverUtil.collectDataFromReceiver(successReceiver)
        def successExpectedData = (1..256).grep {
            it in errorNumbersStage1 == false && it in errorNumbersStage2 == false
        }
        successData.size() == successExpectedData.size()
        successData.sort() == successExpectedData
        println successData

        def errorHandlerForStage1Receiver = localJobTaskExecutor.getOutBoundQueue(MainWorkflowName, ErrorHandlerForStage1).get(1).getReceiver()
        def errorStage1Data = ReceiverUtil.collectDataFromReceiver(errorHandlerForStage1Receiver)
        def errorStage1ExpectedData = errorNumbersStage1
        errorStage1Data.size() == errorStage1ExpectedData.size()
        errorStage1Data.sort() == errorStage1ExpectedData

        def globalErrorReceiver = localJobTaskExecutor.getOutBoundQueue(GlobalErrorHandlingWorkflowName, Error).get(0).getReceiver()
        def globalErrorData = ReceiverUtil.collectDataFromReceiver(globalErrorReceiver)
        def errorExpectedData = (callGlobalErrorEvenWhenHandled) ? errorNumbersStage1 + errorNumbersStage2 : errorNumbersStage2
        globalErrorData.size() == errorExpectedData.size()
        globalErrorData.sort() == errorExpectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 6
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, Success, Error, ErrorOnDataStage1,
                                                                      ErrorHandlerForStage1, ErrorOnDataStage2].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def successResult = stepExecutionResults.grep { it -> it.stepName == Success }
        successResult != null
        successResult.size() == 1
        successExpectedData.size() == successResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def errorResult = stepExecutionResults.grep { it -> it.stepName == Error }
        errorResult != null
        errorResult.size() == 1
        errorExpectedData.size() == errorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.errorCount }

        println jobTaskExecutorResult

        where:
        callGlobalErrorEvenWhenHandled << [true, false]
    }

    def "Multiple sources to one step"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator1To64 = "SequenceNumberGenerator1To64"
        def SequenceNumberGenerator65To128 = "SequenceNumberGenerator65To128"
        def SequenceNumberGenerator129To256 = "SequenceNumberGenerator129To256"

        def Collector = "Collector"

        def sequenceNumberGenerator1To64Config = new NumberGeneratorConfig(SequenceNumberGenerator1To64, 1, 64, 1, 10)
        def sequenceNumberGenerator65To128Config = new NumberGeneratorConfig(SequenceNumberGenerator65To128, 65, 128, 1, 20)
        def sequenceNumberGenerator129To256Config = new NumberGeneratorConfig(SequenceNumberGenerator129To256, 129, 256, 1, 5)

        def collectorConfig = new DelegatorConfig(Collector)

        workflowConfig.stepConfigs = [sequenceNumberGenerator1To64Config, sequenceNumberGenerator65To128Config, sequenceNumberGenerator129To256Config, collectorConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator1To64, Collector),
                new StepLink(SequenceNumberGenerator65To128, Collector),
                new StepLink(SequenceNumberGenerator129To256, Collector)
        ]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        [SequenceNumberGenerator1To64, SequenceNumberGenerator65To128, SequenceNumberGenerator129To256].each {
            def emitter = localJobTaskExecutor.getInBoundQueue(it).getEmitter()
            emitter.emit(messageFactory.createMessage("START")) // Need to remove
            emitter.end(messageFactory.createEndMessage()) // Need to remove
        }

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def collectorReceiver = localJobTaskExecutor.getOutBoundQueue(Collector).get(0).getReceiver()
        def collectorData = ReceiverUtil.collectDataFromReceiver(collectorReceiver)
        def collectorExpectedData = (1..256)
        collectorData.size() == collectorExpectedData.size()
        collectorData.sort() == collectorExpectedData

        jobTaskExecutorResult != null
        jobTaskExecutorResult.status == OperationStatus.COMPLETED
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator1To64, SequenceNumberGenerator65To128,
                                                                      SequenceNumberGenerator129To256, Collector].sort()
        [SequenceNumberGenerator1To64, SequenceNumberGenerator65To128, SequenceNumberGenerator129To256, Collector].each {
            def sequenceNumberGeneratorResult = stepExecutionResults.grep { stepExecutionResult -> stepExecutionResult.stepName == it }
            sequenceNumberGeneratorResult != null
            sequenceNumberGeneratorResult.size() == 1
            1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        }

        def collectorResult = stepExecutionResults.grep { it -> it.stepName == Collector }
        collectorResult != null
        collectorResult.size() == 1
        collectorExpectedData.size() == collectorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        3 == collectorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.endCount }

        println jobTaskExecutorResult
    }

    def "Manual abort job"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def DivisibleBy2 = "DivisibleBy2"
        def DivisibleBy3 = "DivisibleBy3"
        def Others = "Others"
        def SequenceNumberDelayInMs = 500
        def MaxNoOfMessages = 6

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1, SequenceNumberDelayInMs)
        def divisibleBy2Config = new DelegatorConfig(DivisibleBy2)
        def divisibleBy3Config = new DelegatorConfig(DivisibleBy3)
        def othersConfig = new DelegatorConfig(Others)

        workflowConfig.stepConfigs = [numberGeneratorConfig, divisibleBy2Config, divisibleBy3Config, othersConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, DivisibleBy2, new DivisibleScriptConfig(2)),
                new StepLink(SequenceNumberGenerator, DivisibleBy3, new DivisibleScriptConfig(3)),
                new StepLink(SequenceNumberGenerator, Others, new DivisibleScriptConfig(0))
        ]

//        println mapperFactory.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(workflowConfig)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        Thread.sleep(SequenceNumberDelayInMs * MaxNoOfMessages);
        localJobTaskExecutor.abort()
        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def divisibleBy2Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy2).get(0).getReceiver()
        def divisibleBy2Data = ReceiverUtil.collectDataFromReceiver(divisibleBy2Receiver)
        def divisibleBy2ExpectedData = (1..MaxNoOfMessages).grep { it % 2 == 0 }
        divisibleBy2Data.size() <= divisibleBy2ExpectedData.size()
//        divisibleBy2Data.sort() == divisibleBy2ExpectedData

        def divisibleBy3Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy3).get(0).getReceiver()
        def divisibleBy3Data = ReceiverUtil.collectDataFromReceiver(divisibleBy3Receiver)
        def divisibleBy3ExpectedData = (1..MaxNoOfMessages).grep { it % 2 != 0 && it % 3 == 0 }
        divisibleBy3Data.size() <= divisibleBy3ExpectedData.size()
//        divisibleBy3Data.sort() == divisibleBy3ExpectedData

        def othersReceiver = localJobTaskExecutor.getOutBoundQueue(Others).get(0).getReceiver()
        def othersData = ReceiverUtil.collectDataFromReceiver(othersReceiver)
        def othersExpectedData = (1..MaxNoOfMessages).grep { it % 2 != 0 && it % 3 != 0 }
        othersData.size() <= othersExpectedData.size()
//        othersData.sort() == othersExpectedData

        jobTaskExecutorResult != null
        jobTaskExecutorResult.status == OperationStatus.ABORTED
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, DivisibleBy2, DivisibleBy3, Others].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy2Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy2 }
        divisibleBy2Result != null
        divisibleBy2Result.size() == 1
        divisibleBy2Data.size() == divisibleBy2Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def divisibleBy3Result = stepExecutionResults.grep { it -> it.stepName == DivisibleBy3 }
        divisibleBy3Result != null
        divisibleBy3Result.size() == 1
        divisibleBy3Data.size() == divisibleBy3Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def othersResult = stepExecutionResults.grep { it -> it.stepName == Others }
        othersResult != null
        othersResult.size() == 1
        othersData.size() == othersResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        println jobTaskExecutorResult
    }

    def "Step based abort job"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def AbortJobOnData = "AbortJobOnData"
        def Success = "Success"
        def Error = "Error"

        def abortOnNumber = 21
        def errorNumbers = [abortOnNumber]

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1, 50)
        def abortJobOnDataConfig = new AbortJobOnDataConfig(AbortJobOnData, errorNumbers)
        def successConfig = new DelegatorConfig(Success)
        def errorConfig = new DelegatorConfig(Error)

        workflowConfig.stepConfigs = [numberGeneratorConfig, abortJobOnDataConfig, successConfig, errorConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, AbortJobOnData),
                new StepLink(AbortJobOnData, Success),
                new StepLink(AbortJobOnData, Error).setErrorHandlingLink(true)
        ]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def successReceiver = localJobTaskExecutor.getOutBoundQueue(Success).get(0).getReceiver()
        def successData = ReceiverUtil.collectDataFromReceiver(successReceiver)
        def successExpectedData = (1..abortOnNumber - 1)
        successData.size() == successExpectedData.size()
        successData.sort() == successExpectedData
        println successData

        def errorReceiver = localJobTaskExecutor.getOutBoundQueue(Error).get(0).getReceiver()
        def errorData = ReceiverUtil.collectDataFromReceiver(errorReceiver)
        def errorExpectedData = []
        errorData.size() == errorExpectedData.size()
        errorData.sort() == errorExpectedData

        jobTaskExecutorResult != null
        jobTaskExecutorResult.status == OperationStatus.ABORTED
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, Success, Error, AbortJobOnData].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def successResult = stepExecutionResults.grep { it -> it.stepName == Success }
        successResult != null
        successResult.size() == 1
        successExpectedData.size() == successResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def errorResult = stepExecutionResults.grep { it -> it.stepName == Error }
        errorResult != null
        errorResult.size() == 1
        errorExpectedData.size() == errorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.errorCount }

        println jobTaskExecutorResult
    }

    def "Conditional routing & unhandled exception "() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def DivisibleBy2 = "DivisibleBy2"
        def DivisibleBy3 = "DivisibleBy3"
        def Others = "Others"
        def ExceptionOnData = [2]

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 256, 1, 5)
        def divisibleBy2Config = new ThrowExceptionOnDataConfig(DivisibleBy2, ExceptionOnData)
        def divisibleBy3Config = new DelegatorConfig(DivisibleBy3)
        def othersConfig = new DelegatorConfig(Others)

        workflowConfig.stepConfigs = [numberGeneratorConfig, divisibleBy2Config, divisibleBy3Config, othersConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, DivisibleBy2, new DivisibleScriptConfig(2)),
                new StepLink(SequenceNumberGenerator, DivisibleBy3, new DivisibleScriptConfig(3)),
                new StepLink(SequenceNumberGenerator, Others, new DivisibleScriptConfig(0))
        ]

//        println mapperFactory.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(workflowConfig)

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)

        def divisibleBy2Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy2).get(0).getReceiver()
        def divisibleBy2Data = ReceiverUtil.collectDataFromReceiver(divisibleBy2Receiver)
        def divisibleBy2ExpectedData = (1..256).grep { it % 2 == 0 }
        divisibleBy2Data.size() < divisibleBy2ExpectedData.size()
        divisibleBy2Data.sort() != divisibleBy2ExpectedData

        def divisibleBy3Receiver = localJobTaskExecutor.getOutBoundQueue(DivisibleBy3).get(0).getReceiver()
        def divisibleBy3Data = ReceiverUtil.collectDataFromReceiver(divisibleBy3Receiver)
        def divisibleBy3ExpectedData = (1..256).grep { it % 2 != 0 && it % 3 == 0 }
        divisibleBy3Data.size() < divisibleBy3ExpectedData.size()
        divisibleBy3Data.sort() != divisibleBy3ExpectedData

        def othersReceiver = localJobTaskExecutor.getOutBoundQueue(Others).get(0).getReceiver()
        def othersData = ReceiverUtil.collectDataFromReceiver(othersReceiver)
        def othersExpectedData = (1..256).grep { it % 2 != 0 && it % 3 != 0 }
        othersData.size() < othersExpectedData.size()
        othersData.sort() != othersExpectedData

        jobTaskExecutorResult != null
        jobTaskExecutorResult.status == OperationStatus.ABORTED
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 4
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, DivisibleBy2, DivisibleBy3, Others].sort()

        println jobTaskExecutorResult
    }

    def "One queue to One instance & data spray"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def InstanceIdPrefix = "InstanceIdPrefix"
        def noOfInstanceIdPrefixInstances = 5
        def dataSprayAlgorithm = { data -> data % noOfInstanceIdPrefixInstances; }

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 0, 511, 1)
        def instanceIdPrefixConfig = new OneQueueToOneInstanceConfig(InstanceIdPrefix, InstanceIdPrefix)
        def instanceIdQueueConfig = new PartitionBasedQueueConfig(noOfInstanceIdPrefixInstances, dataSprayAlgorithm, LocalJobTaskExecutor.DEFAULT_LOCAL_QUEUE_CONFIG)

        workflowConfig.stepConfigs = [numberGeneratorConfig, instanceIdPrefixConfig]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, InstanceIdPrefix)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", InstanceIdPrefix,
                new PartitionBasedStepExecutorConfig(1, 1, instanceIdQueueConfig))

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        println 'Execution started'
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)
        println 'Execution completed'

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(InstanceIdPrefix).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        def expectedData = (((((0..511).step(5).collect { it + "-0" }
                + (1..511).step(5).collect { it + "-1" })
                + (2..511).step(5).collect { it + "-2" })
                + (3..511).step(5).collect { it + "-3" })
                + (4..511).step(5).collect { it + "-4" })
        receivedData.size() == expectedData.size()
        receivedData == expectedData

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 2
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, InstanceIdPrefix].sort()
        stepExecutionResults.collect { it -> it.stepType }.sort() == [numberGeneratorConfig.stepType, instanceIdPrefixConfig.stepType].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def instanceIdPrefixResult = stepExecutionResults.grep { it -> it.stepName == InstanceIdPrefix }
        instanceIdPrefixResult != null
        instanceIdPrefixResult.size() == 1
        512 == instanceIdPrefixResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        def instancesWithoutEndCount = instanceIdPrefixResult.get(0).instanceStats.asList().grep { val -> val.inbound.endCount != 1 }
        instancesWithoutEndCount.size() == 0
        noOfInstanceIdPrefixInstances == instanceIdPrefixResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.endCount }

        // Sequential instance startup check
        def lastInstanceEndTime = 0
        instanceIdPrefixResult.get(0).instanceStats.asList().grep { val ->
            def checkResult = val.startTime >= lastInstanceEndTime;
            lastInstanceEndTime = val.startTime + val.totalExecutionTime;
            return checkResult;
        }

        println jobTaskExecutorResult
    }

    def "Embedded workflow execution"() {
        setup:
        def workflowConfig = new WorkflowConfig()

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def FilterBy2SubWorkflow = "FilterBy2SubWorkflow"
        def FilterBy2 = "FilterBy2"
        def FilterBy3 = "FilterBy3"

        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 512, 1)
        def filterBy2Config = new FilterNonDivisibleBySubWorkflowConfig(FilterBy2SubWorkflow, new FilterNonDivisibleByConfig(FilterBy2, 2))
        def filterBy3Config = new FilterNonDivisibleByConfig(FilterBy3, 3)

        workflowConfig.stepConfigs = [numberGeneratorConfig, filterBy2Config, filterBy3Config]
        workflowConfig.stepLinks = [
                new StepLink(SequenceNumberGenerator, FilterBy2SubWorkflow),
                new StepLink(FilterBy2SubWorkflow, FilterBy3)
        ]

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(SequenceNumberGenerator).getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(FilterBy3).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 85
        def sort = receivedData.sort()
        sort == (6..512).step(6)

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 3
        stepExecutionResults.collect { it -> it.stepName }.sort() == [SequenceNumberGenerator, FilterBy2, FilterBy3].sort()
        stepExecutionResults.collect { it -> it.stepType }.sort() == [numberGeneratorConfig.stepType, filterBy2Config.childConfig.stepType, filterBy3Config.stepType].sort()

        def sequenceNumberGeneratorResult = stepExecutionResults.grep { it -> it.stepName == SequenceNumberGenerator }
        sequenceNumberGeneratorResult != null
        sequenceNumberGeneratorResult.size() == 1
        1 == sequenceNumberGeneratorResult.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def filterBy2Result = stepExecutionResults.grep { it -> it.stepName == FilterBy2 }
        filterBy2Result != null
        filterBy2Result.size() == 1
        512 == filterBy2Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        def filterBy3Result = stepExecutionResults.grep { it -> it.stepName == FilterBy3 }
        filterBy3Result != null
        filterBy3Result.size() == 1
        256 == filterBy3Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }

        println jobTaskExecutorResult
    }

}
