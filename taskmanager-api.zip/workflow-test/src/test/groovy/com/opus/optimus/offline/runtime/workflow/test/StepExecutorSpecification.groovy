package com.opus.optimus.offline.runtime.workflow.test

import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueue
import com.opus.optimus.offline.runtime.queue.api.local.impl.LocalQueueConfig
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalStepExecutorConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.StaticStepTaskCreator
import com.opus.optimus.offline.runtime.workflow.api.impl.StepExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestWorkflowConfiguration.class)
class StepExecutorSpecification extends Specification {

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    StepInstanceExecutorCreatorFactory instanceExecutorCreatorFactory;

    def "Single step execution"() {
        setup:
        def inBoundQueueConfig = new LocalQueueConfig(16, 100);
        def inBoundQueue = new LocalQueue(inBoundQueueConfig);

        def outBoundQueueConfig = new LocalQueueConfig(64, 100);
        def outBoundQueue = new LocalQueue(outBoundQueueConfig);

        def executorService = Executors.newCachedThreadPool()

        def workflowName = "Default"
        def stepName = "AnyName"
        def stepExecutor = new StepExecutor(workflowName, stepName, new LocalStepExecutorConfig(4, 4, null),
                new StaticStepTaskCreator(4, workflowName, new FilterNonDivisibleByConfig(stepName, 2), inBoundQueue, outBoundQueue),
                null)
        stepExecutor.setInstanceExecutorCreatorFactory(instanceExecutorCreatorFactory)
        stepExecutor.setExecutorService(executorService)

        when:
        def result = stepExecutor.start()
        def emitter = inBoundQueue.getEmitter()

        (1..64).each { emitter.emit(messageFactory.createMessage(it)) }
        emitter.emit(messageFactory.createEndMessage())
        result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = outBoundQueue.getReceiver();
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 32
        def sort = receivedData.sort()
        sort == (2..64).step(2)
    }

    def "Linking 3 step execution"() {
        setup:
        def inBoundQueueConfigForSource = new LocalQueueConfig(1, 100);
        def inBoundQueueForSource = new LocalQueue(inBoundQueueConfigForSource);

        def inBoundQueueConfigForFilterBy2 = new LocalQueueConfig(16, 100);
        def inBoundQueueForFilterBy2 = new LocalQueue(inBoundQueueConfigForFilterBy2);

        def inBoundQueueConfigForFilterBy3 = new LocalQueueConfig(8, 100);
        def inBoundQueueForFilterBy3 = new LocalQueue(inBoundQueueConfigForFilterBy3);

        def outBoundQueueConfigForFilterBy3 = new LocalQueueConfig(512, 100);
        def outBoundQueueForFilterBy3 = new LocalQueue(outBoundQueueConfigForFilterBy3);

        def executorService = Executors.newCachedThreadPool()

        def workflowName = "Default"

        def SequenceNumberGenerator = "SequenceNumberGenerator"
        def numberGeneratorConfig = new NumberGeneratorConfig(SequenceNumberGenerator, 1, 512, 1)
        def sourceStepExecutor = new StepExecutor(workflowName, SequenceNumberGenerator, new LocalStepExecutorConfig(1, 1, null),
                new StaticStepTaskCreator(1, workflowName, numberGeneratorConfig, inBoundQueueForSource, inBoundQueueForFilterBy2),
                null)
        sourceStepExecutor.setInstanceExecutorCreatorFactory(instanceExecutorCreatorFactory)
        sourceStepExecutor.setExecutorService(executorService)

        def FilterBy2 = "FilterBy2"
        def filterBy2Config = new FilterNonDivisibleByConfig(FilterBy2, 2)
        def filterBy2StepExecutor = new StepExecutor(workflowName, FilterBy2, new LocalStepExecutorConfig(4, 4, null),
                new StaticStepTaskCreator(4, workflowName, filterBy2Config, inBoundQueueForFilterBy2, inBoundQueueForFilterBy3),
                null)
        filterBy2StepExecutor.setInstanceExecutorCreatorFactory(instanceExecutorCreatorFactory)
        filterBy2StepExecutor.setExecutorService(executorService)

        def FilterBy3 = "FilterBy3"
        def filterBy3Config = new FilterNonDivisibleByConfig(FilterBy3, 3)
        def filterBy3StepExecutor = new StepExecutor(workflowName, FilterBy3, new LocalStepExecutorConfig(2, 2, null),
                new StaticStepTaskCreator(2, workflowName, filterBy3Config, inBoundQueueForFilterBy3, outBoundQueueForFilterBy3),
                null)
        filterBy3StepExecutor.setInstanceExecutorCreatorFactory(instanceExecutorCreatorFactory)
        filterBy3StepExecutor.setExecutorService(executorService)

        when:
        def sourceStepResult = sourceStepExecutor.start()
        def filterBy2StepResult = filterBy2StepExecutor.start()
        def filterBy3StepResult = filterBy3StepExecutor.start()

        def emitter = inBoundQueueForSource.getEmitter()
        emitter.emit(messageFactory.createMessage("START")) // Need to remove
        emitter.emit(messageFactory.createEndMessage()) // Need to remove

        CompletableFuture.allOf(sourceStepResult, filterBy2StepResult, filterBy3StepResult).get(2, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = outBoundQueueForFilterBy3.getReceiver();
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 85
        def sort = receivedData.sort()
        sort == (6..512).step(6)
    }

}
