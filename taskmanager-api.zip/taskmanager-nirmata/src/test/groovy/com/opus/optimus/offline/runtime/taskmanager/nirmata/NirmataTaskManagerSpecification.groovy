package com.opus.optimus.offline.runtime.taskmanager.nirmata


import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

@ContextConfiguration(classes = NirmataConfiguration.class)
//@Profile("local")
class NirmataTaskManagerSpecification extends Specification {
/*
    @Autowired
    IRawTaskManager taskManager

    def "Dummy"() {
        setup:

        when:

        expect:
        taskManager != null
    }
*/
}
