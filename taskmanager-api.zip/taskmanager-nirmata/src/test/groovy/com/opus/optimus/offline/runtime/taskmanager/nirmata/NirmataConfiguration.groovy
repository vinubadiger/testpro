package com.opus.optimus.offline.runtime.taskmanager.nirmata

//@Configuration
//@ComponentScan("com.opus.optimus.offline.runtime")
//@EnableMongoRepositories ("com.opus.optimus.offline.runtime")
//@PropertySource(factory = YamlPropertySourceFactory.class, value = "classpath:application-test.yml")
class NirmataConfiguration {
}
