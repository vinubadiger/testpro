package com.opus.optimus.offline.runtime.taskmanager.nirmata;

import com.nirmata.workflow.WorkflowManager;
import com.nirmata.workflow.executor.TaskExecution;
import com.nirmata.workflow.executor.TaskExecutionStatus;
import com.nirmata.workflow.executor.TaskExecutor;
import com.nirmata.workflow.models.ExecutableTask;
import com.nirmata.workflow.models.TaskExecutionResult;
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutor;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutorFactory;
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NirmataTaskExecutor implements TaskExecutor {
	private static final Logger logger = LoggerFactory.getLogger(NirmataTaskExecutor.class);
    ITaskExecutorFactory taskExecutorFactory;
    MapperFactory mapperFactory;

    public NirmataTaskExecutor(ITaskExecutorFactory taskExecutorFactory, MapperFactory mapperFactory) {
        this.taskExecutorFactory = taskExecutorFactory;
        this.mapperFactory = mapperFactory;
    }

    @Override
    public TaskExecution newTaskExecution(WorkflowManager workflowManager, ExecutableTask executableTask) {
        System.out.println("Task received !!!");
        return new NirmataTaskExecution(workflowManager, executableTask);
    }

    public class NirmataTaskExecution implements TaskExecution {

        WorkflowManager workflowManager;
        ExecutableTask executableTask;

        public NirmataTaskExecution(WorkflowManager workflowManager, ExecutableTask executableTask) {
            this.workflowManager = workflowManager;
            this.executableTask = executableTask;
        }

        @Override
        public TaskExecutionResult execute() {
            Map<String, String> metaData = executableTask.getMetaData();
            String executionInfoAsString = metaData.get(NirmataTaskManager.EXECUTION_INFO);
            String taskId = metaData.get(NirmataTaskManager.TASK_ID);
            try {
                ExecutionInfo executionInfo = mapperFactory.getMapper().readValue(executionInfoAsString, ExecutionInfo.class);
                String jobId = executableTask.getRunId().getId();
                JobTask jobTask = JobTask.builder()
                        .taskId(taskId)
                        .executionInfo(executionInfo)
                        .build();
                ITaskExecutor taskExecutor = taskExecutorFactory.newTaskExecutor(jobId, jobTask);

                if (taskExecutor == null) {
                    return new TaskExecutionResult(TaskExecutionStatus.FAILED_STOP, "Failed to create task executor.  Please check the logs !!!");
                }

                CompletableFuture<JobTaskExecutorResult> result = taskExecutor.execute();
                result.join();

                return new TaskExecutionResult(TaskExecutionStatus.SUCCESS, "SUCCESS");
            } catch (Throwable e) {
                // Logo and throw exception
                e.printStackTrace();
                logger.error(e.getMessage(), e);
                String errorMessage = e.getMessage();
                if (errorMessage == null || errorMessage.length() == 0) {
                    errorMessage = e.getClass().getCanonicalName() + " type";
                }

                // avoiding invoking the task again
                return new TaskExecutionResult(TaskExecutionStatus.FAILED_STOP, errorMessage);
            }
        }
    }
}
