package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.ReconCaseTemplate;

public interface ReconCaseTemplatesRepository extends MongoRepository<ReconCaseTemplate, String> {
	@Query (value = "{ $and : [ { 'projectName' : ?0 }, { 'activityName' : ?1 }] }")
	List<ReconCaseTemplate> findByProjectNameandActivityName(String projectName ,String activityName);
}
