package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import com.opus.optimus.offline.runtime.taskmanager.mongo.IPublishedWorkflowConfigService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PublishedWorkflowConfigService implements IPublishedWorkflowConfigService {
	private static final Logger logger = LoggerFactory.getLogger(PublishedWorkflowConfigService.class);

	@Autowired
	PublishedWorkflowConfigRepository publishedWorkflowConfigRepository;

	@Override
	public WorkflowConfig findWCByGroupIdAndWorkflowId(String Id, String workflowId) {		
		logger.info("Searching Workflow with GroupId {} & Workflowname {} - ", Id, workflowId);		
		PublishedService publishedService = publishedWorkflowConfigRepository.findWCByGroupIdAndWorkflowId(Id, workflowId);
		return (publishedService == null) ? null : publishedService.getWorkflowConfig();

	}

	@Override
	public WorkflowExecutionConfig findWECByGroupIdAndWorkflowId(String Id, String workflowId) {
		PublishedService publishedService = publishedWorkflowConfigRepository.findWECByGroupIdAndWorkflowId(Id, workflowId);
		return (publishedService == null) ? null : publishedService.getWorkflowExecutionConfig();
	}

	public PublishedService createWorkFlow(PublishedService publishService) {
		return publishedWorkflowConfigRepository.save(publishService);
	}

}
