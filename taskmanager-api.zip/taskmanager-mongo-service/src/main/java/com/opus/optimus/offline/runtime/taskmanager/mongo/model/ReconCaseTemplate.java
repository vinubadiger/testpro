package com.opus.optimus.offline.runtime.taskmanager.mongo.model;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document (collection = "ReconCaseTemplate")
public class ReconCaseTemplate {
	String activityName;
	String projectName;
	String templates;
	String recon_status;
}
