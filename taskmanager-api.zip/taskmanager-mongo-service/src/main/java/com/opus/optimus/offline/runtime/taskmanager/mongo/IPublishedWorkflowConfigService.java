package com.opus.optimus.offline.runtime.taskmanager.mongo;

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig;

public interface IPublishedWorkflowConfigService {

    WorkflowConfig findWCByGroupIdAndWorkflowId(String Id, String workflowId);

    WorkflowExecutionConfig findWECByGroupIdAndWorkflowId(String groupId, String workflowId);

    PublishedService createWorkFlow(PublishedService publishService);

}
