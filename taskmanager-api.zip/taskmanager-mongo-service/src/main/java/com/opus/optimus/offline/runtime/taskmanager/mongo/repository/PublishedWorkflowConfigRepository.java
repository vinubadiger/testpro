package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;

@Repository
public interface PublishedWorkflowConfigRepository extends MongoRepository<PublishedService, String> {
	@Query (value = "{ $and : [ { '_id' : ?0 }, { 'workflowName' : ?1 }] }")
	PublishedService findWCByGroupIdAndWorkflowId(String Id, String workflowName);

	@Query (value = "{ $and : [ { '_id' : ?0 }, { 'workflowName' : ?1 }] }")
	PublishedService findWECByGroupIdAndWorkflowId(String Id, String workflowName);
}
