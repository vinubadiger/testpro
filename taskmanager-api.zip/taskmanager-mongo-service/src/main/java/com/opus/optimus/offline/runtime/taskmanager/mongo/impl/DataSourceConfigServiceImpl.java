package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IDataSourceConfigService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository;

@Component
public class DataSourceConfigServiceImpl implements IDataSourceConfigService {

	@Autowired
	private DataSourceConfigRepository dataSourceConfigRepository;
	
	@Override
	public List<MongoDataSourceMeta> findAllDataSourceConfigs() {
		return dataSourceConfigRepository.findAll();
	}

}
