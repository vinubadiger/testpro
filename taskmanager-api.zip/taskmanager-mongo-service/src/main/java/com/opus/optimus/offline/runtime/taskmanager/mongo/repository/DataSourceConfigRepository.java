package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;

@Repository
public interface DataSourceConfigRepository extends MongoRepository<MongoDataSourceMeta, String> {
}
