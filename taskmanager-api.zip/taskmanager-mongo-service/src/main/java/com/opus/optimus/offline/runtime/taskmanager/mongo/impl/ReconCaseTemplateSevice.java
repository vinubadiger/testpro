package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.ReconCaseTemplate;
//TODO This inteface will move into other project later
@Component
public interface ReconCaseTemplateSevice 
{
	ReconCaseTemplate save(ReconCaseTemplate reconCaseTemplates);
	Map<String,String> findByProjectNameandActivityName(String projectName,String activityName);
	
}
