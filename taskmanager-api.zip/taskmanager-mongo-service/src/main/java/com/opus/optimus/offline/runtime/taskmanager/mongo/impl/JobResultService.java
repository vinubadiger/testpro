package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobResultService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

/**
 * This class is used for saving the job result when the job gets executed.
 * Also using this class we can find the job result based on jobId.
 *
 */
@Component
public class JobResultService implements IJobResultService {

	@Autowired
	JobResultRepository jobResultRepository;

	@Autowired
	IJobInfoService jobInfoService;

	@Override
	public JobResult findById(String jobId) {

		try{
			List<JobTaskExecutorResult> jobTaskExecResults = jobResultRepository.findByJobId(jobId);
			return JobResult.builder().taskResults(jobTaskExecResults).build();
			
		} catch (Exception e){
			throw new EngineException(e);
		}

	}

	@Override
	public JobResult saveJobTaskResult(String jobId, String jobTaskId, JobTaskExecutorResult jobTaskExecutorResult) {
		try{
			if (jobTaskExecutorResult.getProjectName() == null || jobTaskExecutorResult.getWorkflowName() == null || jobTaskExecutorResult.getWorkflowType() == null || jobTaskExecutorResult.getGroupId() == null){
				JobInfo jobInfo = this.jobInfoService.findById(jobId);
				jobTaskExecutorResult.setProjectName(jobInfo.getProjectName());
				jobTaskExecutorResult.setWorkflowName(jobInfo.getWorkflowName());
				jobTaskExecutorResult.setWorkflowType(jobInfo.getWorkflowType());
				jobTaskExecutorResult.setGroupId(jobInfo.getGroupId());
				if (jobInfo.getSourceInfo() != null && jobInfo.getSourceInfo().getSourceFile() != null){
					jobTaskExecutorResult.setSourceFile(jobInfo.getSourceInfo().getSourceFile());
				}
			}
			jobResultRepository.save(jobTaskExecutorResult);
			return findById(jobId);
		} catch (Exception e){
			throw new EngineException(e);
		}
	}
}
