/**
 * 
 */
package com.opus.optimus.offline.runtime.taskmanager.mongo;

import java.util.List;
import java.util.concurrent.ConcurrentMap;

import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;

/**
 * @author Manjusha.Dhamdhere
 */
public interface IReconSummary {

	/**
	 * Method that generates Summary after a reconciliation job ends
	 * 
	 * @param jobId - ID of the Reconciliation Job
	 * @return - Returns a map that holds Key wise Summary information
	 */
	ConcurrentMap<SummaryKey, List<ReconSourceSummary>> updateBatchSummary(String jobId);

}
