package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

public interface JobResultRepository extends MongoRepository<JobTaskExecutorResult, String> {
	List<JobTaskExecutorResult> findByJobId(String jobId);
}
