/**
 * 
 */
package com.opus.optimus.offline.runtime.taskmanager.mongo.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongodb.Block;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.SourceMappingType;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationConfig;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IReconSummary;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

@Service
public class ReconSummaryService implements IReconSummary {
	private static final Logger logger = LoggerFactory.getLogger(ReconSummaryService.class);

	@Autowired
	JobInfoRepository jobInfoRepository;

	@Autowired
	PublishedWorkflowConfigRepository publishedServiceRepository;

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	ReconAcitivitySummaryRepository acitivitySummaryRepository;

	private static final String ACTIVITY_NAME = "activityName";
	private static final String RECON_CONTROL_FIELD = "$reconControlFields";
	private static final String PROCESSING_DATE = "processingDate";
	private static final String STATUS = "status";
	private static final String SUB_STATUS = "subStatus";

	@Override
	public ConcurrentMap<SummaryKey, List<ReconSourceSummary>> updateBatchSummary(String jobId) {
		try{
			Optional<JobInfo> jobOption = this.jobInfoRepository.findById(jobId);
			JobInfo jobInfo = jobOption.isPresent() ? jobOption.get() : null;
			if (null == jobInfo){
				throw new EngineException("Invalid JobId");
			}

			Optional<PublishedService> publishedOption = this.publishedServiceRepository.findById(jobInfo.getGroupId());
			PublishedService publishedService = publishedOption.isPresent() ? publishedOption.get() : null;
			if (null == publishedService){
				throw new EngineException("Invalid Group Id");
			}

			ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder = new ConcurrentHashMap<>();

			Optional<IStepConfig> reconConfigOptional = publishedService.getWorkflowConfig().getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.RECON_CONFIG_STEP)).findAny();
			ReconciliationConfig reconConfig = null;
			if (reconConfigOptional.isPresent()){
				reconConfig = (ReconciliationConfig) reconConfigOptional.get();
			} else{
				throw new EngineException("Recon Config not found!");
			}

			publishedService.getWorkflowConfig().getStepConfigs().parallelStream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE)).collect(Collectors.toList()).forEach(stepConfig -> {
				MongoDBReaderConfig mongoStepConfig = (MongoDBReaderConfig) stepConfig;
				getAggregatedResults(mongoStepConfig, recordHolder, mongoStepConfig.getSourceDefinition().getSourceName(), mongoStepConfig.getStepName(), jobInfo.getWorkflowName());
			});

			saveAcitivitySummary(recordHolder, reconConfig.getSourceMapping(), jobInfo.getProjectName());

			return recordHolder;
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException("Error in UpdateBatchSummary", e);
		}
	}

	/**
	 * This method triggers the matching & grouping query to Mongo database and initiates Aggregation operation
	 * 
	 * @param mongoStepConfig - MongoDBReader Step config from where DB connection information will be fetched
	 * @param recordHolder - Map that holds Source wise Summary objects based on the Grouping key
	 * @param sourceName - The name of the Source the Document is holding
	 * @param stepName - The name of the Step the document record is representing
	 * @param activityName - The name of the activity
	 */
	private void getAggregatedResults(MongoDBReaderConfig mongoStepConfig, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String sourceName, String stepName, String activityName) {
		try{
			IDataSource dataSource = dataSourceFactory.getDataSource(mongoStepConfig.getSourceDefinition().getDataSourceName());
			logger.debug("Getting the database information");
			MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
			MongoDatabase database = mongoDataSource.getDatabase();
			logger.debug("database name : {}", database.getName());
			MongoCollection<Document> collection = database.getCollection(mongoStepConfig.getSourceDefinition().getCollectionName());
			logger.debug("Collection name found, record in the collection  : {}", Long.valueOf(collection.count()));

			logger.debug("Aggregation started......");
			List<Document> andConditions = new ArrayList<>();
			andConditions.add(new Document("reconControlFields", new Document("$exists", Boolean.TRUE)));
			andConditions.add(new Document(new StringBuilder("reconControlFields").append(".").append(activityName).toString(), new Document("$exists", Boolean.TRUE)));
			Document match = new Document("$match", new Document("$and", andConditions));

			Document idDocument = new Document(ACTIVITY_NAME, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(ACTIVITY_NAME).toString());
			idDocument.append(PROCESSING_DATE, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(PROCESSING_DATE).toString());
			idDocument.append(STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(STATUS).toString());
			idDocument.append(SUB_STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(SUB_STATUS).toString());
			Document totalAmount = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("amount").toString());
			Document totalVariance = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("tolerance").toString());
			Document count = new Document("$sum", Long.valueOf(1));
			Document group = new Document("$group", new Document("_id", idDocument).append("totalAmount", totalAmount).append("totalVariance", totalVariance).append("count", count));

			List<Bson> aggregationQuery = new ArrayList<>();
			aggregationQuery.add(match);
			aggregationQuery.add(group);
			AggregateIterable<Document> result = collection.aggregate(aggregationQuery);
			result.forEach((Block<? super Document>) (Document document) -> decorateSummaryRecordHolder(document, recordHolder, sourceName, stepName));
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * Method that decorates the Recon Summary object to save it as DB document
	 * 
	 * @param document - Document result fetched from DB
	 * @param recordHolder - Map that holds Source wise Summary objects based on the Grouping key
	 * @param sourceName - The name of the Source the Document is holding
	 * @param stepName - The name of the Step the document record is representing
	 */
	private void decorateSummaryRecordHolder(Document document, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String sourceName, String stepName) {
		if (null == document){
			logger.debug("Result rowset is null");
			return;
		}
		logger.debug("Processing result rowset : {}", document.toJson());
		try{
			Document key = (Document) document.get("_id");
			SummaryKey summaryKey = SummaryKey.builder().activityName(key.getString(ACTIVITY_NAME)).processingDate(key.getDate(PROCESSING_DATE)).status(ReconStatus.valueOf(key.getString(STATUS))).subStatus(ReconSubStatus.valueOf(key.getString(SUB_STATUS))).build();

			ReconSourceSummary reconSourceSummary = ReconSourceSummary.builder().sourceName(sourceName).stepName(stepName).totalAmount(document.getDouble("totalAmount")).totalVarianceAmnt(document.getDouble("totalVariance")).recordCount(document.getLong("count")).build();
			if (!recordHolder.containsKey(summaryKey)){
				recordHolder.put(summaryKey, new ArrayList<ReconSourceSummary>());
			}
			recordHolder.get(summaryKey).add(reconSourceSummary);
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}


	/**
	 * Method that sets Source A & Source B property for the Summary Object that needs to be saved in the DB
	 * 
	 * @param recordHolder - Map that holds Source wise Summary objects based on the Grouping key
	 * @param activityType - The type of the activity
	 * @param projectName - The name of the project
	 */
	private void saveAcitivitySummary(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, SourceMappingType activityType, String projectName) {

		try{
			List<ReconAcitivitySummary> entites = new ArrayList<>();
			logger.debug("Saving Activity Summaries");
			for (Entry<SummaryKey, List<ReconSourceSummary>> entry : recordHolder.entrySet()){
				SummaryKey summaryKey = entry.getKey();
				ReconAcitivitySummary acitivitySummary = ReconAcitivitySummary.builder().activityName(summaryKey.getActivityName()).processingDate(summaryKey.getProcessingDate()).status(summaryKey.getStatus()).subStatus(summaryKey.getSubStatus()).activityType(activityType).projectName(projectName).build();
				entry.getValue().forEach(rec -> {
					switch (rec.getStepName()) {
					case ("Source-A"):
						acitivitySummary.setSourceASummary(rec);
						break;
					case ("Source-B"):
						acitivitySummary.setSourceBSummary(rec);
						break;
					default:
						logger.error("Neither Source A nor Source B found in record");
						break;
					}
				});
				entites.add(populateActivitySummary(acitivitySummary));
			}
			logger.debug("Activity Summaries record count to be saved - {}", Integer.valueOf(entites.size()));
			acitivitySummaryRepository.saveAll(entites);
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/**
	 * Method that checks if the record present in DB. If yes, update it!
	 * 
	 * @param acitivitySummary - Populated Activated Summary Object
	 * @return ReconAcitivitySummary - Final ReconAcitivitySummary Object that needs to be saved in DB
	 */
	private ReconAcitivitySummary populateActivitySummary(ReconAcitivitySummary acitivitySummary) {
		try{
			ReconAcitivitySummary dbAcitivitySummary = acitivitySummaryRepository.findAcitivitySummary(acitivitySummary.getActivityName(), acitivitySummary.getProjectName(), acitivitySummary.getProcessingDate(), acitivitySummary.getStatus(), acitivitySummary.getSubStatus());
			if (dbAcitivitySummary != null){
				acitivitySummary.setId(dbAcitivitySummary.getId());
			}
			return acitivitySummary;
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}
}
