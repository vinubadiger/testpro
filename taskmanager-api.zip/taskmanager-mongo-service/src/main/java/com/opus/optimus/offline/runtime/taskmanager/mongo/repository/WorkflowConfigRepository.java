package com.opus.optimus.offline.runtime.taskmanager.mongo.repository;

import com.opus.optimus.offline.runtime.taskmanager.mongo.IPublishedWorkflowConfigService;
import com.opus.optimus.offline.runtime.workflow.api.IWorkflowConfigRepository;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig;

public class WorkflowConfigRepository implements IWorkflowConfigRepository {
    IPublishedWorkflowConfigService publishedWorkflowConfigRepository;
    String groupId;
    String DEFAULT_FALLBACK_GROUP_ID = "000000000000000000000000";

    public WorkflowConfigRepository(String groupId, IPublishedWorkflowConfigService publishedWorkflowConfigRepository) {
		super();
		this.groupId = groupId;
		this.publishedWorkflowConfigRepository = publishedWorkflowConfigRepository;
	}

    @Override
    public WorkflowConfig getConfig(String workflowName) {
    	WorkflowConfig workflowConfig = publishedWorkflowConfigRepository.findWCByGroupIdAndWorkflowId(groupId, workflowName);
		return (workflowConfig == null)
				? publishedWorkflowConfigRepository.findWCByGroupIdAndWorkflowId(DEFAULT_FALLBACK_GROUP_ID,
						workflowName)
				: workflowConfig;
    }

    @Override
    public WorkflowExecutionConfig getExecutionConfig(String jobTaskId, String workflowName) {
        return publishedWorkflowConfigRepository.findWECByGroupIdAndWorkflowId(groupId, workflowName);
    }
}
