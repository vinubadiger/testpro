package com.opus.optimus.offline.runtime.taskmanager.nirmata;

import com.nirmata.workflow.WorkflowManager;
import com.nirmata.workflow.WorkflowManagerBuilder;
import com.nirmata.workflow.models.TaskType;
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskExecutorFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskReceiver;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.CloseableUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NirmataTaskReceiver implements ITaskReceiver {

    @Value("${taskManager.zooKeeper.connectionString:localhost:2181}")
    String zkConnectionString;

    @Value("${taskManager.zooKeeper.namespace:TaskManager}")
    String namespace;

    @Value("${taskManager.zooKeeper.namespaceVersion:1}")
    String version;

    @Value("${taskManager.zooKeeper.retryPolicy.baseSleepTimeMs:100}")
    int baseSleepTimeMs;

    @Value("${taskManager.zooKeeper.retryPolicy.maxRetries:3}")
    int maxRetries;

    @Autowired
    ITaskExecutorFactory taskExecutorFactory;

    @Autowired
    MapperFactory mapperFactory;

    CuratorFramework curator;
    WorkflowManager workflowManager;

    public void start() {
        curator = CuratorFrameworkFactory.builder()
                .connectString(zkConnectionString)
                .retryPolicy(new ExponentialBackoffRetry(baseSleepTimeMs, maxRetries))
                .build();

        curator.start();

        TaskType taskType = new TaskType(NirmataTaskManager.TASK_TYPE, NirmataTaskManager.TASK_TYPE_VERSION, true);

        workflowManager = WorkflowManagerBuilder.builder()
                .addingTaskExecutor(new NirmataTaskExecutor(taskExecutorFactory, mapperFactory), 1, taskType)
                .withCurator(curator, namespace, version)
                .build();

        workflowManager.start();
    }

    public void stop() {
        CloseableUtils.closeQuietly(workflowManager);
        CloseableUtils.closeQuietly(curator);
    }
}
