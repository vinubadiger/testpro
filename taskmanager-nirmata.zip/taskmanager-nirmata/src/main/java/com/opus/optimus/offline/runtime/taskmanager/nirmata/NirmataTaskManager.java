package com.opus.optimus.offline.runtime.taskmanager.nirmata;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.CloseableUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nirmata.workflow.WorkflowManager;
import com.nirmata.workflow.WorkflowManagerBuilder;
import com.nirmata.workflow.events.WorkflowEvent;
import com.nirmata.workflow.events.WorkflowListener;
import com.nirmata.workflow.events.WorkflowListenerManager;
import com.nirmata.workflow.models.RunId;
import com.nirmata.workflow.models.Task;
import com.nirmata.workflow.models.TaskId;
import com.nirmata.workflow.models.TaskType;
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManager;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

@Component
public class NirmataTaskManager implements IRawTaskManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(NirmataTaskManager.class);

	public static final String EXECUTION_INFO = "EXECUTION_INFO";

	public static final String TASK_ID = "TASK_ID";

	public static final String TASK_TYPE = "JobTask";

	public static final String TASK_TYPE_VERSION = "1";

	public static final TaskType JOB_TASK_TYPE = new TaskType(TASK_TYPE, TASK_TYPE_VERSION, true);

	@Value ("${taskManager.zooKeeper.connectionString:localhost:2181}")
	String zkConnectionString;

	@Value ("${taskManager.zooKeeper.namespace:TaskManager}")
	String namespace;

	@Value ("${taskManager.zooKeeper.namespaceVersion:1}")
	String version;

	@Value ("${taskManager.zooKeeper.retryPolicy.baseSleepTimeMs:100}")
	int baseSleepTimeMs;

	@Value ("${taskManager.zooKeeper.retryPolicy.maxRetries:3}")
	int maxRetries;

	@Autowired
	MapperFactory mapperFactory;

	CuratorFramework curator;

	WorkflowManager workflowManager;

	WorkflowListenerManager workflowListenerManager;

	Map<String, CompletableFuture<Void>> jobIdCompletableFutures = new ConcurrentHashMap<>();

	private List<IRawTaskManagerListener> listeners = new ArrayList<>();

	public void start() {
		try{
			LOGGER.info("Starting Curator instance with Zookeeper {}", zkConnectionString);
			curator = CuratorFrameworkFactory.builder().connectString(zkConnectionString).retryPolicy(new ExponentialBackoffRetry(baseSleepTimeMs, maxRetries)).build();

			curator.start();

			LOGGER.info("Initiating WorkflowManager with curator: {}, namespace: {}, version: {}", curator, namespace, version);
			workflowManager = WorkflowManagerBuilder.builder().withCurator(curator, namespace, version).build();

			workflowListenerManager = workflowManager.newWorkflowListenerManager();
			WorkflowListener workflowListener = event -> {
				if (event.getType() == WorkflowEvent.EventType.TASK_STARTED){
					listeners.stream().forEach(listener -> listener.onTaskStart(event.getRunId().getId(), event.getTaskId().get().getId()));
				} else if (event.getType() == WorkflowEvent.EventType.TASK_COMPLETED){
					listeners.stream().forEach(listener -> listener.onTaskComplete(event.getRunId().getId(), event.getTaskId().get().getId()));
				} else if (event.getType() == WorkflowEvent.EventType.RUN_STARTED){
					listeners.stream().forEach(listener -> listener.onJobStart(event.getRunId().getId()));
				} else if (event.getType() == WorkflowEvent.EventType.RUN_UPDATED){
					listeners.stream().forEach(listener -> listener.onJobComplete(event.getRunId().getId()));
				}

				if (event.getType() == WorkflowEvent.EventType.RUN_UPDATED){
					CompletableFuture<Void> result = jobIdCompletableFutures.remove(event.getRunId().getId());
					if (result != null){
						result.complete(null);
					}
				}
			};
			workflowListenerManager.getListenable().addListener(workflowListener);

			workflowManager.start();
			workflowListenerManager.start();
			LOGGER.info("WorkflowManager & WorkflowListenerManager started");
		} catch (Exception e){
			LOGGER.error(e.getMessage(), e);
			throw e;
		}
	}

	public void stop() {
		CloseableUtils.closeQuietly(workflowListenerManager);
		CloseableUtils.closeQuietly(workflowManager);
		CloseableUtils.closeQuietly(curator);
	}

	@Override
	public String generateJobId() {
		return generateId();
	}

	@Override
	public CompletableFuture<Void> submitJob(String jobId, List<JobTask> jobTasks) {
		try{
			List<Task> vendorTasks = jobTasks.stream().map(jobTask -> createVendorTask(jobTask, JOB_TASK_TYPE)).collect(Collectors.toList());

			Task parentTask = new Task(new TaskId(), vendorTasks);
			LOGGER.info("Submitting Job to WorkflowManager {} with JobID {} ", workflowManager, jobId);
			RunId runId = workflowManager.submitTask(new RunId(jobId), parentTask);

			CompletableFuture<Void> result = new CompletableFuture<>();
			jobIdCompletableFutures.put(runId.getId(), result);

			return result;
		} catch (Exception e){
			LOGGER.error(e.getMessage(), e);
			throw e;
		}
	}

	private Task createVendorTask(JobTask jobTask, TaskType taskType) {
		try{
			String serializedData = mapperFactory.getMapper().writeValueAsString(jobTask.getExecutionInfo());
			Map<String, String> metaData = new HashMap<>();
			metaData.put(TASK_ID, jobTask.getTaskId());
			metaData.put(EXECUTION_INFO, serializedData);
			return new Task(new TaskId(jobTask.getTaskId()), taskType, new ArrayList<>(), metaData);
		} catch (JsonProcessingException e){
			LOGGER.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	private String generateId() {
		return UUID.randomUUID().toString();
	}

	@Override
	public void cancelJob(String jobId) {
		workflowManager.cancelRun(new RunId(jobId));
	}

	@Override
	public void addListener(IRawTaskManagerListener listener) {
		listeners.add(listener);
	}

	@Override
	public void removeListener(IRawTaskManagerListener listener) {
		listeners.remove(listener);
	}
}
